#!/bin/bash
# Episode 0 music test: hook (v5 139.433-149.600 s) -> blue title + sting -> full v5 -> blue thank-you + outro.
set -e
S=/private/tmp/claude-501/-Users-je-jtan/236b7143-fb33-410a-a313-6748d5ce4b28/scratchpad/e0; M=/Users/je/oood/03_ASSETS/music; V5=../../release/episode-00-review-v5.mp4
ffmpeg -nostdin -v error -y \
 -ss 139 -i "$V5" -i "$V5" -i "$S/title.mp4" -i "$S/outro.mp4" -i "$M/oood-sting-5s.wav" -i "$M/oood-outro-11s.wav" \
 -filter_complex "\
[0:v]trim=start=0.4333:end=10.6,setpts=PTS-STARTPTS,format=yuv420p,setsar=1[hv];\
[0:a]atrim=start=0.4333:end=10.6,asetpts=PTS-STARTPTS,afade=t=in:d=0.02,afade=t=out:st=10.1167:d=0.05,aresample=48000,aformat=channel_layouts=stereo[ha];\
[2:v]format=yuv420p,setsar=1[tv];[4:a]volume=-1.6dB,aresample=48000,aformat=channel_layouts=stereo[ta];\
[1:v]format=yuv420p,setsar=1[bv];[1:a]aresample=48000,aformat=channel_layouts=stereo[ba];\
[3:v]format=yuv420p,setsar=1[ov];[5:a]volume=-3.3dB,aresample=48000,aformat=channel_layouts=stereo[oa];\
[hv][ha][tv][ta][bv][ba][ov][oa]concat=n=4:v=1:a=1[v][a]" \
 -map "[v]" -map "[a]" -c:v libx264 -preset medium -crf 18 -profile:v high -pix_fmt yuv420p -r 30 \
 -color_primaries bt709 -color_trc bt709 -colorspace bt709 -c:a aac -b:a 256k -map_chapters -1 -map_metadata -1 -movflags +faststart episode-00-music-test.mp4
