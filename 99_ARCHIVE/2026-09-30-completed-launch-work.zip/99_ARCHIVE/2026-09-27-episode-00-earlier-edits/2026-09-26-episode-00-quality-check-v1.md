# Episode 0 v1 quality and release status

Checked 2026-09-26. **Complete 4:39.300 export, technically checked, ready for host review.** Approval, scheduling and publication are not recorded. This report applies to the exact video hash below.

## Deliverable checks

| Check | Result |
|---|---|
| Video | 1920 × 1080, H.264 High, yuv420p, BT.709, constant 30fps |
| Duration / frames | 279.300 seconds; exactly 8,379 expected video frames |
| Audio | Stereo AAC, 48kHz, approximately 256kbps; separate 24-bit WAV and 192kbps MP3 |
| Full decode | Complete video/audio decode passed |
| Encoded video loudness | -16.44 LUFS integrated; -1.22 dBTP; 4.70 LU loudness range |
| Encoded MP3 loudness | -17.07 LUFS; -1.55 dBTP; separate 0.4dB encoding headroom applied |
| Timing | Audio and video both 279.300 seconds; strictly increasing packet decode timestamps; largest picture presentation interval 0.033334 seconds; largest audio interval 0.021334 seconds |
| AAC leading packet | -0.021333-second priming packet is expected codec delay; container playback begins at zero |
| Black detection | No flagged black spans at the helper's threshold; brief intentional final fade |
| Silence detection | One span, 03:39.171-03:40.794, between caffeine comments and the next response; retained conversational pause, not missing media |
| Chapters | Six embedded chapter boundaries match the edit list; exact timings in chapter document |
| Captions | 97 final-timeline cues; SRT and VTT; ordered, non-overlapping, within duration; at most two lines and 42 characters per line |
| Thumbnail | 1280 × 720 JPEG; three words; Teachers 800; cream/foam waterline at 59%; blue square two-line tile at 11% width; inspected full-size and at 210px |
| On-screen graphic | Opening lower third, 00:08-00:14. Left-to-right 300ms wipe sampled across its reveal; no face obstruction in inspected frames |
| Source preservation | SHA-256 unchanged before/after processing |

The four source audio tracks have identical packet hashes. Only the first mix was used, avoiding duplicate summation. Processing: 65Hz rumble filter, restrained dynamic leveling with gain cap, short cut-edge ramps, then two-pass normalization to a working target of -16 LUFS/-1.5 dBTP. The encoded master is below the -1 dBTP house ceiling. No synthetic voices or music added. Measurements do not establish perceived host balance or remove source room acoustics.

## What was reviewed

- Full original and final machine transcripts read, with source-assisted wording corrections.
- Original picture contact sheet spanning the 11-minute recording.
- Source frames around the Elon/Musk exchange and closing.
- Three sampled pictures at every final edit boundary, including the final farewell cut.
- Lower-third reveal frames and full-size/small thumbnail exports.
- Targeted source retranscriptions to refine the biography, mission, promise, joke ending, caffeine opening and closing boundaries.
- Full automated decode, frame count, stream duration, packet timing, encoded loudness/peak and black/silence checks.

**Not performed:** continuous audiovisual viewing, perceptual before/after audio listening, or a lip-sync sign-off. No tool in this session provided continuous audiovisual perception. Transcript and still-frame analysis are not described as having watched the whole episode. Do not infer original camera sync from equal container durations.

## Final host watch-through

Watch this exact 4:39.300 version with sound and captions. Confirm pacing, naturalness at the cuts, the relative voice levels, and lip-sync at the beginning, middle and end. Confirm the personal facts and that both hosts like how they are represented.

Caption spelling and structure were corrected, but an auditory proofread is still needed. Pay particular attention to:

- **01:54-01:58:** the shirt aside, rendered as "You're repping. Good product placement."
- **02:15-02:18:** "So excited to go on this journey."
- **02:46-02:55:** the Elon/Musk exchange and overlap.
- **04:35-04:39:** the short closing join and farewell timing.

These are source-assisted interpretations, not claimed listening verification. The correction log records every text change. Any correction should be made in the caption source and re-exported; the picture master need not be rerendered for text-only changes.

The unsupported adoption statistic and categorical jobs/nonprofit claims were removed. The website/email plug was also removed because the hosts say it is not yet built. The retained content is predominantly personal experience, opinion and intentions; see the source register for corroboration and limits. No theme music rights need resolving for this dialogue-only version.

The [episode-producer skill](../../../skills/oood-episode-producer/SKILL.md) requires "actual host approval" before calling an export ready to publish. This complete package awaits that final review; creating it does not authorize publication.

## Integrity

- Source SHA-256: `428bd4c2979482c540e585cddec6f4e336783284b9b1e602c5b2a78acedba15b`
- Video SHA-256: `b34c416a4040a3ac6a7ba77d3718afd64f35744e7c553141ab49dbcf64ff46b2`
- Machine evidence: `episode-00-source-inventory-v1.json`, `episode-00-technical-qc-v1.json`, `episode-00-packet-check-v1.json`.
- Edit reproduction: `produce-episode.py` plus frame EDL. Its segment cache is for restarting this exact v1; remove cached segment files when changing source positions or rendering parameters, and version outputs before a later revision.
