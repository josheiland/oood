# Episode 0 edit log v2

Proposed, fuller introduction for host review. The 4:39.300 v1 remains available for comparison. V2 is **7:14.033** and shorter than the planned main episodes. Raw source is unchanged. Frames are half-open at 30fps.

| Section | Source in | Source out | Output in | Output out | Purpose |
|---|---|---|---|---|---|
| 01 | 00:00.000 | 01:03.000 | 00:00.000 | 01:03.000 | Keep the spontaneous opening, newlywed setup and learning joke. |
| 02 | 03:36.800 | 04:20.667 | 01:03.000 | 01:46.867 | Keep names, nickname banter, hometowns, shared history and individual interests. |
| 03 | 04:20.667 | 04:42.367 | 01:46.867 | 02:08.567 | Give Mary room to explain her healthcare interest and their newlywed life. |
| 04 | 04:53.500 | 05:30.800 | 02:08.567 | 02:45.867 | Keep the Run Your City context, shirt aside and broader learning purpose. |
| 05 | 01:59.700 | 02:44.667 | 02:45.867 | 03:30.833 | Keep the accessible-show ambition and the Elon/Musk setup and correction. |
| 06 | 02:56.267 | 03:18.800 | 03:30.833 | 03:53.367 | Keep the practical audience promise and full response. |
| 07 | 06:41.667 | 07:29.033 | 03:53.367 | 04:40.733 | Let the hosts consider valid criticisms and learning as a way to assess them. |
| 08 | 07:35.033 | 07:56.667 | 04:40.733 | 05:02.367 | Keep Mary’s creative direction and the Call Her Daddy contrast. |
| 09 | 08:01.600 | 08:20.900 | 05:02.367 | 05:21.667 | Keep the caffeine and puppy-fostering exchange. |
| 10 | 08:37.767 | 08:53.100 | 05:21.667 | 05:37.000 | Begin the real honeymoon photo story, including Josh’s admission about happy hour. |
| 11 | 09:03.867 | 09:41.767 | 05:37.000 | 06:14.900 | Keep the imagined future holiday photos and Mary’s mixed reaction; omit specific family-planning wishes. |
| 12 | 09:41.767 | 09:52.567 | 06:14.900 | 06:25.700 | Keep the too-generous AI-image punchline; end before the extended hypothetical-children riff. |
| 13 | 05:50.500 | 06:17.400 | 06:25.700 | 06:52.600 | Keep the flexible news/deep-dive plan. |
| 14 | 10:21.800 | 10:25.233 | 06:52.600 | 06:56.033 | Keep invitation; remove the unready website and email address. |
| 15 | 10:39.400 | 10:54.800 | 06:56.033 | 07:11.433 | Preview upcoming episodes and invite fun. |
| 16 | 10:56.400 | 10:59.000 | 07:11.433 | 07:14.033 | Keep farewell, removing the unclear interjection and post-take discussion. |

## Why this version is longer

V1 moved quickly from credentials to show format. The added material gives Mary room to explain her interest in healthcare and how being newly married shapes the learning journey. The skeptical exchange shows that the hosts can be excited about AI while taking concerns seriously. The honeymoon story supplies a specific example of Josh trying a tool, Mary reacting to the result, and both joking about where the tool took it. These moments show their relationship rather than merely describing it.

The story edit removes the specific desired number and sex of future children. The jump from uploading the photos to the generated holiday series preserves the sequence of the real experiment without changing who did it or how Mary reacted. The extended hypothetical-children riff after the "too generous" payoff remains in the raw but is cut because the payoff has landed. Whether this personal anecdote belongs in the public launch still needs both hosts' approval.

V2 still removes the unsupported numerical adoption comparison, broad nonprofit adoption claim, unready website/email address, planning chatter and post-take discussion. The jobs and environmental lines in the retained skeptical exchange are presented as the hosts' concerns and predictions; the source register makes that distinction explicit.

## V1 to V2 comparison

- V1: 4:39.300; compact identity and format introduction.
- V2: 7:14.033; adds 2:34.733 of relationship, nuance, and an actual AI experiment.
- Suggested review: Watch v2 first, then use v1 only to judge whether any section drags. V2 is the recommended editorial direction for the stated goal of helping viewers like the hosts together.

## Visual treatment

The same clean two-host camera frame and one early branded lower third. No stock footage or fabricated AI images. No graphic claims to show the private generated family photos. The existing thumbnail stays grounded in the source picture. No unapproved music.
