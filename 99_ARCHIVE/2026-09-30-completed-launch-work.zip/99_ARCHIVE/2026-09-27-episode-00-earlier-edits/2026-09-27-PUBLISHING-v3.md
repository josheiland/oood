# Episode 0 release package, near-complete cut

Prepared 2026-09-27 for the **11:02.400** v3 review export. Josh watched the raw recording and prefers the whole conversation, with only the post-wrap exchange removed. This package follows that choice. It is a draft until factual, contact-channel, caption and host checks are complete; no upload, scheduling or publication is claimed.

## Title and thumbnail

Recommended: **Meet Josh and Mary | Out of Our Depth, Episode 0**

Other directions: **Why we're learning AI out loud | Episode 0**; **Out of Our Depth starts here**.

Thumbnail: `edit/episode-00-thumbnail-v3.jpg`, 1280 × 720, authentic source frame, Teachers and the adopted blue/cream kit. Copy: **MEET THE HOSTS**. The thumbnail does not depict the private AI-generated family images.

## Description / show notes

**Try this:** Tell us one everyday AI question or experiment you'd want us to explore.

We're Josh and Mary. We're newly married, back at Stanford Business School, and running Run Your City together. We started Out of Our Depth because AI is changing quickly and we want to learn what matters, test what is useful, and make the process more fun to follow.

This first conversation is a chance to get to know us. We talk about our backgrounds, the nonprofit, why we want to learn out loud, and the kind of show we're hoping to make. Along the way there are puppies, an Elon/Musk mix-up, and a honeymoon experiment where Josh used AI to imagine family holiday photos. We leave the detours in because they are part of who we are together.

Our plan is to try a mix of AI news and deeper dives into tools and ideas. We'll see what works and let the format evolve.

| Time | Chapter |
|---|---|
| 00:00 | Opening: why we are here |
| 01:03 | Why learn AI together |
| 01:57 | Make it fun and accessible |
| 03:34 | Meet Josh and Mary |
| 04:50 | Run Your City and the show |
| 05:49 | What to expect |
| 06:37 | Curious and skeptical |
| 07:54 | Fun facts |
| 08:36 | The honeymoon AI experiment |
| 10:17 | Closing invitation |

Learn about [Run Your City](https://www.runyourcity.org/). The AI family pictures are described, not shown; they are imagined images, not depictions of real future people.

## Platform copy drafts

### LinkedIn

We started recording a quick hello and ended up sharing why we're learning AI together, what we're curious about, and a very strange experiment from our honeymoon.

We're Josh and Mary. We're newlyweds, Stanford business students, and nonprofit operators. Out of Our Depth is our way of making sense of AI in public and making it a little more fun to learn along the way.

Episode 0 is the unhurried introduction to who we are and the conversations we want to have. What would you want us to try or explain? [Add verified episode link only after publication.]

### Instagram

We kept the detours in our first episode. That's where you actually meet us.
We're Josh and Mary, learning AI out loud and figuring out this show together.
What should we try next?

### X

Episode 0 is our hello: who we are, why we're learning AI together, and a honeymoon experiment that got a little weird. What should we try next? [Add verified episode link after publication.]

## Clip candidates

The v3 output matches source timing because it is one continuous segment. No clips have been rendered or approved for posting.

| Rank | Source / v3 range | Setup and payoff | Edit note |
|---|---|---|---|
| 1 | 08:37–10:18 | Honeymoon AI-photo experiment and both hosts' mixed, affectionate reaction. | Include setup and Mary's response. Confirm comfort with the full personal story; do not insert private generated pictures. |
| 2 | 02:15–02:40 | The hosts want the AI conversation to be fun, then correct the Elon/Musk mix-up. | Keep the correction and laugh; do not turn the mistake into a false quote. |
| 3 | 06:41–07:35 | Mary raises skepticism and Josh argues that learning helps people critique AI better. | Keep the environmental/jobs caveat and both voices. |

## Upload files and release checks

- Video: `edit/episode-00-master-v3.mp4`, 1920 × 1080, 30fps, H.264/AAC, 11:02.400.
- Audio: `edit/episode-00-audio-master-v3.wav`, `edit/episode-00-audio-v3.mp3`.
- Captions: `edit/episode-00-captions-v3.srt` and `.vtt`, aligned to the exact cut but pending listening proofread.
- Thumbnail: `edit/episode-00-thumbnail-v3.jpg`.
- Editorial record: `edit/episode-00-edit-decisions-v3.json`, `edit/episode-00-edit-notes-v3.md` and `edit/episode-00-quality-check-v3.md`.
- Source/claim register: `02_RESEARCH/episode-00-source-checks-2026-09-26.md`.

Before publication, confirm that the spoken “20% behind” line means the approximate *relative usage* gap supported by the cited 2026 working paper, or record a correction. Verify the website and email invitation, proofread captions against audio, and have both hosts approve this exact cut and personal story. The claim register distinguishes their opinions from checked facts. No music or outside footage was added.
