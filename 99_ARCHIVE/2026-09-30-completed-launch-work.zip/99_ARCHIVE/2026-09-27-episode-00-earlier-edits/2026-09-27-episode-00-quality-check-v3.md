# Episode 0 v3 quality and release status

Checked 2026-09-27. **Near-complete 11:02.400 export, technically checked, ready for host review.** Josh watched the raw source and prefers the full conversation except for the post-wrap tail. That establishes the editorial direction, not exact-export approval. The current cut retains every source frame from 00:00.000 through 11:02.367 and ends after “Peace.” The raw source and earlier proposals are unchanged.

## Technical checks

| Check | Result |
|---|---|
| Video | 1920 × 1080, H.264 High, yuv420p, BT.709, constant 30fps |
| Duration / frames | 662.400 seconds, exactly 19,872 video frames; video and AAC durations agree |
| Audio | Stereo AAC, 48kHz, approximately 256kbps; separate 24-bit WAV and 192kbps MP3 |
| Full decode | Complete video/audio decode passed |
| Encoded video loudness | -16.86 LUFS integrated; -1.51 dBTP; 5.20 LU loudness range |
| WAV / MP3 loudness | WAV -16.43 LUFS / -1.37 dBTP; MP3 -17.09 LUFS / -1.06 dBTP |
| Packet timing | Strictly increasing decode timestamps; largest picture presentation interval 0.033334 seconds, largest audio interval 0.021334 seconds |
| AAC priming | The leading -0.021333-second packet is expected AAC encoder delay; container playback starts at zero |
| Black / silence detection | No flagged spans at the QC helper thresholds |
| Chapters | Ten embedded chapters, matching the chapter document and ending at 11:02.400 |
| Captions | 216 SRT/VTT cues in order, non-overlapping, within the exact runtime; at most two lines and 42 characters per line |
| Thumbnail | 1280 × 720 JPEG, authentic source frame, Teachers blue/cream treatment; visually inspected |
| Source preservation | Raw SHA-256 matches the prior inventory after production |

The source's four audio streams are identical mixes, so only stream 1 was used. Dialogue was normalized, and the AAC/MP3 encodes have headroom below the -1 dBTP house ceiling. The source picture was re-encoded once for an exact 30fps end frame; there is no content splice, overlay, music, generated voice, private generated picture or third-party footage. The full-file decode and sampled exported frames at 00:05, 03:35, 08:36 and 11:01 show no obvious picture issue. A source frame at 11:02.3 was also inspected to confirm the selected visual endpoint.

## Human and factual review still needed

The full source machine transcript was read, and source-assisted corrections were applied to the draft captions. **Continuous audiovisual viewing, perceptual audio comparison, lip-sync sign-off, and an auditory caption proofread were not performed in this tool session.** Josh's raw-footage watch-through does not prove this exact processed export's sound and captions. Both hosts should watch this version with captions, especially the final sign-off at 11:00–11:02 and the personal family-photo story at 08:37–10:18.

The intentionally retained 01:36–01:45 “20% behind” gender-adoption line has close, qualified support: a 2026 HBS working paper estimates a 22% pooled *relative usage* gap, narrowing to roughly 16% in recent periods. It does not establish a universal 20-percentage-point gap or measure “truly adopting” as effective use. Confirm that approximate relative usage was the host's intended meaning; otherwise record a spoken correction/pickup. The nonprofit adoption comparison at 01:45–01:56 is unsupported as a general measurement; treat it as the hosts' experience or qualify it in speech. Verify that the website and spoken email at 10:22–10:39 work before making this the public master. Mary should confirm that the complete future-family details and joking are comfortable to share. These are specific release checks, not a reason to reduce the whole episode to five or seven minutes. The exact source and limits are in the source register.

The [episode-producer skill](../../../skills/oood-episode-producer/SKILL.md) requires actual host approval of this exact version before calling it ready to publish. No upload, schedule or publication is recorded.

## Integrity

- Raw source SHA-256: `428bd4c2979482c540e585cddec6f4e336783284b9b1e602c5b2a78acedba15b`
- Video SHA-256: `3a4c1aabe8d35b0dbf029fc866ee6ac8efb1a94fbefd4b2e06fba2b01bc0c7c6`
- WAV SHA-256: `84dc0938e55c71232c819349376536baba47d8e954d4b0e9ec3267d3ec53eb36`
- MP3 SHA-256: `1e9cf141956c7068eeda8f04102c882f207c3482129d710496f9edd04fee1d50`
- Machine evidence: `episode-00-technical-qc-v3.json`, `episode-00-packet-check-v3.json`, `episode-00-wav-qc-v3.json`, `episode-00-mp3-qc-v3.json`.
- Edit reproduction: `produce-episode-v3.py`, `episode-00-edit-decisions-v3.json` and the original source at the recorded path.
