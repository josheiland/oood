# Episode 0 v2 quality and release status

Checked 2026-09-26. **Complete 7:14.033 fuller export, technically checked, ready for host review.** This is the recommended editorial cut after Josh asked to retain more story and relationship. The 4:39.300 v1 remains for comparison. Host approval, scheduling, and publication are not recorded. This report applies to the exact v2 video hash below.

## Deliverable checks

| Check | Result |
|---|---|
| Video | 1920 × 1080, H.264 High, yuv420p, BT.709, constant 30fps |
| Duration / frames | 434.033333 seconds; exactly 13,021 expected frames |
| Audio | Stereo AAC, 48kHz, approximately 256kbps; separate 24-bit WAV and 192kbps MP3 |
| Full decode | Complete video/audio decode passed |
| Encoded video loudness | -16.50 LUFS integrated; -1.26 dBTP; 5.20 LU loudness range |
| Encoded MP3 loudness | -17.13 LUFS; -1.24 dBTP; separate 0.4dB encoding headroom applied |
| Timing | WAV and video both 434.033333 seconds; AAC reports 434.033000 seconds due to its millisecond time base. Both streams have strictly increasing packet decode timestamps; largest picture presentation interval 0.033334 seconds, largest audio interval 0.021334 seconds. |
| AAC leading packet | -0.021333-second priming packet is expected codec delay; container playback begins at zero |
| Black detection | No flagged black spans at the helper's threshold; brief intentional final fade |
| Silence detection | One 1.623-second span at 05:09.871–05:11.494 between the caffeine exchange and next response; retained conversational pause, not missing media |
| Chapters | Eight embedded boundaries match the frame edit list; exact starts in `episode-00-chapters-v2.md` |
| Captions | 133 final-timeline cues; SRT and VTT; ordered, non-overlapping, within duration; at most two lines and 42 characters per line |
| Thumbnail | 1280 × 720 JPEG, genuine source frame and supplied Teachers blue/cream brand treatment; same visual direction as v1 |
| On-screen graphic | Opening branded lower third, 00:08–00:14; no new claim graphics or third-party footage |
| Source preservation | Raw SHA-256 unchanged before and after processing |

The four raw audio tracks have identical packet hashes. The first mix was used once, avoiding duplicate summation. Dialogue processing uses a 65Hz rumble filter, restrained dynamic leveling, short cut-edge ramps and two-pass normalization. No synthetic voices, generated personal photos, or unapproved music were added.

## Review performed and remaining

The original and final machine transcripts were read and source-assisted wording corrections applied. Source and final still frames, including story joins, were sampled. The full export passed automated decode, frame-count, duration, packet-timing, encoded loudness/peak and black/silence checks. The final caption file was checked structurally against the exact runtime.

**Continuous audiovisual viewing, perceptual before/after listening, lip-sync sign-off, and an auditory caption proofread have not been performed in this tool session.** Transcript and sampled-frame work are not a substitute for that review. Josh and Mary should watch this exact master with captions and check the cut transitions, voice balance, lip-sync, and whether the honeymoon AI-photo anecdote feels right to share. In particular, verify caption wording at 01:47–02:09 (Mary's background), 03:53–04:41 (skepticism), 04:49–05:02 (creative direction), 05:21–06:25 (the photo story, including “groutfits”), and the closing at 07:10–07:14. The correction log records how new cues were prepared.

The specific wishes about future children, an unsupported numerical adoption comparison, and the unready website/email plug are excluded. The retained AI-jobs and environmental comments are attributed to the hosts as concerns and predictions, not asserted as established facts; the source register records that distinction. Release copy and personal-story framing are drafts until the hosts confirm them.

The [episode-producer skill](../../../skills/oood-episode-producer/SKILL.md) requires actual host approval of this exact version before it can be called ready to publish. A technically checked package does not imply that approval.

## Integrity

- Source SHA-256: `428bd4c2979482c540e585cddec6f4e336783284b9b1e602c5b2a78acedba15b`
- Video SHA-256: `7cc41b51c3f8e4c228ebd2872c73317be21f3a44e8696d5a515bd6f348430b01`
- WAV SHA-256: `2b619efe495f7fb4846d466af24e9a603784ad762f79c2d26bdc0603178ca1bc`
- MP3 SHA-256: `627c73312d50eced277a8646255d431485173ba4a17457bead50ef096030d2d0`
- Machine evidence: `episode-00-technical-qc-v2.json`, `episode-00-packet-check-v2.json`, `episode-00-mp3-qc-v2.json`.
- Edit reproduction: `produce-episode-v2.py` and frame EDL. Its cached segments belong to this exact cut; clear the cache when changing source positions or render parameters, and version future outputs.
