# Episode 0 edit log v1

Proposed edit; not host-approved. Source remains unchanged. Frames are half-open at 30fps. Final duration: **4:39.300**.

| Section | Source in | Source out | Output in | Output out | Reason |
|---|---|---|---|---|---|
| 01 | 00:00.000 | 01:03.000 | 00:00.000 | 01:03.000 | Keep the spontaneous opening, newlywed setup and selfish-learning joke. |
| 02 | 03:36.800 | 04:20.667 | 01:03.000 | 01:46.867 | Remove production planning; keep names, hometowns, shared history and both interests. |
| 03 | 04:53.500 | 05:30.800 | 01:46.867 | 02:24.167 | Keep Mary explaining Run Your City, the shirt aside, and the broader learning purpose. |
| 04 | 01:59.700 | 02:44.667 | 02:24.167 | 03:09.133 | Retain the full Elon/Musk setup and response; remove unsupported adoption/jobs claims before it. |
| 05 | 02:56.267 | 03:18.800 | 03:09.133 | 03:31.667 | Keep the practical audience promise and complete response without repeating the Stanford bubble setup. |
| 06 | 08:01.600 | 08:20.900 | 03:31.667 | 03:50.967 | Keep the caffeine exchange, mutual teasing and puppy-fostering fact; trim the initial wait. |
| 07 | 05:50.500 | 06:17.400 | 03:50.967 | 04:17.867 | Keep the flexible two-video plan: current developments and deeper topics. |
| 08 | 10:21.800 | 10:25.233 | 04:17.867 | 04:21.300 | Keep the invitation for viewer input; remove the unready website and email plug. |
| 09 | 10:39.400 | 10:54.800 | 04:21.300 | 04:36.700 | Keep the next-episode preview and invitation to have fun. |
| 10 | 10:56.400 | 10:59.000 | 04:36.700 | 04:39.300 | Keep the farewell; remove an unclear short interjection and post-take discussion. |

## Editorial review

The core introduction is strong when the hosts explain why they want to learn together and let each other interrupt. The Elon/Musk confusion and caffeine exchange give a stranger a sense of the relationship. Mary retains her own founding story and editorial point of view; Josh explains the audience promise and format.

The original meanders after the initial introduction. Removing the mid-take planning, repeated motivation, AI-critique tangent and long honeymoon-photo story gives the teaser one clear route. The honeymoon story is preserved in the original and may support a separate bonus after its own edit.

The gender-adoption statistic, nonprofit-adoption comparison and categorical jobs prediction are omitted because this short introduction does not need a sourced argument about adoption. No caption or overlay is used to contradict retained speech. The website/email plug is removed because the hosts explicitly say it has not been made.

Source ranges are reordered; no reaction shot is moved independently of its audio. Setup and correction stay together for the Elon/Musk exchange. The last short unclear interjection is omitted between the next-episode preview and farewell. Audio has short edge ramps and the final picture fades over 0.45 seconds.

## Graphics and captions

One lower third at output 00:08-00:14: JOSH + MARY / OUT OF OUR DEPTH, blue panel, Teachers, navy text; 300ms left-to-right wipe. No chapter slates interrupt this short conversation. Chapter metadata and written chapters provide navigation. No theme music or effects added. The clean picture master has caption sidecars rather than burned-in text.

## Review scope

The complete raw and final machine transcripts were read; the source picture was sampled across the recording; source joke and closing sequences were sampled; frames at all joins and the lower-third wipe were inspected. Short source passages were retranscribed to refine boundaries. This is not a claim of continuous audiovisual viewing or perceptual listening. See the final QC report for the remaining host review.
