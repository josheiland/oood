# Earlier Episode 0 proposals

Superseded by `01_EPISODES/E000-why-were-here/release/episode-00-review-v5.mp4` and `01_EPISODES/E000-why-were-here/PUBLISHING.md`. These notes record the shorter v1/v2 proposals and the unadorned v3 review, not current release files.
