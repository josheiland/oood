# Episode 0 release package

Prepared 2026-09-26. Draft copy for the complete v1 edit, 4:39.300. Awaiting host watch-through and approval; not scheduled or published.

## Recommended title

**Why we're here | Out of Our Depth, Episode 0**

Alternatives:

- Meet Josh and Mary | Out of Our Depth
- Learning AI out loud | Out of Our Depth, Episode 0

## Thumbnail

`edit/episode-00-thumbnail-v1.jpg`, 1280 × 720. Copy: **MEET THE HOSTS**. Authentic frame from source 02:25, Teachers 800, blue display type, a cream/foam waterline at 59%, and a square two-line OOOD tile. A paired-host photo sits beside the large type; the photograph is a direct source crop, not a generated cutout. No altered expressions.

Other directions, not rendered: **LEARNING OUT LOUD** in the kit's blue-flood announcement layout; **WE'RE DOING THIS** with an actual opening reaction frame.

## Description / show notes

Tell us one thing you want to understand about AI. We'll use your questions to help shape the show.

We're Josh and Mary. We just got married, we're at Stanford Business School, and we help run a nonprofit called Run Your City. We're also trying to keep up with AI.

Out of Our Depth is where we'll learn out loud, work out what's useful, and have some fun along the way. In this short introduction, we share who we are, why we're starting the show, and what you can expect. Including a little confusion about Elon's first and last name.

We're starting with a mix of AI news and deeper dives into tools and ideas. The format will evolve as we go.

00:00 Meet Josh and Mary
01:03 Our background
01:46 Why we're doing this
02:24 Make AI fun
03:31 Off the clock
03:50 What to expect

Learn about [Run Your City](https://www.runyourcity.org/).

## Social copy drafts

### LinkedIn

We help people learn about AI. We still mixed up Elon's first and last name while recording our intro.

We're starting Out of Our Depth to make learning AI useful and fun. We're Josh and Mary: newlyweds, Stanford MBA students, and nonprofit operators trying things as we go.

Episode 0 is a short introduction to us and why we're doing this. We'll start with AI news and deeper dives into tools and ideas, then see what helps people most.

What would you want us to try or explain? Watch: [insert verified episode link after publication].

### Instagram

Newly married. Learning AI out loud. We're Josh and Mary, and this is Out of Our Depth.
Episode 0 is a quick hello and a look at why we're starting the show.
What do you want us to try or explain?

### X

We're Josh and Mary. We just got married, we're trying to keep up with AI, and we're starting a podcast about it. Out of Our Depth begins with a short hello. What should we try or explain? [insert verified episode link]

## Ranked clip opportunities

No separate clips were requested or rendered. These are candidate ranges from the finished v1 timeline; retain setup and response when adapting them.

| Rank | Moment | Source range | Approximate v1 range | Hook / context |
|---|---|---|---|---|
| 1 | Elon and Musk | 02:11-02:34 | 02:35-02:59 | "We're clearly learning." Start with Mary explaining what she wants from AI coverage, then keep the first-name/last-name correction. Reframe to keep both hosts. |
| 2 | Caffeine / are we fun? | 08:06-08:17 | 03:36-03:47 | "One of us inhales caffeine." Keep Josh's response and the affectionate reversal. |
| 3 | Why start this? | 00:42-01:03 | 00:42-01:03 | Keep Josh's learning motivation and Mary's interruption together. |

The honeymoon AI-photo story at source 08:38-10:17 is a separate possible bonus, not part of v1. It needs its own edit and review before use.

## Upload package

- Video: `edit/episode-00-master-v1.mp4`, 1920 × 1080, 30fps, H.264/AAC.
- Audio: `edit/episode-00-audio-master-v1.wav` (48kHz, 24-bit stereo); `edit/episode-00-audio-v1.mp3` (192kbps stereo).
- Captions: `edit/episode-00-captions-v1.srt` and `.vtt`, timed to this exact export; review notes are in the QC report.
- Thumbnail: `edit/episode-00-thumbnail-v1.jpg`.
- Review details: `edit/episode-00-quality-check-v1.md`, edit decisions, chapter timings, and source register.

The spoken website/email plug was removed because the recording says it is not set up. No episode URL or live publication status is invented. Confirm the exact master, caption wording, personal details and upload copy during the host watch-through. Music is intentionally absent; an unresolved theme track does not prevent this dialogue-only version from being released after approval.
