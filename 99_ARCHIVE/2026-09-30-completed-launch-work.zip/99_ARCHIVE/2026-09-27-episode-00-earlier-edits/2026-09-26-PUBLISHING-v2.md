# Episode 0 release package, fuller cut

Prepared 2026-09-26. Draft package for the complete **7:14.033** v2 edit. This is the recommended version for review because it gives viewers time with Josh and Mary as a couple. Host approval, scheduling and publication are unconfirmed.

## Recommended title and thumbnail

**Why we're learning AI out loud | Out of Our Depth, Episode 0**

Thumbnail: `edit/episode-00-thumbnail-v2.jpg`, 1280 × 720, Teachers 800, three-word copy **MEET THE HOSTS**. The photo shows the real hosts in an unaltered frame from the source. It does not imply the imagined family pictures are shown in the episode.

Other title directions: **Meet Josh and Mary | Out of Our Depth**; **Why we're here | Episode 0**. The current thumbnail stays useful whichever title is chosen.

## Description / show notes

**Try this:** Think of one everyday question about AI you'd like us to test or explain. Tell us in the comments.

We're Josh and Mary. We just got married, we're at Stanford Business School, and we help run Run Your City. We're learning how to make sense of AI while everything around it keeps changing.

In this short introduction, we share where we come from, why we're starting Out of Our Depth, and what we hope to explore together. We also tell the story of an AI experiment from our honeymoon: Josh used our photos to imagine future family holiday pictures. Mary had mixed feelings about what it made. That's part of what we want this show to be: real experiments, honest reactions, and enough room to laugh at ourselves.

We'll start with AI news and deeper dives into tools and ideas. We'll see what is useful and let the format evolve.

00:00.000 Meet Josh and Mary
01:03.000 Our background
02:08.567 Why we're doing this
02:45.867 Make AI fun
03:53.367 Curious, even when skeptical
05:02.367 Off the clock
05:21.667 An AI experiment at home
06:25.700 What to expect

Learn about [Run Your City](https://www.runyourcity.org/).

The holiday pictures are described in the conversation. This episode does not display them or establish that they depict real future people.

## Platform copy drafts

### LinkedIn

On our honeymoon, Josh used AI to imagine years of family holiday photos. Mary had mixed feelings about the result. That's a fair preview of this show.

We're Josh and Mary, newlyweds, Stanford business students, and nonprofit operators. We're starting Out of Our Depth to learn about AI in public, try things ourselves, and work out what is useful.

Episode 0 is a short introduction to us, why we're doing this, and the kinds of conversations we hope to have. We want to make the subject easier to follow and more fun to spend time with.

What would you want us to try or explain? [Insert verified episode link after publication.]

### Instagram

We asked AI to imagine our future holiday photos. Mary had thoughts.
We're Josh and Mary. Episode 0 is a quick hello and why we're learning AI out loud.
What should we try next?

### X

We're Josh and Mary. Our short Episode 0 introduction includes an AI experiment from our honeymoon, a few laughs, and why we're learning this stuff out loud. What should we try or explain? [Insert verified episode link.]

## Clip candidates

No separate clips were requested or rendered. Use the final-export timing below to review moments before making platform crops.

| Rank | V2 range | Why it works | Editing note |
|---|---|---|---|
| 1 | 05:21-06:25 | An actual AI experiment with setup, result and mixed reaction. | Preserve both hosts. Do not insert the private generated images without their approval. |
| 2 | 02:46-03:12 | Mary wants AI to feel fun; the Elon/Musk confusion shows the hosts learning too. | Keep the correction and laugh, not just the mistake. |
| 3 | 05:02-05:21 | The caffeine contrast and "we're not that fun" reversal. | Keep the response that makes the exchange affectionate. |

## Upload files and status

- Video: `edit/episode-00-master-v2.mp4`, 1920 × 1080, 30fps, H.264/AAC, 7:14.033.
- Audio: `edit/episode-00-audio-master-v2.wav` and `edit/episode-00-audio-v2.mp3`.
- Captions: `edit/episode-00-captions-v2.srt` and `.vtt` aligned to this exact cut.
- Thumbnail: `edit/episode-00-thumbnail-v2.jpg`.
- Editorial comparison: `edit/episode-00-edit-notes-v2.md` and the preserved 4:39.300 v1.
- Technical and review findings: `edit/episode-00-quality-check-v2.md`.

Review the exact video and captions together, especially the personal story and how the AI-generated children are described. The unsupported adoption statistic and unready website/email plug are excluded. No theme music or outside footage was added. Do not use "out now" or a live URL until publication is verified.
