# Episode brief: Make AI useful — Projects, connectors, skills

- **Episode ID:** E002
- **Status:** proposed v3 final cut (30:55.600) from the September 26 reshoot in `edit/`; awaiting host review. Outline below is the pre-shoot draft
- **Owner:** Josh Eiland / Mary
- **Prior recording date:** 2026-09-25 (now reference material)
- **Current reshoot:** 2026-09-26 (source file supplied that day)
- **Target publication date:** 2026-09-27 proposed launch target; not confirmed
- **Content lane:** deep dive
- **Primary audience:** Curious professionals and everyday AI users

## One-sentence promise

Understand how background, connected information, and reusable instructions can make an AI assistant more useful.

## Why now

Josh has requested one more reshoot to better align the episode with the show's practical, casual, relatable, and entertaining goals. The September 25 cut is preserved as reference. Current preparation: [feedback and plan](reshoot-feedback-and-plan-2026-09-25.md), [recording cue sheet](reshoot-recording-cue-sheet-2026-09-25.md).

## Core question

How do you move beyond a generic chatbot answer to useful help on real tasks?

## Working thesis

Relevant context, controlled access to information, and reusable task instructions make repeat work easier; people still need to check outputs and exercise judgment.

## Audience starting point

Viewers may have tried a chatbot but not organized ongoing context, connected apps, or saved a repeat workflow.

## Story arc

1. A familiar frustration and concrete result; clear three-part promise.
2. Projects and useful background, led by Mary.
3. Connectors and access to a specific source, led by Josh.
4. Skills and reusable directions, with both hosts explaining and judging.
5. One continuing task brings the three together; Mary's design example shows reusable judgment.
6. An honest failure, limits, one next action, and a brief personal closing.

This is a proposed arc for the additional reshoot. Example choice and visual treatment remain for host review; the edit must follow what is actually recorded.

## Must-support claims

| Claim | Evidence needed | Research owner | Status |
|---|---|---|---|
| Current product behavior and terminology in new dialogue | Official product documentation, matched to actual app/account and spoken wording | Codex / hosts | Core terminology checked in reshoot addendum; demonstration verification pending |
| Personal workflow outcomes | Hosts’ account; distinguish anecdotes from general guarantees | Josh / Mary | Recorded account, not independently verified |

## Host experience to include

Mary's context choices, personal reading preferences if she wants to share them, and brand judgment; Josh's access/workflow explanation and a real limitation or overbuilt attempt. Confirm the actual stories before rolling. Do not fabricate demonstrations or host outcomes.

## Visuals or demos

Proposed: a complete spoken explanation with optional brief result inserts. The same outline can use host picture throughout. Hosts have not settled screen-share policy. The supplied OOOD brand kit now governs new visuals; music and recurring effects beyond the kit's rules remain unresolved.

## Clip candidates

Identify from the completed edit rather than prescribing unrecorded lines.

## Risks

Product capabilities change. Speech recognition can mishear names or overlap. Preserve source synchronization and check speaker balance.

## Open questions before the additional recording

- Actual app/example, temporary visual treatment, personal stories, recording date, and edit/review ownership.
- Whether the proposed September 27 release target remains feasible.
- Final logo/platform exports and music choices remain separate open project decisions; the supplied visual brand guidelines are adopted.

## Previous recording evidence

- [x] Source located: `/Users/je/Movies/Episode 2 Raw.mp4`
- [x] Editing authorized by Josh on 2026-09-25
- [x] Assembled export passes technical checks
- [x] Retained product claims checked against primary documentation; host anecdotes remain self-reported
- Existing cut is now reference material; host picture lock was not established.

## Pre-shoot checklist (historical; the reshoot is now recorded)

- [x] Feedback and proposed running order drafted
- [x] Concise chronological cue sheet prepared
- [ ] Hosts select example, visual treatment, and personal stories
- [ ] Chosen app/account and demonstration tested; factual wording checked
- [ ] Known blackout/duplicate-mix issues diagnosed; recording preflight passed
- [ ] Outline works aloud and recording date is confirmed
