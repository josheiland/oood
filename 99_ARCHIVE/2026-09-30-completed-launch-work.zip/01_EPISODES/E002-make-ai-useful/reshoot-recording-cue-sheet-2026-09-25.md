# Episode 2 — recording cue sheet

**Draft for Josh and Mary · 2026-09-25 · proposed 20–23-minute episode.** Use this at the camera; keep the [full feedback and production plan](reshoot-feedback-and-plan-2026-09-25.md) for preparation. These are prompts and draft lines, not approved dialogue. One continuing example is proposed: a partner-meeting follow-up, using approved real material or a clearly labeled recreation.

**Remember:** background / access / reusable directions. One task gets more useful. Both explain; both react. Say the correction aloud. Don't pretend a result worked if it didn't.

**Latest host direction, 2026-09-26:** Have fun together and let people get to know the relationship. The clock is a guide, not a reason to cut a great exchange. Record Episodes 0 and 1 before this weekend's E002 reshoot. Apply the supplied OOOD brand to new visuals.

## 00:00–01:30 — pain, payoff, route

- Start with one actual generic sentence and a useful revision. Mary: what would you actually send or change? Josh: what was missing?
- Names; one line that you run Run Your City together and will use it as an example. This also applies to school, home, and other work.
- Draft promise: “If you're tired of explaining the same things to AI, we're going through three things that can help: background, access to the right information, and directions you can reuse.”
- Brief intern/onboarding analogy if helpful. Don't extend it into a story about promotions or managing agents.

## 01:30–04:30 — Projects = background

- Mary explains the workspace and relevant context: mission, audience, voice, a useful source.
- Josh asks what she would deliberately leave out. Focused desk, not everything you own.
- One everyday parallel: a class, household project, or another real use.
- Say instructions and files; don't promise all chats are remembered or sources automatically refreshed.
- Bridge: “Now it knows us. It still doesn't know what happened in that meeting.”

## 04:30–07:30 — connectors = access

- Josh: a connection to another supported service, with authorized access.
- Find the approved meeting note. Name the fact it contributes. Mary checks it against the source.
- Reading a note and sending/changing something are different capabilities. Controls depend on the actual app and setup.
- Keep this example at a draft. Don't tour every app, permission menu, or pricing plan.
- Bridge: “It can find the facts. But I keep giving it the same directions about the output.”

## 07:30–11:30 — skills = reusable directions

- Define first: save a repeatable way of doing a task. The product's exact mechanism may vary.
- Show/read three rules: concise draft; next steps with stated owners/dates; flag anything missing.
- Mary, if wanted: explain your own reading preferences before Josh names the custom skill. What format helps you, and what can it miss?
- Josh: the core is instructions, sometimes with resources or code. Saved directions still need testing and updates.
- A named bot may be a saved prompt; explain what is actually underneath it. Skip Markdown and slash-command guessing.
- Bridge: “Let's put those three pieces together.”

## 11:30–14:30 — does the output actually help?

- Same task: compare actual results. What came from background? What came from the source? What came from the saved directions?
- Mary edits one sentence. Josh checks a fact/commitment. Keep unknown details unknown.
- Brief disagreement: when does an AI-assisted message still feel like you? Which messages do you want to write personally?
- If the demo disappoints, explain why and what you changed. Don't manufacture a win.

## 14:30–16:30 — Mary's judgment becomes reusable

- Mary: one real brand rule, an example, and something you rejected.
- Josh: how that helps you make a first pass without asking Mary to start from scratch.
- Land that the taste came from Mary; saving it doesn't eliminate her judgment.
- Skip the full platform/website history and the banking tutorial.

## 16:30–18:30 — honest miss and limits

- One true failure: stale grant result, missing detail, or directions it didn't follow. Confirm the story before rolling.
- What caught it? What did you change? What still needs review?
- Say when setup isn't worth it. A one-off prompt or manually attached file may be enough.

## 18:30–21:00 — recall, action, human ending

- Project: useful background. Connector: access to information/tools. Skill: reusable directions.
- Draft action: “Pick one task you keep repeating. Give it a few relevant facts, try it, and judge the result before adding more.”
- One approved funny recent prompt, real reaction, short sign-off. No new technical tangent.

## Before rolling / pickups

- Choose app, example, and whether to use short result inserts. Test them; save honest outputs.
- Both mics verified; distinct tracks checked; 1080p matched; blackouts/sync test passed; framing and lighting matched; notifications hidden.
- Warm up first. Record opening options after the body. Repeat whole sentences after factual slips.
- In the audio-only check, nobody should need the words “look here” to understand the point.
