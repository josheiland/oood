# Episode 2 — edit folder

## Current: v3 from the September 26 reshoot (corrected proposed cut, host review pending)

Open **[episode-02-final-cut-v3.mp4](episode-02-final-cut-v3.mp4)**: **30:55.600**, 1920 × 1080 at 30 fps. It preserves the v2 edit, graphics and dialogue mix, and removes 11.7 seconds containing one unsupported product claim. The new join is at **16:12.5**. [V3 edit notes](episode-02-edit-notes-v3.md), [source addendum](../../../02_RESEARCH/episode-02-v3-source-addendum-2026-09-27.md), corrected captions, chapters, audio master, EDL, render script and QC are alongside. Host review, caption listening proof and name approvals remain open. Nothing is scheduled or published.

## Previous: v2 from the September 26 reshoot

Open **[episode-02-final-cut-v2.mp4](episode-02-final-cut-v2.mp4)**: **31:07.300**, 1920 × 1080 at 30 fps, chapters embedded. Edited by jtan (Claude) on 2026-09-26 from `/Users/je/Movies/Episode 2 Raw.mp4`, the new reshoot. Kit v2 brand graphics, pop-ups timed to the spoken word, a cold open, leveled dialogue.

| File | Purpose |
|---|---|
| `episode-02-final-cut-v2.mp4` | Complete proposed episode |
| `episode-02-audio-master-v2.wav` | 48 kHz 24-bit leveled dialogue master |
| `episode-02-captions-v2.srt` / `.vtt` | Machine captions timed to v2, names corrected; needs a listening proofread |
| `episode-02-transcript-v2.md` | Readable transcript on the v2 timeline |
| `episode-02-chapters-v2.md` | Chapter list |
| `episode-02-edit-notes-v2.md` | What was cut and why, every join, every graphic, optional trims, review limits |
| `episode-02-quality-check-v2.md` | Technical measurements |
| `episode-02-edit-decisions-v2.json` | Reversible edit list: source ranges, overlay anchors, audio chain |
| `render-episode-v2.py`, `prepare-captions-v2.py`, `graphics-v2/` | Rebuild from the untouched source |

Claims: [episode-02-v2-source-checks-2026-09-26.md](../../../02_RESEARCH/episode-02-v2-source-checks-2026-09-26.md). Not approved, scheduled or published.

## Reference: v1 from the September 25 take

**Current status, 2026-09-25:** Josh has requested another reshoot. This cut is preserved as reference, not the planned release master. See the [new reshoot plan](../reshoot-feedback-and-plan-2026-09-25.md).

Open **[episode-02-final-cut-v1.mp4](episode-02-final-cut-v1.mp4)** — **23:50.733**, 1920 × 1080 at 30 fps.

The cut uses the September 25 reshoot only: revised opening, Projects → connectors → skills, concrete host examples, recap, and sign-off. Dialogue is leveled. Neutral on-screen notes clarify product differences, and a workflow graphic covers one source picture dropout. Music and final show-logo assets remain unconfirmed.

| File | Purpose |
|---|---|
| `episode-02-final-cut-v1.mp4` | Complete edited episode, with embedded chapters |
| `episode-02-edit-notes-v1.md` | Editorial choices, exact source ranges, treatments, and review limits |
| `episode-02-chapters-v1.md` | Chapter timestamps |
| `episode-02-reference-transcript-v1.md` | Approximate timed review transcript; not finished captions |
| `episode-02-quality-check-v1.md` | Technical measurements and remaining playback review |
| `episode-02-edit-decisions-v1.json` | Reversible frame list and all on-screen copy |
| `render-episode.py` | Rebuild from the unchanged original |

Product-source checks: [Episode 2 research](../../../02_RESEARCH/episode-02-source-checks-2026-09-25.md).

Original: `/Users/je/Movies/Episode 2 Raw.mp4`. Generated media and `intermediate/` are excluded from Git. Keep these media files and the source backed up separately. This is a complete proposed final cut, pending Josh and Mary’s end-to-end playback and approval; it has not been scheduled or published.
