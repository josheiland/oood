---
tags: [oood, episode-02, qc]
---

# Episode 2 v2 — quality check

Checked 2026-09-26 by jtan. **Complete export, technically checked, ready for host review.** Not approved, scheduled or published.

## Export

| Check | Result |
|---|---|
| File | `episode-02-final-cut-v2.mp4`, 788,560,535 bytes |
| SHA-256 | `a8cd364f3e52aa7bf6a372aea614c32eaa467c76549f78dc38fe6c9f4c864069` |
| Video | H.264 High, 1920 × 1080, 30 fps constant, yuv420p, BT.709; 56,019 frames, exactly the edit list's total |
| Audio | AAC-LC 48 kHz stereo, 256 kbps, encoded once from the 24-bit master |
| Duration | Video 1867.300 s, audio 1867.300 s (31:07.300) |
| Full decode | Passed with no errors |
| Loudness (encoded file) | −16.6 LUFS integrated, −1.3 dBTP true peak, 4.5 LU range. The first encode peaked at −0.9 dBTP, so the audio was re-encoded 0.6 dB lower with the video stream copied untouched |
| Audio master WAV | −16.0 LUFS, −1.5 dBTP, 48 kHz 24-bit |
| Black frames | None (0.1 s / 95% threshold); only the intentional 0.5 s end fade |
| Silence | No span below −48 dB lasting 1.5 s or longer |
| Chapters | Nine embedded; match `episode-02-chapters-v2.md` |
| Source | SHA-256 `087b52c2…a79b42d` unchanged before and after; original only read |

## Sync and frame accuracy

- **Audio vs source:** 28 samples (two per segment) cross-correlated against the source audio. Constant offset of −5 ms at every point: no drift and no segment shifted relative to another.
- **Picture vs source:** frames near both ends of every segment compared with source frames −2…+2. Every sample is either frame-exact or one frame (33 ms) ahead, and the error doesn't grow over the 7-minute segments. This matches small timestamp irregularities in the OBS source (duplicate frames appear next to the mismatches), not an edit error. One frame is well inside normal lip-sync tolerance. Details: `intermediate/v2/quality/frame-offset-check.json`.
- These checks cover the edit, not the camera's own sync. The source looked sync-clean in the samples, but that needs a human watch to confirm.

## Joins

The finished audio was retranscribed around all 13 joins (`intermediate/v2/quality/join-retranscription.json`). Every join lands between words, with no clipped syllables heard. Listen closely at:

- **23:04:** Josh's "but that's been one" and Mary's "And what I like…" overlap in the original, so the retranscription hears "but that's been… what I like." It's natural crosstalk, not a cut artifact, but it's the busiest join.
- **05:52 and 05:56:** two joins 3.6 s apart inside the Granola explanation.

## Graphics

All 17 cues were inspected in the finished file: title card, host name, six chapter lower thirds, three recap lower thirds, six note cards. Teachers and JetBrains Mono, kit palette, lower thirds at the bottom left, no face covered, nothing clipped. Each cue starts on the onset of its anchor word. The lower-third wipe and title-card move were sampled at single frames, not watched in motion.

## Levels

Fourteen passages from both hosts on the final master measure −16.7 to −18.4 dBFS (75th-percentile active speech). Before leveling, Mary ran 1–3 dB under Josh in the first minutes. This is a level proxy, not a listening test.

## Not done

- No continuous real-time viewing or listening by anyone. Josh and Mary should watch end to end.
- Captions (`.srt`/`.vtt`) are machine-generated with corrected names; they need a listening proofread before upload. The cold-open line "want to go to sleep" and "my credits, runs over" are inferred from context.
- Open content items: humanizer "built into Claude" at 16:09 (recommended cut); naming Lewis, Olivia, Tyler and Chloe. See the claim register.
