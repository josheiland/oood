# Episode 002 hook testers (jtan, 2026-09-29)

Josh asked for 7–8 hook options in the Episode 000 tester format: the hook, then the `EPISODE 002 / MAKE AI USEFUL` card with the 5.267-second sting, then the start of the episode. Each file is a private 1080p30 review clip of about 25 seconds. None has an outro or burned-in captions.

Every tester uses the same card, sting and post-title opening: raw frames 59–495 (00:01.967–00:16.500), "And we're live" through "Triple OD." They differ only in the hook. As with Episode 000's honeymoon hook, the hook moment plays again at its original place in the full episode.

| File | The moment | Raw source | Hook | Total |
|---|---|---|---:|---:|
| `01-credits-bedtime.mp4` | Mary: Josh sprints to the laptop at bedtime to spend his AI credits. "I gotta send it off to do something useful." | 17:49.433–17:55.733 | 6.3 s | 26.1 s |
| `02-sephora.mp4` | The email-drafting routine skips junk like "the Sephora new deal drop… although yours might think that's important." "But that is important." "Honestly, great call out." | 31:56.500–32:04.333 | 7.8 s | 27.6 s |
| `03-overtraining.mp4` | Mary: ChatGPT says she's overtraining. "Honestly, Chat, I ran like one time, like a week ago." | 04:59.300–05:06.533 | 7.2 s | 27.0 s |
| `04-typed-bullets.mp4` | On professors going back to hand-typed slides: "People are like, you literally typed those bullets. They look like trash, but you did it." | 29:07.533–29:11.967 | 4.4 s | 24.2 s |
| `05-eat-that-up-v2.mp4` | Josh's AI newsletter "doesn't look beautiful or anything." "I would hate that." "But you would eat that up." | 23:30.333–23:35.067 | 4.7 s | 24.5 s |
| `06-stole-brand-skill.mp4` | Josh: "So now I've stolen Mary's Run Your City brand design skill… she's much better at that than I am." | 14:26.733–14:39.267 | 12.5 s | 32.3 s |
| `07-infinite-time.mp4` | Mary: "with the time we have left, which is like infinite because we have nothing to do." | 22:17.300–22:22.100 | 4.8 s | 24.6 s |
| `08-outputting-trash.mp4` | Mary: "I was like, yes, AI will do it. And then I would just like… outputting trash." | 30:11.900–30:15.567 | 3.7 s | 23.5 s |

`05-eat-that-up.mp4` is the first render of option 5. It runs on into "yeah, no," and an ASR check heard the start of the next word, so `-v2` replaces it. It ends on "up" with a 40 ms fade. The hosts talk over each other there, so listen to that ending before choosing it.

## How the boundaries were chosen

Word timings come from a fresh whisper.cpp pass with DTW token alignment over the whole raw. Whisper alone runs about 0.1–0.3 s late at word edges, so each cut is placed in a measured silence in the audio envelope between the two words. Three ends were placed by hand from the envelope where the hosts' speech runs together (04, 05, 08). The starts of 01 and 06 have no pause before them, so they sit at the quietest frame of continuous speech. After rendering, each hook and each post-title opening was transcribed again from the finished file to confirm the first and last words heard. **This is an ASR check, not a human listen.** Josh caught a leaked "we" on the Episode 000 hook that the checks missed, so listen to the last word of whichever hook you like before we lock it.

## Audio

Both mics are centered in both ears (the raw pans Josh and Mary apart), with a 70 Hz high-pass and gentle leveling. One linear loudness pass runs over the whole raw, so the hooks and the full episode share exactly the same dialogue processing. The sting (−1.6 dB) and card match Episode 000.

## Reproduce

`../jtan-002/build-hooks.py [hook-id ...]` rebuilds from the untouched raw (`/Users/je/Movies/Episode 2 Raw.mp4`, SHA-256 `087b52c2…a79b42d`), which was re-downloaded from Drive on 2026-09-29 and hash-verified. It refuses to overwrite existing files. `hooks.json` records raw frames, durations and the ASR text of each hook.

Nothing here is approved, scheduled or published.

Speaker attributions above are only where the words make the speaker unambiguous. The transcript has no speaker labels.
