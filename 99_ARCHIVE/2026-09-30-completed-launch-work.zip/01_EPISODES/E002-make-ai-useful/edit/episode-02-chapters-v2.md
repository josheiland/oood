# Episode 2 v2 — chapters

Draft chapter list for `episode-02-final-cut-v2.mp4` (also embedded in the file). Not a publication claim.

00:00 Cold open
00:06 Meet your AI intern
01:45 Projects: background
05:22 Connectors: access
08:39 Skills: reusable directions
20:25 Recap
20:51 What we built with AI
28:09 Where AI missed
30:13 What's next
