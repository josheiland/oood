# Episode 2 — reference transcript v1

Transcribed directly from the finished audio and checked against the complete source transcript and word-aligned joins. Approximate phrase timing. **A review aid, not publication-ready captions.** Clear product names are normalized; bracketed wording remains uncertain. Overlapping speakers are not individually attributed. The MP4 is authoritative.

## Make AI useful

**[00:00]** We're back. Josh and Mary. Eiland. Newlyweds. And Out of Our Depth [overlapping wording unclear].

**[00:08]** All the ways. All the ways. All the ways. Every last one. Every last one, including AI, but that is the point of this podcast, is to learn out loud.

**[00:16]** Today we are going to go through projects, connectors, and skills. Yeah. Before we get into the specific settings and different kind of layers of your configuration of your AI tool,

**[00:27]** one metaphor that we found really useful is sort of thinking about your AI tool of choice as your intern.

**[00:33]** And we think that what we're going to talk through today is really how you get your intern from being like fresh sophomore showing up at your office for the first time to like six months post grad has been around a little bit.

**[00:46]** Knows the lay of the land? Not as ripe. Yeah. Not as ripe. Right. Oh, yeah. Not as ripe. Yeah, exactly.

## Projects: background

**[00:53]** Project is really just giving background to your AI. And the thing I love about it is it's it makes things so much quicker, but you can do it for so many different things.

**[01:05]** We have one for the nonprofit we run. I have one for my classes. I have one for our wedding planning. Do you have one for each class or one for all your classes?

**[01:13]** I have one for all my classes because I don't really know because it takes a moment to set up. And really, I want it to be able to pull what are the assignments I have, like what is the typical way that I write and whatnot.

**[01:28]** But I think basically back to your metaphor, it's an intern.

**[01:32]** And how I envision it is you can't expect someone that you have joining your team to have all the contacts right away. And that's what chat AI is. And when I use chat, I really just mean AI more broadly.

**[01:45]** But that's what chat is without a project. Like it has so much data, but like nothing specific. It doesn't know our mission, our goals, whatever it is.

**[01:54]** And with a project, especially the one that I use most often, which is for our nonprofit, it has all the things that I need it to know. And you have to be careful. You can't have too much there.

**[02:05]** Totally. Yeah. I think the example and the framing that you share with me that I think is super helpful is like imagining again that this AI tool is your intern.

**[02:15]** If you gave your intern a desk and you put, you know, you can choose what you're going to put on their desk when they show up and it could be 600 files.

**[02:24]** But then it's going to take them so much time whenever they need to refer to a certain piece of information to find the right thing.

**[02:30]** And it can just be overwhelming and kind of drown them out in the pure volume of stuff in front of them. And so it's very similar where when you're setting up a project, you have the ability to put in a project description.

**[02:40]** That's high level instructions and background knowledge for it. And you really want that to be the core, broadly applicable information that's going to apply across any individual chat or task that you're handling within that project.

**[02:53]** Yeah. So like for our nonprofit, we want to have the mission statement, maybe our last annual report documents and key info that's going to be useful for it to incorporate regardless of what the specific task that it's trying to accomplish versus, you know, it doesn't need to have

**[03:09]** super detailed information on how we configure our bank accounts for our different chapters because for the vast majority of chats, that's going to be totally irrelevant and distracted more than it helps.

**[03:19]** Yeah. People talk a lot about like context, like you have to be, I don't know exactly, do you know what it totally stands for in AI?

**[03:26]** Context.

**[03:27]** Yeah.

**[03:28]** I think, I mean, I just think of context as what is the information that's being shared with the model when it's running a certain query or prompt. So it's like, you know, your prompt that you type in as the user is part of that context.

**[03:44]** The power, I think of the project description is that it's custom built by you with like, here are the things that I want my intern to know off the bat. Like here's almost like the basic onboarding so that it's not asking me the dumb questions over and over whenever I'm asking it to do a basic task.

**[04:00]** Yeah. Yeah.

**[04:01]** That's mostly, you know, you can type in text, but most tools also have the ability for you to attach files as well. And so that's where, like we said, you know, you can literally just drag and drop your PDFs or Word docs or whatever it may be. And some tools now also have the ability to have that be through Google Drive so that it can be a little bit more of like a live document that it will refresh over time instead of a static view from a file.

## Connectors: access

**[04:22]** And then comes connectors. Connectors give it access to, you know, your Google Drive, your calendar, your Slack, like truly almost everything. I really wanted to give it access to my text, but I can't yet because I forget Apple.

**[04:36]** And I think that's fun. There is then it can start doing stuff like I you don't well, you could sometimes want it to automatically send an email, but like I was so exhausted last night and I was trying to send a proposal through and I just had a conversation with a chat and I kept telling it to tell me what it's coming up with.

**[04:55]** And I just told it, don't don't like ask me, just send it right to my academic advisor and I went to bed and I woke up and I was like, did I actually do it? And I did it and it was great. And it was like phenomenal. I was like so shocked.

**[05:06]** Yeah, I feel like I definitely air towards less giving it less permissions on like sending or. Yeah, it was the first time I like send it without looking. But yeah, they're getting a lot better.

**[05:17]** And I think that the cool thing is that you can set pretty granular levels of access for the different connectors based on the different specific actions. So like for your Google drive, for example, when you configure that connection, which is the connection is pretty much just like an integration.

**[05:31]** Like when you integrate a tool with any other app in the past, it's very similar. Yeah, connection is literally just like access to other apps. Like you're pretty much just telling it like here's my login that you can now use to act on my behalf with this app.

**[05:43]** So when you go in with Google drive, you can then go into the settings on, you know, chat, call on your AI tool and it'll list out all the different primary types of actions that it has within that connector.

**[05:54]** And you can select for each like I'm going to give you full access to do it whenever you like versus ask me for permission versus don't even bother. I don't want you doing that.

**[06:02]** And so you can go through and be pretty specific around where you want to let it go free versus require more. Do you have everything on total permission?

**[06:12]** I tell it, it can't like send any emails. I can't do it like it can't change anything, but it can. I like I'm Google calendar. I have it adds up all the time.

**[06:22]** I think with communication, I always have a draft so I can look at it, but I'm thinking about having it do a bunch of drafts and then at like a recurring time, which is a routine, which we can get in later.

**[06:35]** But it like tells me or we have a conversation says this is the draft. This is what I wrote. Can I send it? And I think that would be really fun.

**[06:44]** Yeah. And that way too, then you could give it feedback and kind of teach it how to get better and it'll be able to learn from that process of going back and forth with you.

## Bonus: voice input

**[06:53]** I want to do one day, maybe like Sunday where all I I try to do everything through voice AI and see like what are the boundaries because I think I mean by voice.

**[07:04]** So you know how you can text into a good call. You can text or like type into AI. You can also have a conversation or with AI, but there's some limitations and that's like the little like circle on the side where you can like go back and forth and it's actually gotten a lot better the voice.

**[07:25]** But there's some limitations of the voice when you're going back and forth and having that conversation. You can also use totally separate tools like Wispr Flow that I love. It's I now pay for it.

**[07:37]** Oh, well, yeah, you upgraded.

**[07:40]** I wish I don't think you're thrilled about but but I needed unlimited words. I was using it so much and it's so fun because it looks like the more you use it, the more beneficial it is. And now it knows like so many of my words like Lokes and Lewis.

**[07:55]** It doesn't write as L-E-W-I-S. And so where I used to learn is it like when you speak to it, it takes its first pass at transcribing it, but then it kind of watches.

**[08:06]** And if you replace like L-E-W-I-S to be L-O-U-I-S, then it will know in the future.

**[08:11]** It saves in the dictionary. And then there's like little words like Lokes or Lovebugs that I just like use all the time. And you can just add it to your dictionary. And I and then there's another piece of it that you can do like more casual versus like more formal.

**[08:26]** And so I have it when it's when it knows I'm on my email app, it's more formal. And when it's on text like I hate when Siri adds periods to my text like it's so drama. I don't want that. Wispr Flow never does it.

**[08:39]** And like things like that, then I can actually like talk when I'm responding and not ever needs to get a voice memo from me.

**[08:45]** Yeah, that makes sense. And I think there's also an ability in Wispr Flow and like probably other similar tools where you can kind of be word vomiting live like brain dumping and you can say, oh, actually, instead of that, say this.

**[08:59]** And instead of just transcribing that whole thing, it will know like, okay, let me go delete that last part and replace it. So it like has a little bit of added intelligence beyond just transcribing exactly what you say to like sort of translate everything you tell it into the final output that you want.

## When to keep it personal

**[09:14]** So when does it matter that it comes from AI clearly? And when does it not? I actually think that if it comes from AI, but it like sounds like me, I this is a hot take, but I don't care.

**[09:29]** Like I think that's like the same thing because I have trained my AI to sound like me a little bit, a little bit, but like I draft a lot of texts and emails that I think are more personal and I have AI adjusted, but like I like it better.

**[09:44]** I think it then communicates when I'm trying to say better. I think there are some instances like I'm going to messaging you or our team where I'm like, I don't really care if it's clearly coming from AI.

**[09:53]** I don't need to edit around and like make it like really, and I think it's important to like figure out what works for you in that trade off.

**[10:00]** Totally. Yeah. I think it's like a super personal decision. When I think about to your point, it's super context dependent of where both do I care and the person who's receiving it, do they care?

**[10:10]** So like, you know, if we are going back and forth with the parent, one of the chapters of our nonprofit, because they're trying to figure out when to show up with their kid on Sunday, like I'm okay for AI to just essentially fully take that right?

**[10:22]** Because it's going to be able to pull together a response super quickly and get them the information they need as soon as possible.

**[10:26]** And that's the most important thing in that moment. Right. Like that parent doesn't care whether the response comes from me or Claude, as long as it's correct and gets to them on time.

**[10:34]** And so if I can use AI to, you know, get a bunch of responses out much quicker than I could on my own, like that's a win versus if I'm sending you a message like checking in on you, I don't want that to be automated by Claude, you know, because that takes out a lot of the meaning.

**[10:50]** I agree. So I think it's just, it's almost like where does it add more meaning, but I will say, minus the work stuff.

**[11:01]** Like, I'm not a good writer. So like, a lot of times I will like, like voice and record that in with Granola, Wispr Flow like we just talked about. Did we talk about Granola? No Granola we use for literally just about everything.

**[11:16]** And we basically, it just records meetings. It records you talking, but it does a really nice job for, I think Granola is the one we've enjoyed the most.

## Meeting notes to follow-up

**[11:23]** And it's nice because it will, you can link it to your calendar and then it'll just pop up a minute before your zoom call and you can just hit start.

**[11:30]** So it's super easy to run in the background. And obviously depending on what state you're in, there's like legal implications where you need to make sure you have consent of people you're recording.

**[11:37]** But most people, I feel like are totally fine with it. And then it's so helpful because then you don't have to worry about getting down all the notes during the meeting.

**[11:45]** You can really just totally, and it will, you know, transcribe the whole meeting and then summarize it.

**[11:49]** And then you can chat natively within Granola and ask it to help with things.

**[11:53]** Or to your point, you can just connect your Granola through one of these connectors into your chat or cloud or whatever tool.

**[12:00]** And then I'll constantly be telling it, hey, can you help draft this follow up email based on the context of this meeting, you know, that you can find in Granola.

**[12:08]** Yeah. And so, yeah, that's such a lot.

**[12:11]** So then your AI goes into Granola without you having to copy and paste and it then basically does a draft for you.

**[12:18]** And if it's connected both to Granola and Gmail, which these are one time connections, same with project background.

**[12:24]** We'll talk about skills, which is a little bit more dynamic or, you know, you use or you can build multiple times.

**[12:31]** But with connectors, you just do it one time and then you can say, OK, draft this, send it on Gmail, you know, book a follow up on Google Cal.

**[12:40]** And it's just like so dynamic. Yeah, totally. Yeah.

## Skills: reusable directions

**[12:45]** Yeah. OK, I love it. So a project that's a background connector.

**[12:50]** That's access. Then we have skills, which basically like directions.

**[12:55]** This you can use across different projects.

**[12:59]** You can use just in your chat without any project.

**[13:02]** And it's really to like a level up a specific task.

**[13:06]** So if we go back to our intern metaphor, our intern now has a project context and let's just use the nonprofit as an example.

**[13:14]** So the intern now knows the most important things about the nonprofit and now has access to what we use.

**[13:19]** So it has access to our our meeting notes, but also our calendar, Gmail, whatever.

**[13:24]** And the skill then doubles down on like a specific thing we want it to do.

**[13:29]** So the one that I use a ton is the my dyslexia skill and contrary to what it sounds like, it actually undyslexifies me in some ways and all like feed it in a case for Stanford or an email, whatever it is.

**[13:45]** And it will give me kind of the very concise, clear download of what it is in like a diagram visual.

**[13:54]** And then I can know immediately or just a lot quicker what it is.

**[13:58]** And then I can double click into anything.

**[14:00]** It also does it the reverse.

**[14:02]** So I will say something or type something really quickly and then it just like more organically or in a better way of writing communicates it.

**[14:12]** And so it kind of does it both ways.

**[14:14]** That's like a skill.

**[14:15]** It's like your intern comes to you and shows you a slide going back to Bain and we're like, no, do this, do this, do this.

**[14:22]** The fun thing about a skill is like you tell it once and it knows it forever.

**[14:25]** So it's anything that you want to do many, many times, make it a skill because then you can just streamline it.

**[14:32]** You do backslash dyslexia or backslash humanizer, which makes it sound.

**[14:38]** And there's a lot of skills that already come embedded in Claude or ChatGPT.

**[14:42]** So I'd almost say, yeah, like mess around and make one, but also just start using them and see which ones like you like a lot.

**[14:49]** Totally.

**[14:50]** And a skill is really just a document with text instructions.

**[14:53]** So it's a dot MD file, which is just marked down.

**[14:56]** It's essentially just text format a certain way that these AI tools are good at reading and understanding.

## Build, test, and share skills

**[15:01]** It can actually you can build out the file yourself or you can even just tell your chat, your cloud, et cetera, hey, build me a new skill that does this.

**[15:08]** And then to your point, you can go back and forth with it and make sure that you give it all your preferences.

**[15:12]** And then you did such a cool one when you you didn't even talk to it.

**[15:16]** Yeah.

**[15:17]** Yeah.

**[15:17]** So Claude, at least I think I don't know if the other providers offer this, but Claude has a really good idea.

**[15:22]** He has a really cool ability called like learn a skill or watch a skill.

**[15:28]** I can't remember the exact name, but you just have it record you.

**[15:32]** So I guess maybe it's called record skill.

**[15:34]** You go in and you just give it access to watch your screen as you do something.

**[15:38]** And so for us, we through our nonprofit have a bunch of different chapters and we manage all of their bank accounts through a site called Mercury.

**[15:46]** And so each time when we're launching new chapters, if we're launching, say, 20 new chapters,

**[15:50]** I historically would have to go in and create a new profile for that chapter,

**[15:55]** invite them through their email to claim that profile, then create a new bank account for them,

**[15:59]** set up the debit card with the bank account, tie the profile to the bank account, go through all these manual steps 20 times.

**[16:06]** And it's super repetitive.

**[16:07]** And to Mary's point, that's the best use case for a skill is when you're just doing something repetitive over and over.

**[16:12]** And so what I did is I used the learn a skill or record a skill and Claude and literally just did that once for one chapter.

**[16:18]** And then it watched, took notes of everything, learned that workflow.

**[16:23]** And now I can just give it a list or a spreadsheet, whatever, with the new chapters and the email address and the information it needs.

**[16:30]** And then tell it, go set up all the bank accounts and it now can go into Mercury, follow all those steps.

**[16:35]** And then it'll let me know if it runs any issues or it'll tell me confirmed.

**[16:39]** And I was super impressed.

**[16:41]** I recorded it one time and then tested it out and it pretty much worked off the bat.

**[16:45]** But if that wasn't the case, I definitely suggest like when I set up a skill, I'll definitely test it the first couple of times and more closely review the output and give it feedback to kind of tune it.

**[16:53]** And then from there, the idea is that it's again, like set and forget, use it where in the future, sometimes it'll kind of identify on its own.

**[17:02]** Claude will say, maybe I should tap in the dyslexify skill here because I know that Mary likes to ingest information visually instead of through text.

**[17:10]** If it doesn't, then to your point, you can always just do slash dyslexify and then that will automatically trigger the skill.

**[17:17]** But when you trigger a skill, pretty much what it's doing is just feeding in that document as additional context.

**[17:21]** - Direction, it's just additional. - Exactly.

**[17:23]** So it's just telling it, hey, read this document before you respond.

**[17:26]** So yeah, there's a lot of built-in ones within Claude and within chat, but now it's just super easy to build your own too.

**[17:33]** So that's a super fun way to just offload repetitive manual work. And you talked a little bit about the writing one.

**[17:40]** For me, I feel like the design skill that you built out has been super useful.

**[17:43]** How did you actually set that one up?

**[17:45]** So I did that on Claude Design and I love Claude Design.

**[17:49]** I think we should do a whole different episode on design because I eat that up.

**[17:54]** But basically, on Claude Design, you can go through and show it your website.

**[18:00]** I like the modern feel. I want the wording to feel very human, which means like, miss me with the punctuation and the capitalization.

**[18:12]** All of that is so giving. When every sub header or subtitle is all caps, I want to vomit.

**[18:20]** And so things like that and add little diamonds and smiley faces.

**[18:24]** Because we're Run Your City, we want it to feel fun.

**[18:27]** And it's been so fun to see because we've been able to take something like our website that took us so long.

**[18:35]** We used to build it on Wix, which was like drag and drop.

**[18:40]** And you had to change it for desktop versus your kind of phone and mobile.

**[18:46]** With the design skill, which to answer your question, basically, I went back and forth.

**[18:53]** We had a long conversation.

**[18:54]** We got very close and at the end, we were both very happy.

**[18:57]** We had a few--

**[18:58]** You had Claude that is.

**[18:59]** Claude Design.

**[19:00]** Oh.

**[19:01]** And then I said, OK, download the skill or just download this.

**[19:04]** And then I upload it to Claude.

**[19:07]** And previously, Claude Design was separate.

**[19:10]** I actually think now it's a little bit more embedded because they've all kind of consolidated.

**[19:14]** But then that's how we had the visual skill or the design skill for the nonprofit.

**[19:21]** And it didn't come up with our brand or design.

**[19:27]** Like I was doing that.

**[19:29]** And there was things I liked.

**[19:30]** There was examples.

**[19:32]** We were going back and forth.

**[19:33]** It was showing me.

**[19:34]** I would keep asking, OK, do it in five different ways and let me decide.

**[19:38]** And this is what I like and this is what I don't like.

**[19:40]** But it enables us now across our entire team to not ship everything to marketing.

**[19:48]** It just streamlines the process.

**[19:50]** It doesn't take our work away.

**[19:51]** It just makes our work better.

**[19:52]** And I think that's where I get so fired up by AI because I think it kind of starts to

**[19:57]** eliminate some of that fear of like, is it taking it away?

**[20:00]** And it's like, no, but it's changing the job.

**[20:03]** And ideally, it's making us all so much more efficient and impactful in what we're trying to do.

**[20:07]** Right.

**[20:08]** And allowing us to spend the time on the things that are actually fun and high value for where

**[20:12]** we should be spending our time.

**[20:14]** And I think what you mentioned, right?

**[20:16]** Like building that skill took a lot of your thinking and time and also just ability.

**[20:22]** Like you're way more talented at design stuff than I am.

**[20:25]** And so now the nice thing is that I can now steal your skill that you build and you share it with me.

**[20:30]** And now I can actually just use the slash RYC design skill, whatever.

**[20:34]** And so I kind of think of using a skill as like being able to phone a friend and whether it's, you know, me or kind of giving Claude the ability.

**[20:41]** We talk about the intern, right?

**[20:43]** Setting up your project is kind of like up, you know, onboarding your intern.

**[20:47]** But then giving it skills is like giving it the ability to call a friend when it needs to do a specific task.

**[20:52]** So, you know, it can call up.

**[20:54]** You're promoting your intern with like a certain amount of skills that that intern might be a full-time employee.

**[21:00]** Yeah, exactly.

**[21:01]** Now it's managing other interns where it's got a design intern and a finance intern, whatever.

**[21:06]** And so it's like into the like 20 agent team.

**[21:10]** We're getting there.

**[21:11]** So like for me, I would in the past just have to bother Mary when I needed something to look nice because she's much better than me.

**[21:17]** But now I can at least do a first pass with the design skill she built out and say, hey, you know, build me out a one pager for this potential partner and make sure it's in the RYC design.

**[21:27]** Yeah.

**[21:28]** And then that skill just instead of a vanilla, whatever basic Google Doc, it now has the colors and the fonts and the shapes and just feels like us.

**[21:38]** So it's a so much time of having to do all that formatting and just helps us keep consistency in our brand and see so, so much time in doing so.

## Recap and one embarrassing prompt

**[21:46]** Yeah, really quick summary.

**[21:47]** So we talked through projects, connectors and skills projects, the basic high level context that's going to get your AI tool up to speed.

**[21:56]** Connectors are going to let it use all of your different apps, third party tools you use day to day.

**[22:01]** And then the skills are going to help it be able to act out specific repeatable tasks to save you time.

**[22:08]** Bam.

**[22:09]** Bada boom.

**[22:10]** Before I sign off, what's the most embarrassing prompt that you asked ChatGPT or Claude in the last week?

**[22:18]** I don't know if it was technically the last week, but I know the one that I'll probably get the most heat for was when we were on our honeymoon.

**[22:26]** You know, we were starting to dabble in a little bit of thinking through the future things to come the next couple of years.

**[22:32]** What do you what are you getting at?

**[22:34]** You had chat.

**[22:35]** He literally had chat.

**[22:36]** And this is what Claude could not do because Claude's not realistic enough.

**[22:40]** He uploaded photos of us and had chat go through year by year.

**[22:46]** What our future four kids, two girls, two boys would look like from birth to like us being dead.

**[22:53]** And it was amazing.

**[22:54]** It was amazing.

**[22:55]** I loved how realistic it was.

**[22:58]** And I loved how it put us in like cute little sweaters, you know, for the Christmas card.

**[23:03]** We weren't getting older and you were like, that's not realistic.

**[23:06]** Make us get older.

**[23:07]** Our kids aren't going to look that cute.

**[23:09]** But I love the idea.

**[23:10]** The inspiration is phenomenal.

**[23:12]** It was pretty wild to look at.

**[23:15]** So we'll have to compare.

**[23:16]** We'll show.

**[23:17]** We'll show.

**[23:18]** We'll show.

**[23:19]** We'll see.

**[23:20]** The side by side.

**[23:21]** And you're like, this is what we hope for. It's like Instagram versus reality.

**[23:26]** Okay.

**[23:27]** With that.

**[23:28]** We'll dive much more in actual specific use cases and examples of how we use these tools

**[23:31]** in a future episode.

**[23:32]** But hopefully this was helpful.

**[23:33]** Let us know what landed, what didn't, where we can be.

**[23:36]** And what you're confused about.

**[23:38]** Like I think, I think we want to learn a lot.

**[23:39]** It's the point of this podcast.

**[23:41]** So excited to get into whatever's next.

**[23:45]** Next.

**[23:46]** Bada bing, bada boom.

**[23:47]** Thanks for joining us.

**[23:48]** See you on the flip.

