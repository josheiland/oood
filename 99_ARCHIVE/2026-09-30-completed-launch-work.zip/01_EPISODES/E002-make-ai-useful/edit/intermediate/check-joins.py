from pathlib import Path
import json,subprocess,wave,numpy as np
p=Path(__file__).resolve().parent;edl=json.loads((p.parent/'episode-02-edit-decisions-v1.json').read_text());out=[];manifest=[]
def pcm(f,t,d):return subprocess.check_output(['ffmpeg','-nostdin','-v','error','-ss',str(t),'-i',str(f),'-t',str(d),'-map','0:a:0','-ac','1','-ar','16000','-f','s16le','-'])
files=[]
for s in edl['segments']:
 fs=sorted((p/'render').glob(s['id']+'-*.mov'),key=lambda f:f.stat().st_mtime)
 files.append(fs[-1])
for i in range(len(files)-1):
 dur=(edl['segments'][i]['out_frame']-edl['segments'][i]['in_frame'])/30
 out += [pcm(files[i],dur-4,4),pcm(files[i+1],0,4),bytes(16000*2)]
 manifest.append({'montage_seconds':i*9,'join':edl['segments'][i]['id']+' → '+edl['segments'][i+1]['id'],'export_seconds':edl['segments'][i+1]['timeline_frame']/30})
with wave.open(str(p/'joins.wav'),'wb') as w:w.setnchannels(1);w.setsampwidth(2);w.setframerate(16000);w.writeframes(b''.join(out))
(p/'joins-manifest.json').write_text(json.dumps(manifest,indent=2))
