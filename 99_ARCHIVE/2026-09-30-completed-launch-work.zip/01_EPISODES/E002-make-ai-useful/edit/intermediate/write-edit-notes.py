from pathlib import Path
import json,re
p=Path(__file__).resolve().parent.parent
j=json.loads((p/'episode-02-edit-decisions-v1.json').read_text());asr=json.loads((p/'intermediate/source-asr.json').read_text())['transcription']
def tc(x):
 ms=round(x*1000);return f'{ms//60000:02}:{ms//1000%60:02}.{ms%1000:03}'
fps=j['fps'];total=j['total_frames']/fps
rows=['# Episode 2 — edit notes v1','','Assembled from the 2026-09-25 reshoot. **Complete proposed final cut; host review pending.**','','Runtime: **'+tc(total)+'** (source: 44:16.033). No prior-take footage is used. The original remains unchanged in `/Users/je/Movies/Episode 2 Raw.mp4`.','','## Editorial shape','','Use the last intro pickup, explain the intern metaphor, then move through Projects, connectors, and skills. Preserve both hosts’ concrete examples, disagreement about personal communication, humor, and sign-off. Remove abandoned starts, repeated setup, production chatter, extended company/hardware tangents, uncertain pricing, and the unsupported general jobs claim.','','## Exact cut list','','Times are half-open ranges at 30 fps; the JSON edit list is the frame-level source of truth.','','| ID | Export in–out | Source in–out | Retained material / reason |','|---|---|---|---|']
for s in j['segments']:
 a=s['in_frame']/fps;b=s['out_frame']/fps;t=s['timeline_frame']/fps
 rows.append(f'| {s["id"]} | {tc(t)}–{tc(t+b-a)} | {tc(a)}–{tc(b)} | {s["rationale"]} |')
rows+=['','## Picture and audio treatment','','- Source framing and 1080p30 cadence retained; no digital punch-ins or synthetic footage. Edits are visible straight cuts between original passages.','- Added neutral, reversible title/definition/clarification overlays. These are editorial aids, not a newly approved show brand system.','- First source picture blackout, 22:23.267–22:30.867, falls in removed material. Second, 25:42.667–25:50.300, is covered by a workflow graphic while the original dialogue continues.','- All four source audio tracks were sample-identical in decoded 8 kHz mono analysis; use only track 0, not a sum of the duplicates.','- Reduce low rumble at 65 Hz; apply smooth dialogue gain capped at 3x, then two-pass loudness normalization targeting −16 LUFS / −1.5 dBTP. Gentle 8 ms audio edge ramps prevent clicks.','- Preserve the source’s room sound and both voices; no voice replacement or aggressive spectral denoising. Brief ending fade follows the sign-off.','- Export includes chapter metadata. No music or unconfirmed logo has been introduced.','','## Claim clarifications','','Product checks and exact sources: `../../../../02_RESEARCH/episode-02-source-checks-2026-09-25.md`. On-screen notes distinguish project instructions/files from a description, qualify connection permissions and refresh behavior, explain Granola audio retention, and remind viewers to test reusable skills. Personal outcomes remain the hosts’ accounts.','','## Rebuild','','Run `python3 render-episode.py` from this directory (requires local ffmpeg/ffprobe, Pillow, and access to the source). The frame list, all overlay copy, and audio settings are in `episode-02-edit-decisions-v1.json`. Generated source/audio/clip caches are under `intermediate/`, excluded from Git.','','## Review limits','','The edit was reviewed through a complete source transcript, word-aligned cut boundaries, sampled source/export pictures, and technical audio/video checks. That is not continuous human audiovisual playback. Final host listening, original camera lip-sync confirmation, and editorial approval remain necessary before publication.']
(p/'episode-02-edit-notes-v1.md').write_text('\n'.join(rows)+'\n')
chap=['# Episode 2 — chapters','','Draft chapter list for the completed edit; not a publication claim.','']
for s in j['segments']:
 if s.get('chapter'):
  sec=int(s['timeline_frame']/fps);chap.append(f'{sec//60:02}:{sec%60:02} {s["chapter"]}')
(p/'episode-02-chapters-v1.md').write_text('\n'.join(chap)+'\n')
# A reference transcript, not final captions. Full rows use segment text; boundary rows use timed tokens.
lines=['# Episode 2 — reference transcript v1','','Machine-assisted transcript in export order. Approximate phrase timing; **not publication-ready captions**. Names are normalized where unambiguous. Overlapping speakers are not individually attributed. Consult the MP4 for exact wording and delivery.','']
for s in j['segments']:
 a=s['in_frame']/fps;b=s['out_frame']/fps;start=s['timeline_frame']/fps
 lines+=['## '+tc(start)+' — '+s['title'],'']
 for r in asr:
  u=r['offsets']['from']/1000;v=r['offsets']['to']/1000
  if v<=a or u>=b:continue
  if u>=a and v<=b:txt=r['text'].strip()
  else:
   tokens=[x for x in r['tokens'] if x['id']<50256 and a <= (x['offsets']['from']+x['offsets']['to'])/2000 < b]
   txt=''.join(x['text'] for x in tokens).strip()
  if not txt:continue
  for old,new in [('Clodr','Claude'),('clodr','Claude'),('chat GBT','ChatGPT'),('chat GPT','ChatGPT'),('chat GBT','ChatGPT'),('chat GBT','ChatGPT'),('chat GBT','ChatGPT'),('chat GBT','ChatGPT'),('whisper flow','Wispr Flow'),('Whisper flow','Wispr Flow'),('open AI','OpenAI'),('anthropic','Anthropic')]:txt=txt.replace(old,new)
  lines.append(f'**[{tc(start+max(0,u-a))}]** {txt}')
  lines.append('')
(p/'episode-02-reference-transcript-v1.md').write_text('\n'.join(lines)+'\n')
print('edit notes, chapters, and reference transcript written')
