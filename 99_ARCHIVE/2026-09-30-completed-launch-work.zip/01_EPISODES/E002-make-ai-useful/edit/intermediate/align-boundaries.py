from pathlib import Path
import json,subprocess
p=Path(__file__).resolve().parent; d=p/'boundaries'; d.mkdir(exist_ok=True)
edl=json.loads((p.parent/'episode-02-edit-decisions-v1.json').read_text())
model=p.parents[3]/'001-make-your-ai-useful/edit/intermediate/models/ggml-small.en.bin'
model=Path('/Users/je/oood/01_EPISODES/001-make-your-ai-useful/edit/intermediate/models/ggml-small.en.bin')
rows=[]
for s in edl['segments']:
 for side in ['in','out']:
  cut=s[side+'_frame']/30;offset=max(0,cut-4);base=d/(s['id']+'-'+side)
  subprocess.run(['ffmpeg','-nostdin','-v','error','-y','-ss',str(offset),'-t','8','-i',str(p/'source.wav'),str(base.with_suffix('.wav'))],check=True)
  with base.with_suffix('.log').open('w') as log:
   subprocess.run(['whisper-cli','-m',str(model),'-f',str(base.with_suffix('.wav')),'-ojf','-of',str(base),'-l','en','-t','3','-nfa','-dtw','small.en','-bs','1','-bo','1','-nf','-mc','0'],stdout=log,stderr=log,check=True)
  data=json.loads(base.with_suffix('.json').read_text())
  ts=[t for a in data['transcription'] for t in a['tokens'] if t['id']<50256 and t['t_dtw']>=0]
  rows.append(s['id']+' '+side+' CUT '+str(cut)+'\n'+' '.join(f"{offset+t['t_dtw']/100:.2f}{t['text']}" for t in ts))
  (d/'alignment-report.txt').write_text('\n\n'.join(rows))
 print(s['id'],'aligned',flush=True)
