from pathlib import Path
import subprocess,json,re,hashlib,numpy as np
P=Path(__file__).resolve().parent.parent;T=P/'intermediate';Q=T/'quality';Q.mkdir(exist_ok=True)
F=P/'episode-02-final-cut-v1.mp4';E=json.loads((P/'episode-02-edit-decisions-v1.json').read_text())
def run(args,path):
 with path.open('w') as log:subprocess.run(args,stdout=log,stderr=subprocess.STDOUT,check=True)
m=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_format','-show_streams','-show_chapters','-of','json',str(F)]));(Q/'probe.json').write_text(json.dumps(m,indent=2))
v=next(x for x in m['streams'] if x['codec_type']=='video');a=next(x for x in m['streams'] if x['codec_type']=='audio')
assert int(v['nb_frames'])==E['total_frames'],(v['nb_frames'],E['total_frames'])
assert abs(float(v['duration'])-float(a['duration']))<0.03,(v['duration'],a['duration'])
print('Frame count, audio/video duration, streams and chapters checked.',flush=True)
run(['ffmpeg','-nostdin','-hide_banner','-nostats','-v','info','-i',str(F),'-map','0:v:0','-an','-vf','scale=160:90,blackdetect=d=0.1:pix_th=0.05','-f','null','-'],Q/'video-decode.log')
print('Full video decode completed.',flush=True)
run(['ffmpeg','-nostdin','-hide_banner','-nostats','-i',str(F),'-map','0:a:0','-vn','-af','loudnorm=I=-16:TP=-1.5:LRA=11:print_format=json,silencedetect=n=-48dB:d=1.5','-f','null','-'],Q/'audio-decode.log')
stats=json.loads(re.findall(r'\{[^{}]+\}',(Q/'audio-decode.log').read_text())[-1]);(Q/'loudness.json').write_text(json.dumps(stats,indent=2))
print('Full audio decode and loudness completed.',stats['input_i'],stats['input_tp'],flush=True)
# AAC packet continuity, excluding the initial encoder-priming packet.
pack=json.loads(subprocess.check_output(['ffprobe','-v','error','-select_streams','a:0','-show_packets','-show_entries','packet=pts_time,duration_time','-of','json',str(F)]))['packets']
gaps=[]
for prev,nxt in zip(pack,pack[1:]):
 delta=float(nxt['pts_time'])-float(prev['pts_time'])-float(prev['duration_time'])
 if abs(delta)>0.00005:gaps.append(delta)
# Compare decoded export against the exact master to check for additional audio delay.
def read_audio(file,t,n=5):
 b=subprocess.check_output(['ffmpeg','-nostdin','-v','error','-ss',f'{t:.9f}','-i',str(file),'-t',str(n),'-vn','-map','0:a:0','-ac','1','-ar','8000','-f','f32le','-'])
 return np.frombuffer(b,dtype=np.float32)
def compare(x,y):
 n=min(len(x),len(y));x=x[:n];y=y[:n];x=x-x.mean();y=y-y.mean()
 fftn=1<<(2*n-1).bit_length();c=np.fft.irfft(np.fft.rfft(x,fftn)*np.conj(np.fft.rfft(y,fftn)),fftn);lags=np.arange(-800,801);scores=c[lags%fftn];lag=int(lags[np.argmax(scores)])
 return {'lag_ms':lag/8,'correlation_at_zero':float(np.corrcoef(x,y)[0,1])}
times=[3,75,180,300,450,600,720,850,1000,1150,1300,1418]
checks=[]
for t in times:checks.append({'export_seconds':t,**compare(read_audio(F,t),read_audio(T/'master-audio.wav',t))})
# Source-to-master checks cover every segment and therefore both ends of the programme.
source_checks=[]
for s in E['segments']:
 dur=(s['out_frame']-s['in_frame'])/30;offset=min(4,dur/3)
 st=s['in_frame']/30+offset;tt=s['timeline_frame']/30+offset
 source_checks.append({'segment':s['id'],'source_seconds':st,'export_seconds':tt,**compare(read_audio(F,tt),read_audio(E['source'],st))})
sourcehash=hashlib.file_digest(open(E['source'],'rb'),'sha256').hexdigest();assert sourcehash==E['source_sha256']
result={'frame_count':v['nb_frames'],'video_duration':v['duration'],'audio_duration':a['duration'],'size':F.stat().st_size,'sha256':hashlib.file_digest(F.open('rb'),'sha256').hexdigest(),'source_sha256_unchanged':sourcehash,'aac_packet_gaps':gaps,'master_alignment':checks,'source_alignment':source_checks,'loudness':stats,'black_spans':re.findall(r'black_start:[^\n]+',(Q/'video-decode.log').read_text()),'long_silences':re.findall(r'silence_(?:start|end):[^\n]+',(Q/'audio-decode.log').read_text())}
(Q/'results.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2),flush=True)
