# (id, anchor_phrase, approx_src_time, kind, kicker/title, line/body, hold_s)
OVERLAYS = [
 ('names',   "We're back on this episode", 4.4,  'lt',   'Out of Our Depth', 'Josh + Mary', 4.5),
 ('ch1',     "It gives your AI context", 99.5, 'lt',   '01 / Projects', 'Background', 5.0),
 ('website', "go to our website", 193,        'note', 'Heads up', 'This works only if your AI can reach that website.', 5.5),
 ('ch2',     "Then we have connectors.", 349,  'lt',   '02 / Connectors', 'Access', 5.0),
 ('granola', "It records meetings for us.", 378.5, 'note', 'Granola', 'Meeting notes app. Granola says it does not keep the audio.', 5.5),
 ('composio',"Composio is this", 1231,          'note', 'Composio', 'A third-party hub that links more of your accounts to your AI.', 6.0),
 ('ch3',     "then we have skills.", 485,      'lt',   '03 / Skills', 'Reusable directions', 5.0),
 ('slash',   "that slash kind of tells it", 567, 'note', 'Using a skill', 'Type / and the skill name, or just ask for it by name.', 5.5),
 ('record',  "record a skill live", 606,       'note', 'Record a skill', 'In Claude Cowork on Mac: do the task once, then review and test it.', 6.0),
 ('wispr',   "whisper flow is another app", 735, 'note', 'Wispr Flow', 'Voice dictation that learns the words you use.', 5.0),
 ('recap1',  "projects gave your intern", 1319, 'lt',  'Recap', 'Projects = background', None),
 ('recap2',  "connectors enabled this intern", 1325, 'lt', 'Recap', 'Connectors = access', None),
 ('recap3',  "skills enabled them", 1332,       'lt',  'Recap', 'Skills = reusable directions', 4.5),
 ('ch4',     "top five things you built", 1342, 'lt',  '04 / Show and tell', 'What we built', 5.0),
 ('ch5',     "AI is really missed", 1826,       'lt',  '05 / Honest misses', 'Where AI missed', 5.0),
 ('ch6',     "Last question before we sign off.", 1993, 'lt', '06 / Up next', 'What we want to learn', 5.0),
]
CHAPTERS = [('Cold open','@CO'),('Meet your AI intern','@S01'),('Projects: background','ch1'),('Connectors: access','ch2'),
            ('Skills: reusable directions','ch3'),('Recap','recap1'),('What we built with AI','ch4'),('Where AI missed','ch5'),("What's next",'ch6')]
