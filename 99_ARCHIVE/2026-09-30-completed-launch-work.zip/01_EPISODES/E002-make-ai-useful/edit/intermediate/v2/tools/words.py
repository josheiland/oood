import json, re, numpy as np, wave
S='/private/tmp/claude-501/-Users-je-jtan/236b7143-fb33-410a-a313-6748d5ce4b28/scratchpad/e2/'
def load_words():
    d=json.load(open(S+'raw.json')); W=[]
    for seg in d['transcription']:
        for t in seg['tokens']:
            tx=t['text']
            if tx.startswith('[_'): continue
            a,b=t['offsets']['from']/1000,t['offsets']['to']/1000
            if tx.startswith(' ') or not W: W.append([tx.strip(),a,b])
            else: W[-1][0]+=tx; W[-1][2]=b
    return [(w,a,b) for w,a,b in W if w]
W=load_words()
norm=lambda s: re.sub(r"[^a-z0-9']","",s.lower())
NW=[norm(w) for w,_,_ in W]
def find(phrase, near=None, win=40):
    p=[norm(x) for x in phrase.split()]; hits=[]
    for i in range(len(W)-len(p)+1):
        if NW[i:i+len(p)]==p: hits.append(i)
    if near is not None: hits=[h for h in hits if abs(W[h][1]-near)<win]
    if not hits: raise ValueError('not found: '+phrase)
    if near is not None: hits.sort(key=lambda h:abs(W[h][1]-near))
    i=hits[0]; return i, W[i][1], W[i+len(p)-1][2]
_env=None
def env():
    global _env
    if _env is None:
        w=wave.open(S+'raw.wav'); x=np.frombuffer(w.readframes(w.getnframes()),dtype=np.int16).astype(np.float32)/32768
        n=len(x)//160; x=x[:n*160].reshape(n,160); _env=20*np.log10(np.sqrt((x**2).mean(1))+1e-9)
    return _env
def context(t, span=4):
    return ' '.join(w for w,a,b in W if t-span<=a<=t+span)
