import sys, json; sys.path.insert(0,'.')
from align import *; from edl_plan import PLAN
def split(p): return p.split('|') if '|' in p else (p,p)
out=[]
for sid,ip,ia,op,oa,ch,why in PLAN:
    try:
        if ip is None: tin,bi,ai=0.0,'',''
        else:
            r,d=split(ip); _,a,_=rough(r,ia); tin,bi,ai=cut_in(d,a)
        r,d=split(op); _,_,b=rough(r,oa); tout,bo,ao=cut_out(d,b)
    except Exception as e:
        print(sid,'ERROR',e); continue
    out.append(dict(id=sid,src_in=round(tin,4),src_out=round(tout,4),chapter=ch,reason=why,join_in=f'{bi} || {ai}',join_out=f'{bo} || {ao}'))
    print(f"{sid}: {tin:8.3f} -> {tout:8.3f} ({tout-tin:6.1f}s)\n   IN  ...{bi} || {ai}\n   OUT {bo} || {ao}...")
json.dump(out,open('resolved.json','w'),indent=1)
print('total', sum(o['src_out']-o['src_in'] for o in out)/60)
