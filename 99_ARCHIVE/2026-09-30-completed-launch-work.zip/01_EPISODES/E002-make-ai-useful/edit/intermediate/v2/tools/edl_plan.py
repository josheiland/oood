# (id, in_phrase, in_approx, out_phrase, out_approx, chapter, reason)
PLAN = [
 ('CO', "I'll be tired", 1069, "something useful.", 1076, 'Cold open', "Cold open: Mary on Josh racing to use up his AI credits before bed. Replayed in context at ~17:40."),
 ('S01', None, 0.0, "pull updates occasionally.", 256, 'Meet your AI intern', "OOOD name bit, the three-part promise, intern metaphor, Mary's Projects explanation with the desk analogy, Josh's folder definition. Ends before Josh repeats Mary's website-pointer point."),
 ('S02', "Totally. And I think that", 280, "focuses in on and has context that doesn't change.", 329, None, "Mary's fitness project, a personal non-work example. Omits Josh's repeat of the class-projects example."),
 ('S03', "So it's a single setup", 346, "It records meetings for us.", 380, 'Connectors: access', "Connectors defined; Mary's connected tools; Granola introduced."),
 ('S04', "transcribes the whole meeting", 397, "generates a summary and follow ups.|generates a summary and followups.", 398, None, "What Granola produces. Omits uncertain free-tier and student-pricing numbers."),
 ('S05', "Obviously, you want to make sure", 435, "do action based off of it.", 482, None, "Consent reminder, notes-to-follow-up workflow. Omits the unverified phone-call recording detail."),
 ('S06', "One thing that I know is helpful", 1203, "It's quite easy. I love it.", 1316, None, "MOVED from 20:05 so the Composio multi-account workaround sits inside the connectors section instead of after skills."),
 ('S07', "And we can go in a little bit more", 482, "who's a specialist in a certain area.", 907, 'Skills: reusable directions', "Skills defined; Mercury setup; slash commands; record a skill; Mary's Dyslexify and brand skill; Wispr Flow aside; Josh reusing Mary's brand skill."),
 ('S08', "So like when I'm calling the bank account", 916, "that's when I love to create a skill.", 1096, None, "Phone-a-friend analogy without the 'supervisees' restart; humanizer; the podcast skills and the overnight-credits exchange."),
 ('S09', "I want to create one to like", 1102, "Totally. Totally.", 1203, None, "Mary's morning-brief wish, personal design skill, why AI tells matter. Omits an unfulfilled promise to share the skill files."),
 ('S10', "We kind of zoomed through that.", 1316, "capabilities that we would want.", 1478, 'What we built', "Recap and the three builds: newsletter, grant finder."),
 ('S11', "but that's been one. And what I like", 1511, "And I think you can see it.", 1683, None, "Grant alerts in Slack, Mary's honest frustration, website rebuild. Omits the agents-reviewing-agents tangent; keeps Josh's 'but that's been one' as the bridge."),
 ('S12', "I think in Claude specifically", 1694, "where you don't want to use AI?", 1832, 'Where AI missed', "Design tells, hand-made slides, the two-hour website test, the final human check. Omits naming a local business as AI-made."),
 ('S13', "Where it missed the mark", 1877, "took me a second.", 2050, "What's next", "Email-draft routine, what it took to make it useful, next topics, OOOD callback sign-off. Omits Mary's class-assignment story (she said on tape she probably would not use it)."),
]
