import json, subprocess, os, re, numpy as np
from words import W, find, env, norm, S
M=os.path.expanduser('~/oood/01_EPISODES/001-make-your-ai-useful/edit/intermediate/models/ggml-small.en.bin')
FPS=30
def dtw_window(t0, dur=14):
    t0=max(0,t0); key=f'win/w{int(t0*100)}_{dur}'
    if not os.path.exists(key+'.json'):
        subprocess.run(['ffmpeg','-v','error','-y','-ss',str(t0),'-t',str(dur),'-i',S+'raw.wav',key+'.wav'],check=True)
        subprocess.run(['whisper-cli','-m',M,'-f',key+'.wav','-ojf','-nfa','-dtw','small.en','-of',key,'-t','8'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,check=True)
    d=json.load(open(key+'.json')); ws=[]
    for s in d['transcription']:
        for t in s['tokens']:
            tx=t['text']
            if tx.startswith('[_') or t['t_dtw']<0: continue
            tt=t0+t['t_dtw']/100
            if tx.startswith(' ') or not ws: ws.append([tx.strip(),tt,tt])
            else: ws[-1][0]+=tx; ws[-1][2]=tt
    return [(w,a,b) for w,a,b in ws if norm(w)]
def locate(phrase, near, edge=None):
    """Return list of window words and index range of phrase (closest to near)."""
    ws=dtw_window(near-7)
    import difflib
    p=[norm(x) for x in phrase.split()]; nw=[norm(w) for w,_,_ in ws]; L=len(p)
    best=None
    for i in range(len(ws)-L+1):
        sc=difflib.SequenceMatcher(None,p,nw[i:i+L]).ratio()
        if edge=='first' and nw[i]!=p[0]: continue
        if edge=='last' and nw[i+L-1]!=p[-1]: continue
        # anchor words must match exactly at the edge we cut on
        key=(round(sc,2), -abs(ws[i][1]-near))
        if best is None or key>best[0]: best=(key,i)
    if best is None or best[0][0]<0.6: raise ValueError(f'dtw miss: {phrase} near {near:.1f}: '+' '.join(nw))
    i=best[1]; return ws,i,i+L-1
def valley(lo, hi, prefer):
    e=env(); a,b=int(lo*100),int(hi*100)
    if b<=a+3: return prefer
    seg=e[a:b]; k=3
    sm=np.convolve(seg,np.ones(k)/k,mode='same')
    floor=sm.min()
    cand=[i for i in range(len(sm)) if sm[i]<=floor+4]
    j=min(cand,key=lambda i:abs((a+i)/100-prefer))
    return (a+j)/100
def cut_in(phrase, near):
    """Cut point just before the first word of phrase."""
    ws,i,_=locate(phrase,near,'first')
    cur=ws[i][1]; prev=ws[i-1][1] if i>0 else cur-0.6
    t=valley(prev+0.35*(cur-prev)-0.05, cur+0.02, cur-0.12)
    return round(t*FPS)/FPS, ' '.join(w for w,_,_ in ws[max(0,i-5):i]), ' '.join(w for w,_,_ in ws[i:i+6])
def cut_out(phrase, near):
    """Cut point just after the last word of phrase."""
    ws,_,j=locate(phrase,near,'last')
    cur=ws[j][1]; nxt=ws[j+1][1] if j+1<len(ws) else cur+0.6
    t=valley(cur-0.02, cur+0.8*(nxt-cur)+0.05, cur+0.15)
    return round(t*FPS)/FPS, ' '.join(w for w,_,_ in ws[max(0,j-5):j+1]), ' '.join(w for w,_,_ in ws[j+1:j+6])
def rough(phrase, near=None): return find(phrase,near)
