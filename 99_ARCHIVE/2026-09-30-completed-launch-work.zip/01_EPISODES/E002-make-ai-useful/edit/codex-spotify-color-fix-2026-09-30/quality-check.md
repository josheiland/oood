# Episode 002 color repair QC

**Use [episode-002-spotify-upload.mp4](episode-002-spotify-upload.mp4) for the upload retry.** Same 33:14.267 ep2hook cut, current Episode 000 cards/music, seven removals and retained five-hour exchange. [Matching captions](episode-002-spotify-upload.srt) and chapters are byte-identical to the prior v3 sidecars.

## Cause

Josh supplied Spotify's color-consistency rejection. Unlike E001's outro mismatch, E002 has unspecified color primaries and transfer at the intro card, starting 00:07.133, with explicit BT.709 again at 00:12.400. Coded H.264 headers contain 241 explicit BT.709 declarations and one unspecified declaration. A keyframe-only decoder scan reports all keyframes as BT.709 and masks the defect. The complete source-frame scan detects 156 frames with unspecified primaries/transfer from 00:07.133 through 00:12.300; the final two boundary frames use BT.709.

## Repair and checks

`repair-command.json` records the metadata-only H.264 pass. Range, matrix, primaries and transfer are now explicit limited BT.709 in every coded header and the MP4 container. No picture or audio recompression was performed. All originals and other agents' files remain preserved.

- 33:14.267 duration, 59,828 frames and all 12 embedded chapters unchanged.
- All 153,311 media packet timing records match the source exactly.
- Picture slice hash and AAC packet hash match exactly (`integrity-checks.json`).
- All 242 SPS headers declare identical explicit limited BT.709.
- Full video decode: every frame has identical color metadata; frame times strictly increase; no reported decoding errors (`color-consistency.json`).
- Original source SHA-256: `eece6af6e408f441c356557b29d6424857ae8301e904654e8d686521ec5d47a3`.
- Fixed file SHA-256: `2d0de694425b1e13523a6a52a4895a1accb994d7b763434f7838b7c53753e858`.
- Existing detailed description chapters and caption timing remain valid.

## Prevention

The shared producer's `scripts/color_qc.py` now checks the container, every coded SPS declaration and every decoded frame. `media_job.py qc` and `render` enforce that gate and stop on failure. New segments set color properties on the frames as well as encoder options; the final mux normalizes H.264 header declarations and container tags. The renderer rejects explicitly different source colors rather than pretending a metadata change converts them. The live producer skill requires this gate for custom hook/card/mux revisions too.

Regression evidence is kept here: the new gate rejects the original export; `regression-qc-rejects-original/` proves the shared QC command refuses it. An initial two-second hook/intro render exposed that encoder options alone were insufficient. After frame-level parameters and mux normalization were added, `regression-render-v2/` passed its color gate and all render checks. Earlier small regression outputs remain preserved.

## Status and sources

Local file repaired and checked. Spotify acceptance/processing still needs confirmation from the upload retry. No upload, publishing or account change was performed. Continuous host review and auditory caption-proof status are unchanged.

- [Spotify video specs](https://support.spotify.com/us/creators/article/video-specs/) — Spotify, undated, accessed 2026-09-30; recommends Rec.709 SDR, H.264/HEVC and compatible audio.
- [FFmpeg H.264 metadata filter](https://ffmpeg.org/ffmpeg-bitstream-filters.html#h264_005fmetadata) — FFmpeg, live documentation, accessed 2026-09-30; supports altering coded range/primaries/transfer/matrix without decoding/reencoding.
