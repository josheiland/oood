# Episode 002 saved-hook v3: technical checks

Checked 2026-09-30. Exact export: `episode-002-full-review-v3.mp4`.

| Check | Result |
|---|---|
| Identity | 706,010,130 bytes; SHA-256 `eece6af6e408f441c356557b29d6424857ae8301e904654e8d686521ec5d47a3`. |
| Picture/timing | 1920 × 1080 H.264, 30 fps, 59,828 frames, 33:14.267. Full video/audio decode passed. |
| Hook | Source SHA-256 `2ee7f0466e54764748f057ab846d6f718af92e77cbe5bc4e39e2df54ec1e14eb`; all 214 picture frames retained. Complete 7.103-second audio plus 30.3 ms timeline padding. Short CPU ASR confirmed the running exchange; uncertain “be a year” wording was corrected using the surrounding episode transcript. |
| Copied episode picture | First/last intro frames, first/last conversation frames and first/last outro frames have identical decoded hashes to recurring-card v2 at the new +25-frame offset. |
| Audio | −16.0 LUFS integrated, 4.8 LU range, −1.4 dBTP true peak. One AAC encode after concatenating the saved hook with the existing episode from the intro onward. |
| Audio preservation | Decoded signal correlation 0.9999996 for the saved hook, 0.9999959 for opening dialogue, 0.9998824 for intro music and 0.9996488 for outro music. No offset search or level adjustment was needed. Signal checks are not a human listening pass. |
| Chapters/captions | 12 chapters and 573 ordered, in-bounds caption cues. Intro starts at 7.133; body at 12.400; outro at 1983.500 seconds. Five-hour exchange remains present. |
| Visual inspection | Finished-export frames 0, 213, 214, 371, 372, 59,504, 59,505 and 59,827 show the saved hook, current cards, correct joins and final fade. |
| Editorial | Hook swap only; same seven raw-source removals and main conversation. The former credits cold open is no longer at the start. |

Ready for host review. A continuous human audiovisual pass and auditory caption proof have not been completed for this export. Technical checks do not establish both hosts' approval or publication. The hook selection itself is Josh's confirmed decision.
