#!/usr/bin/env python3
"""Verify the saved-hook swap, exact copied pictures and retimed package."""
from pathlib import Path
import hashlib
import json
import re
import subprocess
import numpy as np

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[3]
BASE=HERE.parent/'codex-recurring-cards-2026-09-30/episode-002-full-review-v2.mp4'
HOOK=ROOT/'01_EPISODES/E000-why-were-here/edit/ep2hook.mp4'
OUTPUT=HERE/'episode-002-full-review-v3.mp4'
DELTA=25/30
TOTAL=59828

def digest(path):
    with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()

def probe(path):
    return json.loads(subprocess.check_output(['ffprobe','-v','error','-show_streams',
        '-show_format','-show_chapters','-of','json',str(path)]))

def pcm(path,start,duration):
    data=subprocess.check_output(['ffmpeg','-nostdin','-v','error','-ss',str(start),
        '-i',str(path),'-t',str(duration),'-map','0:a:0','-ac','1','-ar','8000','-f','f32le','-'])
    return np.frombuffer(data,dtype='<f4').astype(np.float64)

def similarity(a,b):
    n=min(len(a),len(b));a,b=a[:n],b[:n]
    return float(np.dot(a,b)/np.sqrt(np.dot(a,a)*np.dot(b,b)))

def frame_hash(path,n):
    return subprocess.check_output(['ffmpeg','-nostdin','-v','error','-ss',f'{n/30:.9f}',
        '-i',str(path),'-map','0:v:0','-frames:v','1','-f','md5','-']).decode().strip()

def seconds(s):
    a,b,c=s.replace(',','.').split(':');return int(a)*3600+int(b)*60+float(c)

def main():
    p=probe(OUTPUT)
    video=next(x for x in p['streams'] if x['codec_type']=='video')
    audio=next(x for x in p['streams'] if x['codec_type']=='audio')
    assert int(video['nb_frames'])==TOTAL
    assert video['width']==1920 and video['height']==1080 and video['r_frame_rate']=='30/1'
    assert abs(float(video['duration'])-TOTAL/30)<.002
    assert abs(float(audio['duration'])-TOTAL/30)<.002
    assert len(p['chapters'])==12
    assert abs(float(p['chapters'][1]['start_time'])-214/30)<.001
    assert abs(float(p['chapters'][2]['start_time'])-372/30)<.001
    assert abs(float(p['chapters'][-1]['start_time'])-59505/30)<.001
    copied={}
    for old in (189,346,347,59479,59480,59802):
        a,b=frame_hash(BASE,old),frame_hash(OUTPUT,old+25)
        assert a==b,(old,a,b)
        copied[str(old)]=a
    clips={
        'saved_hook':similarity(pcm(HOOK,.1,6.9),pcm(OUTPUT,.1,6.9)),
        'intro_music':similarity(pcm(BASE,6.6,4.5),pcm(OUTPUT,6.6+DELTA,4.5)),
        'opening_dialogue':similarity(pcm(BASE,12,12),pcm(OUTPUT,12+DELTA,12)),
        'outro_music':similarity(pcm(BASE,1983,9.5),pcm(OUTPUT,1983+DELTA,9.5)),
    }
    assert all(x>.99 for x in clips.values()),clips
    srt=OUTPUT.with_suffix('.srt').read_text()
    blocks=re.split(r'\n\s*\n',srt.strip());last=0
    for block in blocks:
        line=block.splitlines()[1];start,end=map(seconds,line.split(' --> '))
        assert 0<=start<end<=TOTAL/30+.001 and start>=last
        last=start
    assert 'five hour' in srt.lower()
    assert 'What type of run should I do today?' in blocks[0]
    frames=[0,213,214,371,372,59504,59505,59827]
    for n in frames:
        subprocess.run(['ffmpeg','-nostdin','-v','error','-n','-ss',f'{n/30:.9f}',
            '-i',str(OUTPUT),'-frames:v','1',str(HERE/f'frame-{n:05}.jpg')],check=True)
    with (HERE/'full-decode.log').open('x') as log:
        subprocess.run(['ffmpeg','-nostdin','-v','error','-xerror','-i',str(OUTPUT),
            '-map','0:v:0','-map','0:a:0','-f','null','-'],stdout=log,stderr=log,check=True)
    measurement=subprocess.run(['ffmpeg','-nostdin','-hide_banner','-i',str(OUTPUT),
        '-map','0:a:0','-af','ebur128=peak=true','-f','null','-'],capture_output=True,text=True,check=True).stderr
    summary=measurement[measurement.rfind('Summary:'):]
    with (HERE/'audio-measurement.txt').open('x') as f:f.write(summary+'\n')
    result={'date':'2026-09-30','output':str(OUTPUT),'output_sha256':digest(OUTPUT),
        'output_bytes':OUTPUT.stat().st_size,'video_frames':TOTAL,'duration_seconds':float(p['format']['duration']),
        'hook_source':str(HOOK),'hook_source_sha256':digest(HOOK),'retained_hook_frames':214,
        'new_title_start':214/30,'new_body_start':372/30,'new_outro_start':59505/30,
        'chapter_count':12,'caption_count':len(blocks),'five_hour_line_present':True,
        'copied_picture_frame_hashes':copied,'decoded_audio_correlations':clips,
        'full_decode':'passed','audio_measurement':summary,'sampled_frames':frames,
        'continuous_human_review':False}
    with (HERE/'quality-check.json').open('x') as f:json.dump(result,f,indent=2)
    print(json.dumps(result,indent=2))

if __name__=='__main__':main()
