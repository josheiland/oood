# Episode 002 with Josh's saved ep2hook

**Spotify upload correction:** use [the checked upload copy](../codex-spotify-color-fix-2026-09-30/episode-002-spotify-upload.mp4). The v3 below has inconsistent intro color tags; the new copy fixes metadata without changing picture/audio content, timing or chapters.

**Current review:** [episode-002-full-review-v3.mp4](episode-002-full-review-v3.mp4), 33:14.267, 1080p30. [Draft captions](episode-002-full-review-v3.srt) and 12 chapters match this exact export. Rendered and technically checked 2026-09-30; continuous host review remains open.

Josh selected `/Users/je/oood/01_EPISODES/E000-why-were-here/edit/ep2hook.mp4` as the cold open. It is the seven-second running exchange beginning “What type of run should I do today?” and ending “No, I'm not.” This replaces the credits-at-bedtime cold open. All 214 saved picture frames and the full 7.103-second saved audio are retained; the fractional final picture frame is normalized to the 30 fps timeline with 30.3 ms of audio padding. The hook occupies 00:00.000–00:07.133.

The current Episode 000 intro and theme run 00:07.133–00:12.400. The main conversation then follows in its existing order; the outro begins at 33:03.500 and ends at 33:14.267. The same five-hour exchange, seven raw-source removals, recurring tagline, hidden top labels, raised default outro prompts and music remain in the episode. Every picture packet after the hook is copied from the checked recurring-card v2. Audio is encoded once after the hook replacement; no new dialogue processing or volume change is applied.

## Files and status

- `episode-002-full-review-v3.mp4`, `.srt`, `.chapters.md`, `.edl.json`: current review package and reversible source record.
- `quality-check.md`, `quality-check.json`, `opening-and-outro-contact-sheet.jpg`: measured checks and inspected boundary frames.
- `build-review.py`, `verify-review.py`: rebuild and verification, refusing to overwrite their output files.
- The short hook audio/transcript, normalized hook picture, copied title/body/outro picture and audio assembly are working evidence/intermediates. They are preserved; the user hook and prior exports were not changed.

The hook choice is resolved by Josh's instruction. Continuous viewing/listening, auditory caption proof, named-person comfort and exact-export approval by both hosts remain open. No upload, scheduling or publication occurred. Platform subscribe/recommended-video elements remain a separate assembly step.
