#!/usr/bin/env python3
"""Replace the Episode 002 cold open with Josh's exact saved ep2hook."""
from pathlib import Path
import hashlib
import json
import re
import subprocess

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[3]
BASE=HERE.parent/'codex-recurring-cards-2026-09-30/episode-002-full-review-v2.mp4'
HOOK=ROOT/'01_EPISODES/E000-why-were-here/edit/ep2hook.mp4'
OUTPUT=HERE/'episode-002-full-review-v3.mp4'
BASE_SHA='fa529a038374cc2e426e67278808af9e7955fcff9d7329501cc32703421d4e83'
HOOK_SHA='2ee7f0466e54764748f057ab846d6f718af92e77cbe5bc4e39e2df54ec1e14eb'
OLD_HOOK=189
NEW_HOOK=214
BASE_FRAMES=59803
TOTAL=BASE_FRAMES-OLD_HOOK+NEW_HOOK
DELTA=(NEW_HOOK-OLD_HOOK)/30

def digest(path):
    with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()

def run(args):
    subprocess.run(['ffmpeg','-nostdin','-hide_banner','-loglevel','warning','-n',*args],check=True)

def secs(s):
    h,m,v=s.replace(',','.').split(':')
    return int(h)*3600+int(m)*60+float(v)

def stamp(t):
    n=round(t*1000);h,n=divmod(n,3600000);m,n=divmod(n,60000);s,n=divmod(n,1000)
    return f'{h:02}:{m:02}:{s:02},{n:03}'

def write_new(path,text):
    with path.open('x') as f:f.write(text)

def metadata():
    edl=json.loads(BASE.with_suffix('.edl.json').read_text())
    edl['prior_hook']=edl['hook']
    edl['hook']={'id':'user-ep2hook','source':str(HOOK),'sha256':HOOK_SHA,
        'frames':NEW_HOOK,'source_duration_seconds':7.103,
        'timeline_duration_seconds':NEW_HOOK/30,
        'last_frame_hold_and_audio_padding_seconds':NEW_HOOK/30-7.103,
        'raw_frame_location':'Not remapped; use the user-saved source file'}
    edl['body_ranges_export_start_frame']=[n+NEW_HOOK-OLD_HOOK for n in edl['body_ranges_export_start_frame']]
    edl['chapters']=[[0 if i==0 else t+DELTA,name] for i,(t,name) in enumerate(edl['chapters'])]
    edl['total_frames']=TOTAL
    edl['prior_card_update']=edl.pop('card_update')
    edl['card_update']={
        'base_export':str(BASE),'base_export_sha256':BASE_SHA,
        'intro_frames':[NEW_HOOK,NEW_HOOK+158],
        'outro_frames':[TOTAL-323,TOTAL],
        'intro_png_sha256':edl['prior_card_update']['intro_png_sha256'],
        'outro_png_sha256':edl['prior_card_update']['outro_png_sha256'],
        'picture_copied_from_base_frames':[OLD_HOOK,BASE_FRAMES],
        'final_picture_fade_frames':15,
    }
    write_new(OUTPUT.with_suffix('.edl.json'),json.dumps(edl,indent=2)+'\n')
    lines=[';FFMETADATA1','title=Out of Our Depth | Episode 002: Make AI useful','artist=Josh and Mary']
    for i,(start,name) in enumerate(edl['chapters']):
        end=edl['chapters'][i+1][0] if i+1<len(edl['chapters']) else TOTAL/30
        lines+=['[CHAPTER]','TIMEBASE=1/30000',f'START={round(start*30000)}',
                f'END={round(end*30000)}',f'title={name}']
    write_new(OUTPUT.with_suffix('.ffmeta'),'\n'.join(lines)+'\n')
    write_new(OUTPUT.with_suffix('.chapters.md'),'\n'.join(f'- {stamp(t)[:-4]} {name}' for t,name in edl['chapters'])+'\n')
    # The short hook was ASR-checked; the misheard "be a year" is corrected
    # using the surrounding episode transcript's "be like, you're over training."
    cues=[(0,1.46,'What type of run should I do today?'),
          (1.46,3.0,'Or, you know, be like,\n"You\'re overtraining."'),
          (3.0,6.36,'Like honestly, Chat, I ran like one\ntime, like a week ago.'),
          (6.36,7.103,"No, I'm not.")]
    for block in re.split(r'\n\s*\n',BASE.with_suffix('.srt').read_text().strip()):
        rows=block.splitlines();a,b=map(secs,rows[1].split(' --> '))
        if a>=OLD_HOOK/30-.001:
            cues.append((a+DELTA,min(b+DELTA,TOTAL/30),'\n'.join(rows[2:])))
    assert all(0<=a<b<=TOTAL/30+.001 for a,b,_ in cues)
    write_new(OUTPUT.with_suffix('.srt'),'\n\n'.join(
        f'{i}\n{stamp(a)} --> {stamp(b)}\n{text}' for i,(a,b,text) in enumerate(cues,1))+'\n')

def main():
    assert not OUTPUT.exists()
    assert digest(BASE)==BASE_SHA and digest(HOOK)==HOOK_SHA
    metadata()
    normalized=HERE/'normalized-user-hook-picture.mp4'
    remainder=HERE/'copied-title-body-outro-picture.mp4'
    run(['-i',str(HOOK),'-map','0:v:0','-an','-vf','setpts=N/(30*TB),format=yuv420p',
        '-frames:v',str(NEW_HOOK),'-r','30','-fps_mode','cfr',
        '-c:v','libx264','-threads','4','-preset','veryfast','-crf','18',
        '-profile:v','high','-level:v','4.0','-pix_fmt','yuv420p',
        '-color_primaries','bt709','-color_trc','bt709','-colorspace','bt709',
        '-video_track_timescale','15360',str(normalized)])
    run(['-ss',str(OLD_HOOK/30),'-i',str(BASE),'-map','0:v:0','-an',
        '-map_metadata','-1','-map_chapters','-1','-frames:v',str(BASE_FRAMES-OLD_HOOK),
        '-c:v','copy','-video_track_timescale','15360',str(remainder)])
    concat=HERE/'picture-concat.txt'
    write_new(concat,f"file '{normalized.name}'\nduration {NEW_HOOK/30:.9f}\n"
        f"file '{remainder.name}'\nduration {(BASE_FRAMES-OLD_HOOK)/30:.9f}\n")
    audio=HERE/'hook-and-full-episode-audio.m4a'
    # Retain every source hook audio sample, then pad its fractional last frame.
    graph=(f'[0:a]atrim=end_sample=340944,asetpts=PTS-STARTPTS,apad,atrim=end_sample={NEW_HOOK*1600}[h];'
           f'[1:a]atrim=start_sample={OLD_HOOK*1600},asetpts=PTS-STARTPTS,apad,'
           f'atrim=end_sample={(BASE_FRAMES-OLD_HOOK)*1600}[b];'
           '[h][b]concat=n=2:v=0:a=1[a]')
    run(['-i',str(HOOK),'-i',str(BASE),'-filter_complex_threads','2',
        '-filter_complex',graph,'-map','[a]','-vn','-ar','48000','-ac','2',
        '-c:a','aac','-b:a','256k',str(audio)])
    run(['-f','concat','-safe','0','-i',str(concat),'-i',str(audio),
        '-i',str(OUTPUT.with_suffix('.ffmeta')),'-map','0:v:0','-map','1:a:0',
        '-map_metadata','2','-map_chapters','2','-c','copy',
        '-video_track_timescale','15360','-movflags','+faststart',str(OUTPUT)])
    print(OUTPUT,TOTAL/30)

if __name__=='__main__':main()
