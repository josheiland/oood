#!/usr/bin/env python3
"""Render Episode 2 v2 (the 2026-09-26 reshoot) from episode-02-edit-decisions-v2.json.

Single video encode: every segment is read straight from the untouched raw file, brand
overlays are composited in the same pass, and the audio is built once as a lossless master.
Outputs are versioned; nothing existing is overwritten except this version's own cache.

Usage: python3 render-episode-v2.py [--graphics-only] [--audio-only]
"""
import json, subprocess, sys, shutil
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE / 'graphics-v2'))
import oood_graphics as G  # noqa: E402

EDL = json.loads((HERE / 'episode-02-edit-decisions-v2.json').read_text())
SRC = EDL['source']
FPS = EDL['fps']
AUDIO_STREAM = EDL['audio_stream']          # absolute ffprobe index; all four tracks are identical mixes
CACHE = HERE / 'intermediate' / 'v2'
GFX = CACHE / 'gfx'
OUT_MP4 = HERE / 'episode-02-final-cut-v2.mp4'
OUT_WAV = HERE / 'episode-02-audio-master-v2.wav'
LOG = CACHE / 'logs'
for d in (CACHE, GFX, LOG):
    d.mkdir(parents=True, exist_ok=True)


def ff(args, name):
    with open(LOG / f'{name}.log', 'w') as f:
        subprocess.run(['ffmpeg', '-nostdin', '-hide_banner', '-y', *args], stdout=f, stderr=f, check=True)


def timeline():
    """Frame-exact export positions for every segment."""
    t = 0
    for s in EDL['segments']:
        s['frames'] = round((s['src_out'] - s['src_in']) * FPS)
        s['out_in_frame'] = t
        t += s['frames']
    return t


def to_export(src_t, seg_id):
    s = next(x for x in EDL['segments'] if x['id'] == seg_id)
    assert s['src_in'] - 1e-6 <= src_t < s['src_out'], (seg_id, src_t)
    return s['out_in_frame'] / FPS + (src_t - s['src_in'])


def build_graphics():
    items = []
    t = EDL['title_card']
    path = GFX / 'title.mov'
    if not path.exists():
        G.render_title_clip(t['kicker'], t['title'], t['detail'], path, hold_s=t['hold'])
    items.append(dict(path=path, start=to_export(EDL['segments'][t['segment_index']]['src_in'], EDL['segments'][t['segment_index']]['id']), x=0, y=0))
    ovs = EDL['overlays']
    for i, o in enumerate(ovs):
        start = to_export(o['src_anchor'], o['segment'])
        hold = o['hold']
        if hold is None:  # run until just before the next overlay
            nxt = to_export(ovs[i + 1]['src_anchor'], ovs[i + 1]['segment'])
            hold = min(5.0, nxt - start - 0.2)
        o['export_start'] = round(start, 3)
        o['export_end'] = round(start + hold, 3)
        img = G.lower_third(o['kicker'], o['line']) if o['kind'] == 'lt' else G.note(o['kicker'], o['line'])
        path = GFX / f"{o['id']}.mov"
        img.save(GFX / f"{o['id']}.png")
        G.render_wipe_clip(img, hold, path)
        items.append(dict(path=path, start=start, x=96, y=1080 - img.size[1] - 72))
    return items


def build_audio(total_frames):
    parts = []
    for s in EDL['segments']:
        dur = s['frames'] / FPS
        p = CACHE / f"a-{s['id']}.wav"
        n = round(dur * 48000)
        ff(['-ss', f"{s['src_in']:.6f}", '-i', SRC, '-map', f'0:{AUDIO_STREAM}', '-t', f'{dur + 0.05:.6f}',
            '-af', f'atrim=end_sample={n},apad=whole_len={n},afade=t=in:d=0.008,afade=t=out:st={dur - 0.008:.6f}:d=0.008',
            '-ar', '48000', '-ac', '2', '-c:a', 'pcm_f32le', str(p)], f"a-{s['id']}")
        parts.append(p)
    lst = CACHE / 'audio-concat.txt'
    lst.write_text(''.join(f"file '{p}'\n" for p in parts))
    joined = CACHE / 'audio-joined.wav'
    ff(['-f', 'concat', '-safe', '0', '-i', str(lst), '-c:a', 'pcm_f32le', str(joined)], 'audio-concat')
    total = total_frames / FPS
    pre = EDL['audio_processing']['pre_filters']
    ff(['-i', str(joined), '-af', f"{pre},loudnorm=I=-16:TP=-1.5:LRA=11:print_format=json", '-f', 'null', '-'], 'loudness-pass1')
    txt = (LOG / 'loudness-pass1.log').read_text()
    stats = json.loads(txt[txt.rindex('{'):txt.rindex('}') + 1])
    (CACHE / 'loudness-pass1.json').write_text(json.dumps(stats, indent=1))
    ln = (f"loudnorm=I=-16:TP=-1.5:LRA=11:measured_I={stats['input_i']}:measured_TP={stats['input_tp']}:"
          f"measured_LRA={stats['input_lra']}:measured_thresh={stats['input_thresh']}:offset={stats['target_offset']}:linear=true")
    fade = EDL['audio_processing']['end_fade_s']
    ff(['-i', str(joined), '-af', f"{pre},{ln},aresample=48000,atrim=end_sample={round(total * 48000)},"
        f"apad=whole_len={round(total * 48000)},afade=t=out:st={total - fade:.6f}:d={fade}",
        '-ar', '48000', '-ac', '2', '-c:a', 'pcm_s24le', str(OUT_WAV)], 'audio-master')


def chapters_file(total_frames):
    marks = []
    for title, ref in EDL['chapters']:
        if ref.startswith('@'):
            s = next(x for x in EDL['segments'] if x['id'] == ref[1:])
            t = s['out_in_frame'] / FPS
        else:
            t = next(o for o in EDL['overlays'] if o['id'] == ref)['export_start']
        marks.append((title, t))
    meta = CACHE / 'chapters.ffmeta'
    lines = [';FFMETADATA1', f"title={EDL['title']}", '']
    for i, (title, t) in enumerate(marks):
        end = marks[i + 1][1] if i + 1 < len(marks) else total_frames / FPS
        lines += ['[CHAPTER]', 'TIMEBASE=1/1000', f'START={int(t * 1000)}', f'END={int(end * 1000)}', f'title={title}', '']
    meta.write_text('\n'.join(lines))
    return meta, marks


def render_video(total_frames, items, meta):
    args, filt, n = [], [], 0
    for s in EDL['segments']:
        args += ['-ss', f"{s['src_in']:.6f}", '-t', f"{s['frames'] / FPS + 0.2:.6f}", '-i', SRC]
        filt.append(f"[{n}:v]setpts=PTS-STARTPTS,tpad=stop_mode=clone:stop=3,trim=end_frame={s['frames']},setpts=PTS-STARTPTS[v{n}]")
        n += 1
    filt.append(''.join(f'[v{i}]' for i in range(n)) + f'concat=n={n}:v=1:a=0,format=yuv420p[base]')
    cur = 'base'
    for k, it in enumerate(items):
        args += ['-i', str(it['path'])]
        filt.append(f"[{n}:v]setpts=PTS-STARTPTS+{it['start']:.6f}/TB[g{k}]")
        filt.append(f"[{cur}][g{k}]overlay=x={it['x']}:y={it['y']}:eof_action=pass:format=auto[o{k}]")
        cur = f'o{k}'
        n += 1
    fade = EDL['audio_processing']['end_fade_s']
    total = total_frames / FPS
    filt.append(f"[{cur}]fade=t=out:st={total - fade:.6f}:d={fade},trim=end_frame={total_frames},format=yuv420p[vout]")
    args += ['-i', str(OUT_WAV)]
    wav = n
    n += 1
    args += ['-i', str(meta)]
    graph = CACHE / 'filtergraph.txt'
    graph.write_text(';\n'.join(filt))
    ff([*args, '-filter_complex_script', str(graph), '-map', '[vout]', '-map', f'{wav}:a', '-map_metadata', str(n),
        '-map_chapters', str(n), '-c:v', 'libx264', '-preset', 'medium', '-crf', '18', '-profile:v', 'high',
        '-pix_fmt', 'yuv420p', '-color_primaries', 'bt709', '-color_trc', 'bt709', '-colorspace', 'bt709',
        '-r', str(FPS), '-filter:a', 'volume=-0.6dB',  # AAC overshoots the WAV's -1.5 dBTP; keeps encoded peaks under -1 dBTP
        '-c:a', 'aac', '-b:a', '256k', '-movflags', '+faststart', str(OUT_MP4)], 'video')


if __name__ == '__main__':
    total = timeline()
    items = build_graphics()
    meta, marks = chapters_file(total)
    resolved = HERE / 'intermediate' / 'v2' / 'edl-with-export-times.json'
    resolved.write_text(json.dumps(dict(total_frames=total, segments=EDL['segments'], overlays=EDL['overlays'],
                                        chapters=[dict(title=t, start=round(s, 3)) for t, s in marks]), indent=1))
    if '--graphics-only' in sys.argv:
        sys.exit(0)
    build_audio(total)
    if '--audio-only' in sys.argv:
        sys.exit(0)
    render_video(total, items, meta)
    print(OUT_MP4, total, 'frames')
