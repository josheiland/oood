# Episode 2 — quality check v1

Checked 2026-09-25. **Complete edited episode; host playback and approval pending.**

## Export checks

- Duration: **23:50.733**. Video: 1430.733333 s; audio: 1430.733000 s.
- Picture: H.264, 1920 × 1080, 30 fps, yuv420p, BT.709. **42922 frames** match the edit list exactly.
- Audio: stereo AAC at 48 kHz; encoded once from the lossless leveled master. Nine chapter markers embedded. Fast-start metadata allows playback before the whole file downloads.
- File size: 1,112,750,652 bytes (1.11 GB).
- Full video and audio decode completed successfully. No video decoding errors or black spans detected at the 0.1-second / 5%-pixel threshold.
- Final loudness: **-16.48 LUFS**, true peak **-1.01 dBTP**, loudness range **4.10 LU**.
- Long silences below −48 dBFS lasting at least 1.5 seconds: 0.
- AAC packet timestamps are continuous. Twelve export/master comparisons and one source/export comparison per edited segment found no added delay greater than 2 ms. These checks assess editing alignment, not original camera lip sync.
- Original source SHA-256 is unchanged. The raw recording was only read.

## Dialogue balance

75th percentile of 50 ms RMS windows, measured on the final AAC export. This is an active-speech proxy, not a perceptual score.

| Passage | Export time (s) | Level (dBFS) |
|---|---|---|
| Mary / projects | 65 | -20.34 |
| Josh / projects | 140 | -17.5 |
| Mary / dictation | 507 | -18.34 |
| Josh / dictation | 541 | -17.89 |
| Mary / personal messages | 568 | -19.76 |
| Josh / personal messages | 615 | -17.56 |
| Mary / skills | 819 | -17.31 |
| Josh / skill setup | 970 | -16.71 |

## Visual and editorial checks

- Full source transcript reviewed, with exact word-alignment checks at the proposed boundaries and an independent transcript of the finished audio.
- Reviewed 36 source frames and 43 export frames, including cut boundaries, every graphic, the repaired dropout, and the ending.
- Source blackout at 22:23.267–22:30.867 is excluded. The 25:42.667–25:50.300 blackout is covered with an opaque workflow graphic; its original audio continues.
- The opening is the final recorded pickup, followed by the original intern explanation. No old-take footage or replacement dialogue was introduced.
- Explanatory overlays are legible and stay below the hosts’ faces. Neutral typography is a provisional editorial treatment, not a permanent brand decision.

## Remaining human review

This verification uses transcripts, word alignment, sampled visuals, and full-file technical checks. It is **not continuous human audiovisual playback**. Josh and Mary should watch/listen end to end before publication, particularly for original camera lip sync, naturalness of the cuts, and their preferred sound. The reference transcript contains uncertain overlapping wording and is not a finished caption track. Personal experiences remain host accounts.

## Integrity and reproducibility

- Export SHA-256: `ce585f602a56690547d6c2f389dd655101f66d938c0304f567c06870a616e22c`
- Unchanged source SHA-256: `f5638f1056c3986e457c1d9dbb084f8ead581688375f2e30f9487bec94987525`
- `episode-02-edit-decisions-v1.json` records all source frames, on-screen copy, chapters, and audio treatment. `render-episode.py` rebuilds the export.
- Detailed probe, decoding, loudness, packet, timing, and visual results are local under `intermediate/quality/` (excluded from Git).
