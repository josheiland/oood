# Episode 002 September 26 reshoot: Codex factual review cut

**Current preferred review cut:** [Josh's selected ep2hook export](../codex-user-hook-2026-09-30/episode-002-full-review-v3.mp4), 33:14.267, 1080p30. It derives from the recurring-card update of the unchanged jtan fuller v2, replacing the credits cold open with Josh's saved running exchange. It matches current Episode 000 cards/music and keeps the five-hour exchange, raw order and relationship moments. The seven raw-source removals are listed in `consensus-review.md` and exactly in the `.edl.json` sidecars. It is not an approved or published master.

The 33:05.100 Codex v1 video in this folder removes that line. It remains a technically checked **comparison cut**, not the preferred version. No media was overwritten or deleted.

## Codex comparison files

- `episode-002-fact-corrected-codex-v1.mp4`: comparison video, 59,553 frames.
- `episode-002-fact-corrected-codex-v1.srt`: retimed machine captions; the new join's sentence case was corrected. **Needs a human listening proofread.**
- `episode-002-fact-corrected-codex-v1.chapters.md`: 12 embedded chapters on the new timeline.
- `episode-002-fact-corrected-codex-v1.edl.json`: source ranges and timing of every internal removal, plus head/tail trims.
- `consensus-review.md`: which source segments should go, which can stay, where Codex and Claude differed, and Josh's subsequent decision to keep the usage-window exchange.
- `build-fact-corrected-v1.py`: rebuilds from the hash-checked, unchanged `/Users/je/Movies/Episode 2 Raw.mp4` using the existing jtan source builder without editing any jtan file. Requires the local jtan builder's current cards/music/transcription intermediates.
- `quality-check.md`: measured export checks and review limits.

Short WAV/MP4 previews, sampled JPEGs and an ASR JSON/WTS file in this folder document the comparison cut's 17:36–17:44 raw-source join. They are working evidence; none is another release candidate. No media was removed or overwritten during this audit.

The [fresh Claude challenge](https://claude.ai/chat/cb77c05a-4e75-4aad-9b29-93346d72e829) was based on quotes and source links, not a media watch. Codex inadvertently saw the older Claude removal list during file inventory before locking its independent findings; see `consensus-review.md` for the full disclosure. Source checks are in `02_RESEARCH/codex-episode-02-raw-source-checks-2026-09-29.md`.

**Review remaining for preferred September 30 export:** Josh and Mary's continuous playback and listening at its joins; caption proofread; named-person comfort; and a final recheck of changeable product claims. Josh selected ep2hook, resolving the hook choice. The rights to the proposed theme were confirmed by Josh on 2026-09-28. No upload, schedule or publication is claimed.
