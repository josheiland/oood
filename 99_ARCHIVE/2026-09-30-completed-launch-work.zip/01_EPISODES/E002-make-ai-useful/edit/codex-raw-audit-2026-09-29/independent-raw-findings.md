# Episode 002 reshoot: Codex raw findings, before Claude challenge

**Historical provisional review.** Josh subsequently directed on 2026-09-29 that the five-hour usage-window exchange stay. The current removal judgment and preferred cut are in `consensus-review.md` and `README.md`; the provisional recommendation below is preserved for comparison.

Date: 2026-09-29. Source: `/Users/je/Movies/Episode 2 Raw.mp4`, 34:17.100, SHA-256 `087b52c20549f20118216a867005944948da8d39f013b3089789a987aa79b42d`.

This is a **provisional edit judgment**, not host approval. I reviewed the available transcript, sampled source frames, scanned the entire source video for decode errors/black frames and audio for long silence, and checked the claims below against primary product pages. I could not listen to the source audio in this environment. Proposed boundaries must be heard and checked frame by frame before rendering. I accidentally encountered a Claude removal list during file inventory before locking this document; therefore this is my judgment from the source evidence, **not a blind independent list**. The additional claims at 09:30–10:00 and 17:20–17:40 came from my separate claim review.

## Clear removals or spoken corrections

All times are approximate **raw source** times unless marked precisely. Keep adjoining reactions and the hosts' natural pace. Replace a line with a brief spoken pickup when possible; otherwise cut the narrowest complete utterance.

| Raw range | Flag | Reason and treatment |
|---|---|---|
| 00:00–00:02 | Recording pre-roll | Camera shows Mary drinking and Josh waiting; begin at first intentional on-air beat. Confirm the first word is intact. |
| 06:34.3–06:38.3 | False Granola price limit | “20 or 25 meetings per month” contradicts Granola's current free plan, which advertises unlimited meetings with limited history. Remove only the number/limit assertion; preserve the useful Granola example. |
| About 09:30–10:00 | Overstated skill definition | Josh twice says a skill is “just a document with text in it.” A Claude skill has a `SKILL.md` plus optional scripts and resources. Prefer a pickup: “At its simplest, a skill is saved instructions; it can also include scripts and reference files.” If no pickup, remove the two absolute statements while retaining the instructions explanation. This is a factual precision fix, not grounds to discard the whole skills segment. |
| 15:08.8–15:16.6 | Abandoned restart | Josh starts an intern/supervisees analogy, loses it, and restarts. Remove only the failed start if the next sentence stands alone. |
| 15:46.9–15:58.2 | False built-in claim | Mary presents Humanizer as built into Claude. The official built-in skill list does not include it. Preserve her experience using a custom/community skill and resume before “makes” rather than clipping that word. |
| About 17:20–17:40 | Overgeneralized usage limits | Josh says ChatGPT, Claude, and “most of these tools” give usage in each five-hour window. Claude uses five-hour sessions; ChatGPT limits vary by model and plan. Remove or redub the generalized clause, retaining the bedtime/usage joke. |
| 28:05.3–28:14.5 | Unsupported named accusation | Calling a particular Charlottesville shop's work “very clearly made by AI” is an unverified claim about an identifiable third party. Remove the name/attribution or the short exchange if it cannot be de-identified cleanly. Keep general opinions about AI design. |
| 30:33.8–31:17.1 | On-tape withdrawal | Mary says of the Canvas assignment story “I don't think I can use that example” and “I probably won't use that.” Treat that as her recorded boundary and omit the story, checking the join into the next topic. |
| 34:08.7–34:17.1 | Off-air tail | Conversation has ended; a hand obstructs the lens and the final seconds include a long pause. End after the audible goodbye. |

## Keep, with optional factual qualification

- **07:07–07:21 Granola outbound calls:** The core claim is correct for outbound calls made through Granola's iPhone dialer. Its wording could imply any ordinary phone call is captured; a small caption or show-note qualification can clarify the dialer requirement. Do not remove the whole exchange.
- Retain strong personal anecdotes, playful or spicy opinions, and host banter unless an assertion is demonstrably false or withdrawn by a host. The line about the Charlottesville shop is flagged because it assigns an unverified fact to an identifiable third party, not because it is critical or funny.
- No full-file picture blackout or decode failure was detected. Automated low-motion flags were not frozen frames on a frame-hash check. A complete audiovisual watch remains outstanding.

## Primary-source checks

- Granola [pricing](https://www.granola.ai/pricing), accessed 2026-09-29: free plan has unlimited meetings, with limited meeting history; [iPhone phone-call instructions](https://www.granola.ai/blog/how-to-take-meeting-notes-on-a-phone-while-walking-without-typing), accessed 2026-09-29: outbound calling through Granola's dialer.
- Anthropic [What are skills?](https://support.claude.com/en/articles/12512176-what-are-skills), accessed 2026-09-29: skill folder can contain instructions, scripts and resources; built-in examples do not include Humanizer.
- Anthropic [limit reset](https://support.claude.com/en/articles/17007452-what-is-a-limit-reset), accessed 2026-09-29: Claude session limit resets on a five-hour cycle. OpenAI [ChatGPT model usage](https://help.openai.com/en/articles/20001354-gpt-56-and-gpt-6-pro-in-chatgpt), accessed 2026-09-29: limits vary by model and plan.
