# Episode 002 reshoot: raw-footage removal review

**2026-09-29, for Josh and Mary.** Source times below refer to `/Users/je/Movies/Episode 2 Raw.mp4` (34:17.100), not the assembled-cut clock. The raw source is unchanged. This is a review list, not approval or proof of a finished export.

## Agreed changes before a final cut

| Raw source | Action | Why |
|---|---|
| **00:00.000–00:01.967** | Trim opening pre-roll. | Mary is drinking and Josh is waiting before the intentional opening. Confirm the first spoken word survives the join. |
| **06:34.267–06:38.267** | Remove Josh's “20 or 25 meetings per month” assertion. | Granola's current free Basic plan has **unlimited meetings** and 30-day note history. Preserve the rest of the example and the student-plan line. [Granola source](https://www.granola.ai/blog/granola-pricing-startups-free-trial-discounts) |
| **15:46.933–15:58.200** | Remove the claim that Humanizer is built into Claude. | Anthropic's pre-built skill list consists of document skills; Humanizer is not included. Keep Mary's own experience with the skill. Resume at **15:58.200**, preserving “makes”; the older 15:58.633 join clips that word. [Anthropic's list](https://support.claude.com/en/articles/12512180-use-skills-in-claude) |
| **30:33.800–31:17.100** | Remove Mary's Canvas anecdote. | She twice says on tape she will not use that example. Respect that recorded boundary; check the join into the following “where AI missed” point. |
| **34:08.667–34:17.100** | Trim after the goodbye. | Off-air comment, lens obstruction and lingering pause. |

## Conditional or optional edit

| Raw source | Judgment |
|---|---|
| **15:08.767–15:16.633** | Josh abandons and restarts the intern/supervisees analogy. A clean ~8-second polish trim is reasonable, and it is already absent from Claude's current assembly. It is **not** a factual error; keep it if the actual delivery is charming and the join feels forced. |
| **28:05.300–28:14.467** | The recorded remark names a Charlottesville shop and says its work was “very clearly made by AI.” The opinion can be spicy; the attribution to an identifiable shop is unverified. **Do not play the name attached to the allegation.** Claude prefers muting the name and keeping the subjective impression; Codex prefers removing the nine seconds if the edit cannot make the person/place unidentifiable and natural. Both agree the current named version should not remain. |

## Keep in the episode

- **09:29.200–09:46.260:** “A skill is just a document with text in it” is a simplified explanation of the most basic case, not an invented capability. Simple skills can be Markdown instructions, while others include scripts/resources. We agree **not** to cut this teaching exchange. [Anthropic](https://support.claude.com/en/articles/12512176-what-are-skills)
- **07:07–07:21:** The Granola outbound-call line is directionally correct. Keep it. If written notes or captions explain it, specify **outbound iPhone calls through Granola's built-in dialer**. [Granola](https://www.granola.ai/blog/how-to-take-meeting-notes-on-a-phone-while-walking-without-typing)
- **17:36.467–17:44.800:** Keep Josh's five-hour usage-window exchange and the bedtime joke. On 2026-09-29 Josh explicitly directed that the line stay. His current Codex account shows a five-hour primary usage window; [OpenAI's documentation](https://help.openai.com/en/articles/20001354-gpt-56-and-gpt-6-pro-in-chatgpt) also shows limits vary across ChatGPT plans and models, so this is conversational shorthand rather than a universal product rule. The “most folks” qualifier was not independently established. Josh's decision supersedes the Codex/Claude proposal to cut or rerecord it.
- Keep other personal examples, jokes, strong opinions and host reactions. No full-file blackout or decode error was found in the September 26 source.

## How the comparison was made

Codex documented its provisional findings in `independent-raw-findings.md` before a fresh Claude web-chat challenge, but accidentally opened an older Claude removal list earlier during file inventory. This was **not a blind comparison**. The [fresh Claude discussion](https://claude.ai/chat/cb77c05a-4e75-4aad-9b29-93346d72e829) reviewed the earlier seven cuts and Codex's two new claims. Claude initially considered the five-hour line optional; after Codex brought current OpenAI usage documentation, Claude agreed it needed an **audible correction**. Josh subsequently made the authoritative editorial choice to keep it. Claude judged the skill-definition line an acceptable beginner simplification; Codex accepted that judgment. The Granola phone line stays. Claude had only supplied quotes and links, not the source media, and did not listen or watch in that chat.

Codex read transcripts, sampled source frames, and scanned the full video for black frames/decode faults and audio for long silence. **No continuous audiovisual watch or listening proofread has been completed.** Technical QC cannot substitute for Josh and Mary's exact-export review.

The existing `jtan-full-002/episode-002-full-credits-hook-jtan-v2.mp4` omits the seven ranges above, keeps the five-hour exchange, and has no clipped “makes.” The **current preferred 33:14.267 host-review cut** is [Josh's selected ep2hook version](../codex-user-hook-2026-09-30/episode-002-full-review-v3.mp4), which replaces the credits cold open with his saved running exchange and preserves the main conversation, matching Episode 000 recurring cards/music and the same seven removals. The separate `episode-002-fact-corrected-codex-v1.mp4` in this folder removes an additional 8.333 seconds; its render and technical checks remain documented as a comparison only. Exact-export approval by both hosts remains open.
