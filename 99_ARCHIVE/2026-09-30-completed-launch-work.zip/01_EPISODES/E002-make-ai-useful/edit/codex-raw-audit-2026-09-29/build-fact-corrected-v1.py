#!/usr/bin/env python3
"""Build Codex's Episode 002 review version without changing jtan's files.

Reuses the tested September 26 source builder, adding one narrow factual trim.
Usage: python3 build-fact-corrected-v1.py <new-output.mp4>
"""

import importlib
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
JTAN_BUILDER = HERE.parent / "jtan-002"
sys.path.insert(0, str(JTAN_BUILDER))
builder = importlib.import_module("build-full")

# Raw frames 31694..31944 remove the unsupported common five-hour-window
# assertion while joining the completed "overnight" to "before I go to sleep".
# A CPU Whisper check of a stitched preview found both boundary words intact.
builder.REMOVALS.insert(
    3,
    (
        "ChatGPT, Claude and most tools do not share a universal five-hour usage window; "
        "ChatGPT limits vary by plan/model",
        31694, 1056.467, 31944, 1064.8,
    ),
)

if __name__ == "__main__":
    if len(sys.argv) != 2:
        raise SystemExit("usage: build-fact-corrected-v1.py <new-output.mp4>")
    output = Path(sys.argv[1])
    if output.exists():
        raise SystemExit(f"refusing to overwrite {output}")
    sys.argv[:] = [str(JTAN_BUILDER / "build-full.py"), "01-credits-bedtime", str(output)]
    builder.main()
    captions = output.with_suffix(".srt")
    contents = captions.read_text()
    marker = "before I go to sleep, I like to like,"
    if contents.count(marker) != 1:
        raise RuntimeError("expected caption at the five-hour join was not found once")
    captions.write_text(contents.replace(marker, "Before I go to sleep, I like to like,", 1))
