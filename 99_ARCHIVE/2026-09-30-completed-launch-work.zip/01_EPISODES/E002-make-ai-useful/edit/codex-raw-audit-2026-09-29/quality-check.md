# Episode 002 Codex v1 comparison: technical check and status

Checked 2026-09-29. Output: `episode-002-fact-corrected-codex-v1.mp4`.

| Check | Result |
|---|---|
| Source | September 26 raw, SHA-256 `087b52c20549f20118216a867005944948da8d39f013b3089789a987aa79b42d`; builder verified the hash. |
| Output identity | SHA-256 `26b0a98b6ced7995043cf1244397e8ff7ec8f801f4965e0bbda8c1fb92f020af`; 703,006,071 bytes. |
| Picture | 1920 × 1080, H.264, 30 fps, 59,553 frames; sampled hook, title, both sides of the new join and outro render. The raw had no detected full-frame blackout. |
| Audio | AAC stereo; EBU R128 analysis: −16.0 LUFS integrated, 4.8 LU range, −1.4 dBTP true peak. Both source voices were centered by the existing dialogue process. |
| Timeline | 33:05.100; 12 chapters are embedded and in range. Eight raw-source removals total, including a new 8.333-second correction at raw 17:36.467–17:44.800. |
| Decode | Full-file video and audio decode with error-stop succeeded (exit 0). |
| Captions | 570 cues; all start before end, remain in export bounds and are ordered. Searches found no “five hour,” “20 or 25,” “built into Claude,” “clearly made by AI,” “Canvas,” or “supervisees” in the exported SRT. |
| New join | A CPU Whisper check of a short preview and the finished export hears “overnight” → “before I go to sleep” with no clipped boundary word. Sampled frames show a normal two-host jump cut. This is machine and visual evidence, **not a human listening pass**. |

## Editorial status

This check applies only to the **Codex v1 comparison cut**. It confirms the five-hour line is absent from that cut; Josh later directed that the line stay. The preferred review version is the already rendered 33:13.433 `../jtan-full-002/episode-002-full-credits-hook-jtan-v2.mp4`, whose own README records its technical checks. The shop remark is removed in both versions. The simple-skills and Granola outbound-call explanations are retained as described in `consensus-review.md`.

No continuous audiovisual watch or auditory caption proofread has been completed by Codex. Josh and Mary have not approved either exact export, selected a final hook, signed off on named personal examples, scheduled or published it. Product details should be rechecked on publication day.
