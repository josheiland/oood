#!/usr/bin/env python3
"""Build SRT/VTT captions and a readable transcript for the E002 v2 export.

Words come from whisper.cpp small.en with DTW token timestamps, run in 30 s windows over each kept
source range (intermediate/v2/tools/capwords.json), then moved onto the export timeline. Timing is
machine-derived (roughly +/-0.15 s); wording corrections are listed in CORRECTIONS.
"""
import json, re
from pathlib import Path
HERE = Path(__file__).resolve().parent
EDL = json.loads((HERE / 'intermediate/v2/edl-with-export-times.json').read_text())
CAP = json.loads((HERE / 'intermediate/v2/tools/capwords.json').read_text())
FPS = 30
CORRECTIONS = [
    (r'\bwant to go to save\b', 'want to go to sleep'), (r'\b[Mm]y credit,? (like )?run over\b', 'My credits, runs over'), (r'\bsleep and just like\b', 'sleep and Josh, like'), (r'\bdyslexia phi\b', 'Dyslexify'), (r'\bRun Your City scale\b', 'Run Your City skill'), (r'\bClaude design\b', 'Claude Design'), (r'\bWhen When\b', 'When'),
    (r'\bwww\.\S*?\.org', 'runyourcity.org'),
    (r'\b(Renier|Rener|Renner|render|rent your severe|when your|run your) (City|city)\b', 'Run Your City'),
    (r'\brent your severe\b', 'Run Your City'),
    (r'\bcloud design\b', 'Claude Design'), (r'\bCloud design\b', 'Claude Design'),
    (r'\bchat GPT cloud\b', 'ChatGPT, Claude'), (r'\bcloud\b', 'Claude'),
    (r'\byour call out or chat\b', 'your Claude or chat'),
    (r'\bChad\b', 'Chat'), (r'\bJim and I\b', 'Gemini'),
    (r'\b[Ww]hisper [Ff]low\b', 'Wispr Flow'), (r'\bgranola\b', 'Granola'),
    (r'\bM dashes\b', 'em dashes'), (r'\bbrand scale\b', 'brand skill'),
    (r'\bR Y C\b', 'RYC'), (r'\bRIC\b', 'RYC'), (r'\b(on )?dyslexia five\b', 'Dyslexify'),
    (r'\b[Cc]hat GPT\b', 'ChatGPT'), (r'\bUSB\b', 'GSB'),
]
def fix(t):
    for a, b in CORRECTIONS:
        t = re.sub(a, b, t)
    return re.sub(r'\s+', ' ', t).strip()

bysrc = {}
for sid, w, t in CAP:
    bysrc.setdefault(sid, []).append((w, t))
cues = []
for s in EDL['segments']:
    base = s['out_in_frame'] / FPS
    raw = sorted({(w, t) for w, t in bysrc.get(s['id'], []) if s['src_in'] - 0.1 <= t < s['src_out']}, key=lambda x: x[1])
    ws = []
    for i, (w, t) in enumerate(raw):
        nxt = raw[i + 1][1] if i + 1 < len(raw) else s['src_out']
        a = max(t, s['src_in']); b = min(nxt, t + 0.8, s['src_out'])
        ws.append((w, base + a - s['src_in'], base + b - s['src_in']))
    cur = []
    for i, w in enumerate(ws):
        cur.append(w)
        text = ' '.join(x[0] for x in cur)
        nxt_gap = ws[i + 1][1] - w[2] if i + 1 < len(ws) else 9
        end_sentence = w[0][-1] in '.?!'
        if len(text) > 68 or (end_sentence and len(text) > 30) or nxt_gap > 0.7 or cur[-1][2] - cur[0][1] > 5.5 or i + 1 == len(ws):
            cues.append([cur[0][1], max(cur[-1][2], cur[0][1] + 0.8), text]); cur = []
for i in range(len(cues) - 1):  # no overlaps
    cues[i][1] = min(cues[i][1], cues[i + 1][0] - 0.02)

def two_lines(t, width=42):
    if len(t) <= width:
        return t
    best = min((abs(i - len(t) / 2), i) for i, c in enumerate(t) if c == ' ')[1]
    return t[:best] + '\n' + t[best + 1:]

def stamp(t, sep):
    h, r = divmod(t, 3600); m, s = divmod(r, 60)
    return f'{int(h):02d}:{int(m):02d}:{s:06.3f}'.replace('.', sep)

srt, vtt, md = [], ['WEBVTT', ''], ['# Episode 2 v2 transcript (machine, corrected names)', '',
                                     'Timed to episode-02-final-cut-v2.mp4. Speaker labels omitted: the recording is a single mixed track and speakers are not machine-identified. Treat uncertain words as approximate.', '']
prev = '.'
for i, (a, b, t) in enumerate(cues, 1):
    t = fix(t)
    if prev[-1:] in '.?!':
        t = t[:1].upper() + t[1:]
    prev = t
    srt += [str(i), f'{stamp(a, ",")} --> {stamp(b, ",")}', two_lines(t), '']
    vtt += [f'{stamp(a, ".")} --> {stamp(b, ".")}', two_lines(t), '']
    md.append(f'[{int(a // 60):02d}:{int(a % 60):02d}] {t}')
(HERE / 'episode-02-captions-v2.srt').write_text('\n'.join(srt))
(HERE / 'episode-02-captions-v2.vtt').write_text('\n'.join(vtt))
(HERE / 'episode-02-transcript-v2.md').write_text('\n'.join(md) + '\n')
print(len(cues), 'cues')
