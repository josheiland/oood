# Episode 2 — chapters

Draft chapter list for the completed edit; not a publication claim.

00:00 Make AI useful
00:53 Projects: background
04:21 Connectors: access
06:53 Bonus: voice input
09:14 When to keep it personal
11:21 Meeting notes to follow-up
12:45 Skills: reusable directions
15:01 Build, test, and share skills
21:46 Recap and one embarrassing prompt
