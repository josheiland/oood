# Episode 2 v3 chapters

- 00:00:00.000 Cold open
- 00:00:06.566 Meet your AI intern
- 00:01:45.217 Projects: background
- 00:05:22.427 Connectors: access
- 00:08:39.982 Skills: reusable directions
- 00:20:13.870 Recap
- 00:20:39.340 What we built with AI
- 00:27:58.287 Where AI missed
- 00:30:01.947 What's next
