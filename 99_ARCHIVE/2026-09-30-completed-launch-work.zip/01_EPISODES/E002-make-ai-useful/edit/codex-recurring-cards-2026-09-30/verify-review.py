#!/usr/bin/env python3
"""Check exact audio, timing, copied captions, chapters and card boundaries."""
from pathlib import Path
import hashlib
import json
import subprocess

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[3]
SOURCE = ROOT / '01_EPISODES/E002-make-ai-useful/edit/jtan-full-002/episode-002-full-credits-hook-jtan-v2.mp4'
OUTPUT = HERE / 'episode-002-full-review-v2.mp4'

def digest(path):
    with path.open('rb') as f:
        return hashlib.file_digest(f,'sha256').hexdigest()

def probe(path):
    return json.loads(subprocess.check_output(['ffprobe','-v','error','-show_streams',
        '-show_format','-show_chapters','-of','json',str(path)]))

def audio_hash(path):
    return subprocess.check_output(['ffmpeg','-nostdin','-v','error','-i',str(path),
        '-map','0:a:0','-c:a','copy','-f','hash','-hash','sha256','-']).decode().strip()

def packet_time_hash(path):
    data=subprocess.check_output(['ffprobe','-v','error','-select_streams','a:0',
        '-show_packets','-show_entries','packet=pts,dts,duration,size','-of','csv=p=0',str(path)])
    return hashlib.sha256(data).hexdigest()

def main():
    a,b=probe(SOURCE),probe(OUTPUT)
    video=next(s for s in b['streams'] if s['codec_type']=='video')
    audio=next(s for s in b['streams'] if s['codec_type']=='audio')
    assert int(video['nb_frames'])==59803
    assert video['width']==1920 and video['height']==1080
    assert video['r_frame_rate']=='30/1'
    assert abs(float(video['duration'])-59803/30)<.001
    assert abs(float(audio['duration'])-59803/30)<.001
    assert a['chapters']==b['chapters']
    ah,bh=audio_hash(SOURCE),audio_hash(OUTPUT)
    assert ah==bh,(ah,bh)
    apt,bpt=packet_time_hash(SOURCE),packet_time_hash(OUTPUT)
    assert apt==bpt,(apt,bpt)
    srt=OUTPUT.with_suffix('.srt')
    assert digest(srt)==digest(SOURCE.with_suffix('.srt'))
    assert 'five hour' in srt.read_text().lower()
    frames=[188,189,346,347,59479,59480,59787,59802]
    for number in frames:
        subprocess.run(['ffmpeg','-nostdin','-v','error','-n','-ss',f'{number/30:.9f}',
            '-i',str(OUTPUT),'-frames:v','1',str(HERE/f'frame-{number:05}.jpg')],check=True)
    with (HERE/'full-decode.log').open('x') as log:
        subprocess.run(['ffmpeg','-nostdin','-v','error','-xerror','-i',str(OUTPUT),
            '-map','0:v:0','-map','0:a:0','-f','null','-'],stdout=log,stderr=log,check=True)
    result={
        'date':'2026-09-30','source':str(SOURCE),'output':str(OUTPUT),
        'source_sha256':digest(SOURCE),'output_sha256':digest(OUTPUT),
        'output_bytes':OUTPUT.stat().st_size,'video_frames':59803,
        'duration_seconds':float(b['format']['duration']),
        'audio_packet_sha256':bh,'audio_packet_timing_sha256':bpt,
        'audio_identical':True,'chapters_identical':True,'chapter_count':len(b['chapters']),
        'caption_sha256':digest(srt),'captions_identical':True,'five_hour_line_present':True,
        'full_decode':'passed','sampled_frames':frames,
        'intro_frames':[189,347],'outro_frames':[59480,59803],
        'continuous_human_review':False,
    }
    with (HERE/'quality-check.json').open('x') as f:json.dump(result,f,indent=2)
    print(json.dumps(result,indent=2))

if __name__=='__main__':
    main()
