#!/usr/bin/env python3
"""Replace recurring cards at verified closed GOPs; copy dialogue and music."""
from pathlib import Path
import hashlib
import json
import shutil
import subprocess

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[3]
SOURCE = ROOT / '01_EPISODES/E002-make-ai-useful/edit/jtan-full-002/episode-002-full-credits-hook-jtan-v2.mp4'
OUTPUT = HERE / 'episode-002-full-review-v2.mp4'
EXPECTED_SHA = '598a11f1a33c487a082ea74551671a6e5bb1b6acbd506f4c3c98e4b9d14016da'
TOTAL = 59803
INTRO_START, BODY_START, LAST_BODY_KEY, OUTRO_START = 189, 347, 59460, 59480

def digest(path):
    with path.open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()

def run(args):
    subprocess.run(['ffmpeg', '-nostdin', '-hide_banner', '-loglevel', 'warning', '-n', *args], check=True)

def check_frames(path, count):
    data = json.loads(subprocess.check_output(['ffprobe','-v','error','-select_streams','v:0',
            '-show_entries','stream=nb_frames,duration','-of','json',str(path)]))
    assert int(data['streams'][0]['nb_frames']) == count, (path, data)
    assert abs(float(data['streams'][0]['duration']) - count/30) < .001, (path, data)

def main():
    if OUTPUT.exists():
        raise FileExistsError(OUTPUT)
    assert digest(SOURCE) == EXPECTED_SHA
    # The keys at frames 0, 189, 347 and 59460 were read from this exact source.
    hook, intro, body, tail = [HERE / name for name in
            ('copied-hook.mp4','updated-intro.mp4','copied-body.mp4','updated-tail.mp4')]
    for start, count, target in [(0, INTRO_START, hook),
            (BODY_START, LAST_BODY_KEY-BODY_START, body)]:
        run(['-ss',f'{start/30:.9f}','-i',str(SOURCE),'-map','0:v:0',
             '-an','-map_metadata','-1','-map_chapters','-1','-frames:v',str(count),
             '-c:v','copy','-video_track_timescale','15360',str(target)])
        check_frames(target, count)
    encode = ['-c:v','libx264','-threads','4','-preset','veryfast','-crf','18',
              '-profile:v','high','-level:v','4.0','-pix_fmt','yuv420p',
              '-r','30','-fps_mode','cfr','-video_track_timescale','15360',
              '-color_primaries','bt709','-color_trc','bt709','-colorspace','bt709']
    run(['-loop','1','-framerate','30','-i',str(HERE/'intro-card.png'),
         '-frames:v',str(BODY_START-INTRO_START),'-an',*encode,str(intro)])
    check_frames(intro, BODY_START-INTRO_START)
    tail_frames = TOTAL-LAST_BODY_KEY
    pre_outro = OUTRO_START-LAST_BODY_KEY
    run(['-ss',f'{LAST_BODY_KEY/30:.9f}','-i',str(SOURCE),
         '-loop','1','-framerate','30','-i',str(HERE/'outro-card.png'),
         '-filter_complex_threads','2','-filter_complex',
         f"[1:v]format=yuv420p,fade=t=out:st={(tail_frames-15)/30:.9f}:d=0.5[card];"
         f"[0:v][card]overlay=0:0:enable='gte(n,{pre_outro})',format=yuv420p[v]",
         '-map','[v]','-an','-map_metadata','-1','-map_chapters','-1',
         '-frames:v',str(tail_frames),*encode,str(tail)])
    check_frames(tail, tail_frames)
    pieces=[(hook,INTRO_START),(intro,BODY_START-INTRO_START),
            (body,LAST_BODY_KEY-BODY_START),(tail,tail_frames)]
    concat=HERE/'picture-concat.txt'
    with concat.open('x') as f:
        for path,count in pieces:
            f.write(f"file '{path.name}'\nduration {count/30:.9f}\n")
    run(['-f','concat','-safe','0','-i',str(concat),'-i',str(SOURCE),
         '-map','0:v:0','-map','1:a:0','-map_metadata','1','-map_chapters','1',
         '-c','copy','-video_track_timescale','15360','-movflags','+faststart',str(OUTPUT)])
    check_frames(OUTPUT,TOTAL)
    for suffix in ('.srt','.chapters.md'):
        target=OUTPUT.with_suffix(suffix)
        if target.exists():raise FileExistsError(target)
        shutil.copy2(SOURCE.with_suffix(suffix),target)
    edl=json.loads(SOURCE.with_suffix('.edl.json').read_text())
    edl['card_update']={
        'date':'2026-09-30','base_export':str(SOURCE),'base_export_sha256':EXPECTED_SHA,
        'intro_frames':[INTRO_START,BODY_START],'outro_frames':[OUTRO_START,TOTAL],
        'copied_picture_frames':[[0,INTRO_START],[BODY_START,LAST_BODY_KEY]],
        'reencoded_picture_frames':[[INTRO_START,BODY_START],[LAST_BODY_KEY,TOTAL]],
        'intro_png_sha256':digest(HERE/'intro-card.png'),
        'outro_png_sha256':digest(HERE/'outro-card.png'),
        'audio':'Original AAC copied in full, including Episode 000 theme music',
        'final_picture_fade_frames':15,
    }
    OUTPUT.with_suffix('.edl.json').write_text(json.dumps(edl,indent=2)+'\n')
    print(OUTPUT)

if __name__=='__main__':
    main()
