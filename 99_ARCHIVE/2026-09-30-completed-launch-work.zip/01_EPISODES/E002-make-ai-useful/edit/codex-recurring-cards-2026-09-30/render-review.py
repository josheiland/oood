#!/usr/bin/env python3
"""Apply September 30 recurring cards to the checked Episode 002 assembly."""
from pathlib import Path
import hashlib
import json
import shutil
import subprocess

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[3]
SOURCE = ROOT / '01_EPISODES/E002-make-ai-useful/edit/jtan-full-002/episode-002-full-credits-hook-jtan-v2.mp4'
CARDS = ROOT / '03_ASSETS/codex-mono-mirrored-3digit'
OUTPUT = HERE / 'episode-002-full-review.mp4'
SOURCE_SHA = '598a11f1a33c487a082ea74551671a6e5bb1b6acbd506f4c3c98e4b9d14016da'
TOTAL = 59803
INTRO_START, INTRO_END, OUTRO_START = 189, 347, 59480

def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def main():
    if OUTPUT.exists():
        raise FileExistsError(OUTPUT)
    if digest(SOURCE) != SOURCE_SHA:
        raise RuntimeError('Source differs from the checked Episode 002 assembly')
    for name in ('intro-card.png', 'outro-card.png'):
        target = HERE / name
        if target.exists():
            raise FileExistsError(target)
        shutil.copy2(CARDS / name, target)
    config = json.loads((CARDS / 'episode-000.json').read_text())
    config['episode_number'] = '002'
    (HERE / 'card-copy.json').write_text(json.dumps(config, indent=2) + '\n')
    command = [
        'ffmpeg', '-nostdin', '-hide_banner', '-loglevel', 'warning', '-n',
        '-i', str(SOURCE),
        '-loop', '1', '-framerate', '30', '-i', str(HERE / 'intro-card.png'),
        '-loop', '1', '-framerate', '30', '-i', str(HERE / 'outro-card.png'),
        '-filter_complex_threads', '2', '-filter_complex',
        f"[0:v][1:v]overlay=0:0:enable='between(n,{INTRO_START},{INTRO_END - 1})'[intro];"
        f"[2:v]format=yuv420p,fade=t=out:st={(TOTAL - 15) / 30:.9f}:d=0.5[outro];"
        f"[intro][outro]overlay=0:0:enable='between(n,{OUTRO_START},{TOTAL - 1})',format=yuv420p[v]",
        '-map', '[v]', '-map', '0:a:0', '-map_metadata', '0', '-map_chapters', '0',
        '-frames:v', str(TOTAL), '-r', '30', '-fps_mode', 'cfr',
        '-c:v', 'libx264', '-threads', '8', '-preset', 'veryfast', '-crf', '18',
        '-profile:v', 'high', '-pix_fmt', 'yuv420p',
        '-color_primaries', 'bt709', '-color_trc', 'bt709', '-colorspace', 'bt709',
        '-c:a', 'copy', '-movflags', '+faststart',
        '-progress', str(HERE / 'render-progress.log'), str(OUTPUT),
    ]
    (HERE / 'render-command.json').write_text(json.dumps(command, indent=2) + '\n')
    with (HERE / 'render-log.txt').open('x') as log:
        subprocess.run(command, stdout=log, stderr=log, check=True)
    for suffix in ('.srt', '.chapters.md'):
        destination = OUTPUT.with_suffix(suffix)
        if destination.exists():
            raise FileExistsError(destination)
        shutil.copy2(SOURCE.with_suffix(suffix), destination)
    edl = json.loads(SOURCE.with_suffix('.edl.json').read_text())
    edl['card_update'] = {
        'date': '2026-09-30', 'base_export': str(SOURCE), 'base_export_sha256': SOURCE_SHA,
        'intro_frames': [INTRO_START, INTRO_END], 'outro_frames': [OUTRO_START, TOTAL],
        'intro_png_sha256': digest(HERE / 'intro-card.png'),
        'outro_png_sha256': digest(HERE / 'outro-card.png'),
        'audio': 'Copied AAC packets; includes existing Episode 000 theme music',
        'final_picture_fade_frames': 15,
    }
    OUTPUT.with_suffix('.edl.json').write_text(json.dumps(edl, indent=2) + '\n')
    print(OUTPUT)

if __name__ == '__main__':
    main()
