# Episode 002 with September 30 recurring cards

**Earlier credits-hook review:** [episode-002-full-review-v2.mp4](episode-002-full-review-v2.mp4), 33:13.433, 1920 × 1080, 30 fps. Rendered and technically checked on 2026-09-30. Superseded for current review by [Josh's selected ep2hook version](../codex-user-hook-2026-09-30/episode-002-full-review-v3.mp4), 33:14.267. Exact-export host approval remains open.

Josh asked whether Episode 002 incorporates the latest Episode 000 cards and theme music. The September 29 jtan cut already used the same theme music, but retained the old episode-specific intro and top labels. This new Codex export uses the exact current Episode 000 intro and outro stills: `FIGURING OUT AI TOGETHER`, hidden top labels, and outro prompts raised 48 pixels. The final half-second picture fade is preserved.

The source is the unchanged `../jtan-full-002/episode-002-full-credits-hook-jtan-v2.mp4`. Hook 01, raw order, the five-hour usage exchange, dialogue, music and all seven prior removals retain their timing. The [removal review](../codex-raw-audit-2026-09-29/consensus-review.md) documents the judgments and Josh's keep decision. No jtan file was changed.

## Package and review

- `episode-002-full-review-v2.mp4`: earlier credits-hook review video.
- Matching `.srt`, `.chapters.md` and `.edl.json`: copied caption text/timing, all 12 chapters, and reversible source ranges plus the card update.
- `card-copy.json`, `intro-card.png`, `outro-card.png`: snapshot of the approved recurring artwork. Editable native-font sources remain in `03_ASSETS/codex-mono-mirrored-3digit/`.
- `quality-check.md`, `quality-check.json`, `music-match.json` and `card-boundary-contact-sheet.jpg`: technical and sampled visual evidence.
- `render-card-splice.py` and `verify-review.py`: reproducible local build and checks; refuse to overwrite output files.

The card cue ranges are 00:06.300–00:11.567 and 33:02.667–33:13.433. The original hook and main conversation picture are copied through verified keyframe boundaries except for the final 20 conversation frames adjoining the outro, which are reencoded with the card. The full original AAC audio is copied without any change in packet content or timing.

Continuous host viewing/listening, machine-caption proofread, final hook choice and named-person comfort remain open. No upload or publication occurred. Josh's planned platform subscribe and recommended-video elements have not been added.

The copied video sections and short card renders are rebuild intermediates. `interrupted-picture-pass.mp4` and `render-review.py` record an earlier stopped full-picture pass; they are not review candidates. They remain preserved under the project's no-cleanup-without-Josh rule.
