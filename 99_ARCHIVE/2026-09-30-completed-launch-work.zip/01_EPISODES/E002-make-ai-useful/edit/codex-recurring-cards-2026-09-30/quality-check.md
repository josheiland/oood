# Episode 002 recurring cards: checked export

Checked 2026-09-30. Exact file: `episode-002-full-review-v2.mp4`.

| Check | Result |
|---|---|
| Video | 1920 × 1080, H.264, 30 fps, 59,803 frames, 33:13.433. Full video/audio decode passed. |
| Export identity | 706,379,526 bytes; SHA-256 `fa529a038374cc2e426e67278808af9e7955fcff9d7329501cc32703421d4e83`. |
| Base export | Unchanged jtan v2, SHA-256 `598a11f1a33c487a082ea74551671a6e5bb1b6acbd506f4c3c98e4b9d14016da`. |
| Audio | Full AAC packet payload and packet timestamp hashes match the base. The base's recorded −16.0 LUFS / −1.4 dBTP measurement therefore applies; no new audio processing was performed. |
| Theme music | Decoded comparisons against current Episode 000 music gave correlation 0.99978 for the intro and 0.99927 for the outro, with zero offset and essentially identical volume. This is signal evidence, not a listening pass. |
| Cards | Exact current Episode 000 PNG snapshots. Intro frames 189–346; outro frames 59,480–59,802. Sampled frames show the recurring tagline, hidden top labels, raised prompts and final half-second fade. |
| Picture preservation | Hook frames 0–188 and body frames 347–59,459 are copied. The new cards and final 20 conversation frames before the outro are reencoded. |
| Timeline | All 12 embedded chapters equal the base, including the same body and outro start. |
| Captions | Matching SRT is byte-identical to the base (571 cues). Five-hour line remains present. Caption listening proof remains open. |
| Editorial | Same hook and seven raw-source removals as the fuller cut; no added dialogue cut. |

Ready for host review. No continuous human audiovisual pass has been completed for this export. Host approval, caption listening proof, hook selection and named-person comfort are not established by these checks. No platform upload or publication was performed.
