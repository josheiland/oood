# Episode 2 v2 transcript (machine, corrected names)

Timed to episode-02-final-cut-v2.mp4. Speaker labels omitted: the recording is a single mixed track and speakers are not machine-identified. Treat uncertain words as approximate.

[00:00] Like, I'll be tired and want to go to sleep and Josh, like, no, no, no.
[00:02] My credits, runs over to the laptop.
[00:04] It's like, no, I got to like send it off to do something useful.
[00:07] And we're live.
[00:11] We're back on this episode of OOD.
[00:15] O-O-O-D.
[00:17] Yeah, it doesn't roll off the tongue.
[00:19] Out of our depth. Triple OD. We are going into the kind of
[00:24] fundamentals that we keep coming back to, so there's a lot of stuff in
[00:28] AI, and I think one of the things that at I get annoyed by is
[00:34] I think there's so many things that you can learn and you can build and
[00:37] you can spend so much time learning and building, but that I don't keep
[00:41] coming back to. I don't keep using over and over, but projects, connectors,
[00:45] and skills is something that I think we should all have.
[00:49] I think it just, everyone needs to have them built out.
[00:52] It saves so much time. Totally.
[00:55] Yeah, I think these are definitely no regrets things that will, what we
[00:58] like to say is take your AI tool from being a fresh intern, showing up.
[01:04] About the metaphor. You know, like we're talking freshmen intern.
[01:07] Mm-hmm, super ripe, super ripe.
[01:11] To, you know, six months post-grad, you know, at this point, maybe getting
[01:16] promoted to, you know, full-time.
[01:18] Maybe. Let's not jump the gun. but at least like up to speed on what it
[01:22] is that you do what you need from them.
[01:24] Well connected with the tools they need to be successful and actually
[01:26] useful. So yeah, if you if you follow this advice on projects, connectors
[01:31] and skills, you should get your and turn up that learning curve real quick,
[01:35] the intern being your AI. And okay, all right.
[01:38] So let me talk to the high level.
[01:41] And then we can go down our rabbit holes.
[01:44] Projects. It gives your AI context.
[01:47] So a project is
[01:51] if we go back to this intern metaphor, which I frickin' love because I'm
[01:55] just a people person, but AI doesn't have feelings and we have to remember
[01:58] that anyway beside the point we're already in the rabbit holes.
[02:02] Our intern comes in, knows nothing.
[02:04] I like to use a nonprofit as an example because we're trying to get people
[02:08] up to speed all the time. We also have thousands of volunteers, but
[02:14] no one gets paid. So how much we're able to do is the biggest driver of
[02:19] our impact. So speed more efficient is really the
[02:25] biggest lever we have to deepen our impact for the nonprofit.
[02:29] It's called Run Your City. When we onboard someone new, we want them
[02:34] to know our mission, we want them to know our reach, we want them to know
[02:36] where our programs are, like all the basic things that aren't really going
[02:39] to change. That's what you want to put in your project.
[02:43] It's basically like if you gave an intern a desk and you put on
[02:48] that desk the most important things that they cannot miss.
[02:52] What you don't want to do is overload the project with so many different
[02:57] files and just give it everything because if we use the metaphor, you
[03:00] take it back to your desk and if it has everything in your desk, you don't
[03:03] know which one to trust, which one's outdated, which one's more important,
[03:06] which one's not. And you can only have so much context.
[03:09] And so you want to use it smart.
[03:11] You want projects to be largely things that remain unchanged.
[03:14] And if they do change, like the number of kids that we reach in the project,
[03:19] the file instructions, it says, "Hey, go to our website, runyourcity.org,
[03:25] and pull down the number of kids, the number of volunteers, anytime you
[03:28] need that." And I think that's a huge unlock.
[03:31] Obviously we have the project for Runor City, the nonprofit.
[03:35] We had a project for wedding planning.
[03:38] I have projects for my classes.
[03:41] Really anything that you want specific, focused context on,
[03:47] get in a project. What else would you do?
[03:49] Totally. Yeah. I mean, a project is really just a folder, right?
[03:52] So like Mary said, there's instructions that you can provide for that
[03:55] folder, which gives it the high level information.
[03:58] Uh, typically you can also attach files to that, essentially just putting
[04:02] files in that folder that then any chats or any tasks within that folder
[04:06] will have easy access to that information going forward.
[04:08] So historically, you know, you could put a file in there, but it would
[04:13] be mostly static. Some of these tools now that you actually attach it
[04:16] to like Google Docs or other files in Google Drive so it can stay a little
[04:20] bit more up to date and it'll pull updates occasionally.
[04:23] Totally. And I think the reason you'd want it, like you don't want to
[04:27] do a product for everything, but what you do is when you want, you don't
[04:30] want the generic answers and using it a lot.
[04:32] So another project I have is like kind of staying fit.
[04:36] I love exercising. I usually have some race or something around the corner.
[04:42] And when I ask, you know, normal chat, hey, what type of run should I
[04:46] do today? Or, you know, be like, year over training.
[04:48] Like honestly, chat, I ran like one time, like a week ago.
[04:51] No, I'm not, but it's going on kind of the general average.
[04:55] And so what I really like is it knows, you know, okay, I used to run in
[04:59] college. I can't run that much.
[05:01] I wait lift every day. And it then tailors what it's saying to me and
[05:05] same with like hydration and fueling and stuff.
[05:08] And I think that's the fun part about projects is this clear kind of room
[05:13] that it focuses in on and has context that doesn't change.
[05:18] So it's a single setup, you do it once, you go back to it a lot, it's
[05:21] fun. Then we have connectors. Connectors are also a single setup.
[05:26] You do it once, you can use it a lot.
[05:28] And what connectors are, are they just give access to other tools that
[05:31] you use. So I have connector from my Claude to
[05:38] Google Calendar, to Slack, to Gmail, to Granola,
[05:44] which is another tangent, but Granola is the note-taking app that we use,
[05:48] or note-taking is maybe the wrong word.
[05:50] It records meetings for us.
[05:52] Transcribes the whole meeting and then generates a summary and follow-ups.
[05:56] Obviously you want to make sure you have the consent of anybody that you're
[05:58] recording. That's like a legal requirement in some states and just like
[06:02] the right thing to do in general, but we found it super useful in our
[06:06] nonprofit and like meetings at school for different orgs to be able to
[06:10] just be fully present and focused in that meeting and not have to worry
[06:13] about taking down all the notes and then having a beautiful summary as
[06:16] well as the full transcript afterwards that you can then look back back
[06:19] at, or to your point feed into your Claude or chat and just tell it, hey,
[06:23] look at the notes from the meeting I had a couple hours ago and drop the
[06:27] follow-up emails and any other to-do items, that kind of thing.
[06:29] Totally. It's fun because Claude can be kind of this anchor and able to
[06:33] tap into Notion or Granola or Slack or anything that you use and actually
[06:38] do action based off of it.
[06:40] One thing that I know is helpful for us, and I don't know if it's a little
[06:44] bit of a tangent, but Composio, do you still need to do that, or it is
[06:47] now? Yeah. So, Composio is kind of related to the connectors, and so
[06:53] historically, both chat and Claude will only let you connect one Google
[06:56] account. ChatGPT has actually changed that, where now you can add multiple
[07:00] Gmail's. has And Claude changed that?
[07:02] The latest that I checked, Claude still only lets you use one Gmail and
[07:05] one Slack and that kind of thing.
[07:06] And so, Composio is this third party tool that I found super useful because-
[07:12] Like website. a Yeah, exactly. It's a website that lets you build a collection
[07:15] of different accounts. And so, then what I do is I just connect my Clod
[07:20] to Composio, and then it can go through Composio to now get to all my
[07:24] different email addresses and my different Slack accounts.
[07:26] And so, it's kind of like a workaround to give it access to more accounts
[07:29] than you could natively within Claude.
[07:31] And it's totally free. I don't pay anything for it.
[07:33] I think, you know, I'm sure there's some limit to it, but I've never gotten
[07:36] close to hitting it. So definitely recommend that to folks.
[07:38] If you are finding that, you know, for example, I have my personal email,
[07:42] my school email, my nonprofit email.
[07:44] And so it was always a pain to me that, you know, I could set up one within
[07:48] Claude, but the others I would have to send screenshots or do a lot more
[07:50] manual work to give it context.
[07:52] Whereas now through Composio, I can more natively pull all that in.
[07:55] So that's been a big, a big game changer for me.
[07:57] Hopefully Claude will build in the ability to do that natively going forward.
[08:00] But it is also a nice thing where when you talk about the ability to use
[08:04] different tools without having to do all the manual set up of like connecting
[08:08] all your accounts, like say that Gemini gets a lot better and I want to
[08:12] start using it. Right now I have to go in and like manually set up 40
[08:15] different accounts. but if Gemini has a connector to Composio, then I
[08:19] can just set that up, and now it has access to everything off the bat.
[08:23] So, yeah, that's another definitely-- I You that tool set it up for me
[08:25] and I. Yeah, definitely a game changer.
[08:28] And setting it up is just honestly clicking through.
[08:30] Yeah. It's quite easy. It's super quick.
[08:32] I love it.
[08:33] And we can go in a little bit more use cases, but just to kind of round
[08:37] out our foundations, then we have skills.
[08:41] You want to give them a download?
[08:42] Yeah, totally. So I think of skills as
[08:45] a shortcut, essentially, to help your AI tool better execute any kind
[08:49] of repeatable task that you might want to tap it in for.
[08:52] So kind of drawing the distinction between the project instructions versus
[08:56] the skills, I think of, like you said earlier, things like our mission
[08:59] statement for Rent Your City, our nonprofit, or our last annual report,
[09:03] I'll go ahead and stick in the project instructions or files, because
[09:07] that's going to be broadly applicable across almost any chat, whereas
[09:10] there might be some really niche use case.
[09:12] Like for example, I help set up all of our bank accounts for our new chapters.
[09:15] And so if we have, you know, 20 new chapters launching across the US,
[09:19] we use a platform called Mercury for our banking.
[09:22] And so historically I would have to go in and create a new profile within
[09:27] Mercury, invite the chapter via their email to claim that profile, create
[09:31] a new bank account, create a debit card, tie the bank account to the profile,
[09:35] like really manual process. And so what I did is I created a skill that
[09:40] can now go and I'll just say, hey, we have 15 new chapters launching,
[09:45] here's their info, create the bank accounts.
[09:48] And, uh, it'll then know to tap in that skill, or you can explicitly do
[09:52] like slash or I see bank account creator, and that'll manually trigger
[09:56] it. Slash is what you do when you're typing into the chat.
[09:59] Exactly. Yeah. So in chat, that slash kind of tells it, Hey, I'm telling
[10:03] you to use a skill and then you can name your skill, whatever you want.
[10:06] And really a skill is actually just a document with text in it.
[10:09] Um, And so it's just a set of instructions that then is going to get fed
[10:13] in along with your prompt to that given interaction with your AI tool
[10:18] that you're using.
[10:20] So it sounds fancy, but it's really just a document with text in it.
[10:23] But what's really cool is that instead of manually typing out that document
[10:26] with a full set of instructions, you can either go back and forth with
[10:29] your chat and say, hey, I want to build a new skill to do this.
[10:32] Help me set it up. Or what you can do, at least through Claude, and I'm
[10:35] guessing the other model providers will offer this soon as well, is you
[10:39] can actually go in and record a skill live.
[10:42] So what it does is it watches your screen.
[10:44] And so that's how I set up. Yeah, exactly.
[10:46] So I told it, hey, watch me do this process once and learn how to do it.
[10:50] So you can do it going forward.
[10:51] And so then you can literally just do the workflow yourself once instead
[10:54] of having to explain it bit by bit.
[10:56] And it will watch the screen recording take note of all the steps and
[11:00] then you know I always like to run at least one or two tests afterwards
[11:04] to make sure that it does the process as I want it gives the right output
[11:07] but I mean it that already just saves me so much time.
[11:11] So any kind of repetitive process I think of as a great use case for building
[11:15] out a skill. And I was kind of confused in the beginning of like okay
[11:18] you have projects and you have skills and when do you use either one.
[11:23] Um, and, and where I've landed is skills.
[11:27] One, you can use across different projects.
[11:29] So I have dyslexia, one of the, the, I, I made a skill for dyslexia dyslexia.
[11:35] I should have called it dyslexia, which calls on dyslexify.
[11:40] And I'll use that when we get a long report for Run Your City.
[11:43] When, when I have a long case for Stanford and I'm using it in the different
[11:47] projects and I'll say, hey, implement this skill and it will shoot out
[11:53] a very concise bolded in the font that I like with a lot of visuals and
[11:57] diagrams so I can ingest it really, really quickly.
[12:00] We have the Run Your City brand skill that isn't applicable in other projects.
[12:06] Like I wouldn't use a Run Your City brand skill for my Stanford classes.
[12:12] But it's different than the project because every time I do something
[12:17] for Run Your City, I don't care about the design.
[12:19] Like there's some times that I wanna do different things, but a lot of
[12:24] times I do. So like a quick tangent on that was in Claude Design.
[12:28] I'm going back and forth. I love design stuff.
[12:31] I'm asking, okay, I'm building this out.
[12:34] This is our colors, um, show me different fonts.
[12:36] I think we need a rebrand. So it's given me different options.
[12:38] I'm going back and forth. We're talking.
[12:40] I'm using the chat feature. I mean, the one that you're literally chatting
[12:43] back and forth with like voice mode.
[12:45] Yeah. And, and I actually don't know if, if Claude Design has voice mode,
[12:50] but what I'm using is the Wispr Flow.
[12:52] So Wispr Flow is another app, um, that I love basically it's like Siri,
[12:59] but it remembers your words. Yeah.
[13:01] First of all, it works. It doesn't add like 18 periods.
[13:03] It doesn't like capitalize things.
[13:05] It's just like that gives me the ick.
[13:06] It learns your style, but it learns your style.
[13:08] So anytime you adjust a word and you can use it on your phone or your
[13:12] computer, anytime you adjust a word, say I'm trying to write my brother's
[13:16] name Lewis. And when I say it the first time it's, it's typing L E W I
[13:20] S I changed changed I it to Lewis, I added it dictionary, it's just like
[13:22] a pop up whenever you change stuff.
[13:24] Once you fix the spelling, it learns how to spell it.
[13:27] Yeah, and so then every time I use that same word, and then you can add
[13:30] your own, like I have so many words that are in the dictionary, lokes,
[13:33] love bugs, whatever it is. own your Yeah, language at this point.
[13:35] Right, and I can just add it directly to the dictionary.
[13:37] So I'm using that, I'm going back and forth, Claude and I are getting
[13:40] close, we get a little frustrated, we come back, and then I'm excited,
[13:43] I'm like, I see the design on the website.
[13:46] I see the pamphlets and the marketing.
[13:48] You can ask for a whole design suite and then keep going back.
[13:51] And then I download that design skill.
[13:53] Then I upload it to Claude. And then whenever I want it to look like
[13:59] our brand, I add it. That's separate from it knowing our mission,
[14:05] our core. And that's where the project is.
[14:07] So I think of skills is like going back to the intern thing
[14:13] When it comes to you when it when the intern comes to you say we're both
[14:18] at Bain So if we if we go back to Bain it the intern has brought us some
[14:22] slides and we're like now do this do this Change this changes like all
[14:26] those adjustments You're like leveling up your intern skill.
[14:30] That's what that's what the skills doing You're just you're just saying
[14:33] okay from now on, whenever you do this, make sure to pay attention to
[14:36] this. And it's so useful. And the nice thing is that you teach it that
[14:41] once and then ideally it remembers that going forward.
[14:43] So it's like an intern with perfect memory in some ways.
[14:46] And, you know, the skill's not always gonna work 100% off the bat.
[14:50] You might need to tweak it over time or it'll get better, but it's mostly
[14:54] like kind of set and forget where you do it once.
[14:56] If you set it up the right way and test it, then you know, you can at
[14:59] any point in time. So now I've stolen Mary's Run Your City brand design
[15:04] skill and I'll use it, which is huge for me because previously, you know,
[15:08] Mary can tell me all she wants the tips, but like she's just much better
[15:11] at that than I am. And so instead of now me having to go to her and bother
[15:15] her to, you know, can you help me make this document look nice before
[15:18] I send it out to a potential partner instead, when I'm building it out
[15:20] with Claude, I'll just tell it, you know, make sure to incorporate the
[15:23] RYC brand and it will, you know, do the right fonts and colors and shapes
[15:28] and it will just feel like us. So it saves so much time.
[15:32] I kind of think of it, I think to your point, like in the, in the intern
[15:36] analogy, I like to think of building out a skill as like letting your
[15:39] intern phone a friend who's a specialist in a certain area.
[15:42] So like when I'm calling the bank account one it's like letting my intern
[15:46] call like a finance or like a mercury whatever guru
[15:52] and tap into their wisdom so if you know you have a design skill or you
[15:56] might have like a strategic planning skill that you use to prep for board
[16:00] meetings it's like okay let your intern call the board management specialist
[16:04] to get their input instead of just using it's like basic built-in knowledge.
[16:07] Yeah. Yeah. I know. I like that a lot.
[16:09] I think other skills at the top of my head, I have a humanizer one that
[16:12] I think is built into Claude.
[16:15] So Claude comes with tons of skills.
[16:17] You can do product management, you can do, you know, I don't know all
[16:20] of them that they come with. I definitely use a humanizer one a lot, and
[16:23] that makes it sound/look, not sound, look like a human wrote it.
[16:28] So it's like specific changes to the language.
[16:31] No em dashes. We don't need to capitalize every subtitle, um, no excessive
[16:36] period. Like it just, it just makes it feel more human.
[16:39] It gets rid of some of the like classic AI slop giveaways.
[16:42] And then that's another one is AI slop.
[16:44] It is, is no AI slop. Pretty similar.
[16:47] Like just design to make the output sound more human.
[16:50] Yeah. So I, I, I honestly think human eyes that are, I mean, dyslexia
[16:54] phi or on Dyslexify and Run Your City brand are my top that
[16:59] I go back to all the time and time again.
[17:01] What about you? Yeah, I definitely use the RYC brand design one.
[17:05] I've started building them out for super tactical specific things that
[17:07] I do a lot like the, uh, and the ones you just built out for, for this
[17:11] podcast. Yeah. So for this podcast, I just built one out that kind of
[17:13] has our brand identity, like the colors and the stuff that we're going
[17:16] with, which maybe will change over time, but at least, um, and then also
[17:20] one that helps us just think through planning for a given episode, one
[17:22] that helps us think through, once we have a raw video file, if there are
[17:26] changes we need to make or that kind of thing, it kind of reviews it and
[17:28] says, uh, maybe you should like, it'll fact check and say, if we actually
[17:31] said something slightly off, it'll suggest that we, you know, maybe remove
[17:34] that or give a caveat or something like that.
[17:36] So yeah, just experimenting with lots of ways that we can use it in this
[17:39] process too, because we don't have time to be spending hours going and
[17:42] doing editing or whatever. So let us know how well you think it's doing
[17:45] and we'll make improvements to it, but we're going to try to really be
[17:48] AI driven in everything we do with this podcast and the spirit of learning
[17:51] as well. Yeah. For the skills that you were just creating, you didn't
[17:55] come up with, right? No, I actually, yeah, totally.
[17:57] I didn't say like come up with these four skills.
[17:59] I was just like, "Hey, yeah, overnight," this is something I love doing
[18:03] too is like, you You have a given amount of usage within each five hour
[18:07] window for, for chat and for Claude and most of these tools.
[18:09] And so before I go to sleep, I like to like, just let it run on something.
[18:12] Cause I'm not needing to worry about saving We'll that.
[18:14] Be like, I'll be tired and want to go to sleep and Josh, like, no, no, no,
[18:17] My credits, runs over to the laptop.
[18:19] I was like, no, I got to like send it off to do something useful.
[18:21] Uh, so yeah, last night I was just like, you know, we're starting this
[18:23] new podcast. Um, there's some things that we're going to be doing each
[18:28] time with the episode production, can you just just like create a set
[18:30] of skills that will be useful going forward?
[18:33] And so it came up with those couple that I mentioned and going forward.
[18:37] I'm sure there'll be other things too.
[18:38] Like, uh, more will continue to catch ourselves doing stuff repeatedly.
[18:42] And that's when I love to create a skill.
[18:44] I want to create one to like help stay up to date on AI learnings and,
[18:48] and have kind of a morning. I know you can do routines and get a morning
[18:51] brief, but I would love to be like, I don't know what's the latest happening
[18:55] here and how can you, you know, write it in a way that I can listen to
[18:58] and really understand. Yeah. Yeah.
[19:01] I think that's a great, great, like anytime that you have personal preferences
[19:05] too, that you just wanted to remember these models or the, you know, chat
[19:09] GPT, Claude start to compile kind of a memory and understand your preferences.
[19:12] But like, it's always nice to just explicitly tell it.
[19:15] If there are certain things, like I've actually built out like a personal
[19:18] brand one too, inspired by your Run Your City brand.
[19:20] That's just like, when I'm doing class assignments, I just want it to
[19:22] look a certain way. And so now I have that, you know, personal design
[19:27] skill too. And I think, I think it's really like the,
[19:33] fun when people start using AI, I think there's so many tells and so I
[19:38] think it does make sense to kind of, not that you want to trick people,
[19:41] but you want it to feel like you.
[19:43] Totally. And I think it's annoying to read stuff with 18M dashes because
[19:47] it feels so like... And I feel like people have this visceral reaction
[19:51] now where when they see something that's clearly AI generated without
[19:55] a lot of effort by the human to put in their own flavor, whatever.
[20:00] People just treat it as less valid.
[20:03] Even if the output quality is great and the research is sound and all
[20:07] that, I think people just have this gut reaction that's like, "Okay, I
[20:10] don't buy into it. That's just AI slop." I think that it is really valuable
[20:15] to make it feel like your own and it goes a long way with how people are
[20:20] going to interpret interpret and read it.
[20:21] Totally. Totally.
[20:22] We kind of zoomed through that.
[20:23] Project Skills Connectors.
[20:25] Projects gave your intern a little background, what you're doing, a little
[20:28] purview. Connectors enabled this intern to actually do stuff.
[20:33] So send the email, add a calendar hold, write the Slack, see the Granola
[20:38] transcripts. And Skills enabled them to phone a friend with the time we
[20:43] have left, which is like infinite because we have nothing to do.
[20:47] But with the time we have left, can you do a top five things you built
[20:52] with AI? Boom, bada-boom, bada-boom.
[20:54] Top five things that I've built most useful for me?
[20:57] Yeah, like relatively recently.
[20:58] Like the quick ones that come to have a mind.
[21:00] I do get a morning newsletter every day with developments in AI, developments
[21:03] in education, and at the intersection of the two.
[21:06] Is it good? Do you like it? It's pretty solid.
[21:08] And actually what it does, the reason that I originally created it is
[21:11] because I have so many newsletters at this point that I've signed up for
[21:15] that, you know, originally I signed up for two or three newsletters, not
[21:17] read them every morning. And then I signed up for more and more.
[21:19] And now it's like so many that it's just overwhelming.
[21:21] Yeah. So literally I have 20 newsletters and I was reading zero of them.
[21:24] So I was like, okay, let me actually make like a meta newsletter that
[21:27] where my AI reads through all of those newsletters and pulls together
[21:30] the most relevant, important, noteworthy things for me.
[21:33] So it's kind of like a summary of all those other newsletters, as well
[21:36] as kind of doing its own research.
[21:37] So yeah, now I read one instead of 20.
[21:39] And yeah, it's pretty solid. I
[21:42] haven't done a great job of giving it feedback.
[21:44] Like in an ideal world, each day I would tell it, "Oh, this was interesting.
[21:47] This wasn't. I would have left more detail here." I think early on I did
[21:49] tell it, like make sure to include the URL whenever there's an article
[21:52] that I can read if I want more detail.
[21:54] So that was nice. And it doesn't look beautiful or anything.
[21:56] I was going to say, yeah, I would hate that, but you would eat that up.
[22:00] Yeah, no, I read it most days and
[22:03] that was really the obstacle that was trying to overcome is like being
[22:07] so overwhelmed by too much information.
[22:08] And so it's super concise and yeah, that's been really great.
[22:12] I enjoy that one a lot. What else have I built?
[22:15] I built a tool for our nonprofit that helps us find grant opportunities.
[22:19] So it does a scan of, you know, based on our profile as an organization,
[22:22] our scale, where we operate our mission, it tries to find good grants
[22:26] that are coming up, you know, with deadlines soon.
[22:28] That might be a good fit. And the thing I really like about that is then,
[22:32] then you built it so that, and by building it, it's really just talking
[22:36] back and forth at the clock. Like it's not, we're not talking Python.
[22:40] We're like, this is, this is just time.
[22:43] Yeah. Um, and our team at RenderCity is now making it much better than
[22:46] my initial version, but it was cool because it was like, I think I took
[22:48] a first spin and sorted away. And from our team took a first spin and
[22:51] we got a couple of versions and then it was like useful, but not all the
[22:55] way there. And so now we have a new team member, Tyler, who's like really
[22:58] going deep and like taking it to where it's, you know, uh, the full version
[23:02] of capabilities that we would want.
[23:04] But that's been one way. Like about that is, is going back to the connectors
[23:07] piece. So you guys outlined it and then, and then you have it just send
[23:11] an update in our Slack grants channel.
[23:14] Yeah. And that's so fun. Cause then it's like red green.
[23:16] It just, it just visually fun. And we have, then we have, you know, Chloe,
[23:19] who's able to go through and make sure that our draft is ready for the
[23:23] grant by the time that we, we, um, the deadline has, and I think it's,
[23:26] it's, it's fun when you see something that you build work end to end,
[23:31] because I think that's like the thing that I find most frustrating is
[23:34] similar to what you're saying with the newsletter.
[23:36] I've, I've tried to build a few things that do like news updates, but
[23:38] one, I don't read, so I don't know why I was doing that too.
[23:41] Um, and I would like to do it in some audio format format, but I just,
[23:45] I felt like it wasn't, uh, comprehensive enough or
[23:51] it just wasn't like valuable enough to to like work it into my every day
[23:56] routine And I want to get there I think it's important but I think that
[24:00] is sometimes a frustration of like give this curve I think you start to
[24:03] learn stuff and you're building everything and nothing is useful and then
[24:06] You like kind of get start to get tired about it And that's where I get
[24:09] fired up about the things that we use over and over totally maybe for
[24:12] the sake of time I'll just do one more but also on the note of Run Your
[24:16] City. We had a website that we'd used for a while through Wix and it was
[24:20] kind of, you know, it was fine.
[24:22] It was serving its purpose, but it took a lot of time.
[24:25] So we had at the time, probably 75 chapters across the U S now we're well
[24:30] over a hundred, but for each individual chapter page, our marketing lead,
[24:33] Olivia would have to go in and manually ask the team, when are your sessions
[24:37] going to take place? Where's the location?
[24:38] And then all the formatting, like we had to drag and drop things based
[24:42] off of, you know, the screen size, different is on a monitor, is on a
[24:46] desktop, is on a phone. And then you have to drag each little star, each
[24:50] icon, like it was a pain in the butt.
[24:53] Totally. Yeah. So the formatting took a lot of time and then we could
[24:56] have paid for like 150 seats to give each chapter individual access, but
[25:00] that would have cost us a crazy amount of money and even just having two
[25:03] or three seats was already very expensive.
[25:04] And so we said, Hey, like, what if we just actually built our own website?
[25:08] And we were able to do that. I mean, away in from our team drove that
[25:12] incredibly quickly, but like literally within a couple of weeks, we not
[25:14] only had to rehold our entire website, but it was actually better in a
[25:18] lot of respects, way more customizable, way more efficient in terms of
[25:22] letting chapters have a direct login where they can upload their information
[25:25] and maintain it in real time. And we use the brand skill that We use the
[25:28] Run Your City skill that we were talking about before to really make sure
[25:31] that it's so aligned with like kind of our voice, our tone, our feel everywhere
[25:37] else. Yeah, and it was cool too because Mary, who was driving a lot of
[25:40] the design, would ask it to mock up like three or four different versions
[25:43] of the homepage and then we could say, oh, we like this from this version,
[25:45] not this. So it was cool to have it just help generate a lot of ideas
[25:49] and ultimately we were still making a lot of decisions of how it was structured
[25:52] and laid out, but it was able to help us with that creative process.
[25:55] Yeah, and I think you can see it.
[25:56] Think in Claude specifically, you can kind of tell when you do enough
[26:00] to like design of tweaking around, like what one is kind of like their
[26:04] go-to fonts and I think it's similar to writing in that now it's just
[26:08] so useful to start using these tools because then one, to your point,
[26:12] like you can build something that is better than what you could build
[26:15] without. And I think that's so fun.
[26:16] It's not just efficient. It's like the output is literally better, but
[26:20] two is I think you start to develop that muscle of how do you make it
[26:23] feel human? And I think it just, it's important because then I think it's
[26:29] more impactful than what it was before.
[26:31] And I think that's what a lot of people fear we're missing, but I actually
[26:35] think there's like, it's invaluable.
[26:37] We now have some professors who are going back to Google Slides and just
[26:41] like writing, like not even in the Stanford GSB kind of template, but
[26:46] just on white slides. And I feel like people appreciate it.
[26:49] People are like, you literally typed those bullets.
[26:52] They look like trash. But you did it.
[26:54] Just the fact there was human effort by-- Yeah.
[26:56] And I think it's fun to be able to decide, OK, where do I want that efficiency?
[26:59] And then when we got the whole website up-- and I was like, I can't believe
[27:04] we did this. I'm not sure it's a priority.
[27:05] And then I saw it, and I was like, OK, it's a priority.
[27:08] Because it was just so well done.
[27:10] But Yeah. we did. mean at like You first you thought it was going to be
[27:12] way too much work to reall the entire website.
[27:14] Way, way, way, way too much work.
[27:15] We were like, okay, well let's just run like a two hour version and see
[27:18] how far we can get and like very quickly.
[27:20] Yeah, I was floored. But I do think it then required us to go through
[27:25] every word and, you know, tweak the design and look at other Claude websites
[27:30] and make sure that, you know, we are really differentiated and look from
[27:33] leaders like, um, leading nonprofits or just websites in general and how
[27:37] are we missing. And so I think, I think that same, um, I mean,
[27:43] it goes back to the intern stuff that we were talking about last episode
[27:45] is like, it's now, it's now like on us to like do that final check.
[27:50] And I think that's what at least in the beginning I was missing a lot
[27:53] is like, I was like, yes, AI will do it.
[27:55] And then I would, I would just outputting trash.
[27:58] Yeah. So on that note, then, to wrap us up, you mentioned one area where,
[28:01] with your daily newsletter podcast, it missed the mark initially.
[28:04] It sounds like that's an area you want to maybe explore, improving at
[28:07] some point. But are there any other things where you feel like AI's really
[28:10] missed, or areas where you tried it and it really didn't land, or where
[28:14] you don't want to use AI?
[28:15] Where I missed a mark. I mean, oh, I like tried to do a lot of email drafts
[28:20] where I actually kind of like what I'm doing now.
[28:22] I added routines. So routines are just, um, something that runs on your,
[28:28] you know, whatever your AI is. Um, it's like a scheduled task.
[28:32] That's either based on a certain time of day or other trigger.
[28:35] Like, yeah, well said. And it goes through all of my emails from what
[28:39] you were saying, because now it's connected through Composio to different
[28:42] emails. So it goes through my school and my Run Your City, not my trash
[28:46] ones. And it drafts responses to what it thinks is a high priority email.
[28:51] So it's like not to like the like blast emails or just updates.
[28:55] Not like to the Sephora, like new deal dropping.
[28:57] Although yours might think that's important.
[28:59] But that is important, honestly.
[29:01] Great call out. um, um, but, so it will draft responses.
[29:06] And I really liked that because then I can go in and, um, just like refine
[29:11] it. Um, and I, I just find it like fun, like to go into my inbox and there's
[29:17] already drafts, what I previously did that was absolutely wasted time.
[29:20] As I tried to have it, like, um, like I could do a draft or it would go
[29:25] through. And, and I think without the right investment in my
[29:31] tone and the right training on my previous emails, it just like totally
[29:35] missed the mark in terms of what I wanted to say and how I wanted to say
[29:39] it, but we went back and forth enough to get it to a point where it can
[29:42] do a pretty good first draft and then,
[29:46] you know. Yeah, so I feel like kind of the theme here is that for a lot
[29:49] of these use cases, it takes a little bit of investment upfront to like
[29:52] go back and forth, give it the feedback, tune it up before it's going
[29:55] to really be useful. But then once you get it to that point, it can save
[29:58] a ton of time and like create a lot of value.
[30:00] It's just usually not like a one hit wonder where you send a prompt and
[30:03] it comes back and it's perfect.
[30:04] It's like, it takes a little bit of giving and I mean, that's part of
[30:07] what shapes it as something that's really you, but then once you get it
[30:11] there, you can save a ton of time.
[30:13] Okay. Last question before we sign off.
[30:15] What is the top three things you're excited to learn in the next episode,
[30:18] if not one after? It doesn't have to be planned, but tell me the things
[30:21] you're excited about. Yeah. I want to chat more.
[30:22] I think agents have been thrown around so much, this idea of AI agents.
[30:27] I think that can mean a lot of different things, and a lot of companies
[30:30] are now trying to build out personal agents that do things for you.
[30:34] Even at Stanford, when people are trying to build startups, it's like,
[30:35] "Do you want to build startups with people or agents?" Yeah.
[30:39] Totally. Yeah. but people talking about like, you know, having a one person
[30:42] company where you have 20 agents instead of employees.
[30:44] So I think digging into agents and what that actually means and what it
[30:47] looks like today will be super interesting.
[30:50] And then I want to learn more from you about like the design side.
[30:52] Cause I know that you do a bunch of stuff with that and I want to learn
[30:56] from you. So that'd be an exciting one to jump into too.
[30:59] Bing bada boom. That's all we got.
[31:02] See you next episode of OOO.
