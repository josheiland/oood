---
tags: [oood, episode-02, edit]
---

# Episode 2 v2 — edit notes (2026-09-26 reshoot)

**Proposed final cut for host review. Not approved, scheduled or published.**

Source: `/Users/je/Movies/Episode 2 Raw.mp4`, the September 26 reshoot, 34:17.100, 1080p30, SHA-256 `087b52c2…a79b42d` (full hash in the edit-decision file). Josh renamed the September 25 take to `Episode 2 Raw - old.mp4`; it is not used here. Nothing from the v1 cut or older takes appears in this edit.

Runtime: **31:07.300** (14 source ranges, one moved). Edited by jtan (Claude) on Josh's request. `render-episode-v2.py` rebuilds everything from the untouched source.

## Editorial shape

The take already runs in a good order, so this is a tightening edit, not a restructure. It keeps the relationship material: the OOOD name bit and its callback at the sign-off, "let's not jump the gun," Mary's overtraining complaint, "you would eat that up," Josh stealing Mary's brand skill, the overnight-credits exchange, the Sephora aside, and the hand-typed slides that "look like trash, but you did it."

What changed from the raw take:

1. **Cold open (6.6 s).** Mary: "I'll be tired and want to go to sleep and Josh, like, no no no, my credits, runs over to the laptop." Josh: "I got to send it off to do something useful." It plays again in context at 18:15. The duplication is intentional.
2. **Composio moved into connectors.** In the raw take it came after skills, which broke the three-part order. It now follows the Granola workflow (06:40–08:34), and Mary's next line ("we can go into more use cases, but to round out our foundations, then we have skills") bridges straight into skills.
3. **Removed for accuracy:** Granola pricing and free-tier guesses; the phone-call recording detail.
4. **Removed for the hosts' protection:** Mary's Canvas assignment story (she says on tape "I probably won't use that"), and naming a Charlottesville business as clearly AI-made.
5. **Removed as repetition or tangent:** Josh restating Mary's website-pointer point; Josh's class-projects example (Mary already gave it); the "supervisees" restart inside phone-a-friend; the unfulfilled "we should include copies of the skills"; the agents-reviewing-agents tangent.
6. **Kept despite length:** Mary's Claude Design and Wispr Flow aside, the AI-tells discussion, and all three builds. Runtime follows the material; see "Optional tightening" if you want it closer to 29 minutes.

## Exact cut list

Half-open ranges at 30 fps. Cut points were chosen from word-level alignment plus the audio envelope, snapped to the quietest point between words. Every join below lists its words on each side.

| ID | Export | Source | Retained material / reason |
|---|---|---|---|
| CO | 00:00.000–00:06.567 | 17:49.433–17:56.000 | Cold open: Mary on Josh racing to use up his AI credits before bed. |
| S01 | 00:06.567–04:23.333 | 00:01.900–04:18.667 | OOOD name bit, three-part promise, intern metaphor, Mary's Projects explanation and desk analogy, Josh's folder definition. 1.9 s of dead air before "And we're live" trimmed. |
| S02 | 04:23.333–05:17.700 | 04:37.633–05:32.000 | Mary's fitness project. |
| S03 | 05:17.700–05:52.367 | 05:45.633–06:20.300 | Connectors defined; Mary's connected tools; Granola introduced. |
| S04 | 05:52.367–05:55.967 | 06:38.867–06:42.467 | What Granola produces. |
| S05 | 05:55.967–06:40.300 | 07:15.267–07:59.600 | Consent reminder; notes-to-follow-up workflow. |
| S06 | 06:40.300–08:33.933 | 20:03.033–21:56.667 | **Moved.** Composio multi-account workaround. |
| S07 | 08:33.933–15:42.200 | 08:00.500–15:08.767 | Skills defined; Mercury setup; slash; record a skill; Dyslexify and brand skill; Claude Design and Wispr Flow aside; Josh reusing Mary's skill. |
| S08 | 15:42.200–18:44.400 | 15:16.633–18:18.833 | Phone-a-friend; humanizer and no-AI-slop; the podcast skills; overnight credits. |
| S09 | 18:44.400–20:21.867 | 18:25.133–20:02.600 | Mary's morning-brief wish; Josh's personal design skill; why AI tells matter. |
| S10 | 20:21.867–23:03.967 | 21:56.667–24:38.767 | Recap; meta-newsletter; grant finder. |
| S11 | 23:03.967–25:56.633 | 25:12.667–28:05.333 | "But that's been one" bridge; grant alerts in Slack; Mary's honest frustration; website rebuild. |
| S12 | 25:56.633–28:15.333 | 28:14.467–30:33.167 | Design tells; hand-typed slides; the two-hour website test; the final human check; Josh's "where has AI missed?" |
| S13 | 28:15.333–31:07.300 | 31:16.867–34:08.833 | Email-draft routine and what it took; next topics; OOOD callback sign-off. |

Joins, in export order (words before || words after):

- 00:06.6 CO→S01: "…to do something useful." || "And we're live."
- 04:23.3 S01→S02: "…it'll pull updates occasionally." || "Totally. And I think that the reason…"
- 05:17.7 S02→S03: "…has context that doesn't change." || "So it's a single setup…"
- 05:52.4 S03→S04: "…It records meetings for us." || "transcribes the whole meeting and then…"
- 05:56.0 S04→S05: "…a summary and follow-ups." || "Obviously, you want to make sure…"
- 06:40.3 S05→S06: "…do action based off of it." || "One thing that I know is helpful for us…"
- 08:33.9 S06→S07: "…it's quite easy. I love it." || "And we can go in a little bit more use cases…"
- 15:42.2 S07→S08: "…a specialist in a certain area." || "So like when I'm calling the bank account one…"
- 18:44.4 S08→S09: "…that's when I love to create a skill." || "I want to create one to, like, help stay up to date…"
- 20:21.9 S09→S10: "…interpret and treat it. Totally. Totally." || "We kind of zoomed through that."
- 23:04.0 S10→S11: "…capabilities that we would want." || "But that's been one. And what I like about that…"
- 25:56.6 S11→S12: "Yeah. And I think you can see it." || "I think in Claude specifically…"
- 28:15.3 S12→S13: "…where you don't want to use AI?" || "Where it missed the mark…"

Listen hardest at 05:52–05:56 (two quick joins inside a Mary-to-Josh handoff) and at 23:04 (Josh's line lands right before Mary jumps in).

## Picture, graphics, audio

- One continuous take, fixed framing. No black or frozen frames in the source (checked across the full file). Straight cuts; no punch-ins.
- **Brand kit v2** graphics built with Teachers and JetBrains Mono and the kit's palette (`graphics-v2/oood_graphics.py`):
  - title card: full-frame, 1.5 s, type moves up 24 px, over the first 1.5 s of "And we're live";
  - lower thirds: blue block at bottom left, 300 ms wipe from the left, for hosts, chapters and recap;
  - note cards: the kit's definition-popup extension, cream with a foam waterline and a blue accent.
- **Pop-up timing:** every graphic starts on the onset of its anchor word (found by word-level alignment), not a few seconds early. The cue list with anchor words and times is in `intermediate/v2/edl-with-export-times.json` and the edit-decision file.

| Export | Graphic | Anchor word(s) |
|---|---|---|
| 00:06.6–00:08.1 | Title: MAKE AI USEFUL | start of segment |
| 00:09.7 | Josh + Mary | "We're back" |
| 01:45.2 | 01 / Projects: Background | "It gives your AI context" |
| 03:21.3 | Heads up: works only if your AI can reach that website | "go to our website" |
| 05:22.4 | 02 / Connectors: Access | "Then we have connectors" |
| 05:50.8 | Granola: does not keep the audio | "It records meetings for us" |
| 07:07.7 | Composio: third-party hub | "Composio is this" |
| 08:40.0 | 03 / Skills: Reusable directions | "then we have skills" |
| 10:01.3 | Using a skill: type / and the name | "that slash kind of tells it" |
| 10:40.9 | Record a skill: Cowork on Mac | "record a skill live" |
| 12:52.9 | Wispr Flow | "Wispr Flow is another app" |
| 20:25.6 / 20:29.5 / 20:40.1 | Recap: Projects = background / Connectors = access / Skills = reusable directions | each word in Mary's recap |
| 20:51.0 | 04 / Show and tell: What we built | "top five things you built" |
| 28:10.0 | 05 / Honest misses: Where AI missed | "AI is really missed" |
| 30:13.6 | 06 / Up next | "Last question before we sign off" |

- **Audio:** all four source tracks are identical mixes; stream 1 only. 70 Hz high-pass, gentle dynamic leveling (max 3x gain), a light peak limiter, then two-pass linear loudness normalization to −16 LUFS / −1.5 dBTP. 8 ms ramps at every cut; 0.5 s fade at the end. The MP4's AAC is encoded 0.6 dB lower than the master to keep its true peak under −1 dBTP (−16.6 LUFS / −1.3 dBTP measured). Fourteen sampled passages from both hosts on the final master sit between −16.7 and −18.4 dBFS (75th-percentile active speech). That's a level proxy, not a listening test.

## Optional tightening (about 2 minutes available)

| Export | What | Saves |
|---|---|---|
| 12:45–13:37 | Wispr Flow aside inside Mary's Claude Design story | ~50 s |
| 19:43–20:21 | Josh's half of the AI-tells discussion | ~40 s |
| 24:38–25:05 | Website rebuild: drag-and-drop and seat-pricing detail | ~25 s |
| 16:09–16:22 | Humanizer "built into Claude" (inaccurate; recommended cut regardless) | ~10 s |

## Review limits

This edit was made from a full machine transcript, word-level alignment at every cut and graphic, audio-envelope checks, sampled frames and full-file technical checks. **Nobody has watched or listened to it continuously in real time.** Josh and Mary should watch it end to end for how the cuts sound, lip sync, and whether they're happy with every personal detail. Claims are in `02_RESEARCH/episode-02-v2-source-checks-2026-09-26.md`.
