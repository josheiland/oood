"""Rebuild Episode 2 from its immutable source and frame-based edit list."""
from pathlib import Path
import subprocess,json,re,hashlib,sys
from PIL import Image,ImageDraw,ImageFont
P=Path(__file__).resolve().parent
T=P/'intermediate';R=T/'render';R.mkdir(parents=True,exist_ok=True)
E=json.loads((P/'episode-02-edit-decisions-v1.json').read_text());FPS=E['fps'];SRC=Path(E['source'])
def run(args,log):
 with log.open('w') as f:subprocess.run(args,stdout=f,stderr=subprocess.STDOUT,check=True)
def panel(path,kicker,line,detail=''):
 im=Image.new('RGBA',(1740,172),(0,0,0,0));d=ImageDraw.Draw(im)
 d.rounded_rectangle((0,0,1739,171),radius=16,fill=(16,20,25,224))
 d.rectangle((0,22,5,148),fill=(255,255,255,240))
 font=lambda n,b=False:ImageFont.truetype('/System/Library/Fonts/Supplemental/Arial'+(' Bold' if b else '')+'.ttf',n)
 d.text((30,18),kicker,font=font(24,True),fill=(204,210,215,255))
 d.text((30,57),line,font=font(38,True),fill='white')
 if detail:d.text((30,113),detail,font=font(27),fill=(232,234,236,255))
 im.save(path)
if not (T/'source-leveled.wav').exists():
 run(['ffmpeg','-nostdin','-hide_banner','-y','-i',str(SRC),'-map','0:a:0','-vn','-af','highpass=f=65,dynaudnorm=f=250:g=15:p=0.85:m=3:r=0.1:t=0.002','-ar','48000','-c:a','pcm_s24le',str(T/'source-leveled.wav')],T/'level.log')
clips=[]
for n,s in enumerate(E['segments']):
 dur=(s['out_frame']-s['in_frame'])/FPS
 key=hashlib.sha256(json.dumps(s,sort_keys=True).encode()).hexdigest()[:12]
 out=R/f'{s["id"]}-{key}.mov'
 valid=False
 if out.exists():
  try:
   m=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_streams','-of','json',str(out)]))
   valid=int(next(x for x in m['streams'] if x['codec_type']=='video')['nb_frames'])==s['out_frame']-s['in_frame']
  except Exception: pass
 if not valid:
  inputs=[];filt=['[0:v:0]setpts=PTS-STARTPTS[v0]']
  for i,o in enumerate(s.get('overlays',[])):
   png=R/f'{s["id"]}-{i}.png'
   if o.get('type')=='card':
    im=Image.new('RGBA',(1920,1080),(16,20,25,255));d=ImageDraw.Draw(im)
    ft=lambda z:ImageFont.truetype('/System/Library/Fonts/Supplemental/Arial.ttf',z)
    d.text((120,160),'OUT OF OUR DEPTH  /  CONNECTORS',font=ft(28),fill=(194,202,210,255))
    d.text((120,237),'From meeting notes to a follow-up',font=ft(64),fill='white')
    labels=[('01','Meeting notes','Find the relevant context.'),('02','Email draft','Turn the notes into a response.'),('03','Your review','Check it before sending.')]
    for z,(num,title,detail) in enumerate(labels):
     x=120+z*575;d.rounded_rectangle((x,405,x+525,705),radius=20,fill=(32,39,47,255),outline=(81,91,104,255),width=2)
     d.text((x+32,439),num,font=ft(30),fill=(182,192,205,255));d.text((x+32,515),title,font=ft(45),fill='white');d.text((x+32,601),detail,font=ft(27),fill=(221,226,231,255))
    d.text((120,829),'Connect the apps. Give clear instructions. Keep your judgment.',font=ft(34),fill=(222,227,232,255))
    im.save(png)
   else: panel(png,o['kicker'],o['line'],o.get('detail',''))
   inputs+=['-loop','1','-framerate','30','-i',str(png)]
   # Bound PNG input; main video is the timeline clock.
   filt.append(f"[v{i}][{i+2}:v]overlay=x={0 if o.get('type')=='card' else 90}:y={0 if o.get('type')=='card' else 848}:enable='between(t,{o['start']},{o['end']})':eof_action=repeat:shortest=1[v{i+1}]")
  final=f'v{len(s.get("overlays",[]))}'
  if n==len(E['segments'])-1:
   filt.append(f'[{final}]fade=t=out:st={dur-0.5}:d=0.5[vfinal]');final='vfinal'
  audiofade=0.5 if n==len(E['segments'])-1 else 0.008
  filt.append(f'[1:a:0]atrim=duration={dur:.9f},asetpts=PTS-STARTPTS,apad=whole_dur={dur:.9f},afade=t=in:d=0.008,afade=t=out:st={dur-audiofade:.9f}:d={audiofade}[a]')
  run(['ffmpeg','-nostdin','-hide_banner','-y','-threads','2','-ss',f"{s['in_frame']/FPS:.9f}",'-i',str(SRC),'-ss',f"{s['in_frame']/FPS:.9f}",'-i',str(T/'source-leveled.wav'),*inputs,'-filter_complex_threads','2','-filter_complex',';'.join(filt),'-map',f'[{final}]','-map','[a]','-t',f'{dur:.9f}','-c:v','h264_videotoolbox','-b:v','6M','-profile:v','high','-pix_fmt','yuv420p','-r','30','-fps_mode','cfr','-video_track_timescale','30000','-color_primaries','bt709','-color_trc','bt709','-colorspace','bt709','-c:a','pcm_s24le','-ar','48000','-map_metadata','-1',str(out)],R/f'{s["id"]}.log')
 clips.append(out);print(f'{n+1}/{len(E["segments"])} rendered: {s["title"]}',flush=True)
concat=R/'concat.txt';concat.write_text(''.join("file '"+str(f)+"'\n" for f in clips))
if '--reuse-audio' in sys.argv:
 # Only for a picture-only revision with unchanged source ranges and mix.
 info=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_format','-of','json',str(T/'master-audio.wav')]))
 assert abs(float(info['format']['duration'])-E['total_frames']/FPS)<1/48000
 stats=json.loads((T/'loudness-pass1.json').read_text())
 print('Reusing the existing lossless audio for a picture-only revision.',flush=True)
else:
 run(['ffmpeg','-nostdin','-hide_banner','-nostats','-f','concat','-safe','0','-i',str(concat),'-map','0:a:0','-af','loudnorm=I=-16:TP=-1.5:LRA=11:print_format=json','-vn','-f','null','-'],R/'loudness-pass1.log')
 stats=json.loads(re.findall(r'\{[^{}]+\}',(R/'loudness-pass1.log').read_text())[-1])
 flt=f"loudnorm=I=-16:TP=-1.5:LRA=11:measured_I={stats['input_i']}:measured_TP={stats['input_tp']}:measured_LRA={stats['input_lra']}:measured_thresh={stats['input_thresh']}:offset={stats['target_offset']}:linear=true,atrim=duration={E['total_frames']/FPS:.9f},asetpts=N/SR/TB"
 run(['ffmpeg','-nostdin','-hide_banner','-y','-f','concat','-safe','0','-i',str(concat),'-map','0:a:0','-vn','-af',flt,'-ar','48000','-c:a','pcm_s24le',str(T/'master-audio.wav')],R/'master-audio.log')
metadata=[';FFMETADATA1','title=Out of Our Depth | Episode 2: Make AI useful','artist=Josh Eiland and Mary','comment=Edited from the September 25 reshoot. Host review pending.']
for s in E['segments']:
 if not s.get('chapter'):continue
 start=s['timeline_frame']/FPS
 nexts=[x['timeline_frame']/FPS for x in E['segments'] if x.get('chapter') and x['timeline_frame']>s['timeline_frame']]
 end=min(nexts) if nexts else sum(x['out_frame']-x['in_frame'] for x in E['segments'])/FPS
 metadata+=['[CHAPTER]','TIMEBASE=1/1000',f'START={round(start*1000)}',f'END={round(end*1000)}',f'title={s["chapter"]}']
(R/'chapters.ffmeta').write_text('\n'.join(metadata)+'\n')
run(['ffmpeg','-nostdin','-hide_banner','-y','-f','concat','-safe','0','-i',str(concat),'-i',str(T/'master-audio.wav'),'-i',str(R/'chapters.ffmeta'),'-map','0:v:0','-map','1:a:0','-map_metadata','2','-map_chapters','2','-c:v','copy','-c:a','aac','-b:a','256k','-ar','48000','-movflags','+faststart','-video_track_timescale','30000',str(P/'episode-02-final-cut-v1.mp4')],R/'final-mux.log')
(T/'loudness-pass1.json').write_text(json.dumps(stats,indent=2))
print('Final export complete.',flush=True)
