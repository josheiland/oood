#!/usr/bin/env python3
"""Eight Episode 002 hook testers: hook -> EPISODE 002 card with sting -> first ~15 s of the episode.

Same shape as the Episode 000 testers. The hook moment also plays again in its
original place in the full episode, as Episode 000's honeymoon hook does.
"""

import json
import sys
from pathlib import Path

import e002_common as c

OUT = c.HERE.parent / "jtan-hooks-002"

# id, label, first words, approx raw start (s), last words, approx raw end (s).
# An int in place of words is a hand-placed raw frame, chosen from the audio
# envelope where the hosts' speech runs together and the word timings can't.
HOOKS = [
    ("01-credits-bedtime", "Mary: Josh racing to spend his AI credits before bed",
     "I'll be tired", 1069, "something useful", 1076),
    ("02-sephora", "Email routine skips the Sephora deal drop / \"But that is important\"",
     "Not like to the Sephora", 1916, "great call out", 1922),
    ("03-overtraining", "Mary: ChatGPT says she's overtraining",
     "what type of run", 299, "No, I'm not", 304),
    ("04-typed-bullets", "Hand-typed slides: \"They look like trash, but you did it\"",
     "Like people are like", 1747, 52559, 1752),  # ends in the 70 ms gap after "you did it", before "just"
    ("05-eat-that-up-v2", "Plain AI newsletter / \"But you would eat that up\"",
     "And it doesn't look beautiful", 1409, 42452, 1415, 0.04),  # Josh's "yeah, no" overlaps "eat that up" with no gap; ends on "up" with a 40 ms fade. v1 (frame 42464) kept "yeah, no"
    ("06-stole-brand-skill", "Josh stole Mary's brand design skill",
     "So now I've stolen", 866, "than I am", 878),
    ("07-infinite-time", "Mary: the time we have left is 'infinite because we have nothing to do'",
     "with the time we have left", 1337, "nothing to do", 1341),
    ("08-outputting-trash", "Mary: 'yes, AI will do it' and then it output trash",
     "I was like yes AI will do it", 1811, 54467, 1815),  # ends after "trash", before Josh's "yeah"
]

BODY_FROM = ("And we're live", 2.4)
BODY_TO = ("Triple OD", 15.5)


def main():
    c.check_raw()
    OUT.mkdir(exist_ok=True)
    body_a = c.cut_before(*BODY_FROM)
    body_b = c.cut_after(*BODY_TO)
    record = {"body_frames": [body_a, body_b], "hooks": []}
    only = set(sys.argv[1:])
    for hid, label, first, t0, last, t1, *fade in HOOKS:
        if only and hid not in only:
            continue
        a = first if isinstance(first, int) else c.cut_before(first, t0)
        b = last if isinstance(last, int) else c.cut_after(last, t1)
        out = OUT / f"{hid}.mp4"
        pieces = [("src", a, b, *fade), ("intro",), ("src", body_a, body_b)]
        if not out.exists():
            c.render(pieces, out, crf=20)
        W = c.words()
        text = " ".join(w for w, s, e in W if a / c.FPS <= s < b / c.FPS)
        record["hooks"].append({
            "file": out.name, "label": label, "raw_frames": [a, b],
            "raw_seconds": [round(a / c.FPS, 3), round(b / c.FPS, 3)],
            "hook_seconds": round((b - a) / c.FPS, 3),
            "total_seconds": round((b - a + c.TITLE_FRAMES + body_b - body_a) / c.FPS, 3),
            "asr_text": text})
        print(hid, round((b - a) / c.FPS, 2), "s |", text)
    path = OUT / "hooks.json"
    if path.exists() and only:
        old = json.loads(path.read_text())
        keep = [h for h in old["hooks"] if h["file"] not in {x["file"] for x in record["hooks"]}]
        record["hooks"] = sorted(keep + record["hooks"], key=lambda h: h["file"])
    path.write_text(json.dumps(record, indent=1, ensure_ascii=False))


if __name__ == "__main__":
    main()
