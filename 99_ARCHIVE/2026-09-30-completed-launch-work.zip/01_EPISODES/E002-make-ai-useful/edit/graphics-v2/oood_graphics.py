#!/usr/bin/env python3
"""OOOD brand graphics for the E002 v2 edit (kit v2, Sept 2026).

Renders animated overlay clips (PNG-in-MOV with alpha) cropped to their own box:
- lower third: blue block bottom-left, Teachers 800 cream line, JetBrains Mono label; 300 ms wipe from left.
- note: definition-popup extension, cream card with foam waterline, blue accent, navy body; same wipe.
- title: full-frame chapter card, cream/foam waterline, type moves up 24 px, 1.5 s hold.
"""
import subprocess, tempfile, shutil
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

ROOT = Path('/Users/je/oood/03_ASSETS/brand-fonts')
TEACHERS, MONO = ROOT / 'teachers.ttf', ROOT / 'jetbrains-mono.ttf'
BLUE, SMALL_BLUE, CREAM, FOAM, NAVY, TINT, LABEL = '#38B6FF', '#0E6FC0', '#FBF1E5', '#FDF8F2', '#0B2A45', '#A9DCFF', '#EAF5FF'
FPS = 30

def font(path, size, weight):
    f = ImageFont.truetype(str(path), size)
    f.set_variation_by_axes([weight])
    return f

def tracked(d, xy, text, f, fill, tracking=0.0):
    """Draw text with letter spacing expressed as a fraction of the font size."""
    x, y = xy
    for ch in text:
        d.text((x, y), ch, font=f, fill=fill)
        x += d.textlength(ch, font=f) + tracking * f.size
    return x

def tracked_len(d, text, f, tracking=0.0):
    return sum(d.textlength(ch, font=f) + tracking * f.size for ch in text) - (tracking * f.size if text else 0)

def lower_third(kicker, line):
    big, lab = font(TEACHERS, 64, 800), font(MONO, 26, 500)
    probe = ImageDraw.Draw(Image.new('RGBA', (10, 10)))
    w = int(max(tracked_len(probe, line.upper(), big, -0.02), tracked_len(probe, kicker.upper(), lab, 0.16))) + 88
    h = 150
    im = Image.new('RGBA', (w, h), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    d.rounded_rectangle((0, 0, w - 1, h - 1), radius=12, fill=BLUE)
    tracked(d, (44, 22), kicker.upper(), lab, LABEL, 0.16)
    tracked(d, (42, 58), line.upper(), big, CREAM, -0.02)
    return im

def note(title, body, max_width=1040):
    head, txt = font(TEACHERS, 46, 800), font(TEACHERS, 36, 600)
    probe = ImageDraw.Draw(Image.new('RGBA', (10, 10)))
    width = max_width
    lines, cur = [], ''
    for word in body.split():
        cand = (cur + ' ' + word).strip()
        if cur and probe.textlength(cand, font=txt) > width - 96:
            lines.append(cur); cur = word
        else:
            cur = cand
    if cur: lines.append(cur)
    if len(lines) > 2: raise ValueError('note body too long: ' + body)
    width = int(max([probe.textlength(l, font=txt) for l in lines] + [tracked_len(probe, title.upper(), head, -0.02)])) + 96
    h = 40 + 56 + 14 + 46 * len(lines) + 34
    im = Image.new('RGBA', (width, h), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    mask = Image.new('L', (width, h), 0); ImageDraw.Draw(mask).rounded_rectangle((0, 0, width - 1, h - 1), radius=12, fill=255)
    card = Image.new('RGBA', (width, h), CREAM); cd = ImageDraw.Draw(card)
    cd.rectangle((0, int(h * 0.58), width, h), fill=FOAM)
    cd.rectangle((0, 0, 12, h), fill=BLUE)
    tracked(cd, (46, 36), title.upper(), head, BLUE, -0.02)
    for i, ln in enumerate(lines):
        cd.text((46, 40 + 56 + 14 + 46 * i), ln, font=txt, fill=NAVY)
    im.paste(card, (0, 0), mask)
    return im

def icon_tile(size):
    """Square blue tile, two-line cream lockup: OUT OF OUR over DEPTH, kept in the middle 80%."""
    im = Image.new('RGBA', (size, size), BLUE); d = ImageDraw.Draw(im)
    target = size * 0.74
    big = font(TEACHERS, 100, 800)
    big = font(TEACHERS, int(100 * target / tracked_len(d, 'DEPTH', big, -0.02)), 800)
    bw = tracked_len(d, 'DEPTH', big, -0.02); x0 = (size - bw) / 2
    cap = big.getbbox('D')[3] - big.getbbox('D')[1]
    top = font(TEACHERS, 100, 800)
    top = font(TEACHERS, max(8, int(100 * (cap / 3) / (top.getbbox('O')[3] - top.getbbox('O')[1]))), 800)
    tcap = top.getbbox('O')[3] - top.getbbox('O')[1]
    block = tcap + cap * 0.28 + cap
    y0 = (size - block) / 2
    tracked(d, (x0 - top.getbbox('O')[0], y0 - top.getbbox('O')[1]), 'OUT OF OUR', top, CREAM, 0.02)
    tracked(d, (x0 - big.getbbox('D')[0], y0 + tcap + cap * 0.28 - big.getbbox('D')[1]), 'DEPTH', big, CREAM, -0.02)
    return im

def title_frame(kicker, title, detail, dy):
    im = Image.new('RGBA', (1920, 1080), CREAM); d = ImageDraw.Draw(im)
    d.rectangle((0, int(1080 * 0.59), 1920, 1080), fill=FOAM)
    lab, big, sub = font(MONO, 30, 500), font(TEACHERS, 190, 800), font(TEACHERS, 48, 600)
    tracked(d, (150, 330 + dy), kicker.upper(), lab, SMALL_BLUE, 0.18)
    tracked(d, (140, 380 + dy), title.upper(), big, BLUE, -0.03)
    d.text((150, 680 + dy), detail, font=sub, fill=NAVY)
    tile = icon_tile(170)
    im.paste(tile, (150, 1080 - 170 - 80))
    return im

def _encode(frames_dir, out):
    subprocess.run(['ffmpeg', '-v', 'error', '-y', '-framerate', str(FPS), '-i', str(frames_dir / 'f%04d.png'),
                    '-c:v', 'png', '-pix_fmt', 'rgba', str(out)], check=True)

def ease_out(t):
    return 1 - (1 - t) ** 3

def render_wipe_clip(im, hold_s, out, wipe_ms=300, fade_frames=6):
    """Wipe in from the left over wipe_ms, hold, short fade out. Total length = hold_s."""
    tmp = Path(tempfile.mkdtemp())
    n = round(hold_s * FPS); nw = round(wipe_ms / 1000 * FPS)
    w, h = im.size
    for i in range(n):
        if i < nw:
            vis = int(w * ease_out((i + 1) / nw))
            fr = Image.new('RGBA', (w, h), (0, 0, 0, 0)); fr.paste(im.crop((0, 0, vis, h)), (0, 0))
        else:
            fr = im.copy()
        if i >= n - fade_frames:
            a = (n - i - 1) / fade_frames
            fr.putalpha(fr.getchannel('A').point(lambda v: int(v * a)))
        fr.save(tmp / f'f{i:04d}.png')
    _encode(tmp, out); shutil.rmtree(tmp)

def render_title_clip(kicker, title, detail, out, hold_s=1.5, move_frames=12, fade_frames=6):
    tmp = Path(tempfile.mkdtemp()); n = round(hold_s * FPS)
    for i in range(n):
        dy = int(24 * (1 - ease_out(min(1, (i + 1) / move_frames))))
        fr = title_frame(kicker, title, detail, dy)
        if i >= n - fade_frames:
            a = (n - i - 1) / fade_frames
            fr.putalpha(fr.getchannel('A').point(lambda v: int(v * a)))
        fr.save(tmp / f'f{i:04d}.png')
    _encode(tmp, out); shutil.rmtree(tmp)
