---
tags: [oood, episode-02, edit]
---

# Episode 2 v3 — corrected final cut for host review

**Source:** `/Users/je/Movies/Episode 2 Raw.mp4`, the September 26 reshoot (SHA-256 `087b52c20549f20118216a867005944948da8d39f013b3089789a987aa79b42d`). The September 25 take is not used. V3 is derived from the fully rendered v2 cut of that source; [v2 edit notes](episode-02-edit-notes-v2.md) contain every earlier source range, join, graphic and editorial choice. V1 and v2 are preserved.

**Change:** Remove v2 16:12.500–16:24.200 (351 frames, 11.700 s), corresponding to raw 15:46.933–15:58.633. This drops the spoken claim that Mary's Humanizer skill is built into Claude and the speculative list of default skills. The retained sentence joins “I have a humanizer one that” to “makes it sound/look ...,” keeping Mary's personal example and the ensuing discussion. The v2 cold open, host dynamic, three-part explanation, examples, limitations, show-and-tell and sign-off remain. No chapter or branded graphic falls within the removal.

**Runtime:** 30:55.600 (55,668 frames, 1080p30). The change is reproducible with [render-episode-v3.py](render-episode-v3.py) and [episode-02-edit-decisions-v3.json](episode-02-edit-decisions-v3.json). The earlier v2 EDL maps the base edition back to the untouched raw source. V3 uses v2's branded picture and separately mastered lossless audio, then retimes the captions and chapters. It retains the original dialogue mix, without music or invented sound effects.

**Source check:** [v3 addendum](../../../02_RESEARCH/episode-02-v3-source-addendum-2026-09-27.md) documents the correction. Other retained claims and on-screen notes remain in the [v2 claim register](../../../02_RESEARCH/episode-02-v2-source-checks-2026-09-26.md). Product details should be checked again before publication because capabilities can change.

**Review:** This is a proposed final cut. The 31-minute v2 was assembled using transcript, audio alignment, sampled frames and technical checks, without a continuous real-time viewing by either host. The v3 correction is timed by source word alignment, but it also needs a human listen at the new join (16:12.5). The v3 captions are retimed machine captions, not a listening-proofread transcript. Josh and Mary should watch the full cut, proof captions, decide whether to share the named personal examples (Lewis, Olivia, Tyler and Chloe), and approve this exact version before publication. No scheduling or publication is implied.
