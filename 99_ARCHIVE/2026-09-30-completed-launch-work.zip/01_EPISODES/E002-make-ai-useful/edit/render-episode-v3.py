#!/usr/bin/env python3
"""Make the corrected E002 review cut from the fully rendered September 26 reshoot edit.

V2 was rendered from the untouched raw source; its EDL remains the source-range
record. This script removes one inaccurate spoken passage without changing the
rest of the edit or its graphics. It never overwrites v2.
"""

import hashlib
import json
import re
import subprocess
from pathlib import Path

HERE = Path(__file__).resolve().parent
V2 = HERE / "episode-02-final-cut-v2.mp4"
WAV2 = HERE / "episode-02-audio-master-v2.wav"
V3 = HERE / "episode-02-final-cut-v3.mp4"
WAV3 = HERE / "episode-02-audio-master-v3.wav"
EDL = HERE / "episode-02-edit-decisions-v3.json"
FFMETA = HERE / "intermediate" / "v3" / "chapters.ffmeta"
GRAPH = HERE / "intermediate" / "v3" / "filtergraph.txt"


def run(args):
    subprocess.run(args, check=True)


def sha256(path):
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(8 * 1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def stamp(seconds, sep=","):
    ms = round(seconds * 1000)
    h, ms = divmod(ms, 3600000)
    m, ms = divmod(ms, 60000)
    s, ms = divmod(ms, 1000)
    return f"{h:02d}:{m:02d}:{s:02d}{sep}{ms:03d}"


def seconds(stamp_text):
    h, m, tail = stamp_text.replace(",", ".").split(":")
    return int(h) * 3600 + int(m) * 60 + float(tail)


def write_captions(cut_start, cut_end, total):
    original = (HERE / "episode-02-captions-v2.srt").read_text()
    cues = []
    for block in re.split(r"\n\s*\n", original.strip()):
        lines = block.splitlines()
        time_line = next((x for x in lines if " --> " in x), None)
        if time_line is None:
            continue
        a, b = map(seconds, time_line.split(" --> "))
        words = "\n".join(lines[lines.index(time_line) + 1:])
        if b <= cut_start:
            pass
        elif a >= cut_end:
            a -= cut_end - cut_start
            b -= cut_end - cut_start
        elif a < cut_start and b > cut_end:
            raise ValueError(f"Caption spans both sides of removal: {block}")
        elif a < cut_start:
            if cut_start - a < 0.2:
                continue
            b = cut_start
        elif b > cut_end:
            a = cut_start
            b -= cut_end - cut_start
            # 'That' is removed at the start of this v2 cue; the previous
            # caption already ends with the retained 'that'.
            assert words.startswith("that makes it"), words
            words = words.removeprefix("that ")
        else:
            continue
        if a < b and a < total:
            cues.append((a, min(b, total), words))
    srt = []
    vtt = ["WEBVTT", ""]
    transcript = []
    for i, (a, b, words) in enumerate(cues, 1):
        srt.extend([str(i), f"{stamp(a)} --> {stamp(b)}", words, ""])
        vtt.extend([f"{stamp(a, '.')} --> {stamp(b, '.')}", words, ""])
        transcript.append(f"[{int(a // 60):02d}:{int(a % 60):02d}] {words.replace(chr(10), ' ')}")
    (HERE / "episode-02-captions-v3.srt").write_text("\n".join(srt))
    (HERE / "episode-02-captions-v3.vtt").write_text("\n".join(vtt))
    (HERE / "episode-02-transcript-v3.md").write_text("\n".join(transcript) + "\n")
    return len(cues)


def write_chapters(cut_start, cut_end, total):
    probe = subprocess.check_output([
        "ffprobe", "-v", "error", "-show_chapters", "-of", "json", str(V2)
    ])
    original = json.loads(probe)["chapters"]
    marks = []
    for chapter in original:
        t = float(chapter["start_time"])
        if cut_start <= t < cut_end:
            raise ValueError("A chapter starts within the removal")
        if t >= cut_end:
            t -= cut_end - cut_start
        marks.append((chapter["tags"]["title"], t))
    FFMETA.parent.mkdir(parents=True, exist_ok=True)
    lines = [";FFMETADATA1", "title=Out of Our Depth, Episode 2: Make AI useful", ""]
    md = ["# Episode 2 v3 chapters", ""]
    for i, (title, start) in enumerate(marks):
        end = marks[i + 1][1] if i + 1 < len(marks) else total
        lines += ["[CHAPTER]", "TIMEBASE=1/1000", f"START={round(start * 1000)}",
                  f"END={round(end * 1000)}", f"title={title}", ""]
        md.append(f"- {stamp(start, '.')} {title}")
    FFMETA.write_text("\n".join(lines))
    (HERE / "episode-02-chapters-v3.md").write_text("\n".join(md) + "\n")


def main():
    edl = json.loads(EDL.read_text())
    cut_start = edl["cut_v2_frames"][0] / 30
    cut_end = edl["cut_v2_frames"][1] / 30
    old_frames = edl["v2_total_frames"]
    new_frames = old_frames - edl["cut_v2_frames"][1] + edl["cut_v2_frames"][0]
    total = new_frames / 30
    assert (cut_start, cut_end, total) == (972.5, 984.2, 1855.6)
    if V3.exists() or WAV3.exists():
        raise FileExistsError("v3 output already exists; move it aside before rebuilding")
    assert sha256(V2) == edl["v2_sha256"]
    write_chapters(cut_start, cut_end, total)
    cues = write_captions(cut_start, cut_end, total)
    a, b = edl["cut_v2_frames"]
    sa, sb, st = (x * 1600 for x in (a, b, new_frames))  # 48 kHz / 30 fps
    GRAPH.write_text(";\n".join([
        "[0:v]split=2[vl][vr]",
        f"[vl]trim=end_frame={a},setpts=PTS-STARTPTS[v0]",
        f"[vr]trim=start_frame={b},setpts=PTS-STARTPTS[v1]",
        f"[v0][v1]concat=n=2:v=1:a=0,trim=end_frame={new_frames},format=yuv420p[vout]",
        "[1:a]asplit=2[al][ar]",
        f"[al]atrim=end_sample={sa},asetpts=PTS-STARTPTS,afade=t=out:st={cut_start-0.008:.6f}:d=0.008[a0]",
        f"[ar]atrim=start_sample={sb},asetpts=PTS-STARTPTS,afade=t=in:d=0.008[a1]",
        f"[a0][a1]concat=n=2:v=0:a=1,atrim=end_sample={st},asplit=2[master][enc0]",
        "[enc0]volume=-0.6dB[enc]",
    ]))
    run(["ffmpeg", "-nostdin", "-hide_banner", "-y", "-i", str(V2), "-i", str(WAV2),
         "-i", str(FFMETA), "-filter_complex_script", str(GRAPH),
         "-map", "[vout]", "-map", "[enc]", "-map_chapters", "2", "-map_metadata", "2",
         "-c:v", "libx264", "-preset", "veryfast", "-crf", "18", "-profile:v", "high",
         "-pix_fmt", "yuv420p", "-color_primaries", "bt709", "-color_trc", "bt709",
         "-colorspace", "bt709", "-r", "30", "-c:a", "aac", "-b:a", "256k",
         "-movflags", "+faststart", str(V3),
         "-map", "[master]", "-ar", "48000", "-ac", "2", "-c:a", "pcm_s24le", str(WAV3)])
    print(f"Rendered {V3.name}: {new_frames} frames, {total:.3f} s; {cues} caption cues")


if __name__ == "__main__":
    main()
