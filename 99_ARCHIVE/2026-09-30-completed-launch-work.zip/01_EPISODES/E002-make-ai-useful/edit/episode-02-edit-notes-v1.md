# Episode 2 — edit notes v1

Assembled from the 2026-09-25 reshoot. **Complete proposed final cut; host review pending.**

Runtime: **23:50.733** (source: 44:16.033). No prior-take footage is used. The original remains unchanged in `/Users/je/Movies/Episode 2 Raw.mp4`.

## Editorial shape

Use the last intro pickup, explain the intern metaphor, then move through Projects, connectors, and skills. Preserve both hosts’ concrete examples, disagreement about personal communication, humor, and sign-off. Remove abandoned starts, repeated setup, production chatter, extended company/hardware tangents, uncertain pricing, and the unsupported general jobs claim.

## Exact cut list

Times are half-open ranges at 30 fps; the JSON edit list is the frame-level source of truth.

| ID | Export in–out | Source in–out | Retained material / reason |
|---|---|---|---|
| S01 | 00:00.000–00:20.133 | 43:31.100–43:51.233 | Final intro pickup: host identity, learning in public, and the three-part route. |
| S02 | 00:20.133–00:53.567 | 02:37.867–03:11.300 | Retain the original, fuller intern metaphor; remove abandoned outlines. |
| S03 | 00:53.567–03:43.900 | 03:40.300–06:30.633 | Mary’s everyday examples, essential nonprofit context, desk analogy, plain-language definition of context. |
| S04 | 03:43.900–04:00.767 | 07:22.033–07:38.900 | Keep the practical onboarding takeaway; omit the system-prompt and harmful-request tangent. |
| S05 | 04:00.767–04:21.900 | 09:15.933–09:37.067 | Files and connected information; omit the universal automatic-memory and website-refresh claims. |
| S06 | 04:21.900–06:53.500 | 12:34.333–15:05.933 | Definition, real email example, permissions, and draft review. |
| S07 | 06:53.500–09:14.800 | 16:12.267–18:33.567 | Keep Mary’s concrete dictation example and the hosts’ exchange; omit the hardware/vendor/privacy tangent. |
| S08 | 09:14.800–11:21.467 | 22:36.133–24:42.800 | Begin after the picture dropout; retain contrasting host perspectives and introduce Granola. |
| S09 | 11:21.467–12:45.533 | 25:04.200–26:28.267 | Omit uncertain pricing/limits; keep the connected-notes workflow and consent reminder. Cover source picture blackout at 25:42.667–25:50.300 with a simple workflow card; keep original dialogue. |
| S10 | 12:45.533–15:01.233 | 26:56.100–29:11.800 | Three-part bridge and Mary’s dyslexia example; explain the instruction file. |
| S11 | 15:01.233–19:22.033 | 29:27.033–33:47.833 | Omit file-format tangent; keep recorded-workflow example, testing caveat, and Mary’s design process. |
| S12 | 19:22.033–21:46.400 | 34:00.067–36:24.433 | Keep the specific design experience and team reuse; omit the general jobs claim. |
| S13 | 21:46.400–23:50.733 | 40:52.667–42:57.000 | Remove extended product rankings/pricing tangent; preserve recap, lighthearted closing, and sign-off. |

## Picture and audio treatment

- Source framing and 1080p30 cadence retained; no digital punch-ins or synthetic footage. Edits are visible straight cuts between original passages.
- Added neutral, reversible title/definition/clarification overlays. These are editorial aids, not a newly approved show brand system.
- First source picture blackout, 22:23.267–22:30.867, falls in removed material. Second, 25:42.667–25:50.300, is covered by a workflow graphic while the original dialogue continues.
- All four source audio tracks were sample-identical in decoded 8 kHz mono analysis; use only track 0, not a sum of the duplicates.
- Reduce low rumble at 65 Hz; apply smooth dialogue gain capped at 3x, then two-pass loudness normalization targeting −16 LUFS / −1.5 dBTP. Gentle 8 ms audio edge ramps prevent clicks.
- Preserve the source’s room sound and both voices; no voice replacement or aggressive spectral denoising. Brief ending fade follows the sign-off.
- Export includes chapter metadata. No music or unconfirmed logo has been introduced.

## Claim clarifications

Product checks and exact sources: [Episode 2 source checks](../../../02_RESEARCH/episode-02-source-checks-2026-09-25.md). On-screen notes distinguish project instructions/files from a description, qualify connection permissions and refresh behavior, explain Granola audio retention, and remind viewers to test reusable skills. Personal outcomes remain the hosts’ accounts.

## Rebuild

Run `python3 render-episode.py` from this directory (requires local ffmpeg/ffprobe, Pillow, and access to the source). The frame list, all overlay copy, and audio settings are in `episode-02-edit-decisions-v1.json`. Generated source/audio/clip caches are under `intermediate/`, excluded from Git.

## Review limits

The edit was reviewed through a complete source transcript, word-aligned cut boundaries, sampled source/export pictures, and technical audio/video checks. That is not continuous human audiovisual playback. Final host listening, original camera lip-sync confirmation, and editorial approval remain necessary before publication.

## Voice-level spot checks

Eight 10–12 second passages were measured after export. The active-speech RMS proxy differs by about 0.5–2.8 dB between the paired Mary/Josh passages. This indicates reasonably close levels in those samples, not a substitute for listening or a claim of identical vocal tone. Natural emphasis and room sound remain.
