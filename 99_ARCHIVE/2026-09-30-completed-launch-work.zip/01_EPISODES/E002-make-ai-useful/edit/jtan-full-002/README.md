# Episode 002 full theme cut, mishaps only (jtan, 2026-09-29)

**Open `episode-002-full-credits-hook-jtan-v2.mp4`.** 33:13.433, 1920 × 1080, 30 fps, 59,803 frames. It's a private review cut, not approved, scheduled or published.

Josh asked for one full version of Episode 002 with only the clear mishaps removed and the current intro and outro cards. This cut follows the Episode 000 and 001 approach, not the tighter v2/v3. The September 26 take plays in its recorded order with no pop-ups or callouts. Composio stays where it was said, after skills, instead of being moved into connectors.

## Sequence

| Export | What |
|---|---|
| 00:00.000–00:06.300 | Hook 01, credits at bedtime (raw 17:49.433–17:55.733). It plays again in place at 17:36. |
| 00:06.300–00:11.567 | `EPISODE 002 / MAKE AI USEFUL` card with the 5.267 s sting, as in Episode 000 |
| 00:11.567–33:02.667 | The take from "And we're live" through "…took me a second," with five removals |
| 33:02.667–33:13.433 | Outro card (Love it? Tell Mary / Hate it? Tell Josh / …) with the outro music and fade |

The hook is swappable. `../jtan-002/build-full.py <hook-id> <new-file.mp4>` rebuilds with any of the eight testers in `../jtan-hooks-002/`, in about six minutes.

## What was removed (and nothing else)

| Raw | Length | Why |
|---|---:|---|
| 00:00.000–00:01.967 | 2.0 s | Dead air before "And we're live" |
| 06:34.267–06:38.267 | 4.0 s | Josh: the Granola free plan "gives you like 20 or 25 meetings per month." That's wrong: Granola's free Basic plan has unlimited meetings with a 30-day note history. The student year-free line before it is accurate and stays. Join: "…their like pro plan." → "And yeah, transcribes the whole meeting…" |
| 15:08.767–15:16.633 | 7.9 s | Josh's abandoned restart: "you now, if your AI tool is your intern, or sort of like giving it supervisees…" Join: "…a specialist in a certain area." → "So like when I'm calling the bank account one…" |
| 15:46.933–15:58.200 | 11.3 s | Mary: Humanizer "I think is built into Claude… Claude comes with tons of skills, product management…" It's a community skill, not built in. Join: "I have a humanizer one that" → "makes it sound slash look…" |
| 28:05.300–28:14.467 | 9.2 s | Names a Charlottesville shop as "very clearly made by AI." Join: "…you can see it." → "I think in Claude specifically…" |
| 30:33.800–31:17.100 | 43.3 s | The Canvas assignment story. Mary says on tape "I don't think I can use that example" and "I probably won't use that." Join: "…where you don't want to use AI?" → "Where it missed the mark…" |
| 34:08.667–end | 8.4 s | Off-air "And that was good." after the sign-off |

That's 86 s out of 34:17. **Kept even though v2 cut them:** the Granola phone-call detail (checked: Granola's iPhone app records outbound calls only, which is what Josh says), Josh restating Mary's website-pointer point, his class-projects example, the agents-reviewing-agents tangent, "we should include copies of the skills," the Wispr Flow aside, and both halves of the AI-tells chat.

## Checks

- Full-file decode: no errors. −16.0 LUFS integrated, −1.4 dBTP true peak, LRA 4.8 LU.
- Every join was transcribed from the finished file, and each reads as the words in the table. The humanizer join was also tested before rendering by stitching candidate audio. That's how v1's clip was caught: v1 resumed at 15:58.633 and cut off "makes." **The existing v3 cut resumes at that same 15:58.633 point and has the same clip at its 16:12.5 join. An ASR check of the v3 file hears "one that… it sound/look".**
- Sampled frames: hook, title card, body and outro render correctly.
- Captions: `…-v2.srt`, 571 cues, ordered and in bounds. They're machine words (whisper DTW timings) carrying the 9/26 transcript's punctuation, with product names corrected (Claude, Composio, Granola, Run Your City, Wispr Flow, Gemini). They're a draft and need a listening proofread.
- Chapters are embedded (12) and listed in `…-v2.chapters.md`.
- SHA-256 `598a11f1a33c487a082ea74551671a6e5bb1b6acbd506f4c3c98e4b9d14016da`.

**Nobody has watched it straight through.** The joins passed an ASR check, not a human listen.

## Still the hosts' call

- Which hook opens the episode.
- Names said on air: Mary's brother Lewis, and RYC's Olivia, Tyler and Chloe.
- Any of the kept tangents, if 33 minutes feels long.
- Recheck product claims on publish day, since they change fast: Claude's single Gmail/Slack connector, and ChatGPT's multi-account support from 8/28.

## Files

`episode-002-full-credits-hook-jtan-v1.mp4` (and its sidecars) is the first render, with the clipped "makes." It's superseded by v2 and safe to delete once Josh says so. `.edl.json` holds the exact raw frame ranges, export offsets and the removed text. Audio is centered for headphones, with a 70 Hz high-pass, gentle leveling and one linear loudness pass over the whole raw. The source is `/Users/je/Movies/Episode 2 Raw.mp4` (SHA-256 `087b52c2…a79b42d`), re-downloaded from Drive and hash-verified on 2026-09-29.
