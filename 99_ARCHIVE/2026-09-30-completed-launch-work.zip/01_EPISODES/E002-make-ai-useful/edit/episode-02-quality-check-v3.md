---
tags: [oood, episode-02, qc]
---

# Episode 2 v3 — quality check

Checked 2026-09-27. **Complete local export, technically checked, ready for Josh and Mary's review.** Not host-approved, scheduled or published.

## Source and export

| Check | Result |
|---|---|
| Source | `/Users/je/Movies/Episode 2 Raw.mp4`, September 26 reshoot, 34:17.100, SHA-256 `087b52c20549f20118216a867005944948da8d39f013b3089789a987aa79b42d` before and after production |
| Video | `episode-02-final-cut-v3.mp4`, 676,637,314 bytes, SHA-256 `435747f0f57274e14a90cf5e4bab8b5414a58086bd73a08dc84d6339b7eb1427` |
| Video stream | H.264 High, 1920 × 1080, 30 fps, yuv420p, BT.709, 55,668 frames |
| Audio stream | AAC-LC, stereo, 48 kHz, 256 kb/s setting |
| Duration | Picture, encoded audio and container all 1855.600 s (30:55.600) |
| Chapters | Nine embedded, matching `episode-02-chapters-v3.md` |
| Audio master | `episode-02-audio-master-v3.wav`, 48 kHz 24-bit stereo, SHA-256 `06a34fe7b2a0f1b3bc33c26d85ddd32ec4dfa8a4c038709c11983096b2680193` |

## Measured checks

- Full-file video and audio decode finished without errors. The decoded frame count was 55,668, matching the edit decision list.
- Full-file black-frame scan found no black span of at least 0.1 s at the specified 95% picture threshold. Sampled finished frames before and after the 16:12.5 join show the same two-host setup without a blackout; a finished recap graphic was also inspected.
- Encoded audio: **−16.64 LUFS integrated**, **−1.40 dBTP**, 4.50 LU range. Separate WAV master: **−16.01 LUFS**, **−1.49 dBTP**, 4.50 LU range.
- One-second WAV samples at v3 05:00, 16:40 and 30:00 match the corresponding v2 master samples exactly after accounting for the 11.7 s removal. The cut uses 8 ms audio fades; the sample step at the join is small (679 / 8,388,608 full-scale units in one channel, 2 in the other).
- `episode-02-captions-v3.srt` has 558 sequential cues with no overlap, nonpositive duration or cue past the export end. The unsupported “built into Claude” and “comes with tons of skills” wording is absent. The VTT and readable transcript use the same retimed cues.

## Review still required

- No one in this workflow watched or listened to the full episode continuously in real time. Technical decode and still-frame inspection do not establish final editorial approval, lip sync by eye or the sound of every join.
- The v3 captions were retimed from machine captions, with the new sentence corrected, but have **not** had a listening proofread.
- Josh and Mary should assess the new join at 16:12.5, overall pacing, and whether to name Lewis, Olivia, Tyler and Chloe. Product details may change and should be rechecked on publication day. Approval and release timing for this exact version are not recorded.
