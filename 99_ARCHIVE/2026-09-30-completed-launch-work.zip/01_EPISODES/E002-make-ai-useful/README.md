# Episode 002: current release archive

**Published on YouTube and Spotify**, confirmed by Josh 2026-09-30. The canonical final video, matching captions, published thumbnail, saved description/chapters and manifest are in [Drive](https://drive.google.com/drive/folders/1OdHgDxylP4Rs_zQ7_U8PHSlKTZZbnRBt). Local video exports and render intermediates were removed after checksum verification to free space. Original recordings remain in [Drive Raw](https://drive.google.com/drive/folders/1KrXgS2Ms6MSz6KXF5YWz1M3fZ_6_fshm); download a source before rebuilding.

[Archive receipt](../codex-drive-archive-2026-09-30/README.md) identifies the exact versions and verification. Lightweight project/edit records, brand templates and small selected hooks remain local. Older local media links below are historical and may no longer resolve; publication-status statements below describe their original review stage.

## Historical production notes

# Episode 2 — Make AI useful

The Projects, connectors, and skills episode. **Current Spotify upload file:** [episode-002-spotify-upload.mp4](edit/codex-spotify-color-fix-2026-09-30/episode-002-spotify-upload.mp4), the same final cut with consistent color tags. [Repair checks](edit/codex-spotify-color-fix-2026-09-30/README.md) passed; retry acceptance remains unconfirmed. **The September 26 reshoot is recorded** (`/Users/je/Movies/Episode 2 Raw.mp4`, 34:17). The current [33:14.267 full review](edit/codex-user-hook-2026-09-30/episode-002-full-review-v3.mp4) opens with Josh's exact saved `ep2hook.mp4`, followed by Episode 000's latest recurring cards and matching theme music. It retains the seven mishap removals and five-hour exchange per Josh's instruction. [Checks and review status](edit/codex-user-hook-2026-09-30/README.md) accompany it. The prior credits-hook cut, earlier 30:55.600 [v3 cut](edit/episode-02-final-cut-v3.mp4) and other versions remain references. The September 25 take was renamed `Episode 2 Raw - old.mp4`; its v1 cut is reference only.

Start with the [complete feedback and reshoot plan](reshoot-feedback-and-plan-2026-09-25.md). Use the [short recording cue sheet](reshoot-recording-cue-sheet-2026-09-25.md) at the camera. These are drafts; the proposed runtime, example, and optional visual inserts are not host-approved format decisions.

Sources: `/Users/je/Movies/Episode 2 Raw.mp4` (Sept 26 reshoot, current) and `/Users/je/Movies/Episode 2 Raw - old.mp4` (Sept 25). Keep both unchanged. The older `001-make-your-ai-useful` folder is a separate reference edit, not this episode’s release master.

`edit/` holds earlier reference cuts and the current full-review package: video, captions, chapters, reversible edit records, source checks and technical QC. `edit/intermediate/` is a local, Git-ignored working cache. Video/audio exports are excluded from Git. Host approval, scheduling and publication remain unconfirmed.

The [current YouTube description draft](codex-description-final-cut-v2-2026-09-30.txt) preserves Josh's supplied copy and has 23 detailed chapters timed to the exact 33:14.267 ep2hook export. The [chapter audit](codex-chapter-audit-v2-2026-09-30.md) records final-timeline topic anchors; [description source checks](../../02_RESEARCH/codex-episode-002-description-checks-2026-09-30.md) support the confidential-conversation and account-permission notes. Revised for shared YouTube/Spotify use: chapter starts are at least 33 seconds apart and the final chapter lasts 65.267 seconds. Saved locally on 2026-09-30; not applied to a platform.

**2026-09-29, jtan:** eight hook testers are in [edit/jtan-hooks-002/](edit/jtan-hooks-002/README.md), and a 33:13 mishaps-only full cut with the `EPISODE 002` cards is in [edit/jtan-full-002/](edit/jtan-full-002/README.md). The full cut keeps the raw order and removes 86 s of clear mishaps only. Hook choice and host review remain open.
