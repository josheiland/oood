# Episode 2 — feedback and final-reshoot plan

Prepared 2026-09-25 for Josh and Mary. **Draft for host review.** Josh has confirmed another reshoot; the structure, example, runtime, and visual treatment below are recommendations, not approved show-format decisions. Recording date and publication remain unconfirmed.

**2026-09-26 steering:** Josh clarified that entertainment, accessibility, and audience affection for the hosts and their relationship must drive the episode. Preserve good exchanges even when they take longer than the outline. Record Episodes 0 and 1 first, then reshoot E002 this weekend, September 26–27; exact times remain open. Use the adopted [brand kit rules](../../03_ASSETS/brand-guidelines.md) for all new visuals and [editorial direction](../../00_CONTEXT/editorial-direction.md) for planning/editing. Runtime and the single-example structure below remain suggestions.

## The change that matters most

Make the episode about a recognizable frustration: **“Why does my AI keep giving me answers that aren't useful to me?”** Projects, connectors, and skills are the three ways into that problem. Let the audience experience the improvement through one continuing task, with your reactions and judgment driving the conversation.

The current material has useful explanations and distinctive personal stories. The opportunity is to connect them more tightly. The listener should leave remembering **background / access / reusable directions**, knowing when each helps, and feeling able to try one small change.

Recommended working title: **Why Your AI Still Gives You Generic Answers**. Descriptive subtitle: **Projects, connectors, and skills—with examples from our actual work.** Only use the subtitle if the final examples are real host work; label any recreated demonstration clearly.

## Evidence and review limits

This assessment uses the [September 23 watchback notes](https://notes.granola.ai/d/b62feebf-fa25-4fb4-af2e-00a4df3bad47), current project goals, both recording outlines, the September 25 cut's [reference transcript](edit/episode-02-reference-transcript-v1.md), [edit notes](edit/episode-02-edit-notes-v1.md), [technical checks](edit/episode-02-quality-check-v1.md), and both claim registers. This pass is a transcript/document review, not a new end-to-end viewing or listening session. Comments on structure and wording are grounded in those documents; delivery coaching is proposed, not a claim about facial expressions or vocal performance I personally observed.

Unless explicitly marked **earlier cut** or **raw**, timestamps below refer to the **23:50.733 September 25 export** and are approximate. The transcript is not authoritative for uncertain wording or speaker attribution.

The format recommendation draws on the [existing audio/video research](../../02_RESEARCH/podcast-video-audio-and-demos-2026-09-25.md). That research does not prove that screen shares improve retention or establish an ideal episode length. The runtime and visual durations below are editorial budgets to test.

## What success means for this episode

| OOOD goal | What to deliver here | How to check before release |
|---|---|---|
| Useful to busy, thoughtful non-experts | One recognizable task; three clear distinctions; one next step | A listener can explain the three ideas without repeating product jargon |
| Casual, relatable, entertaining | Both hosts have opinions, specific stories, and real reactions | Preserve disagreement and a few natural jokes; remove duplicated explanation |
| Grounded in operating experience | RYC explains why you care; an ordinary-life parallel makes it transferable | A listener outside nonprofits can name a use for the lesson |
| Honest experimentation | One actual limitation or failure, plus what you changed | No implication that polished output equals verified success |
| Learning in public with credibility | Correct names and boundaries; distinguish experience from product facts | No technical correction relies solely on a graphic |
| Teachable and memorable | Background / access / reusable directions | A test listener can choose the right tool for a new example |

## Preserve these strengths

- **The relationship and complementary strengths.** Mary's design judgment and Josh's ability to reuse it are more distinctive than a generic feature explanation (17:40–21:38).
- **Mary as a knowledgeable user.** Her class, reading, writing, and design examples make the lesson personal. Build on these instead of assigning her a permanent beginner role.
- **The focused-desk analogy.** Useful for explaining why the assistant needs relevant background (02:05–03:09). Keep it brief and clearly metaphorical.
- **Different views on personal communication.** The exchange at 09:14–10:50 is worth keeping in a shorter form tied to reviewing the example output.
- **The human source of the taste.** Mary's point at approximately 19:21—she supplied the brand judgment—is a strong practical and editorial payoff.
- **An unforced personal ending.** The final prompt story gives the hosts dimension. Keep one approved story after the actionable close, without turning the ending into another lesson.

## Prioritized feedback checklist

**P0:** fix before recording. **P1:** build into the reshoot. **P2:** optional polish after the core works. The check column defines what “fixed” means; it is not a claim that the change has already been made.

| # | Priority | Evidence / gap | Change for the reshoot | Check |
|---|---|---|---|---|
| 1 | P0 | 00:00–00:53 establishes identity, topic names, and an analogy before showing a useful result | Start with the pain and a concrete output. Let Mary judge a specific sentence before the full explanation | Viewer benefit is clear in the first 30 seconds |
| 2 | P0 | 00:16 gives a list of features; the payoff stays implicit | State the route as three problems: it doesn't know our background, can't find the needed information, and needs the same directions again | Each topic answers one question the audience already understands |
| 3 | P0 | Skills begins at 12:45; voice input, personal messages, and meeting software intervene | Teach all three concepts consecutively. Put the short personal-message disagreement inside the combined example | Skills starts around minute 7 in the proposed structure |
| 4 | P0 | The examples jump among nonprofit work, classes, email, dictation, meetings, banking, and design | Use one throughline: a follow-up after a partner meeting. Add only two short personal/brand examples | Every major section improves the same task |
| 5 | P0 | 04:22 “And then comes connectors” names the next topic before motivating it | First say that the missing information lives elsewhere; then define the connection and give the example | Each transition contains problem → definition → payoff |
| 6 | P0 | Skills examples begin around 13:29; the instruction-file definition arrives at 14:50 | Give the plain definition before naming a custom skill. Reveal three actual rules, not a file-format explanation | Listener can explain the mechanism before hearing the brand name |
| 7 | P0 | 02:30–02:53 and 03:44 equate project description with instructions; overlays currently clarify | Say “project instructions and relevant files.” Use the actual field names only for the demonstrated app | Spoken explanation is correct without the screen |
| 8 | P0 | 04:22 “almost everything,” 05:31 login analogy, 05:43–06:02 generic permission claims | Describe authorized access to supported services. Separate reading from changing/sending; don't describe pasting a password into chat | No promise of universal access or universal approval controls |
| 9 | P0 | 14:22 “knows it forever,” 16:53 “set and forget,” and generic shortcut language | Explain saved directions, then testing and maintenance. Name the actual app if demonstrating invocation | No permanent-learning or guaranteed-trigger claim |
| 10 | P0 | Current cut needs visual notes to qualify several spoken claims | Record corrected sentences. Graphics should reinforce the words | Audio-only review has no missing caveat |
| 11 | P0 | 15:38–16:45 bank-account workflow is a large capability leap for a beginner lesson | Remove from the main explanation; at most a brief clearly bounded advanced anecdote if independently confirmed by Josh | No suggestion that connecting an app or saving instructions alone completes financial operations |
| 12 | P0 | Prior quality report records two raw picture blackouts and duplicated audio mixes | Diagnose and test OBS before the new take; record and verify separately usable microphones if supported | No blackouts, missing mic, or drift in a representative test |
| 13 | P1 | September 23 direct feedback asks for Mary to explain, not just ask | Mary owns the opening judgment, useful background, reading preferences, and brand judgment. Josh owns access mechanics and putting the workflow together | Both define something and both challenge or evaluate something |
| 14 | P1 | Hosts reported the earlier take felt dry and improved as they warmed up | Warm up off-record with a real recent AI annoyance; record the opening again at the end | Opening has the same conversational ease as the body |
| 15 | P1 | 00:27, 02:05, 13:06, and 20:34–21:06 repeatedly extend the intern metaphor | Use one short onboarding analogy and one callback. Cut the promotion/managing-interns/agent-team extension | The metaphor clarifies the lesson without becoming another topic |
| 16 | P1 | 01:05 lists personal uses; RYC identity remains implicit | Briefly introduce RYC as the nonprofit you run together. Add one class or household parallel | No assumed knowledge of RYC; no nonprofit-only audience framing |
| 17 | P1 | 03:19 asks what context stands for; several product-name searches occur aloud | Define context immediately as the information available for the current response. Put names on the cue sheet | Product uncertainty is checked before rolling, not guessed on camera |
| 18 | P1 | 06:53–09:14 is a separate voice-input mini-episode | Move the full Wispr/voice experiment to a future episode. Allow one sentence if needed to explain Mary's input | Voice never interrupts the three-part route |
| 19 | P1 | 09:14–10:50 contains a good disagreement plus repetition and assumptions about recipients | Keep 45–60 seconds around the actual draft: what would each of you change or keep personal? | Opinions are phrased as your preferences, not what all recipients want |
| 20 | P1 | 11:01–12:40 adds calendar behavior, meeting capture, connected notes, Gmail, and scheduling | Use one existing document or meeting note. Explain task input → useful output; avoid adding a software tour | No new app is named without a clear role |
| 21 | P1 | 13:29 reading preference story is compelling but can sound like a broad dyslexia benefit | Mary introduces her own experience first, if she wants it included. Explain the specific format that helps her | Personal experience stays personal; Josh uses her chosen name afterward |
| 22 | P1 | 17:40–21:38 contains strong design material mixed with setup history and broad future-of-work claims | Keep the three design rules, a before/after, and what Mary still rejected. Compress the website/tool history | Audience sees how Mary's judgment became reusable |
| 23 | P1 | Earlier cut 17:28–20:53 contains automation and grant-search failures; new cut lacks an equally concrete failure beat | Re-record one truthful failure: stale grant result, missed source detail, or failed reuse. Say what caught it and what remains hard | One specific miss and a practical correction; no invented demo failure |
| 24 | P1 | “Bot,” “skill,” saved prompt, and action-taking workflow can blur together | Briefly show what is under the name: saved words, optional resources/tools, and the steps the system actually performs | A named bot is not treated as proof of autonomy or sophistication |
| 25 | P1 | 21:46 recap names the concepts, then jumps to the personal story | Give one small viewer action before the story; briefly repeat it at the sign-off if natural | Listener knows what to do next without buying or connecting everything |
| 26 | P1 | Past host feedback identifies abrupt light/seating changes between takes | Mark chair/camera placement, stabilize lighting, match mic distance, and take a continuity photo | Pickups match the main take closely enough for simple cuts |
| 27 | P1 | A before/after could accidentally imply all improvements came from one feature | Hold task and source material constant where practical; name each added ingredient. Save actual outputs and disclose edited excerpts | No staged failure, invented result, or implied benchmark |
| 28 | P1 | Earlier notes ask for a route/progress sense without deciding a permanent visual system | Speak short recaps at transitions; optionally add three simple labels | A listener always knows what the next topic adds |
| 29 | P2 | Sound effects, recurring progress graphics, and end visuals remain open | Use host reactions and clean cuts first; test any graphic or effect only when it clarifies or supports a real joke | Polish doesn't carry the explanation or interrupt a punchline |
| 30 | P2 | No established performance thresholds or approved companion format | Draft description recap, vocabulary, sources, and clip candidates after the take; measure against your own early baseline | No invented retention target or claim of audience response |

## Recommended 21-minute running order

Aim for **20–23 minutes finished**; the table allocates 21 minutes. This is a scope guide, not a reason to rush a good exchange. Capture approximately 25–30 minutes of conversation plus pickups if that is comfortable. Record sections cleanly instead of repeatedly restarting the episode.

| Finished time | Beat and lead | Content and interplay | Exit condition / transition |
|---|---|---|---|
| 00:00–00:45 | Cold open — both | One actual generic sentence versus a useful revision; Mary says specifically what she would change or send. Josh asks what the assistant was missing | The audience has a reason to care before the vocabulary |
| 00:45–01:30 | Promise and orientation — Josh, Mary | Names, one-line RYC context, the three-part route. No prerequisite to have watched Episodes 0 or 1 | “We'll use one follow-up to show what each part adds” |
| 01:30–04:30 | Projects / background — Mary | Define context and a Project. Mary chooses a short organization brief, audience, and approved voice example. Josh asks what she would leave out. One quick class/household parallel | “It knows us now. It still doesn't know what happened in that meeting” |
| 04:30–07:30 | Connectors / access — Josh | Define the connection. Retrieve one approved note/document, point to a specific fact, and verify it. Mary challenges an ambiguity. Distinguish reading from taking an action | “It can find the facts. But I still keep asking for the same format” |
| 07:30–11:30 | Skills / reusable directions — Mary, Josh | Start with three written rules for the follow-up. Josh explains how a supported skills system reuses them. Mary gives her reading-preference example if approved; Josh asks how she tests it | “Now let's use all three on the same job” |
| 11:30–14:30 | Combined payoff — both | Compare the actual resulting draft to the source. Identify one useful detail, one sentence to edit, and one fact still missing. Keep the short debate about personal communication | Audience can attribute each improvement to background, access, or directions |
| 14:30–16:30 | Mary's judgment travels — Mary | Brief brand example: which rules came from her, what Josh can reuse, and what she still reviews. Prefer one concrete artifact over platform history | “Saving the rules doesn't remove the need for judgment” |
| 16:30–18:30 | What failed / when not to build — both | One verified miss from your experience. Explain the check and setup/maintenance effort. A one-off task may need only a regular prompt; manual attachment can be enough | Audience understands the limits and the smallest useful starting point |
| 18:30–19:45 | Recall and action — both | One sentence each for background/access/directions. Pick one repeated task, add a few relevant facts, try it, and evaluate the result before adding complexity | A clear action has landed |
| 19:45–21:00 | Human ending — both | One funny recent prompt and a real reaction. Brief callback to the lesson, sign-off | No new feature explanation after the recap |

## The continuing example: meeting → follow-up draft

**Proposed example, not an existing verified result.** Use a host-approved, redacted partner meeting if available. Otherwise use a clearly labeled fictional meeting. A fictional recreation is preferable to implying that an invented partner, deadline, or result is real.

Prepare one small packet: the request, a short organization brief, one meeting note, and three reusable directions. Keep the final task constant: **draft a short follow-up that reflects the discussion and makes the next steps clear.**

| Stage | What changes | What viewers should notice | What to say if it doesn't work |
|---|---|---|---|
| Initial request | No organization background or meeting source | Output may be generic or ask for missing details; show what actually happens | “It needs information we haven't given it” |
| Add background | Relevant instructions and a short brief | Does the language better fit the audience and organization? | Say which information was missed; don't claim improvement just because this was the planned beat |
| Add access | Locate the approved meeting note through the chosen connection | Can you trace the draft's facts back to that source? | Show the retrieval failure honestly; use the prepared source as a labeled fallback |
| Add reusable directions | Save/apply the three task rules using the verified app mechanism | Does the draft follow the requested structure while preserving facts? | Identify the rule it missed and revise/test it |
| Human review | Both hosts evaluate the result | Which sentence would Mary rewrite? Which action or date would Josh verify? | Leave unknown information unresolved rather than manufacturing a complete-looking draft |

Suggested three rules for the demonstration: keep the draft concise and direct; list next steps with owners and dates **only when the notes state them**; flag missing details rather than inventing commitments. These are new demonstration instructions, not a claim about a skill the hosts already use.

Do not send a real message during this example. A draft and a source check demonstrate the lesson completely. If no connection is available, use the note manually and explicitly say that this shows the workflow's logic, not a successful connector demonstration. Do not conflate access with freshness: check the document date and relevant passage.

Use the same app and configuration for the central demonstration where practical. Save inputs and outputs, label any changes, and say if several attempts were needed. This is an illustrative workflow, not a controlled model evaluation. You do not need a deliberately bad first answer to make the lesson work.

## Conversation and host preparation

- **Mary:** choose the context that matters; explain your actual reading preferences in your own terms; bring one design rule and an output you would reject. You should initiate explanations and ask Josh to justify claims.
- **Josh:** make the mechanics legible; bring the approved note and exact access setup; describe one thing you overbuilt or had to fix. Do not re-explain Mary's whole answer after she lands it.
- **Both:** use prompts, not memorized paragraphs. Finish a thought, then hand over with a specific question. Ask “What changed?” or “Would you actually use that?” instead of a generic “Does that make sense?”
- Keep the entertainment inside the task: Mary assessing Josh's draft, Josh admitting he depends on her taste, an output missing the point. Do not script a disagreement, reaction, or failure that did not happen.
- Repetition should serve recall. One definition, one example, one short restatement is enough. Park future episodes when they arise and return to the current question.
- Warm up for five minutes before the take. Record the opener and closing pickups after the body so their promise matches what you actually covered.

## Screen-share proposal and audio fallback

**Recommended for this episode, pending host choice:** a conversation that is complete through audio, with up to three short result inserts if useful. This does not settle the show's permanent format.

1. A generic-versus-revised excerpt in the opening.
2. The source passage beside the follow-up draft.
3. Mary's brand rules beside the resulting design.

Budget roughly 20–45 seconds per insert as an editing experiment, not a research-backed rule. Explain the important difference aloud before or while showing it. Enlarge the relevant sentence or design detail; don't show an unreadable desktop. Return to the hosts for judgment and reaction.

Record the screens separately if needed; label recreations and don't imply a prerecorded operation is happening live. If a demo stalls, finish the explanation conversationally and capture an honest pickup. Menu navigation, login, loading, and long setup belong in an optional companion walkthrough, if the hosts choose to make one.

If the hosts prefer no screen shares, the same running order works: read the relevant sentence, describe the source fact and correction, and explain the visual example's specific change. Avoid “as you can see” as the only explanation.

## Accuracy notes for the new take

These are recommended formulations, not quotes from the hosts. The [reshoot source addendum](../../02_RESEARCH/episode-02-reshoot-source-addendum-2026-09-25.md) records the fresh checks and their limits. The [existing source pack](../../02_RESEARCH/episode-02-source-checks-2026-09-25.md) remains the reference for other named products.

| Avoid / qualify | Say or do instead |
|---|---|
| Project description is the instruction field | “Keep relevant background in the project's instructions and files.” Show the exact fields only after testing the selected app |
| It automatically remembers everything / always checks the latest site | “We've made this background available; we still check that it used the right information.” Don't promise automatic updates |
| Give it your login / it can connect to everything | “Authorize a connection to a supported service.” Explain the demonstrated access |
| It will always ask before sending / a prompt is an access restriction | “The controls depend on the app and setup. Here's what this one allows.” Make the demonstration a draft |
| Learn it once, know it forever | “Save the directions so you can reuse them; test them and update them as the task changes” |
| Every product uses the same slash command / a saved prompt is always a native skill | Describe the reusable-instructions idea, then name and test the actual product mechanism |
| A skill is only a text file | “The core is reusable instructions; a skill can also include supporting resources or code.” Skip file extensions unless needed |
| Skill equals workflow equals autonomous bot | Point to the actual saved directions, connected capabilities, and executed steps separately |
| Dyslexify works for people with dyslexia generally | Mary describes what helps her personally and chooses whether/name/how to share it |
| The assistant said “done,” so a workflow succeeded | Check the output or destination. Josh's prior financial-workflow experience remains a host account, not an audited demonstration |
| Granola records and stores meeting audio | If retained, verify and use the precise current product description from the source pack; otherwise say “meeting notes” and omit capture mechanics |
| One-time setup / no maintenance | “You don't need to repeat every setup step each time, but sources, access, and instructions still need checking” |
| This saves everyone time / replaces tasks, not jobs | Describe your specific experience, including setup and review effort. Omit unsupported general claims |
| Approximate product prices, rankings, or limits | Leave out unless essential and checked for the exact product, plan, and publication date |

## Shoot preparation and recording workflow

Suggested owners below are planning assignments, not confirmed commitments. Josh and Mary can swap them.

**Before the session**

- Josh: choose the actual app and connection, test the example, save the inputs/outputs, and record the product/plan/date. Confirm factual wording against the source notes.
- Mary: select the personal and design examples she wants included; approve any visible material. Choose specific rules and a real quality judgment.
- Both: settle the temporary demo treatment, read the cue sheet aloud once, and select one failure story. Decide whether the target release date still works after a new recording and edit.
- Prepare redacted or fictional demo content; hide private tabs, notifications, names, account information, and meeting content that is not cleared for sharing.

**Technical preflight**

- Match OBS and Logi Tune at 1920 × 1080, using the intended recording frame rate. Preserve the established 1080p decision.
- Check each microphone alone, then both together, at normal and animated speaking levels. Listen to the recording, not just the live meters.
- Verify whether the intended individual microphone tracks are actually distinct: the prior source's four tracks were duplicate mixes. Do not assume extra tracks equal separate microphones.
- Investigate the prior blackouts at raw 22:23–22:31 and 25:43–25:50: test camera continuity, scene changes, cables, and the actual recording setup. Cause is not established by the existing report.
- Run a test at least as long as the expected uninterrupted take, exercising any screen changes. Review picture and sync at the start, middle, and end and around transitions. If failures recur, fix the setup before the main take.
- Mark seats and camera placement; stabilize lighting/exposure where available; match microphone positions. Record a continuity photo and a short room-tone sample.
- Confirm available recording space and a second copy destination. Keep raw media outside Git and record its location in the asset manifest when it exists.

**During the session**

- Warm up, record the body in chapter blocks, then record two short opening options and the closing pickups. Use the selected clean opener; do not assemble a promise the body never fulfills.
- For a factual slip, pause and repeat the entire corrected sentence. For a tangent, mark it and continue; do not restart the entire episode.
- Leave brief clean pauses at section boundaries for editing. Keep natural laughter, disagreement, and useful interruptions.
- Recheck recording status and sound between blocks. Capture source/output inserts separately after the conversation if that keeps the exchange natural.

**After the session**

- Back up and verify the new source before editing. Keep prior sources and exports intact, with distinct names and dates.
- Update the brief/manifest with the actual recording date and source only once confirmed. Do not label the reshoot recorded or ready in advance.
- Edit for the audience question and three-part route. Prioritize corrected speech, source fidelity, and host chemistry over the exact minute budget.
- Keep any missing fact or unusable demo visible in the editing notes. Do not conceal it with an invented result.

## Release review and stopping rule

Use these checks to avoid another full reshoot driven only by small imperfections. If the story, audio, and facts work, fix isolated problems with pickups or edits.

- [ ] Benefit and route are understandable within the opening minute.
- [ ] Each concept has a clear definition, concrete example, and reason to use it.
- [ ] Both hosts explain, react, and exercise judgment.
- [ ] A listener outside RYC can apply the ideas to their own task.
- [ ] The combined example has traceable inputs and honestly represented output.
- [ ] One concrete limitation/failure survives the edit.
- [ ] All consequential qualifications are spoken; screenshots are supplemental.
- [ ] Product facts are sourced, exact setup is tested, and personal outcomes remain identified as host experience.
- [ ] A person unfamiliar with the outline can explain the three ideas and name a next action after listening without the picture. If not, fix the confusing section.
- [ ] Both hosts watch/listen to the full export for sound, original lip sync, accuracy, personal disclosures, and approval.
- [ ] Release timing is confirmed separately; September 27 remains a target until then.

After release, inspect where viewers leave, whether comments/questions reveal a misunderstood term, and whether people report trying the suggested action. Compare future episodes with your own developing baseline. Segment position, topic, title, and audience size confound conclusions; do not claim one insert or length caused better retention.

## Packaging after the recording

- Choose the title around the problem the final episode actually solves. Avoid broad promises of complete automation or measured productivity gains.
- Derive chapters from the final export. Keep source timestamps separate from published chapter times.
- If approved, put a three-bullet recap, plain definitions, and dated source links in the description. Do not promise a website guide or companion until it exists.
- Candidate clips: Mary choosing what context matters; the difference between access and directions; Mary's taste becoming reusable; a failure that taught you what to check. Select only strong moments actually recorded.
- Preserve the fun close, but keep it shorter than the lesson it follows. No sound-effect package or permanent visual system is required to make this episode work.

## Choices still for the hosts

1. The actual app and approved example packet; the meeting-follow-up throughline above is proposed.
2. Brief visual inserts versus entirely host-led visuals for this take; the permanent format remains open.
3. Mary's personal example and the closing anecdote she and Josh want included.
4. Recording date, edit/review ownership, and whether the proposed September 27 launch target remains feasible.

The [recording cue sheet](reshoot-recording-cue-sheet-2026-09-25.md) reduces this plan to the chronological prompts to keep beside the camera.
