# Episode 002 chapter audit, v2: shared platform spacing

- Date: 2026-09-30.
- Current description: [plain text v2](codex-description-final-cut-v2-2026-09-30.txt).
- Supersedes the 27-chapter YouTube-only description and timing checks in `codex-youtube-chapter-audit-2026-09-30.md`. Those files remain historical references.
- Exact source: `edit/codex-user-hook-2026-09-30/episode-002-full-review-v3.mp4`; duration 1994.267 seconds (33:14.267).
- SHA-256 verified in the preceding audit: `eece6af6e408f441c356557b29d6424857ae8301e904654e8d686521ec5d47a3`.
- Retained starts preserve the prior final-SRT topic anchors; only adjacent short sections are merged. Video/captions and the 12 embedded media chapters are unchanged.
- Checks: 23 chapters, first 00:00, all starts chronological, minimum start-to-start gap 33 seconds, final chapter 65.267 seconds. No chapter is shorter than 30 seconds.
- Official rule: [Spotify Episode chapters](https://support.spotify.com/us/creators/article/episode-chapters/) (Spotify, undated live help, accessed 2026-09-30) states at least three chapters and at least 30 seconds between starts. It advises merging chapters shorter than 30 seconds. Manual entries use chronological plain text, one per line, starting at 00:00. OOOD applies 30 seconds to the final chapter too as a shared-platform default.
- Earlier checks used YouTube's ten-second minimum and missed Spotify's stricter spacing. Josh requested the correction and durable guidance.
- Draft copy only; no platform update, full auditory caption proof or host approval established.

## Merges

- 00:00 opening + 00:12 episode setup → 00:00 Intro: why these three features.
- 05:59 connectors + 06:21 Granola/consent → 05:59 Connectors, Granola and recording consent.
- 22:09 examples setup → included at the end of the 21:43 recap. The newsletter keeps its accurate 22:22 start.
- 32:55 goodbye/outro → included in the 32:09 final agents chapter, extending to the episode end.

## Retained final-timeline anchors

| Chapter | Title | Caption anchor | Opening phrase / reason |
|---|---|---|---|
| 00:00 | Intro: why these three features | 00:00.000 | Saved ep2hook running exchange, followed by recurring intro card/music. |
| 01:43 | Projects: give your AI a desk | 00:01:43,313 | And okay. All right. So let me talk through the high level and then we can go down |
| 04:56 | Mary's fitness project | 00:04:56,593 | answers and using it a lot. So another project I have is, is like kind of staying |
| 05:59 | Connectors, Granola and recording consent | 00:05:59,773 | It's fun. Then we have connectors. |
| 08:12 | Skills: reusable workflows | 00:08:12,033 | our foundations, then we have skills. |
| 08:45 | Josh's bank account skill | 00:08:45,253 | Like for example, I help set up all of our bank accounts for our new chapters. |
| 09:56 | Teaching a skill by showing the workflow | 00:09:56,693 | But what's really cool is that instead of manually typing out that document with a |
| 10:49 | Projects vs. skills (hello, Dyslexify) | 00:10:49,073 | skill. And I was kind of confused in the beginning of like, Okay, you have projects |
| 11:56 | Claude Design and Wispr Flow | 00:11:56,473 | But a lot of times I do so I like a quick tangent on that was in Claude design, |
| 13:40 | Leveling up your intern | 00:13:40,453 | So I think if we did, I think of skills is like going back to the intern thing. |
| 14:33 | The brand skill Josh stole from Mary | 00:14:33,313 | So now I've stolen Mary's Run Your City, uh, brand design skill and I'll use it, |
| 15:42 | Humanizer: less AI slop | 00:15:42,186 | I think other skills at the top of my head, I have a humanizer one that |
| 16:29 | The skills behind this podcast | 00:16:29,880 | like the, uh, and the ones you just built out for, for this podcast. |
| 17:23 | Josh vs. unused credits | 00:17:23,300 | Yeah. Overnight. This is something I love doing too is like, you know, you have a |
| 19:01 | Why AI tells make people tune out | 00:19:01,280 | it's fun when people start using AI. |
| 19:49 | Composio: connecting multiple accounts | 00:19:49,560 | Totally. One thing that I know is helpful for us, and I don't know if it's a little |
| 21:43 | Recap: projects, connectors and skills | 00:21:43,460 | I love it. We kind of zoomed through that. |
| 22:22 | One newsletter instead of 20 | 00:22:22,660 | I do get a morning newsletter every day with developments in AI, developments in |
| 23:37 | A grant finder for Run Your City | 00:23:37,100 | I built a tool for our nonprofit that helps us find grant opportunities. |
| 26:07 | Rebuilding our whole website | 00:26:07,220 | Totally. Maybe for the sake of time, I'll just do one more, but also on the note of, |
| 27:52 | Why human effort still matters | 00:27:52,733 | I think in Claude specifically, you can kind of tell when you do enough to like |
| 29:53 | Where AI missed the mark | 00:29:53,993 | Yeah. So on that note, then to wrap us up, you mentioned one area where like with |
| 32:09 | What's next: agents | 00:32:09,093 | time. Okay. Last question before we sign off. |
