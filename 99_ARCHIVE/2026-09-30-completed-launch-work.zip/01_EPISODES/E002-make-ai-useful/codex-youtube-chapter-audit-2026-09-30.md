# Episode 002 YouTube chapter audit

- Date: 2026-09-30
- Exact export: `edit/codex-user-hook-2026-09-30/episode-002-full-review-v3.mp4`
- SHA-256: `eece6af6e408f441c356557b29d6424857ae8301e904654e8d686521ec5d47a3`
- Verified duration: 1994.267 seconds (33:14.267).
- Description: [plain text draft](codex-youtube-description-final-cut-2026-09-30.txt).
- Timing source: captions accompanying this exact export; topic introductions, rather than the earlier cut's timestamps. Whole-second chapter starts are rounded down to include the opening phrase. The transcript remains a draft and this audit does not establish full auditory caption proof or host approval.
- Cold open 00:00–00:07.133; intro 00:07.133–00:12.400; outro 33:03.500–33:14.267. Hook and intro share one chapter; goodbye and outro share one chapter.
- All 27 starts ascend, first is 00:00, shortest interval is 12 seconds, final chapter lasts 19.267 seconds. These meet the timing rules in [YouTube's Video Chapters help](https://support.google.com/youtube/answer/9884579?hl=en), accessed 2026-09-30. Platform eligibility is separate.
- These detailed description chapters do not replace the export's 12 broader embedded chapters. No video or caption mutation was needed.

## Topic anchors in the final timeline

| Chapter | Title | Caption anchor | Opening phrase / reason |
|---|---|---|---|
| 00:00 | Cold open and intro | 00:00.000 | Saved ep2hook running exchange, followed by recurring intro card/music. |
| 00:12 | Why these three features | 00:00:12,893 | And we're live. |
| 01:43 | Projects: give your AI a desk | 00:01:43,313 | And okay. All right. So let me talk through the high level and then we can go down |
| 04:56 | Mary's fitness project | 00:04:56,593 | answers and using it a lot. So another project I have is, is like kind of staying |
| 05:59 | Connectors: access to your tools | 00:05:59,773 | It's fun. Then we have connectors. |
| 06:21 | Granola and recording consent | 00:06:21,693 | Granola, which is another tangent, but Granola is the note taking app that we use |
| 08:12 | Skills: reusable workflows | 00:08:12,033 | our foundations, then we have skills. |
| 08:45 | Josh's bank account skill | 00:08:45,253 | Like for example, I help set up all of our bank accounts for our new chapters. |
| 09:56 | Teaching a skill by showing the workflow | 00:09:56,693 | But what's really cool is that instead of manually typing out that document with a |
| 10:49 | Projects vs. skills (hello, Dyslexify) | 00:10:49,073 | skill. And I was kind of confused in the beginning of like, Okay, you have projects |
| 11:56 | Claude Design and Wispr Flow | 00:11:56,473 | But a lot of times I do so I like a quick tangent on that was in Claude design, |
| 13:40 | Leveling up your intern | 00:13:40,453 | So I think if we did, I think of skills is like going back to the intern thing. |
| 14:33 | The brand skill Josh stole from Mary | 00:14:33,313 | So now I've stolen Mary's Run Your City, uh, brand design skill and I'll use it, |
| 15:42 | Humanizer: less AI slop | 00:15:42,186 | I think other skills at the top of my head, I have a humanizer one that |
| 16:29 | The skills behind this podcast | 00:16:29,880 | like the, uh, and the ones you just built out for, for this podcast. |
| 17:23 | Josh vs. unused credits | 00:17:23,300 | Yeah. Overnight. This is something I love doing too is like, you know, you have a |
| 19:01 | Why AI tells make people tune out | 00:19:01,280 | it's fun when people start using AI. |
| 19:49 | Composio: connecting multiple accounts | 00:19:49,560 | Totally. One thing that I know is helpful for us, and I don't know if it's a little |
| 21:43 | Recap: projects, connectors and skills | 00:21:43,460 | I love it. We kind of zoomed through that. |
| 22:09 | Top things we've built with AI | 00:22:09,600 | But with the time we have left, can you do a top five things you built with AI? |
| 22:22 | One newsletter instead of 20 | 00:22:22,660 | I do get a morning newsletter every day with developments in AI, developments in |
| 23:37 | A grant finder for Run Your City | 00:23:37,100 | I built a tool for our nonprofit that helps us find grant opportunities. |
| 26:07 | Rebuilding our whole website | 00:26:07,220 | Totally. Maybe for the sake of time, I'll just do one more, but also on the note of, |
| 27:52 | Why human effort still matters | 00:27:52,733 | I think in Claude specifically, you can kind of tell when you do enough to like |
| 29:53 | Where AI missed the mark | 00:29:53,993 | Yeah. So on that note, then to wrap us up, you mentioned one area where like with |
| 32:09 | What's next: agents | 00:32:09,093 | time. Okay. Last question before we sign off. |
| 32:55 | See you next time | 00:32:55,773 | Bing bada boom. That's all we got. |

## Editorial changes to the supplied description

Preserved the opening question, personal examples, intern metaphor, bedtime joke and audience question. Lightly tightened the opening, removed broken link escapes, added the brand-skill and recap chapters, moved Composio into its actual place in the conversation, and rebuilt every start from the selected ep2hook cut. Replaced the skills chapter’s “autopilot” wording with “reusable workflows.” Qualified the California note to confidential conversations and linked Composio’s permission documentation. No five-hour claim is added to the written description.
