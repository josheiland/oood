# Episode 1 release draft

Status: proposed review package. Nothing is approved, scheduled or published. Use this copy only after the exact master and captions pass host review. Source: September 26 shoot; proposed cut 9:58.367.

## Title and thumbnail

Recommended title: **AI names, finally explained | Out of Our Depth 001**

Rendered thumbnail: `edit/episode-01-thumbnail-v1.jpg`, 1280 x 720, **AI NAMES EXPLAINED**. Uses an authentic two-host frame, Teachers, the kit palette and native square two-line logo. Checked at 210px wide.

Alternative title: **Company, model, app: what's the difference?**

Alternative thumbnail direction, not rendered: **WHICH IS WHICH?** with the same real host frame and a small company/model/app visual. No claim of a product comparison test.

## Description / show notes

Try one ordinary task in the AI app you already use. Ask it to explain anything unfamiliar, then check the result before relying on it.

OpenAI, ChatGPT, Claude, Opus, Astra. The names get confusing fast. Josh and Mary sort out the company, the model and the app with a car analogy, talk through how language models learn, and compare what they personally like using.

Along the way: a model-name mix-up, a coding-class grade Mary had to read twice, and recent prompts ranging from nonprofit research to the best pina colada in Maui.

This is a starting point for using language-model tools, not a ranking of the best AI products. The preferences and stories are ours; features and model names change. Check important answers and keep control of account access and actions.

00:00 The AI-name problem
00:45 Company, model, app
01:50 How a language model learns
03:09 Chat, work, and code
04:28 Which tool feels useful?
06:37 Learn by asking
08:44 What are you actually asking?

Company: the organization building or offering the tool.
Model: the trained system producing responses.
App: the product you interact with, including the interface and available tools.
Token: a small chunk of data the model processes. For text, it may be a word or part of a word.

Next: giving AI useful context, access to information and reusable instructions.

## Sources for the description

Checked 2026-09-26. The detailed claim register distinguishes verified product facts, personal experience and removed claims.

- [OpenAI model catalog](https://developers.openai.com/api/docs/models/all)
- [ChatGPT and Codex quickstart](https://learn.chatgpt.com/docs/quickstart)
- [Claude interfaces](https://support.claude.com/en/articles/8114487-what-interfaces-can-i-use-to-access-claude)
- [Claude Fable](https://www.anthropic.com/claude/fable) and [Claude Opus](https://www.anthropic.com/claude/opus)
- [Anthropic's research on language-model processing and hallucinations](https://www.anthropic.com/news/tracing-thoughts-language-model)

## Clip candidates

No separate clips rendered; these ranges are recommendations from the proposed master. Preserve the setup and response when adapting them.

| Rank | Moment | Source | Final master | Hook and edit note |
|---|---|---|---|---|
| 1 | The names defeat us | 13:36.167-14:27.833 | 05:26.000-06:17.667 | "Too many AI names." Keep the spoken correction, Mary's taste judgment and Josh's clarification; do not isolate the wrong company/model pairing. Mild profanity retained. |
| 2 | The coding-class story | 22:23.167-23:43.333 | 07:18.433-08:38.600 | "We remember coding class differently." Keep Josh's qualification and Mary's full grade-reversal story. Personal-details approval required. |
| 3 | AI as a car | 10:01.533-10:37.033 plus 10:58.800-11:28.433 | 00:45.333-01:50.467 | "Company. Model. App." Use the complete analogy; don't present the car metaphor as a technical definition. |
| 4 | Actual recent prompts | 52:51.533-53:23.167 plus 54:56.233-55:37.600 | 08:44.300-09:57.300 | "What are you actually asking AI?" Preserve the real everyday examples. Removed petition/email story is not part of this recommendation. |

## LinkedIn draft

I can use an AI tool every day and still mix up the company, the model and the app.

In Episode 1 of Out of Our Depth, Mary and I use a car analogy to sort out the names, talk through what language models do, and share how we learn by asking the tools questions.

There's also a coding-class story in which we remember our abilities very differently.

What was the first everyday task that made AI useful for you?

## Instagram draft

Company, model, app. We needed a car analogy to keep them straight.
Also in Episode 1: confusing names, coding-class memories and a pina colada search.
What's the most ordinary thing you've asked AI to help with?

## Package and release checks

- Review video: `edit/episode-01-master-v2.mp4`
- Audio: `edit/episode-01-audio-master-v2.wav` and `edit/episode-01-audio-v2.mp3`
- Captions: `edit/episode-01-captions-v2.srt` and `.vtt`
- Transcript, chapter timing, graphics cues, reversible edit list and QC report: `edit/`
- Source register: `02_RESEARCH/episode-01-ai-basics-source-checks-2026-09-26.md`
- Remaining: continuous watch/listen, original camera-sync judgment, auditory caption proofread, personal-story/profanity approval and host decision on the suggested short accuracy pickup.

No release date or live URL is asserted. No account has been modified or footage uploaded.
