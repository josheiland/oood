# Episode 1 chapters v3

Exact proposed master timing. A short viewer-action interval remains in the embedded master metadata but is omitted from the YouTube list.

- 00:00.000 The AI-name problem
- 00:45.333 Company, model, app
- 01:50.467 Open and closed models
- 03:01.667 How a language model learns
- 04:40.400 Chat, work, and code
- 05:59.600 Which tool feels useful?
- 08:08.700 What changes for people?
- 10:49.933 Learning by asking
- 13:52.600 What skills matter?
- 16:18.867 Beyond the chatbot
- 18:31.667 Local models and the cloud
- 21:32.033 Caution and curiosity
- 23:57.567 One tool, one real task
- 24:03.133 What are you actually asking?

## YouTube chapters

00:00 The AI-name problem
00:45 Company, model, app
01:50 Open and closed models
03:01 How a language model learns
04:40 Chat, work, and code
05:59 Which tool feels useful?
08:08 What changes for people?
10:49 Learning by asking
13:52 What skills matter?
16:18 Beyond the chatbot
18:31 Local models and the cloud
21:32 Caution and curiosity
24:03 What are you actually asking?
