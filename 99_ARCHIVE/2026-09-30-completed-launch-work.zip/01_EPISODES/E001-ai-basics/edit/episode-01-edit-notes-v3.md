# Episode 1 proposed fuller edit v3

Josh requested a reassessment toward 25–30 minutes. This version runs **25:20.567** and keeps much more of the hosts' learning, disagreement, humor, and judgment. It remains a review proposal; v2 is the 9:58 short comparison. See `episode-01-editorial-reassessment-v3.md` for why the longer passages were chosen and which other material remains out.

| Edit | Source in–out | Output in–out | Why it stays |
|---|---|---|---|
| 01 | 00:29.033–01:04.433 | 00:00.000–00:35.400 | Keep the painting-a-photo exchange and clear scope; remove setup and the unfulfilled founder-history promise. |
| 02 | 01:21.767–01:31.700 | 00:35.400–00:45.333 | Use the corrected provider statement naming Anthropic, OpenAI and Google. |
| 03 | 10:01.533–10:37.033 | 00:45.333–01:20.833 | Mary explains her confusion and the engine analogy, retaining her model-name recall. |
| 04 | 10:58.800–11:28.433 | 01:20.833–01:50.467 | Preserve the maker/car/engine restatement; omit the sentence equating a harness with only an interface. |
| 05 | 06:22.333–06:30.700 | 01:50.467–01:58.833 | Introduce availability of model weights without the inaccurate all-vendor blanket claim. |
| 06 | 06:34.533–06:46.033 | 01:58.833–02:10.333 | Keep the core closed-weight distinction. |
| 07 | 11:30.033–11:51.367 | 02:10.333–02:31.667 | Keep Mary's engine analogy and her preference for a ready-to-use tool. |
| 08 | 11:59.667–12:29.667 | 02:31.667–03:01.667 | Explain why someone might adapt open weights; omit unsourced universal quality ranking. |
| 09 | 07:55.100–08:01.100 | 03:01.667–03:07.667 | Introduce training on data without the overbroad all-websites example. |
| 10 | 08:21.733–09:33.833 | 03:07.667–04:19.767 | Keep next-token prediction, the fox example, token qualification, and further conversational training. |
| 11 | 09:33.833–09:54.467 | 04:19.767–04:40.400 | Include the concise multimodal explanation; review qualification that capabilities vary by model. |
| 12 | 03:52.033–05:11.233 | 04:40.400–05:59.600 | Describe the products and modes; stop before the unsupported usage ranking. |
| 13 | 02:54.233–03:51.900 | 05:59.600–06:57.267 | Keep Mary's personal preference, creative strengths, and Josh's response about complementing her abilities. |
| 14 | 13:35.967–14:27.833 | 06:57.267–07:49.133 | Keep the model-name frustration, spoken OpenAI correction, and Mary's writing-style preference. |
| 15 | 15:15.533–15:35.100 | 07:49.133–08:08.700 | Keep task-based model choice and the ordinary opening-hours example; remove speculative math/job pivot. v2 removes 0.5 seconds of the preceding sentence tail at the start. |
| 16 | 15:43.033–15:52.167 | 08:08.700–08:17.833 | Keep Mary's segue into the jobs discussion without the unsourced unsolved-problem premise. |
| 17 | 15:57.900–16:43.367 | 08:17.833–09:03.300 | Keep the provocative take, immediate retraction/qualification, Good Will Hunting exchange and opening pushback. |
| 18 | 17:54.433–19:41.067 | 09:03.300–10:49.933 | Keep Josh's view of human judgment and Mary's partial reconsideration; the forecasts remain opinions. |
| 19 | 20:40.667–21:22.133 | 10:49.933–11:31.400 | Keep Mary's friend example and her own learning preferences, before the population generalizations. |
| 20 | 21:22.133–22:23.233 | 11:31.400–12:32.500 | Keep Mary's personal concern about unequal access and why the show should make learning approachable. |
| 21 | 22:23.233–23:43.333 | 12:32.500–13:52.600 | Keep the full coding-class setup, grade reversal, laughter and both hosts' practical conclusion. |
| 22 | 25:14.867–25:42.700 | 13:52.600–14:20.433 | Set up Mary's question about preparing for change versus hype. |
| 23 | 25:50.767–27:49.200 | 14:20.433–16:18.867 | Keep her personal argument for communication, human connection and task-level learning. |
| 24 | 27:49.367–28:19.233 | 16:18.867–16:48.733 | Introduce Mary's switching-cost question as an opinion, not a market conclusion. |
| 25 | 28:19.233–28:27.967 | 16:48.733–16:57.467 | Move from software to chips without the time-sensitive company valuation claim or incomplete hardware setup. |
| 26 | 29:18.467–30:17.967 | 16:57.467–17:56.967 | Explain the role and graphics origins of GPUs; omit the interrupted battery analogy and imprecise chip-versus-GPU passage. |
| 27 | 30:37.500–31:12.200 | 17:56.967–18:31.667 | Retain the moat/advantage joke and low-friction product switching as host observation. |
| 28 | 33:24.833–34:17.800 | 18:31.667–19:24.633 | Keep Josh's failed attempt to run local models on his MacBook Air as personal experience. |
| 29 | 34:45.600–35:07.033 | 19:24.633–19:46.067 | Keep the consumer-choice reason for open models; omit unsupported quality ranking. |
| 30 | 35:24.600–35:48.533 | 19:46.067–20:10.000 | Explain that a provider can host a model even when weights are available. |
| 31 | 36:05.200–36:33.967 | 20:10.000–20:38.767 | Keep Mary's direct open-model versus on-prem question. |
| 32 | 36:33.967–36:51.567 | 20:38.767–20:56.367 | Explain on-prem as a location/hosting choice before the cloud example. |
| 33 | 37:06.433–37:42.100 | 20:56.367–21:32.033 | Use Run Your City apps and the cloud joke for an accessible location distinction; omit blanket hospital-security assertion. |
| 34 | 41:15.867–41:31.167 | 21:32.033–21:47.333 | Keep Mary's personal admission that she undervalues privacy. |
| 35 | 41:37.300–41:48.733 | 21:47.333–21:58.767 | Keep her question about anthropomorphizing a model, then omit an absolute claim about feelings or incentives. |
| 36 | 42:13.367–42:45.200 | 21:58.767–22:30.600 | Keep human responsibility for goals and guardrails as the hosts' interpretation. |
| 37 | 43:16.900–44:43.867 | 22:30.600–23:57.567 | Keep the clearly hypothetical paperclip example and Mary's response about balancing fear and optimism. |
| 38 | 31:45.400–31:50.967 | 23:57.567–24:03.133 | Keep the complete beginner recommendation, without the earlier permission-bypass advice. |
| 39 | 52:48.167–53:23.167 | 24:03.133–24:38.133 | Start the recent-chats exchange and first item; omit the unverified autonomous petition/email story. |
| 40 | 54:56.233–55:37.600 | 24:38.133–25:19.500 | Keep street-style and pina-colada examples plus the next-episode invitation; remove unconfirmed inbox plug. |
| 41 | 55:40.367–55:41.433 | 25:19.500–25:20.567 | Preserve the authentic farewell with a short fade. |

## Review focus

- Treat career outcomes, social inequity, product taste and the AI-safety exchange as host perspective or hypothetical discussion. The paperclip example is not a report of a current incident.
- Listen through every splice for broken clauses or attribution changes. Source-assisted captions are a draft until checked against audio.
- Pay attention to the shift from company/model/app into work, hardware and safety. Decide whether that breadth serves the episode or should become a second episode.
- The initial machine source transcription and sampled frames are not a continuous audiovisual review. Josh and Mary must approve the exact cut, personal details and public framing.

No source media was modified and no publication is implied.
