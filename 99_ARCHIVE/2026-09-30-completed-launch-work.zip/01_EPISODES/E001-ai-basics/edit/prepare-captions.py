"""Source-assisted captions, with explicit text/timing corrections and v2 remapping."""
from pathlib import Path
import json,re,textwrap
P=Path(__file__).resolve().parent
def sec(t):
    h,m,s=t.replace(',','.').split(':');return int(h)*3600+int(m)*60+float(s)
def stamp(t,vtt=False):
    ms=round(t*1000);h,ms=divmod(ms,3600000);m,ms=divmod(ms,60000);s,ms=divmod(ms,1000)
    return f'{h:02}:{m:02}:{s:02}{"." if vtt else ","}{ms:03}'
fix={
1:"We are back and we're doing an AI landscape.",
16:"Okay, what's the model? What's the freaking harness? What's like all",
21:"And that's like Opus.",
22:"You know, that's specific models within Claude, within Chat, Astra, other ones.",
24:"That's all the ones I remember.",
28:"And there's a Toyota or a Prius or whatever it is,",
50:"It's probably going to guess fox, right?",
59:"in a conversational way.",
88:"they've kind of been consolidating them back a little bit more.",
90:"we'll talk a lot about ChatGPT and Claude as like the interface,",
91:"the product that OpenAI and Anthropic respectively have",
92:"built out.",
93:"So a quick caveat.",
102:"personalization, at some of the more human-esque, where",
114:"It feels like it complements your background and your capabilities.",
121:"Like Claude having Luna, whatever, like Sol,",
124:"Those are OpenAI models.",
127:"Like there's so many names to keep track of.",
151:"'cause it's just gonna do a basic web search.",
152:"I was talking to one of my friends",
158:"And I was like, love, put all these questions you're asking me,",
169:"I think it's just developing this skill.",
182:"We both took a coding class. Guys,",
205:"Claude Code",
206:"and it can talk through in English with me.",
217:"Chat or Claude?",
225:"They're not, I mean, nonprofit [unclear] AI stats.",
226:"Oh yeah, yeah.",
232:"Yeah, new fits that aren't athletic fits.",
244:"Hope this was helpful, an AI landscape.",
}
raw=[];log=[]
for block in (P/'intermediate/final-asr.srt').read_text().strip().split('\n\n'):
    ls=block.splitlines();i=int(ls[0]);a,b=map(sec,ls[1].split(' --> '));original=' '.join(ls[2:]).strip();tx=fix.get(i,original)
    for pattern,new in [(r'\b[Cc]loud [Cc]ode\b','Claude Code'),(r'\bClodCode\b','Claude Code'),(r'\bChat GPT\b','ChatGPT'),(r'\bChad\b','Chat'),(r'\banthropic\b','Anthropic')]:tx=re.sub(pattern,new,tx)
    tx=tx.replace('--','...').strip()
    if tx.startswith('- '):tx=tx[2:]
    if tx!=original:log.append({'asr_cue':i,'before':original,'after':tx})
    raw.append([i,a,b,tx])

# Replace ASR spans that straddle source joins, duplicate overlap, or lose timing.
replacements=[
    (9,13,[(27.32,32.98,"the model and the actual platform or product that you're using?"),(32.98,35.4,"Who are the different key companies in the space?"),(35.4,40.52,"The provider, I guess at the highest level, would be Anthropic or OpenAI or Google,"),(40.52,44.6,"right? These are the companies that are actually training the models.")]),
    (39,42,[(108.98,110.466667,"So yeah, I think that's a helpful analogy."),(110.466667,113.42,"High level, the way that these models are trained"),(113.42,116.466667,"is they're just fed a ton of data."),(116.466667,118.86,"And then these models are trained")]),
    (144,145,[(378.20,380.74,"So it's always a trade-off when deciding which model")]),
    (193,194,[(493.82,495.25,"There's some coding difference."),(495.25,497.0,"You still passed the class, though. We ended up with..."),(497.0,498.18,"I passed the class.")]),
    (207,214,[(517.34,519.10,"What's wrong? It's so good. It's so fun."),(519.10,521.63,"I totally agree. As a, especially as a beginner,"),(521.63,523.67,"it makes sense to just learn one tool and learn how to use it well"),(523.67,524.80,"and get comfortable with it.")]),
    (245,245,[(595.08,597.80,"And see you in the next episode."),(597.80,598.55,"Peace.")]),
]
cues=[]
for i,a,b,tx in raw:
    match=next((r for r in replacements if r[0]<=i<=r[1]),None)
    if match:
        if i==match[0]:cues.extend(match[2]);log.append({'asr_cues':[match[0],match[1]],'replacement':match[2],'basis':'Source transcript, targeted token alignment and exact EDL boundaries; auditory proofread pending.'})
    else:cues.append((a,b,tx))

# Remove 0.5s at v1 06:17.667 for v2. Later words retain their relative timing.
cut_a=377.666667;cut_b=378.166667
def remap(t):return t if t<=cut_a else max(cut_a,t-.5)
cues=[(remap(a),remap(b),tx) for a,b,tx in cues if not(a>=cut_a and b<=cut_b)]

# Join tiny continuations; then wrap and split into readable two-line cues.
merged=[];i=0
while i<len(cues):
    a,b,tx=cues[i];i+=1
    while i<len(cues):
        na,nb,nt=cues[i]
        if na-b<.25 and (nb-na<.85 or b-a<.85 or len(nt)<12) and len(tx+' '+nt)<=84 and nb-a<=7:
            b=nb;tx+=' '+nt;i+=1
        else:break
    merged.append((a,b,tx))
result=[]
for a,b,tx in merged:
    lines=textwrap.wrap(tx,42,break_long_words=False,break_on_hyphens=False)
    groups=['\n'.join(lines[j:j+2]) for j in range(0,len(lines),2)]
    weight=sum(len(g) for g in groups);pos=a
    for j,g in enumerate(groups):
        end=b if j==len(groups)-1 else pos+(b-a)*len(g)/weight
        result.append((pos,end,g));pos=end
for i,(a,b,tx) in enumerate(result):
    assert 0<=a<b<=598.366667,(a,b,tx)
    assert len(tx.splitlines())<=2 and all(len(s)<=42 for s in tx.splitlines()),tx
    if i:assert a>=result[i-1][1]-.001,(result[i-1],result[i])
for ext in ['srt','vtt']:
    text=('WEBVTT\n\n' if ext=='vtt' else '')+'\n\n'.join(('' if ext=='vtt' else f'{i+1}\n')+f'{stamp(a,ext=="vtt")} --> {stamp(b,ext=="vtt")}\n{tx}' for i,(a,b,tx) in enumerate(result))+'\n'
    (P/f'episode-01-captions-v2.{ext}').write_text(text)
(P/'episode-01-caption-corrections-v2.json').write_text(json.dumps({'basis':'Full final-v1 local ASR, raw-source ASR, targeted source token alignment, official name checks, exact v2 EDL remap. No perceptual listening verification claimed.','review_focus':['00:49 harness','05:44 overlapping potato/point landed exchange','08:15-08:24 grade-story overlap','08:37 short overlapping phrases','09:10 nonprofit prompt title unclear','09:52 final landscape phrase'],'changes':log,'caption_count':len(result),'max_characters_per_line':42,'max_lines':2},indent=2)+'\n')
(P/'episode-01-transcript-v2.md').write_text('# Episode 1 final-timeline transcript v2\n\nSource-assisted caption transcript. Uncertain wording is marked; auditory proofread remains open. Speaker labels omitted where overlaps make attribution uncertain.\n\n'+'\n\n'.join(f'**{stamp(a)}** '+tx.replace('\n',' ') for a,b,tx in result)+'\n')
print(f'{len(result)} cues, ordered, two lines maximum, within v2 duration.')
