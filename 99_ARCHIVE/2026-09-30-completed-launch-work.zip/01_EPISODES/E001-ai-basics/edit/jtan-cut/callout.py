"""Brief fact-check callout for Episode 1: cream card, Teachers 800 in OOOD blue (kit v2)."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path('/Users/je/oood/01_EPISODES/E002-make-ai-useful/edit/graphics-v2')))
from PIL import Image, ImageDraw
import oood_graphics as G

def callout(text, size=46):
    f = G.font(G.TEACHERS, size, 800)
    probe = ImageDraw.Draw(Image.new('RGBA', (10, 10)))
    w = int(G.tracked_len(probe, text, f, -0.01)) + 80
    h = int(size * 1.9)
    im = Image.new('RGBA', (w, h), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    d.rounded_rectangle((0, 0, w - 1, h - 1), radius=14, fill=G.CREAM)
    box = f.getbbox('Hg')
    G.tracked(d, (40, (h - (box[3] - box[1])) / 2 - box[1]), text, f, G.BLUE, -0.01)
    return im

render_wipe_clip = G.render_wipe_clip
