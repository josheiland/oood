---
tags: [oood, episode-01, edit]
---

# Episode 1 — jtan cut (Josh's 2026-09-27 edit list)

**Proposed cut for host review. Not approved, scheduled or published.** Made by jtan (Claude) from Josh's direct list. This folder is kept separate from the parallel ChatGPT `v4` files in `../` so neither overwrites the other. (jtan briefly overwrote ChatGPT's `episode-01-edit-decisions-v4.json`, then restored it by re-running its `build-v4.py`.)

- Video: `episode-01-jtan-cut.mp4`. Audio master: `episode-01-jtan-cut-audio.wav`.
- Source: `/Users/je/Movies/Episode 1 Raw.mp4` (MD5 `7c86087d…`, re-downloaded from Drive `Video Files/Raw`).
- Runtime **52:36.5**. Straight cuts only; no graphics, chapters or captions (none requested). Dialogue leveled as in Episode 2 (−16 LUFS master).
- Rebuild: `python3 render-jtan.py` (reads `episode-01-edit-decisions-jtan.json`).

## v2 (2026-09-28): fact-check callouts

`episode-01-jtan-cut-v2.mp4` has the same cuts as v1, plus four brief callouts Josh asked for. Each is a cream card with blue Teachers type, bottom-left, wiping in on the anchor word:

| Raw anchor | Callout | Why |
|---|---|---|
| 2:18.9 "closed models" | Most also release a few lesser-known open models | Meta (Llama), Google (Gemma), OpenAI (gpt-oss) and xAI (older Grok) publish open-weight models; Anthropic doesn't |
| 6:33.4 "OpenAI" | OpenAI also has a few open models | Flagships are closed; gpt-oss (Aug 2025) is open-weight |
| 29:05.9 "GPUs" | A GPU is a type of chip | "There's chips and there's GPUs" |
| 29:46.6 "graphical processing unit" | GPU = graphics processing unit | Name correction |

Josh on 2026-09-28: the remaining flagged items are fine as they are.

**v2 QC:** 94,696 frames (52:36.5), identical cut to v1. Full decode clean. −16.6 LUFS / −1.1 dBTP. MD5 `ffb9009582cca29d21297a301b21ec16`. All four callouts checked in the finished file, mid-wipe (+0.1 s) and fully shown (+1.5 s), at 2:03.3, 6:17.9, 27:40.3 and 28:21.0. None covers a face.

## What Josh asked for, and what was done

| Request | Done |
|---|---|
| Start at 0:15, hand over the camera | Opens on 0:15.533, the frame where Mary's hand covers most of the lens |
| 6:46–7:55: remove Mary's model explanation if inaccurate | **Removed** (6:45.9–7:56.0, 70 s). It's inaccurate: weights are fixed numbers learned in training, not a live weighing of good and bad data, and Chat, Cowork and Codex don't change a model's parameters. Josh's "I didn't totally follow" goes with it. Flow: "…mechanism that powers the model." → "The way these models are trained is they're just fed a ton of data." |
| 29–30 min: Nvidia accurate? | **Accurate, kept.** Nvidia is the world's most valuable company (~$5.4T, Sept 2026). GPUs began as gaming and graphics chips and suited AI training. One small slip: "there's chips and there's GPUs." A GPU *is* a chip, and it's "graphics," not "graphical," processing unit. Harmless; not cut. |
| ~33 min: open weight vs open source, and the whole open vs closed section | **One passage removed, one trimmed; the rest is fine.** See below |
| ~39:45: Demis/Dario slip | **Removed** (39:28.2–39:46.6): "Dario came to Stanford… that was Demis… you wanna restart that point? …I forget what it was." Resumes at "So they're like the good guys." |
| Josh's blank-out after 45 min | **Removed** (45:04.9–45:15.3): "I completely blanked on what I was gonna say… totally lost it." |
| Mary's earlier blank-out | **Removed** (31:40.0–31:45.1): "I have no clue where I was going. Absolutely none." Josh's "No, I think you were saying" goes with it. |
| End at 55:41, hand over the camera | Ends on 55:41.533, the peak of the hand wipe, right after "Peace." |
| Keep the Hallie academic-advisor story | Kept |

### The open vs closed section (32:23–36:03 raw)

- **Removed (32:49.1–33:26.3, 37 s):** Josh's definitions are inverted. *Open weight* means the trained weights are published, so you can download, run and fine-tune the model yourself. *Open source* (the OSI's Open Source AI Definition, 2024) adds the code, detailed training-data information and an open license on top. So every open-source model is open-weight, not the other way round, and "open source without open weight, so you can host it but not edit it" isn't possible: you can't self-host a model without its weights. Flow: "DeepSeek… is an open model. Yeah." → "…a model like DeepSeek, for example, you can host on your own computer…"
- **Trimmed (33:41.5–34:09.6, 28 s):** "You need high CPU… computing processing, I actually don't know… more CPU and RAM." Running models locally mostly depends on memory (RAM) and the GPU, and Josh flags his own uncertainty on tape. Flow: "…just not powerful enough to run most of them." → "But for the most part it's pretty annoying and difficult for a beginner…"
- **Accurate, kept:** DeepSeek is open-weight. Open models generally trail the closed frontier. Competition and price pressure. Big companies using open models for cheaper, simpler tasks. Hosted-API revenue for open models. On-prem vs cloud. Hospitals keeping some systems on-prem.
- **Soft, kept:** "Some of the Chinese companies are getting government subsidies." It's hedged ("I think") and broadly reported for Chinese AI, but DeepSeek itself is funded by the hedge fund High-Flyer. Fine as spoken.

## Other fact-check notes (not cut; Josh to decide)

| Raw time (cut time) | Issue | Suggestion |
|---|---|---|
| 2:18 (cut 2:02) | Mary: "These are all closed models," right after naming Meta. Meta's Llama models are open-weight, Google has Gemma, and OpenAI released open-weight gpt-oss (Aug 2025). | Cut that one sentence (~2 s) |
| 6:30 (cut 6:14) | "The closed models, like the ones released by Anthropic and OpenAI." True of their flagships, but OpenAI also ships open-weight models | Leave, or add a caption |
| 13:01 (cut 11:35) | "Harvey or OpenEvidence might take an open model and tune it." **Accurate; jtan's flag was out of date.** In Sept 2026 Harvey launched Tenet, built on the open-weight Kimi K3 (Bloomberg, 2026-09-21) | None |
| 19:44 (cut 18:18) | "I think we said this in the first episode… jobs will not go away." Check the current Episode 0 cut actually says it | Confirm against E0 |
| 20:27 (cut 19:01) | Captions will say "I was CS undergrad," but you both studied systems engineering. Mary likely said "SYS" | Fix in captions only |
| 31:13–31:30 (cut 29:47) | Mary's advice to beginners: grant full permissions. Spicy, and it sits awkwardly next to the later sandbox-escape discussion | Your call; kept |
| 46:42 (cut 43:36) | "Why he was originally ousted… the nonprofit-to-for-profit transition." The board's stated reason in Nov 2023 was that Altman wasn't "consistently candid"; commercialization tension was reported context, not the stated reason | Leave (hedged "I think") or caption |
| 47:30 (cut 44:24) | "He's [Altman] coming to Stanford in a couple weeks" | Confirm it's true and public |
| 48:06 (cut 45:00) | Elon's kids: "eight" / "like 20". Reported count is 14 | Leave; it's banter |

**Verified accurate (kept):** Fable is Anthropic's most capable model, above Opus. Astra is OpenAI's GPT-6 Astra (released Sept 3, 2026). Demis Hassabis stepped down as DeepMind CEO on Aug 5, 2026 to focus on research (now chair and Alphabet chief scientist). Models breaking out of test sandboxes and hacking real companies (OpenAI–Hugging Face, July 2026; Google Gemini, 2026). Nvidia most valuable. Anthropic founded by ex-OpenAI researchers over safety concerns. Musk as an early OpenAI donor and his lawsuit. The Altman-parenting quote. Alexandr Wang at Meta. Self-driving trucks starting commercial runs.

**Note on the parallel ChatGPT v4:** its cut list treats Demis's departure and the model-escape incidents as false and removes about 1.5 minutes built on that premise (raw 49:44, 50:22, 50:58, 51:33–52:18, 40:58). Both are documented. If you prefer that version's other trims, those four Demis cuts and the escape cut shouldn't carry over.

## QC (2026-09-28)

- `episode-01-jtan-cut.mp4`: 1,303,728,019 bytes, MD5 `ffb34dcd864a365c08d13a3e10052c4c`. H.264 1080p30, 94,696 frames, exactly the edit list's total. Video and audio are both 3156.533 s.
- Full decode clean. No black frames. −16.6 LUFS, −1.1 dBTP, LRA 4.9.
- First frame is the hand over the lens, revealing the hosts by 0:00.4. The final frames are the hand covering the lens.
- The finished audio was retranscribed around all six joins (`join-check.json`); each reads as intended, with no clipped words.

## Review limits

Transcript read in full. Word-level alignment at every cut. Frame analysis for the hand wipes. Technical QC. No continuous real-time viewing. Listen at each cut.
