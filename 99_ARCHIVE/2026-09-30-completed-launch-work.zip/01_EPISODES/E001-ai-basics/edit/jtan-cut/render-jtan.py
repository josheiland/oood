#!/usr/bin/env python3
"""Render jtan's Episode 1 cut (Josh's 2026-09-27 edit list) from episode-01-edit-decisions-jtan.json.

Straight cuts only, no graphics or chapters. Reads the untouched raw, builds one leveled
audio master, then encodes video once. Kept in its own folder so it can't collide with the
parallel ChatGPT v4 files in ../
"""
import json, subprocess
from pathlib import Path

HERE = Path(__file__).resolve().parent
EDL = json.loads((HERE / 'episode-01-edit-decisions-jtan.json').read_text())
SRC, FPS, AS = EDL['source'], EDL['fps'], EDL['audio_stream']
AP = EDL['audio_processing']
CACHE = Path('/private/tmp/claude-501/-Users-je-jtan/236b7143-fb33-410a-a313-6748d5ce4b28/scratchpad/e1/render')
CACHE.mkdir(parents=True, exist_ok=True)
OUT_MP4, OUT_WAV = HERE / 'episode-01-jtan-cut-v2.mp4', HERE / 'episode-01-jtan-cut-v2-audio.wav'  # v1 kept alongside


def ff(args, name):
    with open(CACHE / f'{name}.log', 'w') as f:
        subprocess.run(['ffmpeg', '-nostdin', '-hide_banner', '-y', *args], stdout=f, stderr=f, check=True)


segs = EDL['segments']
t = 0
for s in segs:
    s['frames'] = round((s['src_out'] - s['src_in']) * FPS)
    s['out_in_frame'] = t
    t += s['frames']
total = t
dur_total = total / FPS

# audio: per-segment extraction with 8 ms ramps, concat, level, two-pass linear loudnorm
parts = []
for s in segs:
    d = s['frames'] / FPS; n = round(d * 48000); p = CACHE / f"a-{s['id']}.wav"
    ff(['-ss', f"{s['src_in']:.6f}", '-i', SRC, '-map', f'0:{AS}', '-t', f'{d + 0.05:.6f}',
        '-af', f'atrim=end_sample={n},apad=whole_len={n},afade=t=in:d=0.008,afade=t=out:st={d - 0.008:.6f}:d=0.008',
        '-ar', '48000', '-ac', '2', '-c:a', 'pcm_f32le', str(p)], f"a-{s['id']}")
    parts.append(p)
(CACHE / 'concat.txt').write_text(''.join(f"file '{p}'\n" for p in parts))
joined = CACHE / 'joined.wav'
ff(['-f', 'concat', '-safe', '0', '-i', str(CACHE / 'concat.txt'), '-c:a', 'pcm_f32le', str(joined)], 'concat')
pre = AP['pre_filters']
ff(['-i', str(joined), '-af', f'{pre},loudnorm=I=-16:TP=-1.5:LRA=11:print_format=json', '-f', 'null', '-'], 'loud1')
txt = (CACHE / 'loud1.log').read_text(); st = json.loads(txt[txt.rindex('{'):txt.rindex('}') + 1])
ln = (f"loudnorm=I=-16:TP=-1.5:LRA=11:measured_I={st['input_i']}:measured_TP={st['input_tp']}:measured_LRA={st['input_lra']}:"
      f"measured_thresh={st['input_thresh']}:offset={st['target_offset']}:linear=true")
N = round(dur_total * 48000)
ff(['-i', str(joined), '-af', f"{pre},{ln},aresample=48000,atrim=end_sample={N},apad=whole_len={N},"
    f"afade=t=in:d={AP['start_fade_s']},afade=t=out:st={dur_total - AP['end_fade_s']:.6f}:d={AP['end_fade_s']}",
    '-ar', '48000', '-ac', '2', '-c:a', 'pcm_s24le', str(OUT_WAV)], 'master')

# fact-check callouts (v2): cream card, blue type, wipe in on the anchor word
import sys; sys.path.insert(0, str(HERE))
from callout import callout, render_wipe_clip
def to_export(t):
    s = next(x for x in segs if x['src_in'] <= t < x['src_out'])
    return s['out_in_frame'] / FPS + t - s['src_in']
items = []
for o in EDL.get('overlays', []):
    img = callout(o['text']); clip = CACHE / f"co-{o['id']}.mov"
    render_wipe_clip(img, o['hold'], clip)
    o['export_start'] = round(to_export(o['src_anchor']), 3)
    items.append((clip, o['export_start'], 96, 1080 - img.size[1] - 72))

# video: one encode straight from the raw
args, filt = [], []
for i, s in enumerate(segs):
    args += ['-ss', f"{s['src_in']:.6f}", '-t', f"{s['frames'] / FPS + 0.2:.6f}", '-i', SRC]
    filt.append(f"[{i}:v]setpts=PTS-STARTPTS,tpad=stop_mode=clone:stop=3,trim=end_frame={s['frames']},setpts=PTS-STARTPTS[v{i}]")
filt.append(''.join(f'[v{i}]' for i in range(len(segs))) + f'concat=n={len(segs)}:v=1:a=0,format=yuv420p[base]')
cur, n = 'base', len(segs)
for k, (clip, st, x, y) in enumerate(items):
    args += ['-i', str(clip)]
    filt.append(f'[{n}:v]setpts=PTS-STARTPTS+{st:.6f}/TB[g{k}]')
    filt.append(f'[{cur}][g{k}]overlay=x={x}:y={y}:eof_action=pass:format=auto[o{k}]')
    cur = f'o{k}'; n += 1
filt.append(f'[{cur}]trim=end_frame={total},format=yuv420p[vout]')
wav_index = n
(CACHE / 'graph.txt').write_text(';\n'.join(filt))
ff([*args, '-i', str(OUT_WAV), '-filter_complex_script', str(CACHE / 'graph.txt'), '-map', '[vout]', '-map', f'{wav_index}:a',
    '-c:v', 'libx264', '-preset', 'medium', '-crf', '18', '-profile:v', 'high', '-pix_fmt', 'yuv420p',
    '-color_primaries', 'bt709', '-color_trc', 'bt709', '-colorspace', 'bt709', '-r', str(FPS),
    '-filter:a', 'volume=-0.6dB', '-c:a', 'aac', '-b:a', '256k', '-movflags', '+faststart', str(OUT_MP4)], 'video')
(HERE / 'timeline-v2.json').write_text(json.dumps(dict(total_frames=total, segments=segs, overlays=EDL.get('overlays', [])), indent=1))
print(OUT_MP4, total, 'frames', dur_total)
