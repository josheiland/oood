# Episode 1 chapters v1

Exact master timing; the short viewer-action chapter is valid MP4 metadata but is omitted from the YouTube chapter list below.

- 00:00.000 The AI-name problem
- 00:45.333 Company, model, app
- 01:50.467 How a language model learns
- 03:09.133 Chat, work, and code
- 04:28.333 Which tool feels useful?
- 06:37.733 Learn by asking
- 08:39.100 One tool, one real task
- 08:44.800 What are you actually asking?

## YouTube description chapters

00:00 The AI-name problem
00:45 Company, model, app
01:50 How a language model learns
03:09 Chat, work, and code
04:28 Which tool feels useful?
06:37 Learn by asking
08:44 What are you actually asking?
