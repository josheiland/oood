"""Map source Whisper cues and token timings through the exact v6 frame EDL.

This is a draft caption basis. Host auditory proofread is still required.
"""
from pathlib import Path
import json
import re

P = Path(__file__).resolve().parent
edl = json.loads((P / 'episode-01-edit-decisions-v6.json').read_text())
source = json.loads((P / 'intermediate/source-asr.json').read_text())['transcription']

def timestamp(seconds):
    milliseconds = round(seconds * 1000)
    hours, milliseconds = divmod(milliseconds, 3600000)
    minutes, milliseconds = divmod(milliseconds, 60000)
    seconds, milliseconds = divmod(milliseconds, 1000)
    return f'{hours:02}:{minutes:02}:{seconds:02},{milliseconds:03}'

result = []
partials = []
for segment in edl['segments']:
    source_start = segment['in_frame'] / edl['fps']
    source_end = segment['out_frame'] / edl['fps']
    timeline_start = segment['timeline_frame'] / edl['fps']
    for cue in source:
        a = cue['offsets']['from'] / 1000
        b = cue['offsets']['to'] / 1000
        first = max(a, source_start)
        last = min(b, source_end)
        if last - first < .32:
            continue
        text = cue['text']
        if first > a + .08 or last < b - .08:
            tokens = [t for t in cue['tokens']
                      if not t['text'].startswith('[_')
                      and source_start <= (t['offsets']['from'] + t['offsets']['to']) / 2000 < source_end]
            if not tokens:
                continue
            text = ''.join(t['text'] for t in tokens)
            first = max(source_start, tokens[0]['offsets']['from'] / 1000)
            last = min(source_end, tokens[-1]['offsets']['to'] / 1000)
            partials.append({'segment': segment['id'], 'source_cue_start': a,
                             'included_text': text.strip()})
        text = re.sub(r'\s+', ' ', text).strip()
        if not text or last - first < .32:
            continue
        result.append((timeline_start + first - source_start,
                       timeline_start + last - source_start, text))

output = '\n\n'.join(f'{i}\n{timestamp(a)} --> {timestamp(b)}\n{text}'
                     for i, (a, b, text) in enumerate(result, 1)) + '\n'
(P / 'intermediate/v6-source-remap.srt').write_text(output)
(P / 'intermediate/v6-source-remap-partials.json').write_text(
    json.dumps(partials, indent=2) + '\n')
print(f'{len(result)} source cues mapped; {len(partials)} boundary cues trimmed by token time')
