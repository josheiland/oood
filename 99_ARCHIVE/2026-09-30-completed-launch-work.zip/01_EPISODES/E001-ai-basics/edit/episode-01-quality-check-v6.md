# Episode 1 v6: automated quality check

Checked 2026-09-28 after the final chaptered export. This is a **technically checked review cut**, not a host-approved release master.

| Check | Result |
|---|---|
| Master | `episode-01-master-v6.mp4`, H.264, 1920 × 1080, 30 fps, 96,147 frames, 3204.900s |
| Sound | Stereo AAC, 48000 Hz; encoded audio/video duration difference 0.000000s |
| Loudness | -16.51 LUFS integrated; -0.67 dBTP true peak; LRA 4.60 LU |
| Chapters | 19 embedded chapters; separate Markdown list matches v6 timing |
| Captions | 1136 structurally valid ordered SRT cues, source-ASR-derived and **not listening-proofread**; VTT and transcript drafts alongside |
| Full-file decode | Passed. Machine black spans: 0; quiet spans: 3. See `intermediate/qc-v6-final/` for exact data. The intentional hand-cover ending can look dark. |
| File identity | Master SHA-256 `4020b15d9af1ae2aae4596bd80aefef6c436d847ef8390af401f0a07b7861437`; source unchanged SHA-256 `9f58d3a39c91ce4499fd3215355ddc9873051e6e32a5b26a6c73ce05caf93107` |
| Picture treatment | Original camera footage, four brief OOOD clarification pop-ups, and 5 internal four-frame picture/audio crossfades |
| Sampled picture review | Opening, closing, joins and all four pop-ups sampled in `intermediate/v6-sampled-frames.jpg`; no black flash or obscured face in those samples |

Automated checks: `{'frames_match_edl': True, 'duration_within_one_frame': True, 'audio_video_within_50ms': True, 'loudness_within_one_lu': True, 'true_peak_below_zero_db': True, 'chapters_present': True, 'source_hash_unchanged': True, 'four_graphics_declared': True, 'graphic_assets_present': True, 'caption_structure': True}`.

The encoded true peak is below clipping but above the preferred −1 dBTP delivery ceiling. The current v7 review comparisons lower audio further without changing this picture stream. The selected public version should receive a final true-peak delivery pass.

The 3 machine-detected quiet spans are at output 1207.4–1209.0s, 2973.7–2975.2s, 3174.1–3175.7s. The script decoded the full exported audio and video, checked durations, measured encoded loudness/true peak, scanned for black/silent spans, and validated captions structurally. This does **not** establish naturalness of every join, lip sync, intelligibility, speaker balance, caption wording, or continuous picture quality. Josh and Mary should watch and listen to this exact export continuously, including all joins and the opening/closing hand covers, and proof the captions by ear. The episode source addenda document the remaining medical-comparison caveat and dated/subjective claims. No upload, scheduling, publication or exact-export host approval is claimed.
