# Episode 1 proposed edit v2

Current review master: `episode-01-master-v2.mp4`, 9:58.367. V1 is preserved as an intermediate review export. V2 removes a half-second tail of the prior sentence at source 15:15.033, caught by final-export ASR. All later timing shifts 0.5 seconds earlier; earlier content and all graphics are unchanged.

| Edit | Source in-out | Output in-out | Reason |
|---|---|---|---|
| 01 | 00:29.033-01:04.433 | 00:00.000-00:35.400 | Keep the painting-a-photo exchange and clear scope; remove setup and the unfulfilled founder-history promise. |
| 02 | 01:21.767-01:31.700 | 00:35.400-00:45.333 | Use the corrected provider statement naming Anthropic, OpenAI and Google. |
| 03 | 10:01.533-10:37.033 | 00:45.333-01:20.833 | Mary explains her confusion and the engine analogy, retaining her model-name recall. |
| 04 | 10:58.800-11:28.433 | 01:20.833-01:50.467 | Preserve the maker/car/engine restatement; omit the sentence equating a harness with only an interface. |
| 05 | 07:55.100-08:01.100 | 01:50.467-01:56.467 | Introduce training on data without the overbroad all-websites example. |
| 06 | 08:21.733-09:34.400 | 01:56.467-03:09.133 | Keep next-token prediction, the fox example, token qualification, and further conversational training. |
| 07 | 03:52.033-05:11.233 | 03:09.133-04:28.333 | Describe the products and modes; stop before the unsupported usage ranking. |
| 08 | 02:54.233-03:51.900 | 04:28.333-05:26.000 | Keep Mary's personal preference, creative strengths, and Josh's response about complementing her abilities. |
| 09 | 13:36.167-14:27.833 | 05:26.000-06:17.667 | Keep the model-name frustration, spoken OpenAI correction, and Mary's writing-style preference. |
| 10 | 15:15.533-15:35.100 | 06:17.667-06:37.233 | Keep task-based model choice and the ordinary opening-hours example; remove speculative math/job pivot. v2 removes 0.5 seconds of the preceding sentence tail at the start. |
| 11 | 20:40.967-21:22.167 | 06:37.233-07:18.433 | Keep Mary's friend example and her own learning preferences, before the population generalizations. |
| 12 | 22:23.167-23:43.333 | 07:18.433-08:38.600 | Keep the full coding-class setup, grade reversal, laughter and both hosts' practical conclusion. |
| 13 | 31:45.267-31:50.967 | 08:38.600-08:44.300 | Keep the complete beginner recommendation, without the earlier permission-bypass advice. |
| 14 | 52:51.533-53:23.167 | 08:44.300-09:15.933 | Start the recent-chats exchange and first item; omit the unverified autonomous petition/email story. |
| 15 | 54:56.233-55:37.600 | 09:15.933-09:57.300 | Keep street-style and pina-colada examples plus the next-episode invitation; remove unconfirmed inbox plug. |
| 16 | 55:40.367-55:41.433 | 09:57.300-09:58.367 | Preserve the authentic farewell with a short fade. |

## Meaning and continuity

The model-name mistake retains the immediate spoken correction. The grade story keeps its setup, comparison, reaction and conclusion. No reaction is moved to a different statement. The car passage omits the sentence equating harness with the visible interface; the retained maker/car/engine restatement carries the lesson. The speech still briefly names the word harness as an example of jargon, without attempting a technical definition.

The ending omits the academic-petition story because its account access, autonomous email outcome and AI-authorship wording require separate review. The close preserves actual everyday examples and removes the inbox plug. Neither the omission nor the source anecdote establishes what an external tool actually did.

## Review performed

Complete machine transcript read; source frames sampled across the full shoot and around selected host exchanges; local token alignment run for proposed boundaries. See the quality report for final export measurements and frame checks. These checks are not continuous audiovisual viewing or perceptual listening.

## Audio

Use one of four identical source mixes; never sum duplicates. 65 Hz rumble filtering, restrained dynamic leveling, 8 ms edit ramps, then two-pass normalization toward -16 LUFS with peak headroom. No unapproved music. The mixed recording does not provide independent microphones. Listening approval remains open.

