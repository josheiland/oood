"""Build Josh and Mary's mostly intact, claim-checked Episode 1 review cut."""
from pathlib import Path
import json

P = Path(__file__).resolve().parent
SOURCE = Path('/Users/je/Movies/Episode 1 Raw.mp4')
FPS = 30

# Half-open source ranges. Cut at source frames; all times below are seconds.
CUTS = [
    (0, 15, 'Requested hand-cover opening'),
    (106.62, 142.48, 'Unsourced blanket provider ranking and false all-models-closed claim'),
    (390.72, 394.54, 'OpenAI also has open-weight models'),
    (406.04, 471.88, 'Misleading description of model weights and product modes'),
    (711.38, 719.66, 'Unsourced blanket open-versus-closed quality ranking'),
    (752.20, 813.44, 'Unsupported claims about named specialist products'),
    (874.50, 878.82, 'Stronger model does not inherently mean more tokens'),
    (903.72, 915.10, 'Model choice and usage limits conflated'),
    (1734.98, 1757.82, 'Battery analogy and erroneous chips-versus-GPUs distinction'),
    (1786.02, 1788.82, 'GPU expands to graphics, not graphical, processing unit'),
    (1882.78, 1904.06, 'Unqualified permission advice and Mary lost her train of thought'),
    (1982.30, 2004.82, 'Open source without open weights claim is wrong under OSI definition'),
    (2057.80, 2074.84, 'Unsupported blanket open-model quality comparison'),
    (2111.44, 2124.60, 'Unsourced government-subsidy speculation'),
    (2148.52, 2163.48, 'Unsupported blanket revenue comparison'),
    (2219.88, 2226.44, 'On-premises is not automatically more secure'),
    (2369.16, 2386.78, 'Requested Demis/Dario name slip and restart'),
    (2706.12, 2715.30, 'Requested Josh lost-train-of-thought passage'),
    (2797.16, 2850.58, 'Misleading OpenAI nonprofit-structure summary and unverified attributed motive'),
    (3341.70, 3347.233333, 'Requested hand-cover ending'),
]

def frame(sec):
    return round(sec * FPS)

start, end = frame(0), frame(3347.233333)
cuts = [(frame(a), frame(b), why) for a, b, why in CUTS]
assert cuts[0][0] == start and cuts[-1][1] == end
assert all(a < b for a, b, _ in cuts)
assert all(cuts[i][1] <= cuts[i+1][0] for i in range(len(cuts)-1))
segments = []
cursor = 0
last = start
for a, b, why in cuts:
    if a > last:
        segments.append({'id': f'{len(segments)+1:02}', 'in_frame': last,
                         'out_frame': a, 'raw_frames': a-last,
                         'output_start_frame_before_dissolves': cursor})
        cursor += a-last
    last = b
assert last == end
assert all(s['raw_frames'] > 10 for s in segments)
fade_frames = 4
for i, s in enumerate(segments):
    s['timeline_frame'] = s['output_start_frame_before_dissolves'] - i*fade_frames
total_frames = cursor - fade_frames * (len(segments)-1)
edl = {
    'title': 'Out of Our Depth | Episode 1: AI basics and what changes for us',
    'status': 'v5 host-review proposal, no overlays or pop-ups',
    'source': str(SOURCE),
    'source_sha256': '9f58d3a39c91ce4499fd3215355ddc9873051e6e32a5b26a6c73ce05caf93107',
    'fps': FPS, 'width': 1920, 'height': 1080, 'audio_stream': 1,
    'transition': {'video': '4-frame cross-dissolve', 'audio': '4-frame crossfade',
                   'frames': fade_frames},
    'cuts': [{'in_frame': a, 'out_frame': b, 'reason': why} for a,b,why in cuts],
    'segments': segments,
    'total_frames': total_frames,
    'duration_seconds': total_frames / FPS,
    'graphics': [],
}
(P/'episode-01-edit-decisions-v5.json').write_text(json.dumps(edl, indent=2)+'\n')
print(f'{len(segments)} segments, {len(cuts)} cuts, {total_frames/FPS:.3f}s / {total_frames} frames')
