# Episode 1 chapters v2

Exact master timing. The 5.7-second viewer-action chapter is omitted from the YouTube list so all published chapter intervals exceed 10 seconds.

- 00:00.000 The AI-name problem
- 00:45.333 Company, model, app
- 01:50.467 How a language model learns
- 03:09.133 Chat, work, and code
- 04:28.333 Which tool feels useful?
- 06:37.233 Learn by asking
- 08:38.600 One tool, one real task
- 08:44.300 What are you actually asking?

## YouTube chapters

00:00 The AI-name problem
00:45 Company, model, app
01:50 How a language model learns
03:09 Chat, work, and code
04:28 Which tool feels useful?
06:37 Learn by asking
08:44 What are you actually asking?
