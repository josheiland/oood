#!/usr/bin/env python3
"""Seek into the clean master for the late Episode 001 preview hooks."""

import importlib.util
import subprocess
from pathlib import Path

HERE = Path(__file__).resolve().parent
SPEC = importlib.util.spec_from_file_location("hooks", HERE / "build-hook-options.py")
hooks = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(hooks)


def build(name, output_name):
    _, first, after = hooks.selected_hook(name)
    hook_frames = after-first
    hook_seconds = hook_frames/30
    body_seconds = hooks.PREVIEW_BODY_FRAMES/30
    output = HERE / output_name
    if output.exists():
        raise FileExistsError(output)
    graph = ";".join([
        f"[0:v]trim=end_frame={hook_frames},setpts=N/(30*TB),"
        "format=yuv420p,setsar=1[hv]",
        f"[0:a]atrim=duration={hook_seconds:.9f},asetpts=PTS-STARTPTS,"
        f"aresample=48000,volume=-0.6dB,afade=t=out:st={hook_seconds-.05:.9f}:d=0.05,"
        f"apad,atrim=duration={hook_seconds:.9f},aformat=channel_layouts=stereo[ha]",
        f"[2:v]trim=end_frame={hooks.TITLE_FRAMES},setpts=N/(30*TB),"
        "format=yuv420p,setsar=1[tv]",
        f"[3:a]volume=-1.6dB,aresample=48000,apad,"
        f"atrim=duration={hooks.TITLE_FRAMES/30:.9f},aformat=channel_layouts=stereo[ta]",
        f"[1:v]trim=end_frame={hooks.PREVIEW_BODY_FRAMES},setpts=N/(30*TB),"
        "format=yuv420p,setsar=1[bv]",
        f"[1:a]aresample=48000,volume=-0.45dB,apad,"
        f"atrim=duration={body_seconds:.9f},aformat=channel_layouts=stereo[ba]",
        "[hv][ha][tv][ta][bv][ba]concat=n=3:v=1:a=1[v][a]",
    ])
    total = hook_frames+hooks.TITLE_FRAMES+hooks.PREVIEW_BODY_FRAMES
    cmd = ["ffmpeg", "-nostdin", "-hide_banner", "-v", "error", "-n",
           "-ss", f"{first/30:.9f}", "-i", str(hooks.CLEAN),
           "-i", str(hooks.CLEAN),
           "-loop", "1", "-framerate", "30", "-i", str(hooks.INTRO),
           "-i", str(hooks.STING), "-filter_complex", graph,
           "-map", "[v]", "-map", "[a]", "-map_metadata", "-1", "-map_chapters", "-1",
           "-frames:v", str(total), "-r", "30", "-fps_mode", "cfr",
           "-c:v", "libx264", "-preset", "veryfast", "-crf", "21",
           "-profile:v", "high", "-pix_fmt", "yuv420p",
           "-color_primaries", "bt709", "-color_trc", "bt709", "-colorspace", "bt709",
           "-c:a", "aac", "-b:a", "192k", "-movflags", "+faststart", str(output)]
    subprocess.run(cmd, check=True)
    print(f"{output.name}: {total} frames ({total/30:.3f}s)", flush=True)


if __name__ == "__main__":
    build("07-hallie-email", "07-hallie-email-v2.mp4")
    build("08-cs-undgrad", "08-cs-undgrad.mp4")
