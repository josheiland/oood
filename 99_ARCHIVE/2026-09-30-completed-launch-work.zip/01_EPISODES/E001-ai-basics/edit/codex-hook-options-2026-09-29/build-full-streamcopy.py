#!/usr/bin/env python3
"""Assemble Episode 001 without re-encoding the 53-minute conversation picture."""

import importlib.util
import subprocess
from pathlib import Path

HERE = Path(__file__).resolve().parent
SPEC = importlib.util.spec_from_file_location("hooks", HERE / "build-hook-options.py")
hooks = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(hooks)

HOOK = HERE / "selected-hook-segment.mp4"
TITLE = HERE / "episode-001-title-segment.mp4"
OUTRO = HERE / "episode-001-outro-segment.mp4"
LIST = HERE / "episode-001-full-concat.txt"
OUTPUT = HERE / "episode-001-full-review-v3.mp4"
SRT = HERE / "episode-001-full-review-v3.srt"


def run(args):
    subprocess.run(args, check=True)


def video_options(frames):
    return ["-frames:v", str(frames), "-r", "30", "-fps_mode", "cfr",
            "-c:v", "libx264", "-preset", "veryfast", "-crf", "20",
            "-profile:v", "high", "-level:v", "4.0", "-pix_fmt", "yuv420p",
            "-color_primaries", "bt709", "-color_trc", "bt709", "-colorspace", "bt709",
            "-c:a", "aac", "-b:a", "256k", "-ar", "48000", "-ac", "2",
            "-movflags", "+faststart"]


def encode_hook(first, frames):
    if HOOK.exists():
        raise FileExistsError(HOOK)
    duration = frames/hooks.FPS
    graph = (
        f"[0:v]trim=end_frame={frames},setpts=N/(30*TB),format=yuv420p,setsar=1[v];"
        f"[0:a]atrim=duration={duration:.9f},asetpts=PTS-STARTPTS,"
        f"aresample=48000,volume=-0.6dB,"
        f"afade=t=out:st={duration-.05:.9f}:d=0.05,"
        f"apad,atrim=duration={duration:.9f},aformat=channel_layouts=stereo[a]"
    )
    run(["ffmpeg", "-nostdin", "-hide_banner", "-v", "error", "-n",
         "-ss", f"{first/hooks.FPS:.9f}", "-i", str(hooks.CLEAN),
         "-filter_complex", graph, "-map", "[v]", "-map", "[a]",
         "-map_metadata", "-1", "-map_chapters", "-1", *video_options(frames), str(HOOK)])


def encode_card(path, picture, music, frames, volume, fade):
    if path.exists():
        raise FileExistsError(path)
    duration = frames/hooks.FPS
    vfade = f",fade=t=out:st={duration-.5:.9f}:d=0.5" if fade else ""
    afade = f",afade=t=out:st={duration-.7:.9f}:d=0.7" if fade else ""
    graph = (
        f"[0:v]trim=end_frame={frames},setpts=N/(30*TB),format=yuv420p,setsar=1{vfade}[v];"
        f"[1:a]volume={volume}dB,aresample=48000,apad,"
        f"atrim=duration={duration:.9f}{afade},aformat=channel_layouts=stereo[a]"
    )
    run(["ffmpeg", "-nostdin", "-hide_banner", "-v", "error", "-n",
         "-loop", "1", "-framerate", "30", "-i", str(picture),
         "-i", str(music), "-filter_complex", graph,
         "-map", "[v]", "-map", "[a]", "-map_metadata", "-1", "-map_chapters", "-1",
         *video_options(frames), str(path)])


def main():
    _, first, after = hooks.selected_hook(hooks.SELECTED)
    frames = after-first
    for path in (hooks.CLEAN, hooks.INTRO, hooks.OUTRO, hooks.STING, hooks.OUTRO_MUSIC):
        if not path.is_file():
            raise FileNotFoundError(path)
    for path in (OUTPUT, SRT, LIST):
        if path.exists():
            raise FileExistsError(path)
    encode_hook(first, frames)
    encode_card(TITLE, hooks.INTRO, hooks.STING, hooks.TITLE_FRAMES, -1.6, False)
    encode_card(OUTRO, hooks.OUTRO, hooks.OUTRO_MUSIC, hooks.OUTRO_FRAMES, -3.3, True)
    parts = [
        (HOOK, frames/hooks.FPS),
        (TITLE, hooks.TITLE_FRAMES/hooks.FPS),
        (hooks.CLEAN, hooks.BODY_FRAMES/hooks.FPS),
        (OUTRO, hooks.OUTRO_FRAMES/hooks.FPS),
    ]
    LIST.write_text("ffconcat version 1.0\n" + "".join(
        f"file '{path}'\nduration {duration:.9f}\n" for path, duration in parts
    ))
    run(["ffmpeg", "-nostdin", "-hide_banner", "-v", "warning", "-n",
         "-safe", "0", "-f", "concat", "-i", str(LIST),
         "-i", str(HERE / "episode-001-full-review.ffmeta"),
         "-map", "0:v:0", "-map", "0:a:0", "-map_metadata", "1", "-map_chapters", "1",
         "-c:v", "copy", "-c:a", "copy", "-movflags", "+faststart", str(OUTPUT)])
    hooks.write_captions(SRT, first, frames)
    print(OUTPUT, flush=True)
    print(SRT, flush=True)


if __name__ == "__main__":
    main()
