# Episode 001 hooks and updated-card full review: technical check

2026-09-29. Current local review export: `episode-001-full-review-v5.mp4`. SHA-256 `b21b7b780fdbb75bfd5c1d9b79701bcadabb72345f27e1ed97b9469cab6d7d29`. No publication or host approval is implied.

## Picture and edit

- All eight previews were decoded end to end without reported video or audio errors. Their runtime/frame counts, in option order, are: 31.700s/951, 31.900s/957, 36.433s/1,093, 31.467s/944, 34.533s/1,036, 33.533s/1,006, 36.833s/1,105, 33.267s/998. All are 1920 × 1080, 30 fps, H.264/AAC.
- The full review has 96,943 frames at 30 fps (53:51.433 picture). Its final AAC/container duration is 53:51.461, with 28 ms of audio padding. Twenty-two embedded chapters align with the hook (00:00), title (00:10.500), complete clean conversation (00:15.767), and outro (53:40.667).
- Full v4 picture-plus-audio decode passed without reported errors. V5 copies v4's H.264 video stream and makes a final AAC audio-level pass. The six sampled join frames in [`transition-contact-sheet-v4.jpg`](transition-contact-sheet-v4.jpg) show the selected hook, title, opening and hand-cover-to-outro picture sequence in the intended order.
- Packet-timestamp inspection of v5 found zero non-increasing decode timestamps across all 96,943 video and 151,480 audio packets.
- The conversation section is the complete 96,147-frame `episode-01-clean-review-v7.mp4`, carried through by video stream copy. That clean edit has only the seven raw-source removals in [`episode-01-removed-footage-v6.md`](../episode-01-removed-footage-v6.md), with five four-frame internal crossfades and four factual clarification cards. No extra conversation cut was introduced here. Its existing internal-transition and graphics checks remain in the v7 QC record.

## Audio and captions

- Final encoded audio measured **−17.62 LUFS integrated, −1.31 dBTP true peak, 4.70 LU loudness range**. The peak is below the preferred −1 dBTP ceiling. Dialogue, hook and music are stereo AAC at 48 kHz; the 53:24.900 clean conversation itself is otherwise unchanged editorially.
- The three preview/full boundaries were spot-checked in 100 ms RMS windows. The hook has a brief 50 ms audio fade before the sting; the title transitions into the source opening; the hand-cover close goes into outro music. No sustained silent gap was detected at those boundaries. An exact listening pass is still required.
- The full SRT has 1,144 numbered cues with positive, ordered time ranges contained within the picture duration. It retimes the existing machine-derived clean captions, includes the hook again at the front, labels the music, and transcribes the two on-screen outro asks. It still needs auditory proofreading before publication.

## Asset and review status

The Episode 001 cards are rendered from the current three-digit Mono, Mirrored template with the licensed local Teachers and JetBrains Mono files. The title reads `EPISODE 001`; the outro contains Josh's exact two requested asks. Josh confirmed the proposed OOOD theme's music rights on 2026-09-28; the underlying rights document is not in this repository. The raw shoot and older agents' outputs were not altered. Continuous host audiovisual review, personal-detail approval, hook selection and publication timing remain open.

Incomplete or timing-defective local trial exports are retained under `failed-attempts/` per the no-cleanup instruction; they are not review versions. `episode-001-full-review-v4.mp4` is a timestamp-correct stream-copy intermediate. V5 is the current review file.
