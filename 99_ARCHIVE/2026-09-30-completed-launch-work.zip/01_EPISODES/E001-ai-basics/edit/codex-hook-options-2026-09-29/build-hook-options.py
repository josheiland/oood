#!/usr/bin/env python3
"""Eight Episode 001 cold-open previews and one source-preserving full review."""

import argparse
import json
import re
import subprocess
from pathlib import Path

HERE = Path(__file__).resolve().parent
EPISODE = HERE.parents[1]
ROOT = EPISODE.parents[1]
CLEAN = EPISODE / "edit/episode-01-clean-review-v7.mp4"
CAPTIONS = EPISODE / "edit/episode-01-captions-v6.srt"
EDIT = json.loads((EPISODE / "edit/episode-01-edit-decisions-v6.json").read_text())
INTRO = HERE / "intro-card.png"
OUTRO = HERE / "outro-card.png"
STING = ROOT / "03_ASSETS/music/oood-sting-5s.wav"
OUTRO_MUSIC = ROOT / "03_ASSETS/music/oood-outro-11s.wav"
FPS = 30
TITLE_FRAMES = 158
PREVIEW_BODY_FRAMES = 478
OUTRO_FRAMES = 323
BODY_FRAMES = EDIT["total_frames"]

# Raw-source frame ranges, selected outside all seven v6 removals. The short
# previews all return to the same unabridged start of the clean conversation.
HOOKS = [
    ("01-model-names", "Why are the model names so confusing?", 13*60+32.44, 13*60+42.92),
    ("02-car-engine", "The model is the engine of the car", 10*60+11.18, 10*60+21.86),
    ("03-coding-midterm", "Mary's coding-midterm surprise", 23*60+4.26, 23*60+19.50),
    ("04-moat", "Mary objects to AI's favorite business word", 30*60+37.50, 30*60+47.78),
    ("05-moon-cloud", "Could the cloud be on the moon?", 37*60+39.86, 37*60+53.20),
    ("06-josh-cannot-code", "Josh says he cannot code; Mary disagrees", 22*60+29.78, 22*60+42.10),
    ("07-hallie-email", "Mary lets AI send an email while she sleeps", 54*60+15.12, 54*60+30.78),
    ("08-cs-undgrad", "Josh's CS background versus Mary's", 20*60+25.10, 20*60+37.18),
]
SELECTED = "01-model-names"


def run(args):
    subprocess.run(args, check=True)


def raw_to_clean(frame):
    for segment in EDIT["segments"]:
        if segment["in_frame"] <= frame < segment["out_frame"]:
            return segment["timeline_frame"] + frame - segment["in_frame"]
    raise ValueError(f"Source frame {frame} is removed")


def selected_hook(name):
    _, label, start, end = next(h for h in HOOKS if h[0] == name)
    first = raw_to_clean(round(start * FPS))
    after = raw_to_clean(round(end * FPS))
    return label, first, after


def graph(first, hook_frames, body_frames, include_outro):
    hook_seconds = hook_frames / FPS
    body_seconds = body_frames / FPS
    end_fade = min(.05, hook_seconds / 10)
    pieces = [
        f"[0:v]trim=start_frame={first}:end_frame={first+hook_frames},"
        "setpts=N/(30*TB),format=yuv420p,setsar=1[hv]",
        f"[0:a]atrim=start={first/FPS:.9f}:end={(first+hook_frames)/FPS:.9f},"
        f"asetpts=PTS-STARTPTS,aresample=48000,volume=-0.6dB,"
        f"afade=t=out:st={hook_seconds-end_fade:.9f}:d={end_fade:.9f},"
        f"apad,atrim=duration={hook_seconds:.9f},aformat=channel_layouts=stereo[ha]",
        f"[1:v]trim=end_frame={TITLE_FRAMES},setpts=N/(30*TB),"
        "format=yuv420p,setsar=1[tv]",
        f"[2:a]volume=-1.6dB,aresample=48000,apad,"
        f"atrim=duration={TITLE_FRAMES/FPS:.9f},aformat=channel_layouts=stereo[ta]",
        f"[0:v]trim=end_frame={body_frames},setpts=N/(30*TB),"
        "format=yuv420p,setsar=1[bv]",
        f"[0:a]aresample=48000,volume=-0.45dB,apad,"
        f"atrim=duration={body_seconds:.9f},aformat=channel_layouts=stereo[ba]",
    ]
    tags = "[hv][ha][tv][ta][bv][ba]"
    count = 3
    if include_outro:
        pieces.extend([
            f"[3:v]trim=end_frame={OUTRO_FRAMES},setpts=N/(30*TB),"
            "format=yuv420p,setsar=1,"
            f"fade=t=out:st={(OUTRO_FRAMES/FPS)-.5:.9f}:d=0.5[ov]",
            f"[4:a]volume=-3.3dB,aresample=48000,apad,"
            f"atrim=duration={OUTRO_FRAMES/FPS:.9f},"
            f"afade=t=out:st={(OUTRO_FRAMES/FPS)-.7:.9f}:d=0.7,"
            "aformat=channel_layouts=stereo[oa]",
        ])
        tags += "[ov][oa]"
        count += 1
    pieces.append(f"{tags}concat=n={count}:v=1:a=1[v][a]")
    return ";".join(pieces)


def full_graph(hook_frames):
    """Use a seeked hook input so the full-body branch never buffers minutes."""
    hook_seconds = hook_frames/FPS
    body_seconds = BODY_FRAMES/FPS
    outro_seconds = OUTRO_FRAMES/FPS
    return ";".join([
        f"[0:v]trim=end_frame={hook_frames},setpts=N/(30*TB),"
        "format=yuv420p,setsar=1[hv]",
        f"[0:a]atrim=duration={hook_seconds:.9f},asetpts=PTS-STARTPTS,"
        f"aresample=48000,volume=-0.6dB,afade=t=out:st={hook_seconds-.05:.9f}:d=0.05,"
        f"apad,atrim=duration={hook_seconds:.9f},aformat=channel_layouts=stereo[ha]",
        f"[2:v]trim=end_frame={TITLE_FRAMES},setpts=N/(30*TB),"
        "format=yuv420p,setsar=1[tv]",
        f"[3:a]volume=-1.6dB,aresample=48000,apad,"
        f"atrim=duration={TITLE_FRAMES/FPS:.9f},aformat=channel_layouts=stereo[ta]",
        f"[1:v]trim=end_frame={BODY_FRAMES},setpts=N/(30*TB),"
        "format=yuv420p,setsar=1[bv]",
        f"[1:a]aresample=48000,volume=-0.45dB,apad,"
        f"atrim=duration={body_seconds:.9f},aformat=channel_layouts=stereo[ba]",
        f"[4:v]trim=end_frame={OUTRO_FRAMES},setpts=N/(30*TB),"
        "format=yuv420p,setsar=1,"
        f"fade=t=out:st={outro_seconds-.5:.9f}:d=0.5[ov]",
        f"[5:a]volume=-3.3dB,aresample=48000,apad,"
        f"atrim=duration={outro_seconds:.9f},"
        f"afade=t=out:st={outro_seconds-.7:.9f}:d=0.7,"
        "aformat=channel_layouts=stereo[oa]",
        "[hv][ha][tv][ta][bv][ba][ov][oa]concat=n=4:v=1:a=1[v][a]",
    ])


def ffmetadata(path, first, hook_frames):
    hook_length = hook_frames / FPS
    body_start = hook_length + TITLE_FRAMES/FPS
    outro_start = body_start + BODY_FRAMES/FPS
    end = outro_start + OUTRO_FRAMES/FPS
    chapter_rows = [
        (0, "Cold open"), (hook_length, "Theme and title"),
        (body_start, "Opening and the AI landscape"),
        (60, "Companies, models, and apps"),
        (367, "Open and closed models"), (390, "How a model learns"),
        (519, "The engine analogy"), (732, "Choosing a model"),
        (862, "Work and human skills"), (1159, "Learning by asking"),
        (1354, "The coding-class story"), (1433, "What skills matter"),
        (1618, "NVIDIA and GPUs"), (1856, "Open weights and local models"),
        (2055, "On-prem and cloud"), (2177, "The people behind the companies"),
        (2322, "Safety, limits, and optimism"), (2578, "Founders and their reputations"),
        (2826, "A rapid-fire ranking"), (3031, "Our recent chats"),
        (3068, "A real use case from Mary"),
    ]
    chapters = chapter_rows[:3] + [(body_start + time, title) for time, title in chapter_rows[3:]]
    chapters.append((outro_start, "Outro"))
    lines = [";FFMETADATA1", "title=Out of Our Depth | Episode 001: AI basics and what changes for us", "artist=Josh and Mary"]
    for i, (start, title) in enumerate(chapters):
        stop = chapters[i+1][0] if i+1 < len(chapters) else end
        if stop <= start:
            raise ValueError((start, stop, title))
        lines += ["[CHAPTER]", "TIMEBASE=1/30000", f"START={round(start*30000)}", f"END={round(stop*30000)}", f"title={title}"]
    path.write_text("\n".join(lines) + "\n")


def parse_time(value):
    h, m, rest = value.split(":")
    s, ms = rest.split(",")
    return int(h)*3600 + int(m)*60 + int(s) + int(ms)/1000


def stamp(value):
    total = round(value*1000)
    h, total = divmod(total, 3600000)
    m, total = divmod(total, 60000)
    s, ms = divmod(total, 1000)
    return f"{h:02}:{m:02}:{s:02},{ms:03}"


def write_captions(path, first, hook_frames):
    blocks = []
    for block in re.split(r"\n\s*\n", CAPTIONS.read_text().strip()):
        lines = block.splitlines()
        start, end = lines[1].split(" --> ")
        blocks.append((parse_time(start), parse_time(end), "\n".join(lines[2:])))
    hook_start = first/FPS
    hook_end = (first+hook_frames)/FPS
    hook_length = hook_frames/FPS
    body_start = hook_length + TITLE_FRAMES/FPS
    body_end = body_start + BODY_FRAMES/FPS
    end = body_end + OUTRO_FRAMES/FPS
    cues = []
    for start, stop, body in blocks:
        lo, hi = max(start, hook_start), min(stop, hook_end)
        if hi > lo:
            cues.append((lo-hook_start, hi-hook_start, body))
    cues.append((hook_length, body_start, "[Instrumental theme music]"))
    cues += [(start+body_start, stop+body_start, body) for start, stop, body in blocks]
    cues.append((body_end, end, "[Instrumental theme music]"))
    path.write_text("\n\n".join(
        f"{i}\n{stamp(start)} --> {stamp(stop)}\n{body}"
        for i, (start, stop, body) in enumerate(cues, 1)
    ) + "\n")


def build(name, full=False):
    label, first, after = selected_hook(name)
    hook_frames = after-first
    body_frames = BODY_FRAMES if full else PREVIEW_BODY_FRAMES
    output = HERE / ("episode-001-full-review-v2.mp4" if full else f"{name}.mp4")
    if output.exists():
        raise FileExistsError(output)
    args = ["ffmpeg", "-nostdin", "-hide_banner", "-v", "error", "-n"]
    if full:
        args += ["-ss", f"{first/FPS:.9f}", "-i", str(CLEAN),
                 "-i", str(CLEAN),
                 "-loop", "1", "-framerate", "30", "-i", str(INTRO),
                 "-i", str(STING),
                 "-loop", "1", "-framerate", "30", "-i", str(OUTRO),
                 "-i", str(OUTRO_MUSIC)]
        meta = HERE / "episode-001-full-review.ffmeta"
        if not meta.exists():
            ffmetadata(meta, first, hook_frames)
        args += ["-i", str(meta)]
    else:
        args += ["-i", str(CLEAN), "-loop", "1", "-framerate", "30", "-i", str(INTRO),
                 "-i", str(STING)]
    total_frames = hook_frames + TITLE_FRAMES + body_frames + (OUTRO_FRAMES if full else 0)
    args += ["-filter_complex", full_graph(hook_frames) if full else graph(first, hook_frames, body_frames, False),
             "-map", "[v]", "-map", "[a]"]
    if full:
        args += ["-map_metadata", "6", "-map_chapters", "6"]
    else:
        args += ["-map_metadata", "-1", "-map_chapters", "-1"]
    args += ["-frames:v", str(total_frames), "-r", "30", "-fps_mode", "cfr",
             "-c:v", "libx264", "-preset", "veryfast", "-crf", "20" if full else "21",
             "-profile:v", "high", "-pix_fmt", "yuv420p",
             "-color_primaries", "bt709", "-color_trc", "bt709", "-colorspace", "bt709",
             "-c:a", "aac", "-b:a", "256k" if full else "192k",
             "-movflags", "+faststart", str(output)]
    run(args)
    if full:
        srt = HERE / "episode-001-full-review-v2.srt"
        if srt.exists():
            raise FileExistsError(srt)
        write_captions(srt, first, hook_frames)
    print(f"{output.name}: {total_frames} frames ({total_frames/FPS:.3f}s), {label}", flush=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--full", action="store_true")
    parser.add_argument("--only", choices=[x[0] for x in HOOKS])
    args = parser.parse_args()
    for path in (CLEAN, CAPTIONS, INTRO, OUTRO, STING, OUTRO_MUSIC):
        if not path.is_file():
            raise FileNotFoundError(path)
    if args.full:
        build(SELECTED, full=True)
    else:
        for name, *_ in HOOKS:
            if args.only in (None, name):
                build(name)


if __name__ == "__main__":
    main()
