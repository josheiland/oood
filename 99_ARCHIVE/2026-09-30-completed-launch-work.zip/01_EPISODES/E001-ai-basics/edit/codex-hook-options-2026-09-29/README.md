# Episode 001 hook comparison and full review

Prepared for Josh and Mary's review on 2026-09-29. Each short video has one unaltered conversational hook, the 5.267-second Episode 001 Mono, Mirrored title card with the OOOD sting, and the same 15.933-second start of the episode. The hooks appear again later in the full conversation, matching the Episode 000 cold-open format. The preview lengths vary with the natural end of each exchange.

| Option | Raw-source hook | Hook length | Preview length | What it offers |
|---|---:|---:|---:|---|
| [01 Model names](01-model-names.mp4) | 13:32.433–13:42.933 | 10.500s | 31.700s | Mary's accessible frustration with model names; directly sets up the episode. **Used in the full review cut.** |
| [02 Car engine](02-car-engine.mp4) | 10:11.167–10:21.867 | 10.700s | 31.900s | Mary's simple car-engine analogy for a model. |
| [03 Coding midterm](03-coding-midterm.mp4) | 23:04.267–23:19.500 | 15.233s | 36.433s | A personal Josh/Mary moment with the 29-versus-90-something test score. |
| [04 Moat](04-moat.mp4) | 30:37.500–30:47.767 | 10.267s | 31.467s | Mary objects to AI business jargon and Josh translates it. |
| [05 Moon cloud](05-moon-cloud.mp4) | 37:39.867–37:53.200 | 13.333s | 34.533s | A playful detour from the cloud to proposed lunar data centers; no operational facility is claimed. |
| [06 Josh cannot code](06-josh-cannot-code.mp4) | 22:29.767–22:42.100 | 12.333s | 33.533s | Josh admits his coding limits; Mary pushes back. |
| [07 Hallie email](07-hallie-email-v2.mp4) | 54:15.133–54:30.767 | 15.633s | 36.833s | Mary lets AI send an email overnight, then worries and finds it worked. |
| [08 CS undergrad](08-cs-undgrad.mp4) | 20:25.100–20:37.167 | 12.067s | 33.267s | A concise contrast in Josh and Mary's coding experience. |

The [full Episode 001 review](episode-001-full-review-v5.mp4) opens with option 01, then the same title/music, the **entire 53:24.900 clean v7 conversation**, and a 10.767-second music/outro card. The outro reads “What should we try next? Tell us in the comments” and “Know someone figuring out AI? Send this their way.” The [matching captions](episode-001-full-review-v5.srt) are draft machine-derived captions, not yet listening-proofed. Editable [intro](intro-template.svg) and [outro](outro-template.svg) SVGs and the [card copy](episode-001-card-copy.json) are in this folder.

The full conversation is the existing source-preserving v7 edit. It has **only the seven source removals** in [the exact raw-footage cut list](../episode-01-removed-footage-v6.md): pre-roll to 00:15, Mary's inaccurate model explanation, Mary's lost-thought passage, Josh's inverted open-source/open-weight definition, the Demis/Dario name slip, Josh's lost-thought passage, and the post-wrap tail after 55:41.700. Five internal four-frame crossfades and four brief factual clarification cards remain. All other discussion, including Demis's role change, Harvey/OpenEvidence, the open/closed model comparison, the GPU correction, and Hallie's story, stays. No additional conversation cuts were made for the hook versions or full review.

The same OOOD intro/outro music was confirmed cleared by Josh on 2026-09-28; the underlying rights document is not in this repository. This is a local host-review package, not a claim of host approval, upload, scheduling, or publication.

The [technical check](episode-001-hook-and-full-qc-v5.md) records frame counts, decode results, audio level and the remaining caption/listening review. Incomplete trial files are preserved under `failed-attempts/`; they are not for review.
