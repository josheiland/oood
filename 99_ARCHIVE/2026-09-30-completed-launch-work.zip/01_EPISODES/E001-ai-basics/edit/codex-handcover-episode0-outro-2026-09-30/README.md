# Episode 001 current host-review export

[Watch the full v2 review](episode-001-full-review-v2.mp4) (52:25.733, 1080p30). [Draft captions](episode-001-full-review-v2.srt) and 22 embedded chapters match this exact file. This is a local review, not an upload or publication.

The cold open remains Josh's exact saved `ep1hook.mp4`; the intro page and song are unchanged from the preceding full review. **Immediately after the intro, picture begins on Mary's hand obscuring the lens at raw 00:15.833.** The preceding 25 conversation frames (0.833 seconds) are omitted, so the hand uncovers the camera before Mary speaks. [All eight raw-source removals](removed-footage.md) are listed explicitly; the 83-second NVIDIA/GPU detail cut remains.

The final page now uses the **exact current Episode 000 card asset** (SHA-256 `d301f0b98e8b07dab46bc8631b9f9cca7142c079359c38efb6b5051e71456a0f`) with its three prompts: “Love it? Tell Mary”; “Hate it? Tell Josh”; “Have an idea for what to cover next? Let us know”. The 10.767-second outro music and half-second picture fade remain. This supersedes the earlier Episode 001-specific two-ask outro for the current review.

This revision copies the saved hook, title and nearly all conversation picture packets; the only newly encoded picture is the short Episode 000 outro card. Audio was re-encoded once to remove the same opening 0.833 seconds cleanly. The earlier full export, raw media, Josh's hook and other agents' work remain untouched. See [technical checks](quality-check.md). Captions need auditory proofreading and Josh and Mary still need to approve this exact video after continuous viewing/listening.
