#!/usr/bin/env python3
"""Retime Episode 001 captions and chapters after the 25-frame opening trim."""

from pathlib import Path
import re

HERE = Path(__file__).resolve().parent
PRIOR = HERE.parent / "codex-elon-hook-review-2026-09-30"
SOURCE_SRT = PRIOR / "episode-001-full-review.srt"
SOURCE_META = PRIOR / "episode-001-full-review.ffmeta"
SRT = HERE / "episode-001-full-review-v2.srt"
META = HERE / "episode-001-full-review-v2.ffmeta"
BODY_START_FRAME = 263 + 158
BODY_TRIM_FRAMES = 25
BODY_START = BODY_START_FRAME / 30
TRIM = BODY_TRIM_FRAMES / 30
OUTRO_START = (263 + 158 + 93653 - BODY_TRIM_FRAMES) / 30
END = (94397 - BODY_TRIM_FRAMES) / 30


def seconds(value):
    hh, mm, rest = value.split(":")
    ss, ms = rest.split(",")
    return int(hh) * 3600 + int(mm) * 60 + int(ss) + int(ms) / 1000


def stamp(value):
    ms = round(value * 1000)
    hh, ms = divmod(ms, 3600000)
    mm, ms = divmod(ms, 60000)
    ss, ms = divmod(ms, 1000)
    return f"{hh:02}:{mm:02}:{ss:02},{ms:03}"


def captions():
    cues = []
    for block in re.split(r"\n\s*\n", SOURCE_SRT.read_text().strip()):
        lines = block.splitlines()
        first, last = lines[1].split(" --> ")
        start, stop = seconds(first), seconds(last)
        if start >= BODY_START + TRIM:
            start -= TRIM
            stop -= TRIM
        elif stop > BODY_START:
            stop = min(stop, BODY_START)
        if start < stop and start < OUTRO_START:
            cues.append((start, min(stop, OUTRO_START), "\n".join(lines[2:])))
    cues.append((OUTRO_START, END, "[Instrumental theme music]"))
    if any(not (0 <= a < b <= END + .001) for a, b, _ in cues):
        raise ValueError("Caption outside new picture duration")
    SRT.write_text("\n\n".join(
        f"{i}\n{stamp(start)} --> {stamp(stop)}\n{text}"
        for i, (start, stop, text) in enumerate(cues, 1)) + "\n")


def chapters():
    content = SOURCE_META.read_text()
    header, *blocks = content.split("[CHAPTER]\n")
    output = [header.rstrip()]
    for block in blocks:
        rows = block.strip().splitlines()
        fields = dict(row.split("=", 1) for row in rows)
        start, stop = int(fields["START"]), int(fields["END"])
        trim_ticks = BODY_TRIM_FRAMES * 1000
        anchor = BODY_START_FRAME * 1000
        if start > anchor:
            start -= trim_ticks
        if stop > anchor:
            stop -= trim_ticks
        output += ["[CHAPTER]", "TIMEBASE=1/30000", f"START={start}",
                   f"END={stop}", f"title={fields['title']}"]
    META.write_text("\n".join(output) + "\n")


if __name__ == "__main__":
    for path in (SRT, META):
        if path.exists():
            raise FileExistsError(path)
    captions()
    chapters()
    print(SRT)
    print(META)
