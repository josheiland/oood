# Episode 001 v2: every raw-source removal

The original 55:47.233 shoot at `/Users/je/Movies/Episode 1 Raw.mp4` is unchanged. These are all eight half-open raw-source ranges absent from the conversation body. The opening trim now ends at **00:15.833**, so the first post-title picture frame is Mary’s hand obscuring the lens; her approach to the lens is gone. The saved `ep1hook.mp4` remains an intentional repeated cold open.

| # | Raw-source range removed | Duration | Reason |
|---:|---|---:|---|
| 1 | **00:00:00.000–00:00:15.833** | **15.833s** | Pre-roll plus the approach of Mary's hand toward the camera. Begin on the cover/uncover moment. |
| 2 | 00:06:46.033–00:07:51.867 | 65.833s | Misleading model-weights/product-modes explanation and confused response. |
| 3 | 00:28:54.867–00:30:17.867 | 83.000s | GPU/battery/gaming-history detour; brief NVIDIA setup remains. |
| 4 | 00:31:39.400–00:31:45.400 | 6.000s | Mary's lost-train-of-thought passage; her permissions preference remains. |
| 5 | 00:33:02.300–00:33:24.833 | 22.533s | Reversed open-source/open-weight definition; the rest of the comparison remains. |
| 6 | 00:39:29.167–00:39:46.767 | 17.600s | Demis/Dario name slip and restart; the role-change discussion remains. |
| 7 | 00:45:06.133–00:45:15.300 | 9.167s | Josh's lost-train-of-thought passage. |
| 8 | 00:55:41.700–00:55:47.233 | 5.533s | Post-wrap tail after the closing hand cover. |

Original raw footage removed totals 225.500 seconds. Six four-frame internal crossfades overlap another 0.800 seconds, leaving a 52:00.933 conversation body. The rest of the body remains in source order. The two GPU correction graphics fall wholly inside cut #3; the model-access and OpenAI-structure clarifications remain.
