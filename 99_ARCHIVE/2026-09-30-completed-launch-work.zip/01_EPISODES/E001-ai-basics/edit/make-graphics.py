"""Native OOOD graphics; original source frame and licensed Teachers font."""
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
import json, subprocess

P = Path(__file__).resolve().parent
ROOT = P.parents[2]
G = P / 'graphics'
T = P / 'intermediate'
FONT = ROOT / '03_ASSETS/brand-fonts/teachers.ttf'
BLUE, CREAM, FOAM, NAVY = '#38B6FF', '#FBF1E5', '#FDF8F2', '#0B2A45'

def font(size, weight=800):
    f = ImageFont.truetype(str(FONT), size)
    f.set_variation_by_axes([weight])
    return f

def tight(d, xy, text, f, fill, tracking=-.02):
    x,y=xy
    for ch in text:
        d.text((x,y),ch,font=f,fill=fill)
        x += d.textlength(ch,font=f)+f.size*tracking

def icon(size):
    im=Image.new('RGB',(size,size),BLUE); d=ImageDraw.Draw(im)
    for text,sz,y,tr in [('OUT OF OUR',round(size*.0776),size*.34,.02),('DEPTH',round(size*.2228),size*.418,-.02)]:
        f=font(sz);w=sum(d.textlength(ch,font=f)+sz*tr for ch in text)-sz*tr
        tight(d,((size-w)/2,y),text,f,CREAM,tr)
    return im

cards = [
    ('company-model-app','COMPANY / MODEL / APP','Who builds it / what powers it / where you use it'),
    ('car-analogy','THE CAR ANALOGY','Company = maker     Model = engine     App = car'),
    ('model-names','TOO MANY NAMES','OpenAI: GPT models     Anthropic: Claude models'),
    ('tokens','TOKENS','Small chunks of text a model processes'),
    ('check-output','CHECK THE ANSWER','A confident response can still be wrong.'),
]
for slug,title,body in cards:
    im=Image.new('RGBA',(1728,216),CREAM);d=ImageDraw.Draw(im)
    d.rectangle((0,125,1727,215),fill=FOAM)
    tight(d,(34,16),title,font(59),NAVY)
    d.rectangle((34,101,1693,107),fill=BLUE)
    d.text((36,143),body,font=font(39,600),fill=NAVY)
    assert d.textbbox((36,143),body,font=font(39,600))[2]<1694
    im.save(G/f'{slug}.png')

panel=Image.new('RGBA',(650,142),BLUE);d=ImageDraw.Draw(panel)
tight(d,(30,12),'JOSH + MARY',font(59),NAVY)
d.text((33,91),'OUT OF OUR DEPTH',font=font(25,600),fill=NAVY)
panel.save(G/'host-lower-third.png')
for n in range(10):
    fr=Image.new('RGBA',panel.size);w=round(panel.width*n/9)
    if w:fr.paste(panel.crop((0,0,w,panel.height)),(0,0))
    fr.save(T/f'wipe-{n:02d}.png')
subprocess.run(['ffmpeg','-nostdin','-v','error','-y','-framerate','30','-i',str(T/'wipe-%02d.png'),'-vf','tpad=stop_mode=clone:stop_duration=5.666667','-t','6','-c:v','qtrle','-pix_fmt','argb',str(T/'lower-third.mov')],check=True)
(G/'design-spec-v1.json').write_text(json.dumps({'font':str(FONT),'cards':[{'asset':s+'.png','title':t,'body':b,'dimensions':[1728,216],'waterline_y':125} for s,t,b in cards],'lower_third':{'asset':'host-lower-third.png','wipe_seconds':.3},'music':'none; no approved track'},indent=2)+'\n')
print('Five definition cards and animated host lower third prepared.')
