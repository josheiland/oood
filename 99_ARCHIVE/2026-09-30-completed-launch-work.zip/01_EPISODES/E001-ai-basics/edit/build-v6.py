"""Build Josh and Mary's mostly intact, claim-checked Episode 1 review cut."""
from pathlib import Path
import json

P = Path(__file__).resolve().parent
SOURCE = Path('/Users/je/Movies/Episode 1 Raw.mp4')
FPS = 30

# Half-open source ranges. Cut at source frames; all times below are seconds.
CUTS = [
    (0, 15, 'Requested hand-cover opening'),
    (406.04, 471.88, 'Misleading description of model weights and product modes'),
    (1899.40, 1905.40, 'Requested Mary lost-train-of-thought passage'),
    (1982.30, 2004.82, 'Open source without open weights claim is wrong under OSI definition'),
    (2369.16, 2386.78, 'Requested Demis/Dario name slip and restart'),
    (2706.12, 2715.30, 'Requested Josh lost-train-of-thought passage'),
    (3341.70, 3347.233333, 'Requested hand-cover ending'),
]

def frame(sec):
    return round(sec * FPS)

start, end = frame(0), frame(3347.233333)
cuts = [(frame(a), frame(b), why) for a, b, why in CUTS]
assert cuts[0][0] == start and cuts[-1][1] == end
assert all(a < b for a, b, _ in cuts)
assert all(cuts[i][1] <= cuts[i+1][0] for i in range(len(cuts)-1))
segments = []
cursor = 0
last = start
for a, b, why in cuts:
    if a > last:
        segments.append({'id': f'{len(segments)+1:02}', 'in_frame': last,
                         'out_frame': a, 'raw_frames': a-last,
                         'output_start_frame_before_dissolves': cursor})
        cursor += a-last
    last = b
assert last == end
assert all(s['raw_frames'] > 10 for s in segments)
fade_frames = 4
for i, s in enumerate(segments):
    s['timeline_frame'] = s['output_start_frame_before_dissolves'] - i*fade_frames
total_frames = cursor - fade_frames * (len(segments)-1)
edl = {
    'title': 'Out of Our Depth | Episode 1: AI basics and what changes for us',
    'status': 'v6 host-review proposal, four brief brand clarification pop-ups',
    'source': str(SOURCE),
    'source_sha256': '9f58d3a39c91ce4499fd3215355ddc9873051e6e32a5b26a6c73ce05caf93107',
    'fps': FPS, 'width': 1920, 'height': 1080, 'audio_stream': 1,
    'transition': {'video': '4-frame cross-dissolve', 'audio': '4-frame crossfade',
                   'frames': fade_frames},
    'cuts': [{'in_frame': a, 'out_frame': b, 'reason': why} for a,b,why in cuts],
    'segments': segments,
    'total_frames': total_frames,
    'duration_seconds': total_frames / FPS,
    'graphics': [],
}
graphic_specs = [
    ('model-access', 137.90, 5.50, 'graphics/v6-model-access-cropped.png',
     'The flagship models here are closed. OpenAI also offers open-weight gpt-oss.',
     'https://help.openai.com/en/articles/11870455-openai-open-weight-models'),
    ('gpu-chip', 1742.53, 4.00, 'graphics/v6-gpu-chip-cropped.png',
     'A GPU is a chip.',
     'https://www.nvidia.com/en-us/geforce/news/introduction-to-pc-components/'),
    ('gpu-name', 1786.03, 3.50, 'graphics/v6-gpu-name-cropped.png',
     '*Graphics processing unit',
     'https://docs.nvidia.com/cuda/cuda-programming-guide/01-introduction/introduction.html'),
    ('openai-structure', 2798.40, 5.50, 'graphics/v6-openai-structure-cropped.png',
     'Its nonprofit still controls its for-profit arm.',
     'https://openai.com/our-structure/'),
]
for name, raw_start, duration, asset, copy, source_url in graphic_specs:
    source_frame = frame(raw_start)
    segment = next(s for s in segments
                   if s['in_frame'] <= source_frame < s['out_frame'])
    start_frame = segment['timeline_frame'] + source_frame - segment['in_frame']
    edl['graphics'].append({
        'id': name, 'source_start_frame': source_frame,
        'start_frame': start_frame, 'end_frame': start_frame + frame(duration),
        'asset': asset, 'copy': copy, 'source_url': source_url,
        'purpose': 'brief factual clarification', 'overlay_x': 96, 'overlay_y': 615,
    })
(P/'episode-01-edit-decisions-v6.json').write_text(json.dumps(edl, indent=2)+'\n')
print(f'{len(segments)} segments, {len(cuts)} cuts, {total_frames/FPS:.3f}s / {total_frames} frames')
