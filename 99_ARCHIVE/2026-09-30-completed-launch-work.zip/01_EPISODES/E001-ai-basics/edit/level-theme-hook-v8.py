"""Lower the theme cold-open peak while keeping music and dialogue balanced."""
from pathlib import Path
import subprocess

P = Path(__file__).resolve().parent
SOURCE = P / 'episode-01-theme-preview-v6.mp4'
OUTPUT = P / 'episode-01-theme-review-v8.mp4'
assert SOURCE.is_file()
assert not OUTPUT.exists(), f'Preserving existing export: {OUTPUT}'

counts = [305, 158, 96147, 323]
gains = ['-1.8dB', '-0.6dB', '-0.6dB', '-0.6dB']
filters = []
cursor = 0
for index, (frames, gain) in enumerate(zip(counts, gains)):
    end = cursor + frames * 1600
    filters.append(f'[0:a:0]aresample=48000,atrim=start_sample={cursor}:'
                   f'end_sample={end},asetpts=N/SR/TB,volume={gain}[a{index}]')
    cursor = end
filters.append(''.join(f'[a{i}]' for i in range(4))+
               f'concat=n=4:v=0:a=1,apad=whole_len={cursor},'
               f'atrim=end_sample={cursor},asetpts=N/SR/TB[aout]')
graph = P / 'intermediate/v8-theme-audio-filtergraph.txt'
assert not graph.exists(), f'Preserving existing graph: {graph}'
graph.write_text(';'.join(filters) + '\n')
subprocess.run(['ffmpeg', '-nostdin', '-hide_banner', '-loglevel', 'error',
                '-i', str(SOURCE), '-filter_complex_script', str(graph),
                '-map', '0:v:0', '-map', '[aout]', '-map_metadata', '0',
                '-map_chapters', '0', '-c:v', 'copy', '-c:a', 'aac', '-b:a', '256k',
                '-movflags', '+faststart', str(OUTPUT)], check=True)
print(OUTPUT)
