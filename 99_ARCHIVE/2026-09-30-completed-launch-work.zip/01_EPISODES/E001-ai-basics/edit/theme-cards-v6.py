"""Episode 1 private theme-preview title and two-ask outro cards."""
import sys
from pathlib import Path

from PIL import Image, ImageDraw

sys.path.insert(0, '/Users/je/oood/01_EPISODES/E002-make-ai-useful/edit/graphics-v2')
import oood_graphics as G

WHITE = '#FFFFFF'


def title_frame():
    im = Image.new('RGB', (1920, 1080), G.BLUE)
    d = ImageDraw.Draw(im)
    lab = G.font(G.MONO, 32, 500)
    big = G.font(G.TEACHERS, 230, 800)
    sub = G.font(G.TEACHERS, 66, 600)
    G.tracked(d, (150, 300), 'EPISODE 01', lab, WHITE, 0.18)
    G.tracked(d, (140, 350), 'OUT OF OUR', big, WHITE, -0.03)
    G.tracked(d, (140, 560), 'DEPTH', big, WHITE, -0.03)
    d.text((150, 830), 'AI basics and what changes for us', font=sub, fill=WHITE)
    return im


def outro_frame():
    im = Image.new('RGB', (1920, 1080), G.BLUE)
    d = ImageDraw.Draw(im)
    lab = G.font(G.MONO, 30, 500)
    question = G.font(G.TEACHERS, 88, 800)
    answer = G.font(G.TEACHERS, 73, 600)
    G.tracked(d, (150, 188), 'OUT OF OUR DEPTH', lab, WHITE, 0.18)
    d.text((150, 285), 'What should we try next?', font=question, fill=WHITE)
    d.text((150, 388), 'Tell us in the comments', font=answer, fill=WHITE)
    d.text((150, 637), 'Know someone figuring out AI?', font=question, fill=WHITE)
    d.text((150, 740), 'Send this their way', font=answer, fill=WHITE)
    return im


if __name__ == '__main__':
    folder = Path(__file__).resolve().parent / 'graphics'
    for name, frame in [('v6-theme-title', title_frame()),
                        ('v6-theme-outro-two-asks', outro_frame())]:
        out = folder / f'{name}.png'
        if out.exists():
            raise SystemExit(f'Preserving existing graphic: {out}')
        frame.save(out)
        print(out)
