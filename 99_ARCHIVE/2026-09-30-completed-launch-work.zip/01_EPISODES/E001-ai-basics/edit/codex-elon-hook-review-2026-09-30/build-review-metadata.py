#!/usr/bin/env python3
"""Retimed draft captions and chapters for Josh's selected Episode 001 review."""

from pathlib import Path
import re

HERE = Path(__file__).resolve().parent
CAPTIONS = HERE.parent / "episode-01-captions-v6.srt"
SRT = HERE / "episode-001-full-review.srt"
META = HERE / "episode-001-full-review.ffmeta"

FPS = 30
HOOK = 263 / FPS
TITLE = 158 / FPS
BODY_START = HOOK + TITLE
CUT_START = 49617 / FPS
CUT_END = 52107 / FPS
DISSOLVE = 4 / FPS
REMOVED = CUT_END - CUT_START + DISSOLVE
BODY_END = BODY_START + 93653 / FPS
END = BODY_END + 323 / FPS


def seconds(value):
    h, m, rest = value.split(":")
    s, ms = rest.split(",")
    return int(h) * 3600 + int(m) * 60 + int(s) + int(ms) / 1000


def stamp(value):
    total = round(value * 1000)
    h, total = divmod(total, 3600000)
    m, total = divmod(total, 60000)
    s, ms = divmod(total, 1000)
    return f"{h:02}:{m:02}:{s:02},{ms:03}"


def original_cues():
    for block in re.split(r"\n\s*\n", CAPTIONS.read_text().strip()):
        lines = block.splitlines()
        start, stop = lines[1].split(" --> ")
        yield seconds(start), seconds(stop), "\n".join(lines[2:]).rstrip()


def make_captions():
    cues = [
        (0.000, 1.010, "People are starting to try"),
        (1.010, 2.600, "to put data centers on the moon.\nNo way."),
        (2.600, 4.800, "Yeah. Oh my gosh, who has right to the land?"),
        (5.439, 7.899, "That's a whole different, whole different topic."),
        (HOOK, BODY_START, "[Instrumental theme music]"),
    ]
    for start, stop, body in original_cues():
        if stop <= CUT_START:
            cues.append((start + BODY_START, stop + BODY_START, body))
        elif start >= CUT_END:
            cues.append((start - REMOVED + BODY_START,
                         stop - REMOVED + BODY_START, body))
        elif start < CUT_START:
            cues.append((start + BODY_START, CUT_START + BODY_START, body))
        # Cues over the removed span are intentionally omitted. No subtitle
        # is made by combining words across the jump.
    cues.extend([
        (BODY_END, BODY_END + 5.0,
         "[Instrumental outro music]\nWhat should we try next? Tell us in the comments."),
        (BODY_END + 5.0, END,
         "Know someone figuring out AI? Send this their way."),
    ])
    cues.sort(key=lambda x: x[0])
    # A source cue can extend a few milliseconds over the new crossfade.
    # Keep the caption handoff sequential without changing either phrase.
    for i in range(len(cues) - 1):
        start, stop, body = cues[i]
        next_start = cues[i + 1][0]
        if 0 < stop - next_start < .1:
            cues[i] = (start, next_start, body)
    for start, stop, _ in cues:
        if start < 0 or stop <= start or stop > END + .001:
            raise ValueError((start, stop))
    SRT.write_text("\n\n".join(
        f"{i}\n{stamp(start)} --> {stamp(stop)}\n{body}"
        for i, (start, stop, body) in enumerate(cues, 1)) + "\n")


def make_chapters():
    anchors = [
        (0, "Cold open"), (HOOK, "Theme and title"),
        (BODY_START, "Opening and the AI landscape"),
    ]
    body_anchors = [
        (60, "Companies, models, and apps"),
        (367, "Open and closed models"),
        (390, "How a model learns"),
        (519, "The engine analogy"),
        (732, "Choosing a model"),
        (862, "Work and human skills"),
        (1159, "Learning by asking"),
        (1354, "The coding-class story"),
        (1433, "What skills matter"),
        (1618, "AI hardware and the wider market"),
        (1856, "Open weights and local models"),
        (2055, "On-prem and cloud"),
        (2177, "The people behind the companies"),
        (2322, "Safety, limits, and optimism"),
        (2578, "Founders and their reputations"),
        (2826, "A rapid-fire ranking"),
        (3031, "Our recent chats"),
        (3068, "A real use case from Mary"),
    ]
    for source_time, label in body_anchors:
        offset = REMOVED if source_time >= CUT_END else 0
        anchors.append((BODY_START + source_time - offset, label))
    anchors.append((BODY_END, "Outro"))
    lines = [";FFMETADATA1",
             "title=Out of Our Depth | Episode 001: AI basics and what changes for us",
             "artist=Josh and Mary"]
    for (start, label), (stop, _) in zip(anchors, anchors[1:] + [(END, "")]):
        if stop <= start:
            raise ValueError((start, stop, label))
        lines.extend(("[CHAPTER]", "TIMEBASE=1/30000",
                      f"START={round(start * 30000)}",
                      f"END={round(stop * 30000)}", f"title={label}"))
    META.write_text("\n".join(lines) + "\n")


if __name__ == "__main__":
    for output in (SRT, META):
        if output.exists():
            raise FileExistsError(output)
    make_captions()
    make_chapters()
    print(SRT)
    print(META)
