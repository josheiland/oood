# Episode 001: complete raw-footage removal list for this review

The 55:47.233 original recording in `/Users/je/Movies/Episode 1 Raw.mp4` is unchanged. These are **all eight** half-open raw-source ranges absent from the full conversation, rounded to its 30 fps frames. The first seven carry forward the previously documented mishap-only cut; #3 is Josh's new NVIDIA/GPU detour trim. The 8.761-second `ep1hook.mp4` cold open is a repeated excerpt of retained conversation.

| # | Raw-source range removed | Duration | Reason |
|---:|---|---:|---|
| 1 | 00:00:00.000–00:00:15.000 | 15.000s | Pre-roll before the requested hand-cover opening. |
| 2 | 00:06:46.033–00:07:51.867 | 65.833s | Misleading model-weights/product-modes explanation and confused response. |
| 3 | **00:28:54.867–00:30:17.867** | **83.000s** | GPU/battery/gaming history detour. Keep the NVIDIA and AI-hardware setup, then return to the broader AI-company point. |
| 4 | 00:31:39.400–00:31:45.400 | 6.000s | Mary's lost-train-of-thought passage. Her permissions preference stays. |
| 5 | 00:33:02.300–00:33:24.833 | 22.533s | Reversed open-source/open-weight definition. The rest of the comparison stays. |
| 6 | 00:39:29.167–00:39:46.767 | 17.600s | Demis/Dario name slip and restart. The role-change discussion stays. |
| 7 | 00:45:06.133–00:45:15.300 | 9.167s | Josh's lost-train-of-thought passage. |
| 8 | 00:55:41.700–00:55:47.233 | 5.533s | Post-wrap tail after the requested closing hand cover. |

The new #3 cut is a four-frame video dissolve and audio crossfade. The seven prior removals already have five four-frame joins. Original raw footage removed totals 224.667 seconds; six overlaps shorten the body another 0.800 seconds. The 52:01.767 conversation body remains in raw order. The two GPU correction cards fall wholly inside #3, so the full review retains only the model-access and OpenAI-structure clarification cards.
