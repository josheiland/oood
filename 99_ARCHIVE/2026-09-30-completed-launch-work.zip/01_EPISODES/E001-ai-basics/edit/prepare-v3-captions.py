"""Make source-assisted draft captions on the fuller v3 final timeline.

Use the exact-EDL source-token remap with ``source-remap``, or a local
final-export Whisper SRT by default. Names are normalized; all speech still
needs an auditory proofread. Cue overrides live in a versioned JSON file.
"""
from pathlib import Path
import json,re,textwrap,sys
P=Path(__file__).resolve().parent
D=json.loads((P/'episode-01-edit-decisions-v3.json').read_text())
TOTAL=D['total_frames']/D['fps']
SRT=P/('intermediate/v3-source-remap.srt' if len(sys.argv)>1 and sys.argv[1]=='source-remap' else 'intermediate/v3-asr.srt')
BASIS=('Source-recording ASR mapped through the exact v3 frame EDL' if SRT.name=='v3-source-remap.srt' else 'Local ASR of the exact v3 export')
OVERRIDES=P/'episode-01-caption-overrides-v3.json'
manual=json.loads(OVERRIDES.read_text()) if OVERRIDES.exists() else {}
def sec(v):
 h,m,s=v.replace(',','.').split(':');return int(h)*3600+int(m)*60+float(s)
def stamp(t,vtt=False):
 ms=round(t*1000);h,ms=divmod(ms,3600000);m,ms=divmod(ms,60000);s,ms=divmod(ms,1000)
 return f'{h:02}:{m:02}:{s:02}{"." if vtt else ","}{ms:03}'
fixes=[
 (r'\b[Cc]hat\s*G\s*P\s*T\b','ChatGPT'),
 (r'\b[Cc]hat\s*G\s*B\s*T\b','ChatGPT'),
 (r'\b[Cc]loud [Cc]ode\b','Claude Code'),
 (r'\b[Cc]lod ?[Cc]ode\b','Claude Code'),
 (r'\b[Cc]odecs\b','Codex'),
 (r'\b[Ee]ntropic\b','Anthropic'),
 (r'\b[Aa]nthropic\b','Anthropic'),
 (r'\b[Oo]pen ?[Aa][Ii]\b','OpenAI'),
 (r'\b[Nn]vidia\b','NVIDIA'),
 (r'\b[Gg]emini\b','Gemini'),
]
raw=[];changes=[]
for block in SRT.read_text().strip().split('\n\n'):
 ls=block.strip().splitlines()
 if len(ls)<3:continue
 idx=int(ls[0]);a,b=map(sec,ls[1].split(' --> '));original=' '.join(ls[2:]).strip();tx=manual.get(str(idx),original)
 for pattern,repl in fixes:tx=re.sub(pattern,repl,tx)
 tx=re.sub(r'\s+',' ',tx).strip()
 if tx.startswith('- '):tx=tx[2:]
 if tx!=original:changes.append({'asr_cue':idx,'before':original,'after':tx,'manual':str(idx) in manual})
 if not tx or a>=TOTAL:continue
 raw.append((max(0,a),min(TOTAL,b),tx))
merged=[]
for a,b,tx in raw:
 if merged:
  pa,pb,pt=merged[-1]
  if a-pb<=.25 and (b-a<.8 or pb-pa<.8 or len(tx)<12) and len(pt+' '+tx)<=84 and b-pa<=7.5:
   merged[-1]=(pa,b,pt+' '+tx)
   continue
 merged.append((a,b,tx))
result=[];last=0
for a,b,tx in merged:
 a=max(a,last)
 if b<=a:continue
 lines=textwrap.wrap(tx,42,break_long_words=False,break_on_hyphens=False)
 if len(lines)>2 and len(lines)%2:
  for width in range(41,23,-1):
   trial=textwrap.wrap(tx,width,break_long_words=False,break_on_hyphens=False)
   if len(trial)%2==0:
    lines=trial
    break
 groups=['\n'.join(lines[i:i+2]) for i in range(0,len(lines),2)]
 weight=sum(len(g.replace('\n','')) for g in groups);pos=a
 for j,g in enumerate(groups):
  end=b if j==len(groups)-1 else pos+(b-a)*len(g.replace('\n',''))/weight
  if end-pos<.08:continue
  result.append((pos,end,g));pos=end
 last=b
for i,(a,b,tx) in enumerate(result):
 assert 0<=a<b<=TOTAL+.001,(a,b)
 assert len(tx.splitlines())<=2 and all(len(x)<=42 for x in tx.splitlines()),tx
 if i:assert a>=result[i-1][1]-.001
for ext in ['srt','vtt']:
 vtt=ext=='vtt'
 body='\n\n'.join(('' if vtt else f'{i+1}\n')+f'{stamp(a,vtt)} --> {stamp(b,vtt)}\n{tx}' for i,(a,b,tx) in enumerate(result))+'\n'
 (P/f'episode-01-captions-v3.{ext}').write_text(('WEBVTT\n\n' if vtt else '')+body)
(P/'episode-01-caption-corrections-v3.json').write_text(json.dumps({'basis':BASIS+' with automatic official-name normalization and listed manual overrides. No perceptual listening verification claimed.','changes':changes,'caption_count':len(result),'max_characters_per_line':42,'max_lines':2,'auditory_proofread_pending':True},indent=2)+'\n')
(P/'episode-01-transcript-v3.md').write_text('# Episode 1 final-timeline transcript v3\n\nDraft from '+BASIS.lower()+' with name normalization. Auditory proofread and speaker attribution remain open.\n\n'+'\n\n'.join(f'**{stamp(a)}** '+tx.replace('\n',' ') for a,b,tx in result)+'\n')
print(f'{len(result)} ordered caption cues; last end {result[-1][1]:.3f}s of {TOTAL:.3f}s')
