"""Make a small contact sheet for manual review of v5 picture and joins."""
from pathlib import Path
from PIL import Image,ImageDraw
import io
import json
import subprocess

P=Path(__file__).resolve().parent
E=json.loads((P/'episode-01-edit-decisions-v5.json').read_text())
SOURCE=P/'episode-01-master-v5.mp4'
join=[s['timeline_frame']/30 for s in E['segments'][1:]]
times=[0,.5,5,15,60,E['duration_seconds']-.75,E['duration_seconds']-.25]
times+=join
times=sorted(set(round(max(0,min(t,E['duration_seconds']-.05)),3) for t in times))
frames=[]
for t in times:
    data=subprocess.check_output(['ffmpeg','-nostdin','-hide_banner','-loglevel','error',
                                  '-ss',str(t),'-i',str(SOURCE),'-frames:v','1',
                                  '-vf','scale=320:-2','-f','image2pipe','-vcodec','mjpeg','-'])
    frames.append(Image.open(io.BytesIO(data)).convert('RGB'))
width,height=frames[0].size
cols=5;rows=(len(frames)+cols-1)//cols
sheet=Image.new('RGB',(cols*width,rows*(height+24)),(250,250,250))
draw=ImageDraw.Draw(sheet)
for i,(t,im) in enumerate(zip(times,frames)):
    x=(i%cols)*width;y=(i//cols)*(height+24)
    sheet.paste(im,(x,y))
    draw.text((x+4,y+height+4),f'{int(t//60):02}:{t%60:06.3f}',fill=(0,0,0))
out=P/'intermediate/v5-sampled-frames.jpg'
sheet.save(out,quality=90)
print(f'{len(times)} frames sampled: {out}')
