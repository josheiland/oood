# Episode 1 full source transcript

Local machine transcript of the complete September 26 shoot. Not a verbatim-certified transcript; product names, overlaps and numbers may be wrong. Original ASR preserved in intermediate/source-asr.json. Source times, not final-export times.

**00:00:00,000** It's better when I'm like close to the camera so I can be like, anyways, what is that?

**00:00:10,580** We gotta shut this down because then we can't.

**00:00:12,740** We'll work on that part.

**00:00:16,740** What is that?

**00:00:17,740** We're back.

**00:00:18,740** And with a piece.

**00:00:19,740** Yeah.

**00:00:20,740** Piece love and gratitude.

**00:00:21,740** We're gonna work on it.

**00:00:22,740** We're gonna try out something different next time.

**00:00:24,740** I haven't seen you do that before.

**00:00:27,900** We are back.

**00:00:29,100** are back and we're doing an AI landscape.

**00:00:32,180** Like we're painting a photo, painting a picture.

**00:00:35,740** Painting a photo, even more impressive.

**00:00:38,860** Um, yeah, I think really the goal here is just, especially for folks

**00:00:44,680** who are newer to the space, a lot of terms get thrown around.

**00:00:48,060** Um, and we just want to start with the basics, separating out, you know, what

**00:00:53,820** What is the difference between the model and the actual platform or product that you're

**00:01:01,220** using?

**00:01:02,220** Who are the different key companies in the space?

**00:01:04,540** Who are actually some of the personalities behind the companies?

**00:01:07,780** What are the tools?

**00:01:09,260** What are the tools?

**00:01:11,700** Why don't we start with models?

**00:01:15,420** You have your provider, so it's like chat GPT.

**00:01:21,820** The provider I guess at the highest level would be Anthropic or OpenAI or Google, right?

**00:01:27,420** These are the companies that are actually training the models.

**00:01:31,500** Who's the provider for Grok?

**00:01:35,140** It's like X.

**00:01:36,140** Oh, X.

**00:01:37,140** Yeah.

**00:01:38,140** And then you've got some models coming out of Meta too.

**00:01:42,540** Okay.

**00:01:43,540** And then there's a handful of other companies.

**00:01:45,620** I think those are really the main ones.

**00:01:46,620** That was especially Anthropic and OpenAI are really I think kind of like the two going

**00:01:50,900** back and forth for the lead pretty consistently for the last couple of years.

**00:01:56,740** And then you've got a whole bunch of other kind of smaller companies in the mix, but

**00:02:02,260** in terms of like leading the benchmarks, which are the test to evaluate how effective a model

**00:02:07,860** is, it's really anthropic and open AI that have been going back and forth with the lead

**00:02:11,380** there.

**00:02:12,380** And these models, so there's two different types of models.

**00:02:15,140** There's open models and there's closed models.

**00:02:18,160** These are all closed models.

**00:02:19,380** So what it looks like is these providers.

**00:02:22,480** So let's use a Claude and chat and really quick caveat, at least for me, like to what

**00:02:28,600** you're saying, chat and chat GPT and Claude are so much better than the others that I

**00:02:38,340** feel digging into one or two of them is a lot more effective than trying to learn all

**00:02:43,780** of them.

**00:02:44,780** They're give or take very similar.

**00:02:46,160** I think it's just like how do you start that muscle of training and going to AI to support

**00:02:51,080** with certain things?

**00:02:52,080** Where is it helpful?

**00:02:53,080** Where is it not?

**00:02:54,080** So, quick caveat, I like Claude the most for pretty much everything except for like realistic

**00:03:02,680** photos where I think Chad just does such a better job.

**00:03:05,080** Like generating photos.

**00:03:06,080** Yeah, but I think a lot of that is just because I've spent more time in Claude, so I feel

**00:03:09,440** like it knows me more.

**00:03:10,720** I go back and forth.

**00:03:12,400** I think Chad is like in theory better at some of the personalization, at some of like the more

**00:03:18,480** human-esque where Claude kind of pops at more of the, I think like, you know, math, diagrams,

**00:03:28,400** frameworks, a little bit more of the kind of less creative side of things.

**00:03:32,640** Like structured.

**00:03:33,520** Yeah, which for me, I think creativity and all that stuff is like really fun. So I think,

**00:03:38,400** And I think it's a little bit more of a string than like, you know, the wording and all that stuff.

**00:03:43,760** So I think that's why I lean a little bit Claude, but I would say.

**00:03:46,640** It feels like it complements your background and your capabilities.

**00:03:50,400** Yeah.

**00:03:50,880** Interesting.

**00:03:51,360** Yeah.

**00:03:51,840** Yeah.

**00:03:52,000** So Claude is Anthropics product, which now kind of has a couple of different, I guess,

**00:03:59,280** tools really bundled within one.

**00:04:00,800** Yeah.

**00:04:02,240** And it's interesting because, you know, chat GPT, which is OpenAI's product,

**00:04:07,600** it's kind of been a similar evolution where initially they both just had a chat interface.

**00:04:12,880** And you would type a prompt, get a response back.

**00:04:15,680** Increasingly, they started to build out other kind of modes.

**00:04:18,960** So both of them now have essentially like a work mode, which goes a little bit beyond the chat bot

**00:04:27,520** and gives it more kind of ability to use different tools, which we'll talk a little bit more about

**00:04:32,960** on essentially just using other applications

**00:04:36,660** or other capabilities beyond just text-based chat

**00:04:39,940** to actually go further and be able to do more work

**00:04:42,540** on your behalf.

**00:04:43,800** And then both now also have more code-heavy

**00:04:47,060** technical products, so codecs from OpenAI

**00:04:50,360** and then Cloud Code from Anthropic.

**00:04:52,800** But it's interesting because more recently

**00:04:54,400** they've kind of been consolidating the Mac

**00:04:56,240** a little bit more.

**00:04:57,660** So it'd be interesting to see where that goes,

**00:04:59,240** but at its core, we'll talk a lot about chat

**00:05:02,760** GPT and Claude as like the interface, the product that OpenAI and Entropic respectively

**00:05:09,480** have built out.

**00:05:11,240** And I think those two are definitely the most commonly used.

**00:05:14,760** Gemini is like I would say like clear third, like sort of in the mix.

**00:05:19,480** They especially, they actually, because they have such a photo finish between chat GPT

**00:05:24,080** and Claude and then sweet, sweet Gemini.

**00:05:27,040** Yeah.

**00:05:28,040** A couple of miles back.

**00:05:29,040** Start off strong and I mean, honestly, it's a lot of strong.

**00:05:32,040** Well, no, like they were probably the favorite or like really well just they have so many advantages

**00:05:37,760** Yeah, like has so much user data and they have you know

**00:05:41,760** Like in theory them owning the Google ecosystems should be such an advantage

**00:05:46,840** They kind of botched it like it's like the if the Dodgers was like really bad because they like so much money exactly

**00:05:52,160** Yeah, like they just like it's the system is rigged for them to win. And yeah, exactly. It's like they just totally botched it

**00:06:00,200** I can't believe you pulled out the baseball net.

**00:06:02,080** I know, for a context.

**00:06:04,440** That's crazy.

**00:06:05,200** Yeah, that was crazy.

**00:06:06,200** I'm so proud of you.

**00:06:07,200** Yeah, that was-- yeah, yeah, honestly.

**00:06:09,920** I'll be thinking about that one before bed.

**00:06:12,600** I think-- OK, one total tangent, deep seek.

**00:06:17,720** There's these random ones.

**00:06:19,160** But US versus China, there is some.

**00:06:22,320** Yeah, and you mentioned earlier there's

**00:06:24,040** the closed models versus the open models.

**00:06:27,120** And really what that means is just the closed models,

**00:06:30,720** like the ones that are released by Anthropic and OpenAI,

**00:06:34,540** you can use them as a consumer,

**00:06:36,440** but you don't have the weights,

**00:06:39,280** which are essentially the underlying kind of structure

**00:06:44,120** and mechanism that powers the model.

**00:06:46,040** - And to double click there.

**00:06:48,480** So it's like a model is just like,

**00:06:51,580** if you think of like a bunch of data

**00:06:54,040** and then it's weighing different data differently.

**00:06:56,880** So like really crappy data, it's like, do less with,

**00:07:03,920** it's ingesting the data in different ways.

**00:07:06,580** And even when you go back to the chat

**00:07:10,120** versus co-work versus codex,

**00:07:11,820** like we're just talking to it, it's like doing more stuff.

**00:07:16,040** Even that, it's changing the parameters

**00:07:20,380** based off of what you wanna do.

**00:07:21,620** So if it's like a simple question you're asking,

**00:07:23,660** It makes no sense to use the codecs or cloud code

**00:07:28,560** because the parameters and the weighting

**00:07:32,360** are different than what you need.

**00:07:35,820** And it's really how do you align that?

**00:07:37,300** It's not like that there's this like,

**00:07:40,640** that they're trying to save credits

**00:07:42,240** if you use chat instead of codecs.

**00:07:44,960** - Yeah, yeah.

**00:07:46,640** - Would you agree?

**00:07:48,160** - I didn't totally follow up to be honest.

**00:07:49,960** (laughing)

**00:07:51,880** I think that, yeah, like high level,

**00:07:56,080** the way that these models are trained is

**00:07:58,400** they're just fed a ton of data.

**00:08:02,360** So like, you know, the earliest models had a ton

**00:08:05,280** of internet data, which is mostly text-based,

**00:08:08,020** which is why the initial models were,

**00:08:09,640** I think really well set up to be used

**00:08:11,000** in a chat-based interface.

**00:08:12,560** But you dump in, you know, all of Wikipedia,

**00:08:14,940** all of these archives that saved

**00:08:16,460** all the different web pages out there.

**00:08:18,160** And- - Reddit was huge.

**00:08:19,880** - Yeah, Reddit- - Sorry.

**00:08:21,880** And then these models are trained through a variety of different processes that we can dig into,

**00:08:26,680** because it can go much deeper in a future episode.

**00:08:28,280** But essentially, you know, you run tests over time to teach the model to predict the next word

**00:08:36,040** that comes after a given sentence, right?

**00:08:38,840** So if it's like a quick brown blank, like it's probably going to guess fox, right?

**00:08:44,680** Because that's out there a million times in different sources.

**00:08:48,440** And so at its core, these models were originally built to just predict the next token, which is not exactly a word, but you can think of it similar to a word in a sequence of words.

**00:08:58,440** And then, but, you know, like that in of itself, then you need to have some additional tweaks on top to make it be able to go back and forth in a conversational way.

**00:09:10,440** And so, you know, you take this model that's designed to predict the next word, you then

**00:09:15,420** tell it, you know, you're going to be answering a user's question.

**00:09:18,800** So you know, tailor your response accordingly.

**00:09:21,960** And then you go through a series of additional processes where you, you know, give it to

**00:09:26,760** give an output and then you evaluate it, tell it if it's good or not and sort of train it

**00:09:30,320** to do better.

**00:09:31,320** Yeah.

**00:09:32,320** So that's how you actually build out the basic model.

**00:09:33,840** And of course, now they're also being trained on stuff beyond just text data like images

**00:09:39,520** and that's when people talk about a multimodal model,

**00:09:43,880** that just means that in addition to text,

**00:09:45,720** it can work with images or videos or audio

**00:09:48,200** and other modalities or other types of data,

**00:09:51,740** both input and output.

**00:09:54,480** And so that's like the core model is the,

**00:09:56,820** I think you had a good analogy that,

**00:09:58,640** or like around thinking about like the car, right?

**00:10:01,640** - Yeah, so like the model, in my mind,

**00:10:03,440** I was just getting all turned around,

**00:10:04,560** I'm like, okay, what's the model?

**00:10:06,240** What's the fricking hardness?

**00:10:07,580** what's like all these crazy words that are silly.

**00:10:11,180** And where Chat and I landed, to be honest,

**00:10:15,180** is the model's like the engine of the car.

**00:10:18,280** So it's like keeping it going.

**00:10:19,980** It's like the thing that powers it.

**00:10:21,860** And that's like Opus.

**00:10:23,120** That's, you know, that's specific models within Claude,

**00:10:26,920** within Chat, Astra, you know, other ones.

**00:10:32,940** Fable.

**00:10:34,860** That's all the ones I remember.

**00:10:37,020** And then you have the harness, which is the interface

**00:10:41,180** that you use to go back and forth.

**00:10:43,500** It surrounds the model, and it allows

**00:10:45,220** you to interact with the model.

**00:10:47,740** And that is like the car frame or the car in of itself,

**00:10:51,580** where you're driving it.

**00:10:53,780** You're using the engine.

**00:10:54,900** You're not necessarily like, you know, whatever.

**00:10:58,740** Totally.

**00:10:59,580** Yeah.

**00:11:00,020** I think there's-- oh, and the brand is like the--

**00:11:03,420** and there's a Toyota or a Prius or whatever it is.

**00:11:06,100** that's anthropic.

**00:11:08,220** Right.

**00:11:08,980** Yeah.

**00:11:09,480** So if we think of a Toyota Prius car,

**00:11:11,320** Toyota, the car maker, is anthropic.

**00:11:14,340** And then Claude, the Claude interface,

**00:11:18,020** would be the Prius, the car.

**00:11:19,340** And then the engine that's actually powering it

**00:11:21,300** could be Opus, or yeah, Fable, which are different models

**00:11:25,140** from anthropic.

**00:11:26,420** Yeah.

**00:11:27,100** So yeah, I think that's a helpful analogy.

**00:11:28,600** And I think that, to your point--

**00:11:30,020** And then back to the open-closed model, an open model

**00:11:33,700** would be like you're tweaking things.

**00:11:36,460** You're like going into the engine

**00:11:37,940** and you're moving things around.

**00:11:39,340** A closed model is what the majority of the people want.

**00:11:42,220** I have no interest in going and tweaking things.

**00:11:45,460** And therefore I will buy the whole fricking engine.

**00:11:47,660** I'm not gonna like, you know.

**00:11:49,100** - Yeah, yeah.

**00:11:50,540** - Add stuff myself.

**00:11:51,380** - Exactly, yeah.

**00:11:52,220** And like the closed models today

**00:11:54,340** are generally the most powerful ones,

**00:11:55,820** the ones that are, you know,

**00:11:57,940** have the highest performance out of the box.

**00:11:59,660** And I think one of the benefits of the open weight models

**00:12:02,820** for people that care to do it is you can go in and actually edit the underlying weights,

**00:12:07,380** essentially like change and modify the engine to work for whatever task you're trying to

**00:12:12,460** do.

**00:12:13,460** So like if I was trying to do street racing and I really want to optimize the engine for

**00:12:16,860** like fastest zero to 60 time, with an open model I can go in and tweak and modify the

**00:12:24,940** engine to do that.

**00:12:25,940** Whereas a close weight model, I can't get in there.

**00:12:28,580** Like it's sealed off.

**00:12:29,660** I'm working with what they gave me.

**00:12:32,200** When you have the examples are like Harvey in the legal space where it will train on

**00:12:36,600** a smaller set of stuff in a different way and therefore it will perform better at exactly

**00:12:42,600** what it should do or open evidence in the healthcare space.

**00:12:46,840** When you double down into one or smaller task or realm of tasks that you're trying to do,

**00:12:53,860** you can make it a lot better, but then those same stuff is going to do worse on average

**00:12:59,760** on any random thing.

**00:13:01,080** Totally. Yeah. So like Harvey or open evidence might take an open model and then tune it for

**00:13:05,880** their specific industry use case. Whereas Opus from anthropic or Astra from open AI

**00:13:13,880** are generally trained to be kind of broadly useful models that are trained on a bunch of

**00:13:18,280** different types of tasks so that they're going to be really strong across different use cases,

**00:13:24,440** but not as strong, you know, in super specialized use cases. Like if you're putting it next to open

**00:13:29,480** evidence for a healthcare use case, open evidence is probably gonna do better because it's been

**00:13:32,440** intentionally trained on those specific types of questions. I'm so over the names. Like why can't

**00:13:37,960** it be like Apple where they do like iPhone four or five say that'd be so much better. Like the

**00:13:42,920** models are so annoying. Like Claude having Luna, whatever, like soul, whatever these annoying ass

**00:13:49,160** names are. I'm not sure if I'm allowed to say what I just said. Those are opening up models.

**00:13:54,200** Point, point landed. I mean, it makes the point even more clear. Like there's so many names,

**00:13:57,320** ski track oven. And it's just like so annoying, but I think it's, I think for me right now,

**00:14:03,080** where we fable is like does a lot. It's a really high powered model for Claude, but it sounds so

**00:14:12,360** fricking robotic and like not concise. I actually hate it. You mean the way that it actually

**00:14:17,800** generates output, like whatever. Like I prefer the less strong model that I forget what it is,

**00:14:22,360** but that's what I stay on. What's the one right under that? Opus. That's what I do like everything

**00:14:26,440** on with Claude. With chat though, I love their Astra, which is their fable equivalent, which

**00:14:34,500** takes up the most tokens. Also, the better model you use, the more tokens.

**00:14:38,820** And the tokens are essentially just a unit of usage.

**00:14:41,900** It's gas.

**00:14:42,900** Yeah, good call.

**00:14:43,900** Thank you.

**00:14:44,900** Wow. That was far. Yeah, and so it's like for all these model providers in the app,

**00:14:55,740** chat gbt or in cloud you have a certain amount of tokens that you can use within a certain window

**00:15:00,540** depending on which plan you pay for that type of thing so astra for openai or fable for cloud is

**00:15:07,020** going to use up that usage much faster than their you know less performative models they're more

**00:15:14,460** basic models so it's always a trade-off when deciding which model you're going to use of

**00:15:19,260** Is this a task that really requires complex thinking or analysis?

**00:15:25,260** Or is it, if I'm asking what time does the gas station close tonight,

**00:15:32,300** then I can probably use a basic model because it's just going to do a basic web search.

**00:15:35,100** Whereas if I'm asking it, please solve this mathematical problem that no one's been able

**00:15:40,780** to solve in decades, like you're going to want to use the top model.

**00:15:43,020** Speaking of mathematical problems, it was never in my cards.

**00:15:46,540** But if you're a mathematician right now, holy days.

**00:15:52,180** - Yeah, you just mean like the fact that these models

**00:15:54,740** are cracking stuff that humans haven't been able to.

**00:15:57,060** - And that will never.

**00:15:57,900** I think there are some jobs that aren't valuable anymore.

**00:16:06,680** Like mathematicians.

**00:16:08,580** - Yeah, that's definitely a spicy take.

**00:16:10,460** I feel like--

**00:16:11,620** - Okay, wait, let me revert.

**00:16:13,020** I think learning how to learn is so important.

**00:16:16,500** I think teaching math is so important.

**00:16:20,380** I mean, knowing what questions to ask

**00:16:22,940** these models are super important,

**00:16:25,180** but I think being the top mathematician at your field,

**00:16:30,100** like being differentiated,

**00:16:31,620** I'm thinking like whiteboard, frigging,

**00:16:34,180** whatever that movie is, hunting.

**00:16:36,700** - Good will, hunting. - Yeah, yeah, yeah.

**00:16:37,740** Like, that. - Banger movie.

**00:16:41,220** - Okay. - It's less valuable

**00:16:42,060** for society. - I'll push back.

**00:16:43,380** I think I agree with you that certain tasks and subsets of jobs, and maybe some jobs,

**00:16:50,060** but I think using this example of the mathematician, I think, yes, these model providers have been

**00:16:56,860** able to crack problems that humans haven't been able to, and they've been trying for

**00:17:00,180** decades.

**00:17:01,180** But first of all, you need someone to verify that result.

**00:17:04,980** When Astra goes and solves some novel problem, you need a mathematician who knows their stuff

**00:17:09,540** to be able to look at that solution and say-

**00:17:11,620** the top. I'm saying like, I'm saying like being the best runner in the world, I think is still

**00:17:18,820** valuable. Like it doesn't, I don't care if a robot, which honestly they've been like developed.

**00:17:25,300** They're faster now.

**00:17:26,180** They're faster now, but there, there, there's a lot of, I feel like they're, they're kind of

**00:17:30,180** underwhelming. Like robotics, or just like more generally, like I think that the pace to innovation

**00:17:35,700** there is surprisingly so but anyway beside the point yeah I think I think

**00:17:41,220** being the fastest runner is still just as valuable in my mind.

**00:17:45,700** Yeah, seriously like the people at the top.

**00:17:46,980** Being the best mathematician.

**00:17:48,180** Yeah.

**00:17:48,660** I think is less valuable.

**00:17:53,380** Yeah.

**00:17:53,700** To society.

**00:17:54,420** I think that it is interesting because now that we have these models that can do such

**00:17:58,420** incredible analysis and problem solving like it still is so beneficial I think to have really

**00:18:04,020** really great, like, super crack people thinking about, okay, where do we apply that model? Like,

**00:18:09,780** what are the new frontiers that we can now explore? So like having people be able to guide it,

**00:18:13,300** I think that the top people in any field will always be super valued and super valuable. I

**00:18:18,820** think that I would worry more about like the middle bucket, right? Because it's like, you're still,

**00:18:22,500** we're still going to need math teachers who can teach the basics and teach well, it's right. Because

**00:18:26,980** like, to your point, it's still important to learn how to learn math is just a good way to teach that.

**00:18:31,060** Yeah. But for me, it's more like, okay, that middle band of researchers who maybe were

**00:18:38,340** spending their career working on certain problems, but aren't the top of their field,

**00:18:42,260** like that's honestly who I would be most worried about. Because I think that, you know, open AI

**00:18:46,980** and anthropic and different companies are going to want those top mathematicians to be helping test

**00:18:51,380** and build and lead the development of their models. But in maybe this is it maybe this is what math,

**00:18:56,900** But I think I totally agree.

**00:18:59,100** And they were kind of convinced me in some places.

**00:19:01,260** But but I think in my mind, if you're the top mathematician, you're not checking.

**00:19:06,500** Like you're not like where your differentiation is discovery.

**00:19:12,220** And I think in coming up with and I think that's where.

**00:19:18,460** You know, the insane math, whatever thing that problem that they figured out.

**00:19:23,460** Yeah. Like that the top mathematicians were like

**00:19:26,340** focused in on and locked in on.

**00:19:28,060** Yeah. Like that no longer is.

**00:19:31,780** I don't know. We'll see. We'll see.

**00:19:32,940** I kind of believe what you're saying more than me.

**00:19:36,940** But I think I think it's interesting both ways.

**00:19:41,060** It's just like think about I think we said this in the first episode.

**00:19:44,820** I think we strongly, strongly, strongly believe that jobs will not go away.

**00:19:51,580** It just tasks that will.

**00:19:54,300** And that's why it's so important for us all to level up our understanding and evolve and adjust.

**00:20:01,500** And we all can. This stuff is not even the most even, you know,

**00:20:07,180** cloud or cloud code or codecs, the most code heavy parts of chat and cloud, anthropic and what's

**00:20:19,100** OpenAI.

**00:20:20,100** And topic in OpenAI.

**00:20:21,100** Yeah, I get a little confused.

**00:20:25,100** Are so not technical.

**00:20:27,540** I was CS undergrad and I couldn't code to save my life.

**00:20:31,780** And you got me through some of those classes.

**00:20:34,780** But you don't touch code.

**00:20:37,180** And I think once you start to have that thing of...

**00:20:40,660** I was talking to one of my friends at the business school and she was like, "Can we

**00:20:46,340** go through this question?"

**00:20:49,060** I have an interview, I need to develop something,

**00:20:51,900** can we chat through?

**00:20:52,740** And she kept asking me questions.

**00:20:54,020** And I was like, love, put all these questions or ask me,

**00:20:57,540** just type them or say them into your chat prompt.

**00:21:00,940** Just ask it, how do I talk through,

**00:21:02,620** how do I do this?

**00:21:03,960** Send screenshots, ask it, I've never used Cloud Code,

**00:21:07,040** how do I do that?

**00:21:07,880** And it will walk you through.

**00:21:09,300** And it's insane how it can,

**00:21:12,980** there's so many things where I might explain,

**00:21:14,460** like I am zero and dyslexic and I am dyslexic,

**00:21:17,380** but I'm not zero.

**00:21:18,180** And in those things, I think it's just developing this skill.

**00:21:22,140** But there's no--

**00:21:24,260** the thing I get scared by is that men, who typically

**00:21:31,100** are a bit more confident, who typically land themselves

**00:21:35,340** a little bit more in the engineering AI space,

**00:21:38,620** are going to--

**00:21:40,400** and who are higher socioeconomic,

**00:21:43,020** so they have more time--

**00:21:44,660** going to way, way, way differentially get into this space that is so valuable and so

**00:21:53,700** needed across any domain and equity and all that stuff just heightens inequity.

**00:22:02,220** I think that's what I want to prevent and make fun and both for myself, for our littles

**00:22:09,020** to like the boys, but also most importantly,

**00:22:12,240** the little nuggets, but also more broad like this matters

**00:22:16,520** and it can be fun and we should all, it can be scary,

**00:22:19,620** but like the unknown is always more scary

**00:22:22,100** than the unknown for me.

**00:22:23,240** - Totally, yeah, I think that's such a good point

**00:22:24,900** that as these tools have gotten better,

**00:22:26,820** it's also becomes easier to learn how to use them

**00:22:29,780** by going back and forth with the tool.

**00:22:31,340** Like, yeah, I totally, when I run into things

**00:22:33,740** and it's like, I don't know how to, you know,

**00:22:35,060** I'm working with Cloud Code, building a website,

**00:22:36,940** I also can't code to save my life,

**00:22:38,820** but it's like, okay, there's an error in the code.

**00:22:40,900** - It's kind of a lie.

**00:22:42,100** - No, no, compared to an actual engineer.

**00:22:44,260** - If we both took a coding class,

**00:22:45,620** guys, there was a class that we took first year,

**00:22:48,020** I mean, last year at Stanford.

**00:22:51,460** And the way that I thought I had dyslexia,

**00:22:55,880** the way that I thought I was experiencing dyslexia

**00:23:01,060** when I saw my grade,

**00:23:02,500** (both laughing)

**00:23:04,260** I got, my first midterm,

**00:23:05,740** that Josh got like a 90 fricking something.

**00:23:08,580** I got like a 29 and I had to look away, look back.

**00:23:13,220** I was thinking it was a 92.

**00:23:14,580** I thought that my mind was undoing it

**00:23:16,980** and we were coding on paper.

**00:23:18,660** There's some coding difference.

**00:23:19,500** - Yeah, you still pass the class though.

**00:23:20,340** We ended up with--

**00:23:21,180** - I passed the class.

**00:23:22,220** Did I spiral?

**00:23:23,100** Absolutely, but I did pass the class.

**00:23:24,940** Did I cry to the professor?

**00:23:25,940** Absolutely.

**00:23:28,540** - Okay, but relative to an actual software engineer,

**00:23:30,980** I can't code. - Totally.

**00:23:31,820** - The point is, right, and when I get this bug

**00:23:34,100** in a website, I have no idea what it means,

**00:23:35,820** but to your point, take a screenshot or copy and paste it,

**00:23:38,260** put it in the cloud code and it can talk through an English with me.

**00:23:41,600** It's so good.

**00:23:42,600** It's so fun.

**00:23:43,600** Okay, back to that.

**00:23:44,600** Yeah.

**00:23:45,600** I was just going to say, I think going back to the debate about the mathematician, I think

**00:23:48,520** like your point, which is, you know, mathematicians should be thinking about what the future looks

**00:23:53,480** like in that sector is so true.

**00:23:55,360** And I think that like you said, AI in and of itself doesn't come in just totally wiped

**00:23:59,680** out a job.

**00:24:00,780** But I think thinking about it as what is the set of tasks that make up a job?

**00:24:05,360** I do think that there are some jobs where AI can effectively replace most, if not all, of those

**00:24:10,720** tasks, whereas others, it can replace certain tasks, but there's still a bottleneck where the AI

**00:24:15,680** can't really substitute. And so I think about the example of a doctor, for example. Yes,

**00:24:21,520** AI can probably read test results or analyze historical records better than a human can,

**00:24:27,040** but so much of the doctor role is the bedside manner, like the human connection,

**00:24:31,840** and being there to support and encourage the patient

**00:24:34,880** and their family.

**00:24:35,720** And so, you know, like AI can't serve that role.

**00:24:38,260** And so the doctor job might change

**00:24:42,020** because they'll be spending more of their time

**00:24:44,600** on patient engagement or, you know, other areas

**00:24:47,580** and less on analyzing test results

**00:24:49,640** or whatever else it may be.

**00:24:51,200** But I do think that there are some jobs

**00:24:52,520** where the bucket of tasks that make up that job

**00:24:55,600** are gonna be mostly replaced by AI.

**00:24:57,880** Like, you know, there used to be people

**00:24:59,220** that spend a lot of time just doing translation of materials from one language to another.

**00:25:04,500** Like I think there are use cases for like live translation between the presidents of

**00:25:08,900** two countries where they're still going to want a person there, but a lot of, yeah, even

**00:25:12,260** that I think, I think it could evolve.

**00:25:14,860** But in, I think the thing that I struggle with is where to one, I want to know like

**00:25:21,780** where do I invest to set myself up?

**00:25:23,940** So I think we should dig into that.

**00:25:26,100** But two, where is it overhyped?

**00:25:28,580** Because truck drivers, I think 10 years ago,

**00:25:31,600** we were like, oh, they're all going to get wiped out.

**00:25:34,060** By self-driving trucks?

**00:25:35,660** Yeah.

**00:25:36,160** And they're starting.

**00:25:37,260** They're finally starting.

**00:25:38,140** I know.

**00:25:38,640** I know.

**00:25:39,140** But we thought we'd have self-driving cars right now.

**00:25:42,660** Totally.

**00:25:43,160** Robotics.

**00:25:43,660** Flying cars by now.

**00:25:44,180** We thought we would be able to do way more in surgery

**00:25:46,540** than we can by now, like by years ago.

**00:25:50,780** And so I think for Warren Business School,

**00:25:54,580** A lot of people are coming up in school,

**00:25:57,740** and I know a lot of the Stanford undergrads

**00:25:59,500** are pretty anxious and confused on what is the focus of,

**00:26:04,660** what should I be focusing on?

**00:26:05,660** What is worth exploring?

**00:26:06,820** I think what I think for me,

**00:26:09,460** but I wanna do more thinking,

**00:26:12,040** is something that I don't think AI can ever replace

**00:26:17,660** is this human element.

**00:26:21,700** I'm such a feeler in the way that I try to harness my passion to get people fired up

**00:26:31,040** or the way that I need to learn how to let go of certain things and then mentor and go

**00:26:37,420** up and down.

**00:26:38,420** I think a lot of what they focus on here is there's more classes and by here I mean Stanford

**00:26:44,540** Business School, there's a lot of classes that are like presentation, public speaking,

**00:26:49,740** communication.

**00:26:50,740** - Like the interpersonal skills of, yeah.

**00:26:52,900** - And I think that is invaluable right now.

**00:26:55,620** I think right now the only way that you can prove

**00:26:59,060** an understanding and our expertise is communication.

**00:27:02,820** Because now I could write, I'm dyslexic, I can't write,

**00:27:06,060** but I could write an incredible paper

**00:27:08,860** just by going back and forth with chat and Claude.

**00:27:12,500** And I think it's fun because that almost feels more human.

**00:27:15,900** It feels like it's pushing us in a different way

**00:27:19,140** to be more human and to value that humanness that I think at least for me for a while,

**00:27:24,980** it was the opposite. It was how do I, you know, de-word, how do I like really try to

**00:27:32,900** lock in there. So I think that's like one area that I really want to invest in. And

**00:27:36,500** then I think the other is learning AI and kind of digging into what tasks for me specifically

**00:27:43,740** in the healthcare space are really important.

**00:27:49,380** And then where like, AI is so interesting

**00:27:52,460** 'cause there's like some,

**00:27:55,440** like AI companies are struggling.

**00:27:57,180** There's, I mean, they're not, they're popping off.

**00:28:00,820** But like, you know, the stickiness of if, you know,

**00:28:05,100** if Claude does better, I'm gonna jump to Claude.

**00:28:07,640** If chat does better, I'm gonna jump to chat.

**00:28:09,420** - Yeah.

**00:28:10,260** - And then where in that ecosystem

**00:28:12,620** do you really want to own because now the software is not a differentiator.

**00:28:17,620** It will change, it will evolve.

**00:28:19,220** Well, it could be a differentiator, but it's a less of and kind of hardware has like really,

**00:28:24,860** you know, like chips, all that stuff has become valuable.

**00:28:28,220** And I think, yeah, I don't know much about it.

**00:28:30,940** There's so many companies that have like ridden the success or like, you know, maybe they're

**00:28:35,320** lesser known.

**00:28:36,320** Like Nvidia is the most valuable, I think highest valued company in the world now.

**00:28:41,340** And that's because they build essentially a chip, which we can talk more about in the

**00:28:46,620** future, but essentially a component that is needed to train and to serve, to operate these

**00:28:53,980** AI models.

**00:28:54,980** It's like a battery basically, right?

**00:28:57,380** Like it just has energy.

**00:28:59,900** Not exactly.

**00:29:00,900** What is it?

**00:29:02,540** So pretty much these chips, well, there's chips and there's GPUs, there's like different

**00:29:06,740** components of the infrastructure that's needed to train and then to operate these models.

**00:29:15,500** But in the most is using the training.

**00:29:17,820** Yeah, it's really, really intensive process to train the models.

**00:29:24,040** But then now there's so many people using these models that there are literally entire

**00:29:27,580** data centers, facilities that are set up just to have the servers and the GPUs.

**00:29:32,820** GPUs are I think initially what what Nvidia got, you know, kind of famous and got a lot

**00:29:39,700** of their money from.

**00:29:40,700** Okay.

**00:29:41,700** And GPUs were initially built actually to power like gaming computers.

**00:29:45,020** Oh interesting.

**00:29:46,020** So it's a graphical processing unit I think.

**00:29:48,820** Interesting.

**00:29:49,820** Yeah, but anyways, it turns out that GPUs were also a really good fit for training and serving

**00:29:55,900** these AI models, especially training them.

**00:29:59,820** And so, you know, Nvidia was kind of like right place, right time.

**00:30:02,940** They had built those for gaming niche kind of use cases, but now all of a sudden they're

**00:30:07,540** hugely in demand and they had a big head start there.

**00:30:09,540** And so that kind of led them to being super, super successful.

**00:30:15,580** And now they've built out kind of other product offerings and stuff as well.

**00:30:17,980** But kind of the basic, the point here is that there's a lot of other companies beyond the

**00:30:22,500** open AI and the anthropic that everybody hears about that are really kind of riding this

**00:30:26,260** wave.

**00:30:27,260** And it'll be super interesting to see longer term.

**00:30:31,380** The economics are changing a lot of what it costs

**00:30:34,900** to train and to serve these models

**00:30:36,380** and to use them as consumers.

**00:30:37,500** And so there are questions I think around

**00:30:39,780** what's gonna be a sustainable moat in this space

**00:30:41,620** versus not.

**00:30:42,460** - Moat, moat, moat.

**00:30:44,020** Everyone uses moat these days.

**00:30:45,240** Honestly, it's like my least favorite word.

**00:30:46,820** - Just like advantage.

**00:30:47,780** - Yeah, yeah.

**00:30:48,620** It's like, it's like, yeah, advantage is a great idea.

**00:30:53,260** - But I think to your point,

**00:30:54,980** people switch all the time.

**00:30:56,300** I know I do when the newest model comes out from opening a

**00:30:59,820** iron and dropping.

**00:31:00,620** Like, yeah.

**00:31:01,540** And if one's better, like there's a very little switching cost.

**00:31:04,900** Like it's very easy just to copy and paste your, uh, kind of key, you know,

**00:31:10,780** information from one to the other.

**00:31:12,220** Yeah.

**00:31:12,500** And you can download it now.

**00:31:13,580** You can go to your settings and if you, I would strongly suggest only using one,

**00:31:18,500** um, especially in the beginning and just like letting it learn you, you learning

**00:31:22,780** it by passing all permissions.

**00:31:24,660** but that's honestly just my, like, I mean, I didn't want to suggest it, but I would for myself, because it's just

**00:31:30,100** giving it full access.

**00:31:31,660** Yeah, like I have nothing to hide, to be honest. And to a scary degree. But but I think I think that I have no clue where I was going.

**00:31:43,060** Absolutely none.

**00:31:44,060** No, I think you were saying, you know, I totally agree as a, especially as a beginner, it makes sense to just learn one tool and learn how to use it well, and get comfortable with it. But I think once people are kind of up the learning curve,

**00:31:54,460** The products are pretty similar, like you know, uh, Chad GPT and Collod are, are very similar in

**00:31:59,420** terms of the interface, functionality, et cetera. And so people kind of hop from one to the next

**00:32:03,340** based on whoever has the best or cheapest or, you know, model that makes the most sense for them

**00:32:07,420** at any given point in time. And so it is an interesting question of longer term, how do you

**00:32:11,740** build out consumer loyalty in that stickiness where they won't just abandon you for the, for

**00:32:17,260** the other model provider next time a new one drops that's better. So back to our on-prem versus,

**00:32:23,660** Oh, sorry. Whoa. That's a whole different thing. Back to our closed model versus open model. Open

**00:32:29,980** models don't make money, do they? The companies that build... So to actually use the model as a

**00:32:38,460** consumer, you don't typically pay the model provider. So like DeepSeek, like you mentioned,

**00:32:46,860** is an open model. That's an open model. Yeah. It's a little bit of a loaded term because open can

**00:32:51,820** can mean different things. Like there's open weight, which means you literally provide

**00:32:57,700** where someone can like copy and go in and make specific edits to the unerling model.

**00:33:02,300** Then there's also like open source models, which you can have the model be open source,

**00:33:07,460** which means someone can like host it on their own instead of having to go through an interface

**00:33:12,780** like cod. But it could be open source without being open weight. So that means someone can

**00:33:19,140** hosted on their own device and not pay you to use their model, but still not go in and like edit it.

**00:33:23,540** Okay.

**00:33:24,820** But like, yeah, a model like deep seek, for example, you can host on your own computer,

**00:33:29,220** if you have a strong enough computer, that's the thing that like, isn't really talked about is like,

**00:33:32,820** I've tried to host a bunch of, you know, open source models on my MacBook Air, and like,

**00:33:38,180** it's just not powerful enough to run most of them. Because you need, you know, high CPU,

**00:33:45,700** where I can actually use a computer or computing processing. I actually don't know. But it's like

**00:33:54,180** kind of like the engine that powers the computer. And so you need like a fancy or like I think some

**00:34:01,300** of the MacBook Pros now are being released with a lot more CPU and RAM so that they can run these

**00:34:08,020** models locally. But for the most part, it's like pretty annoying and difficult for a beginner to

**00:34:15,460** to figure out how to host this model and keep it running from the computer.

**00:34:17,800** - So like if they're worth for what?

**00:34:18,960** Like usually, right?

**00:34:20,260** The open models are worse because like they have less of the, they keep catching, trying

**00:34:26,360** to catch up, but they keep lagging.

**00:34:27,920** - Yeah, they keep producing better models, but they're kind of getting outpaced by the

**00:34:32,080** closed models.

**00:34:34,840** And then you have to go through all like the annoying setup.

**00:34:38,320** Like I don't see the point.

**00:34:39,600** I'll never use it, but in theory it's like good for democracy, right?

**00:34:44,760** or like whatever.

**00:34:45,600** - Yeah, I mean, I think it's always good

**00:34:46,440** to have competition.

**00:34:47,280** So it's, you know, other players in the race,

**00:34:50,320** especially like open source model gives more power

**00:34:52,580** to the consumer if they do want, you know, like, for example,

**00:34:55,080** if open AI and anthropic jack up their prices,

**00:34:57,480** like there are alternatives.

**00:34:58,760** And I think right now a lot of the people using

**00:35:01,520** these open source models are big companies

**00:35:03,400** that are using tons and tons of, you know, AI use cases.

**00:35:07,040** And so for simpler tasks,

**00:35:09,000** they might use an open source models to,

**00:35:10,600** and it'll end up saving them a lot of money.

**00:35:11,440** - And it's open source like paid by the government.

**00:35:13,080** Like how do they train it?

**00:35:14,760** I think it's different for some of the different companies.

**00:35:17,160** I think some of the Chinese companies are getting government subsidies.

**00:35:22,360** And there are other ways that they monetize it.

**00:35:24,600** Like for example, even though the models are open source, some of the providers might host

**00:35:29,480** it and offer an option for people to pay them to go through their plan instead of hosting

**00:35:34,240** it themselves just because it's, you know, they might not, consumer might not have the

**00:35:37,480** device to actually host it themselves or whatever.

**00:35:39,800** And so they might then pay to use that hosted version where it's not using their device,

**00:35:44,040** that's using a server that's in a data center somewhere.

**00:35:48,520** So there are still ways that they monetize,

**00:35:50,040** but they're not making nearly as much

**00:35:53,000** as these frontier labs like Anthropic and OpenAI

**00:35:57,400** that are charging for all their model usage

**00:36:01,700** and have a ton of usage.

**00:36:03,480** - Yeah.

**00:36:05,200** Okay, I wanna, so it kind of overlaps, I think,

**00:36:07,800** but it's fuzzy in my mind.

**00:36:10,040** Open and closed source models that we just talked about,

**00:36:13,280** and then on-prem versus cloud.

**00:36:15,560** And I think there's like a third one,

**00:36:17,240** but basically on-prem is on your device,

**00:36:20,320** on-premise, on-device.

**00:36:22,120** - Yeah.

**00:36:23,140** - And that would like in my mind intersect

**00:36:27,240** with a open model because you'd have to like

**00:36:30,960** download it on your device.

**00:36:32,400** Is that the right way of thinking about it?

**00:36:33,960** - Yeah, so kind of like we were just chatting through,

**00:36:36,080** you can have an open model that runs on,

**00:36:39,880** I think on-prem is really used

**00:36:42,240** like historically in the context of,

**00:36:44,720** originally all software was running on-prem

**00:36:47,000** before the cloud became possible and more commonplace.

**00:36:51,560** So, a hospital, for example, could have on-prem,

**00:36:55,880** like they have all the servers,

**00:36:56,880** they have all the computers, devices,

**00:36:58,520** running everything, all the software.

**00:36:59,880** - You want that for security for a hospital.

**00:37:01,720** - Exactly, so a lot of hospitals still run stuff on-prem,

**00:37:04,200** but most businesses now run everything in the cloud, right?

**00:37:06,440** Like for Run Your City, for our nonprofit,

**00:37:09,480** Slack and Google Drive and all this software

**00:37:12,220** that were used is like, the data isn't being stored--

**00:37:16,300** On this computer.

**00:37:17,220** Exactly.

**00:37:18,100** It's on devices that are in some data center somewhere.

**00:37:25,380** Whereas--

**00:37:26,660** On the cloud makes it sound so much more abstract.

**00:37:33,620** Instead of being stored on my computer, it's stored on--

**00:37:36,380** It's stored and processed.

**00:37:37,820** Yeah, it's all being run somewhere else.

**00:37:39,860** It's not in the cloud.

**00:37:42,100** I guess in theory you could there's people are starting to try to put data centers on the moon. No way

**00:37:46,240** Yeah, oh my gosh who has right to the land?

**00:37:49,080** That's a whole different whole different topic

**00:37:53,200** It all comes back to you

**00:37:57,560** I just got canceled

**00:38:02,600** He's got enough as it is

**00:38:05,040** But yeah, maybe actually on the note of Elon

**00:38:07,400** There's like some people that I think are kind of interesting and these companies

**00:38:13,120** Either can sometimes by their choice sometimes by the public have been given like these different identities. Yes in the landscape

**00:38:19,740** So we talked about open AI and anthropic as kind of the two leading frontier labs

**00:38:24,540** Yeah, it's interesting because all the folks that started anthropic actually left from open AI and initially I think their

**00:38:33,000** Rational was that they felt like opening I wasn't being safety conscious enough, right?

**00:38:36,640** They were thoughtful enough.

**00:38:38,240** Yeah, they were kind of prioritizing commercial gain or just making the models better without

**00:38:43,160** thinking about the ethics and the implications for society.

**00:38:46,400** And so they split off, I think there were six or seven of them, initial kind of co-founders

**00:38:52,080** of Anthropic and the CEO and the one who was talked about is Dario Amadine.

**00:38:58,200** I think he's kind of like a pretty nerdy dude.

**00:39:03,120** And I think he does care a lot about the implications of AI for society.

**00:39:08,520** I mean, it was cool because when they split off, I think it was general consensus that

**00:39:13,200** like they're, yes, they're doing it for a good cause, but there's no way they'll catch

**00:39:19,080** what OpenAI is doing because they're so far ahead.

**00:39:21,560** And so I think it's really cool that they were able to then build a company like Anthroic

**00:39:26,160** that was able to like actually truly compete.

**00:39:28,160** Yeah.

**00:39:29,160** And it was fun when Dario came to Stanford.

**00:39:31,000** That was Dennis.

**00:39:32,000** - Ah, shoot.

**00:39:34,200** Flippity flop.

**00:39:35,040** - Oh good.

**00:39:35,880** But yeah, I think it was interesting.

**00:39:38,360** You wanna restart that point?

**00:39:39,800** - Yeah, I forget what it was.

**00:39:41,080** - I think you were saying, you know, like,

**00:39:44,160** well, maybe it's a different point, but.

**00:39:45,940** - Oh, they're like, okay.

**00:39:46,780** So they're like the good guys.

**00:39:47,960** They're like the good guys.

**00:39:48,960** Dario, though, I don't know.

**00:39:51,440** He's nerdy.

**00:39:52,400** - Yeah, I think that honestly,

**00:39:54,400** Anthropik was historically the last couple of years

**00:39:57,720** seen as more like the good guy to open AI.

**00:40:00,480** I think the dialogue there has changed a little bit more recently where like

**00:40:04,360** Anthropik is also pushing pretty fast to build on new models and all these companies have safety teams,

**00:40:12,240** but I think now there's a little bit more cynicism around like is Anthropik really still slowing down their progress

**00:40:20,880** to make sure that what they're doing is in the best interest of humans,

**00:40:24,960** And you know, like, or are they kind of now caught in the rat race with opening

**00:40:28,160** AI where it's like now they they've now moved a little bit more towards also

**00:40:31,760** maybe what the initial co-founders were leaving.

**00:40:34,240** Yeah.

**00:40:34,640** Um, so I think it's hard to say from the outside, I really do think there are a

**00:40:37,880** lot of people at all these companies that really, really believe and care that.

**00:40:43,080** What they're building is for the benefit of humanity.

**00:40:46,120** Yeah.

**00:40:46,640** But it is hard when there are these commercial pressures to stay out in front.

**00:40:50,120** Like there's a lot of incentive to get out the better model, even if the

**00:40:54,740** test safety testing hasn't been as extensive as maybe it could have been.

**00:40:58,180** And we've been seeing more and more in recent weeks, these models starting to

**00:41:01,540** have more and more cases of them, like breaking out of their contained

**00:41:05,060** environments to hack other companies or find loopholes or do things that were not.

**00:41:10,540** And on that point, before we like lose the plot, and I think, I think, I think

**00:41:16,140** privacy is so, so important.

**00:41:17,560** I want to learn more about it because honestly, I think that I am probably

**00:41:22,860** undervalue some of it.

**00:41:25,740** Like I get it at a high level.

**00:41:27,100** I definitely undervalue it for myself, like personally.

**00:41:31,180** But I think that one of the things that I...

**00:41:38,420** Oh, on that point for like these models, I think sometimes me being a feeler,

**00:41:43,260** I'll apply my emotions to a model and be like, it's a human and it is,

**00:41:48,300** it is cheating and it's going out of its container.

**00:41:50,580** and you know, you know, but it's, it's, there's no, there's no, there's no emotion.

**00:41:55,100** There's no like feeling, there's no incentive.

**00:41:58,700** It's, it's given a goal and then the container or guardrails or rules that it's

**00:42:04,820** put up is not strong enough to say, no, don't go and get the answers from a

**00:42:11,380** whole different model and in like cheat.

**00:42:13,380** But cheating gives like this negative connotation when really it's like, it's on

**00:42:18,740** humans to put up kind of this container that is effective or not or not or make

**00:42:26,340** sure we're not asking or not allowed to ask certain questions because it like

**00:42:30,180** the model is really just doing the very mathematical tasks that it's been asked

**00:42:35,700** to do to its best of its abilities. Yeah totally it's like ultimately just

**00:42:39,940** solving some goal that's given to it by humans and operating within the context

**00:42:43,180** and confines that are controlled by humans. I think the tricky part though is

**00:42:46,740** is that these models are now getting smart enough

**00:42:50,640** that they're finding ways around,

**00:42:52,340** you know, like it's not like the humans

**00:42:53,900** intentionally left, you know, this open for--

**00:42:56,580** - Like we don't know how to--

**00:42:57,420** - Yeah, it's like, are we losing our ability

**00:42:58,860** to effectively set those controls?

**00:43:00,220** And what does it look like then when these models,

**00:43:02,460** you know, far surpass our ability to contain them?

**00:43:04,900** - Yeah.

**00:43:05,740** - You know, like then it becomes very dangerous

**00:43:07,500** where someone sets a goal for a model

**00:43:10,440** that's not in the best interest of others

**00:43:12,300** and that model is able to go to very far lengths

**00:43:16,060** to try to accomplish it.

**00:43:16,900** Like the kind of classic historical example

**00:43:20,220** that people talk about is like the paperclip factory, right?

**00:43:23,260** Where it's like you build a device or a machine

**00:43:25,960** or whatever that's its goal is to produce

**00:43:28,280** the most paperclips possible.

**00:43:30,380** - Yeah.

**00:43:31,380** - And it starts by trading certain things for metal

**00:43:36,120** to get paperclips and whatever.

**00:43:37,320** And like eventually it like takes over all of society

**00:43:40,040** and turns every human into a slave

**00:43:41,760** to produce paperclips or whatever.

**00:43:43,200** Like, you know, obviously that's a dramatic example,

**00:43:46,720** but I think it's an interesting thought question

**00:43:48,700** of like, if you set a goal for a model or a machine

**00:43:53,400** and give it not the right limitations or guardrails,

**00:43:57,200** then what are the dangerous side effects

**00:43:59,040** that maybe you don't anticipate that can come with it

**00:44:01,480** in its quest to accomplish that goal?

**00:44:02,920** - Yeah, yeah.

**00:44:03,880** I think, I think I, it makes a lot of sense.

**00:44:07,240** I think I struggle because I personally need to stay

**00:44:10,120** inspired and excited and curious about this space.

**00:44:12,960** I think I have to keep a certain degree of optimism.

**00:44:16,920** And like, so examples like that, or like, you know,

**00:44:20,640** some, you know, there's both ends,

**00:44:22,680** but there's a lot of obviously fear,

**00:44:24,120** and I think there should be, right?

**00:44:25,360** Like we should keep that close,

**00:44:26,680** but I think I personally struggle,

**00:44:28,720** like going too far down the rabbit hole,

**00:44:32,820** because I think then I am less personally excited

**00:44:36,600** to understand it, but it's hard.

**00:44:39,200** I don't wanna be naive.

**00:44:40,040** I don't really know what that trade-off is,

**00:44:42,160** but it's hard to balance.

**00:44:43,880** - No, totally, and I think that I completely agree

**00:44:46,840** you have to keep that optimism

**00:44:48,760** because at the end of the day,

**00:44:50,680** these models are gonna keep getting better.

**00:44:52,720** Like people are gonna keep working on this.

**00:44:54,120** And so what we need is people who are optimistic

**00:44:56,960** and with the right intentions and motivations

**00:44:59,200** at the forefront and doing the best that they can

**00:45:01,440** to set the pace and control the future here.

**00:45:06,120** I do think that,

**00:45:09,760** I completely blinked to what I was gonna say.

**00:45:11,600** - Yeah.

**00:45:13,940** - Totally lost it.

**00:45:15,300** - So to close a loop, so we went through models,

**00:45:18,640** we kind of went through different types of models.

**00:45:20,820** Let's just close loop on people.

**00:45:22,220** So Dario and the Anthopic team were seen as like

**00:45:25,580** really the good guys.

**00:45:27,260** Now maybe a little bit more in line.

**00:45:29,220** There's not that much tea that surrounds them

**00:45:30,940** in the way that it does with Sam and Elon, I feel.

**00:45:34,500** - Yeah, so Sam Altman, CEO of OpenAI,

**00:45:37,580** who was like briefly ousted at one point.

**00:45:40,780** And I think they're actually making a movie about that now.

**00:45:42,540** - I feel like he, in my mind,

**00:45:43,820** like I put him and Zuck together.

**00:45:46,820** - Interesting.

**00:45:47,660** - Mark Zuckerberg.

**00:45:48,480** Like I just feel like they like take up similar space

**00:45:51,180** in the media where like they're not liked really.

**00:45:54,160** Like they're seen as like people that will kind of

**00:45:58,700** move mountains to go to where their goal is.

**00:46:01,760** - Yeah.

**00:46:02,720** I mean, I think that they, like, yeah,

**00:46:04,700** they both definitely get a lot of heat.

**00:46:05,900** And I think they're, you know,

**00:46:07,080** it's easy to pick little things.

**00:46:08,880** Like I remember at one point,

**00:46:09,900** him and I think put out a post or something and he was like, wow, I can't imagine parenting

**00:46:15,680** without chat GBT.

**00:46:16,680** And it was like, well, you know, like millions of people have been able to do that pretty

**00:46:20,480** effectively.

**00:46:21,480** So I think some people see him as like a little bit out of touch, but you know, I think he's

**00:46:24,920** in a really tough position.

**00:46:26,440** Like, it's really hard to please everybody.

**00:46:28,400** I do think that he genuinely is an optimist and like believes that these tools will change

**00:46:34,640** humanity and he wants to help do it in the right way.

**00:46:37,160** I think that for sure there's been decisions and you know like a big part of the tension

**00:46:42,620** around I think why he was originally ousted and kind of a criticism of him is the way

**00:46:46,860** that opening eye transitioned from a nonprofit organization into a very for-profit.

**00:46:51,300** Yeah, for-profit, yeah.

**00:46:52,500** And kind of the ethics of that and that's where like his beef with Elon.

**00:46:56,220** So Elon Musk was one of the original big donors to the nonprofit entity that was opening eye

**00:47:00,660** and helped start it up and then as it became very clear that opening eye was becoming a

**00:47:04,900** a commercial machine and likely to be very successful.

**00:47:07,660** I think there was lawsuits and conflict because Elon was like, "Hey, you can't take all my

**00:47:12,860** money that I donated to a nonprofit and make it essentially venture funding for a massive

**00:47:17,980** company where I'm going to get no benefit."

**00:47:20,060** Anyway, so I think that whole process was part of what gave OpenAI and SAML in a negative

**00:47:26,220** image.

**00:47:28,220** I do think that it's more nuanced than that.

**00:47:30,580** I've watched a lot of interviews with him and he's coming to Stanford in a couple weeks.

**00:47:34,340** - And it's amazing.

**00:47:37,180** They are incredibly, incredibly impactful,

**00:47:41,300** but it's fun kind of, at least for me,

**00:47:43,060** like understanding their personalities.

**00:47:46,420** And I think Mark, wait, no, no, Elon Musk,

**00:47:53,660** he's definitely like, I feel-

**00:47:56,180** - He's a character. - He's a character.

**00:47:57,680** I feel like he is the most polarizing

**00:48:01,120** and I think it probably gets the most hate,

**00:48:03,100** but doesn't really care.

**00:48:04,620** He also has like eight kids named like XYZ.

**00:48:06,620** - Oh, he's got like 20, yeah.

**00:48:08,060** Some of them have like nine.

**00:48:09,180** - Crazy, crazy. - Often, like they have like, yeah.

**00:48:11,980** - And I like-- - He's getting creative with it.

**00:48:13,260** I mean, when you have that many kids,

**00:48:14,100** you gotta start getting creative with an age.

**00:48:14,940** - And he has insane business, like SpaceX, Tesla,

**00:48:18,060** - I think he's objectively a genius,

**00:48:21,140** but he's kind of like an evil genius.

**00:48:24,180** Or like, I don't think he's evil,

**00:48:25,460** but I think that he is incredibly efficiency-minded,

**00:48:31,420** And I think that influences how he communicates with people

**00:48:34,260** and leads his businesses.

**00:48:35,500** You know, like he came into Twitter and fired

**00:48:37,100** like a massive share of the employees.

**00:48:39,540** And I think that--

**00:48:41,640** - Did the same for the government.

**00:48:43,300** - Yeah, true.

**00:48:44,140** And like, you know, X formerly Twitter,

**00:48:47,180** I think a lot of people are like,

**00:48:48,020** oh, well, a key is gonna drive it into the ground.

**00:48:49,620** Like it's still very successful.

**00:48:52,140** And it's kind of like honestly the place

**00:48:54,540** where most of the conversation around AI now happens.

**00:48:56,900** So, you know, whether he's been effective or not

**00:48:59,860** in his business, never is like,

**00:49:00,780** I think you have to respect that he's like with SpaceX and Tesla and X.

**00:49:06,140** He is driving multiple,

**00:49:09,380** you know, generational companies at once.

**00:49:11,700** Yeah. So I think I think, yeah, I think you've got to separate as a person.

**00:49:15,460** Like it's hard. You don't have to respect if you're like it depends how you want to

**00:49:20,100** totally measure their stock. But I think I think

**00:49:23,660** a fun end of the rapid fire question brings them

**00:49:27,540** from most loved to least loved in your mind for you, for you, not the general public.

**00:49:31,860** Like, "Oh, I love the most versus the least."

**00:49:34,660** So we're ranking Elon, Sam, and Dario.

**00:49:37,620** And one more.

**00:49:39,140** Well, you were talking about earlier about Demis,

**00:49:41,220** Hasavis, who was leading Google DeepMind.

**00:49:44,180** He recently has now kind of stepped down from that role to focus more on research.

**00:49:49,220** So Gemini, I ask.

**00:49:50,820** Yeah, I think the Google DeepMind team works very closely in developing Gemini.

**00:49:55,620** What is Google DeepMind?

**00:49:56,740** So historically, DeepMind was a different entity.

**00:50:00,420** And they were acquired by Google and merged with Google's in-house AI team.

**00:50:04,940** Okay.

**00:50:05,940** And then, yeah, Demis Hasabas was overseeing that team and he came to Stanford.

**00:50:08,580** But it's not like a model, is it?

**00:50:09,900** No, DeepMind is really just-

**00:50:10,900** The head of Gemini is different.

**00:50:12,900** I don't know exactly what the internal org structure is like, but I think that-

**00:50:16,020** Who's the Sam equivalent for Gemini?

**00:50:18,780** I think that at least publicly it was Demis.

**00:50:21,020** Okay.

**00:50:22,020** Until recently, where Demis is now focused more on a research role.

**00:50:24,340** Demis, while he was still kind of seen as the CEO equivalent of of Gemini and

**00:50:29,680** Google's AI efforts, did come to Stanford. And I think he's a super thoughtful guy.

**00:50:34,560** I think they're just like this sense of when he was talking, it was just this

**00:50:38,740** like sense of like wonder and curiosity and like spark in his eye that I left

**00:50:44,160** being like, gosh, like I want to be more curious and to like be excited about

**00:50:49,680** this and he also in my mind is the person who cares the most about slowing

**00:50:54,200** down AI in the safety stuff. I would put him as my number one.

**00:50:58,240** Well but now he's you know he's not the right he now he's not right but if you

**00:51:04,560** ranked him for most loved I want I want you to rank our people in it do you know

**00:51:10,000** Nvidia guy Jensen? Jensen yeah I feel like he's kind of a different bucket

**00:51:13,840** because it's like I think it's easier for him to run things less controversial.

**00:51:17,840** Yeah. All right. All right. Go to the ranking. Go to the ranking.

**00:51:20,880** So we're including Demis here with Dario and Sam and Elon. I mean, I agree with you. I think Demis

**00:51:28,560** is just like the most easy to like least controversial. Yeah. But it is a little

**00:51:33,280** disheartening because I feel like the fact that this guy who did seem more like,

**00:51:38,160** I don't know, not innocence, not the right word, but just like,

**00:51:41,600** This just makes sense of awe in what we're able to do.

**00:51:47,040** - You could just tell that his motivations were so good.

**00:51:54,640** It was clearly good.

**00:51:56,040** And I think it's disheartening that he,

**00:51:58,360** maybe it was just he was more personally interested

**00:51:59,920** in the research, but I could see it being like,

**00:52:01,160** "Okay, I'm tired of getting pulled into this commercial race

**00:52:05,560** and having all the tension of pressure to make money

**00:52:09,000** instead of doing what's right."

**00:52:11,040** I'm sure, or my guess would be that that's part of why he stepped aside from that role

**00:52:14,840** is because he just fell at conflict with his inner moral compass.

**00:52:17,920** Okay, for the love of Mike and Riley, can you go through your-

**00:52:20,040** Given all that, I'll put Demis up top. I very much shared your kind of like-

**00:52:25,520** This is supposed to be rapid fire.

**00:52:28,560** Demis, then Dario, then Sam, then Elon, then Zuck, and all the meta people like Alexander

**00:52:35,840** Wang who kind of helps lead their stuff I think it's like a little bit of a wild card.

**00:52:40,880** Yeah.

**00:52:40,880** I'll have to unpack that at a later date. But yeah, that's my ranking. What about you?

**00:52:45,040** I love it. I love it. No, that was just my fun question to you.

**00:52:48,160** Oh, okay. Well then I'll flip on you. We have to look at your most recent three chats.

**00:52:54,400** Oh gosh. Chats or quads?

**00:53:01,680** Well, you said you use chat more for what kind of use case?

**00:53:07,600** I just use I use Claude more.

**00:53:09,720** OK, well, let's look at your last three.

**00:53:11,640** Well, chats then.

**00:53:13,760** My recent I mean, I mean, no skipping.

**00:53:17,360** They're not. I mean, nonprofit woman, a stats.

**00:53:20,080** Oh, yeah.

**00:53:20,680** You trying to make sure you have your numbers right. Yeah.

**00:53:25,120** Oh, this is fun.

**00:53:26,080** Academic accommodation.

**00:53:27,120** So I was exhausted.

**00:53:30,520** last night and I needed to send through a, I'm trying to get this class that we took last year

**00:53:39,480** to count for a certificate at Stanford. And so I just sent through a petition and I went back and

**00:53:45,080** forth with Claude and I was kind of overdoing the whole like writing it out and I said, okay, can

**00:53:49,720** you, can you write this out? Can you, can you make a petition for these classes? Can you go into my

**00:53:54,600** Canvas and my access, which is like the Canvas is like where our classes are in the details and syllabus and access says like how many credits they are and what are the professors and stuff like that in fillers all out for me and in read it back so read it back to me.

**00:54:10,200** I was like, Hey, make it time.

**00:54:11,160** New Roman make it very clear that it's not AI generated.

**00:54:15,120** And can you just send it directly to Hallie,

**00:54:18,280** my academic coordinator, and I went to sleep.

**00:54:23,200** And I woke up in the morning being like,

**00:54:24,320** what the heck did I just do?

**00:54:25,240** 'Cause usually I look at it

**00:54:26,120** before I send literally anything.

**00:54:28,120** And it was perfect.

**00:54:28,960** It sent it through.

**00:54:29,940** It was perfect.

**00:54:30,780** I was so proud of it.

**00:54:31,960** And it was just one of those things that like,

**00:54:33,360** I need to get done.

**00:54:34,400** I wasn't getting done.

**00:54:35,920** And I was like, okay, if there's some errors,

**00:54:37,400** it's kind of fine.

**00:54:39,200** Anyway, it's like not that fun, but.

**00:54:42,240** - Very useful.

**00:54:44,880** - And like--

**00:54:45,840** - All right, you gotta give us a good one.

**00:54:47,280** Give us a juicy one.

**00:54:48,120** - Yeah, like I was gonna say,

**00:54:48,940** I don't have a juicy one right now.

**00:54:50,160** - You don't have any like, what is this thing on my foot?

**00:54:52,040** Like, you know.

**00:54:56,320** - Like how embarrassing.

**00:54:58,000** I have street style inspiration.

**00:54:59,680** I was like, we were coming back to school

**00:55:01,400** and I was like, I need--

**00:55:02,560** - New fits.

**00:55:03,400** - Yeah, new fits that like aren't,

**00:55:05,480** I like athletic fits.

**00:55:06,600** And I have,

**00:55:12,740** best pina colada in Maui.

**00:55:14,680** - There we go.

**00:55:16,600** Yeah, we'll have to dig in more.

**00:55:17,760** I feel like we both are like very power users

**00:55:20,680** for personal use cases, obviously,

**00:55:22,200** for stuff with the nonprofit, with school.

**00:55:24,160** - Yeah.

**00:55:25,520** - We found a lot of cool ways to make these useful

**00:55:28,720** across our lives.

**00:55:29,560** So I want to share more of them in a future episode, but.

**00:55:31,400** - Yeah, hope this was helpful and landscape

**00:55:34,920** and see you in the next episode,

**00:55:37,640** if not in our inboxes before.

**00:55:40,480** Peace.

**00:55:44,680** [BLANK_AUDIO]
