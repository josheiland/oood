"""Verify audio-headroom copies against the fully checked v6 picture streams."""
from pathlib import Path
import hashlib
import json
import re
import subprocess
import sys

P = Path(__file__).resolve().parent
SPEC = {
    'clean': {
        'source': 'episode-01-master-v6.mp4',
        'review': 'episode-01-clean-review-v7.mp4',
        'captions': 'episode-01-captions-v6.srt',
        'source_qc': 'intermediate/qc-v6-final/report.json',
        'frames': 96147,
    },
    'theme': {
        'source': 'episode-01-theme-preview-v6.mp4',
        'review': 'episode-01-theme-preview-v7.mp4',
        'captions': 'episode-01-theme-preview-v6.srt',
        'source_qc': 'intermediate/qc-v6-theme/report.json',
        'frames': 96933,
    },
}


def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as file:
        for block in iter(lambda: file.read(8 * 1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def probe(path):
    return json.loads(subprocess.check_output(['ffprobe', '-v', 'error',
        '-show_streams', '-show_chapters', '-show_format', '-of', 'json', str(path)]))


def video_packet_hash(path):
    result = subprocess.check_output(['ffmpeg', '-nostdin', '-v', 'error',
        '-i', str(path), '-map', '0:v:0', '-c', 'copy', '-f', 'hash',
        '-hash', 'sha256', '-'], text=True)
    return result.strip().split('=', 1)[1]


def run(which):
    spec = SPEC[which]
    source = P / spec['source']
    review = P / spec['review']
    captions = P / spec['captions']
    original_qc = P / spec['source_qc']
    assert source.is_file() and review.is_file() and captions.is_file()
    assert original_qc.is_file(), f'Picture source not fully checked: {original_qc}'
    log = P / f'intermediate/v7-{which}-loudness.log'
    if not log.exists():
        with log.open('w') as file:
            subprocess.run(['ffmpeg', '-nostdin', '-hide_banner', '-nostats',
                            '-v', 'info', '-i', str(review), '-vn', '-af',
                            'loudnorm=I=-16:TP=-1.5:LRA=11:print_format=json',
                            '-f', 'null', '-'], stderr=file, check=True)
    matches = re.findall(r'\{[^{}]+\}', log.read_text())
    assert matches, f'Loudness measurement missing: {log}'
    level = json.loads(matches[-1])
    p = probe(review)
    video = next(s for s in p['streams'] if s['codec_type'] == 'video')
    audio = next(s for s in p['streams'] if s['codec_type'] == 'audio')
    source_hash = video_packet_hash(source)
    review_hash = video_packet_hash(review)
    cues = re.split(r'\n\s*\n', captions.read_text().strip())
    checks = {
        'picture_bitstream_identical': source_hash == review_hash,
        'exact_frame_count': int(video['nb_frames']) == spec['frames'],
        'exact_video_duration': abs(float(video['duration']) - spec['frames']/30) < 0.001,
        'audio_video_within_50ms': abs(float(video['duration']) - float(audio['duration'])) <= 0.05,
        'true_peak_below_minus_point_eight_db': float(level['input_tp']) <= -0.8,
        'dialogue_loudness_near_target': -18 <= float(level['input_i']) <= -15,
        'chapters_present': len(p.get('chapters', [])) >= 19,
        'captions_present': len(cues) > 1100,
    }
    report_path = P / f'episode-01-{which}-review-quality-check-v7.md'
    assert not report_path.exists(), f'Preserving existing report: {report_path}'
    report_path.write_text(f'''# Episode 1 {which} review v7: technical check

Checked 2026-09-28. This is a **host-review comparison**, not an approved release.

The v7 copy uses the exact same H.264 picture bitstream as `{spec['source']}`; only the AAC audio was re-encoded 0.6 dB lower for more headroom. The source v6 video's full decode, black/silence scan, chapter and caption checks are in `{spec['source_qc']}`. The v7 audio was decoded end-to-end for loudness and true-peak measurement. A selected public master should receive a final true-peak limiter pass if its encoded peak remains above the preferred −1 dBTP ceiling.

| Check | Result |
|---|---|
| Review video | `{spec['review']}`, 1080p30, {video['nb_frames']} frames, {float(video['duration']):.3f}s; SHA-256 `{sha(review)}` |
| Picture packets | Identical SHA-256 `{review_hash}` in source and review copy |
| Audio | AAC stereo {audio['sample_rate']} Hz, {level['input_i']} LUFS, {level['input_tp']} dBTP true peak, {audio['duration']}s |
| Chapters and captions | {len(p.get('chapters', []))} embedded chapters; {len(cues)} matching-timeline draft SRT cues |

Checks: `{checks}`.

The picture samples and seven exact source removals are documented beside the clean v6 edit. The four on-screen corrections remain present in both review versions. Continuous viewing and listening, auditory caption proof, personal-detail comfort and host approval remain open. The theme version uses proposed music whose public rights remain unconfirmed. No upload, scheduling or publication is claimed.
''')
    print(json.dumps({'checks': checks, 'report': str(report_path)}, indent=2))
    assert all(checks.values()), checks


if __name__ == '__main__':
    if len(sys.argv) != 2 or sys.argv[1] not in SPEC:
        raise SystemExit('Usage: python3 check-review-v7.py clean|theme')
    run(sys.argv[1])
