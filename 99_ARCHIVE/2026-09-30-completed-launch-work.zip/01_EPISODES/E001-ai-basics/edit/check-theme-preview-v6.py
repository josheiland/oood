"""Decode and inspect the Episode 1 private theme comparison."""
from pathlib import Path
from PIL import Image, ImageDraw
import hashlib
import io
import json
import re
import subprocess

P = Path(__file__).resolve().parent
ROOT = P.parents[2]
VIDEO = P / 'episode-01-theme-preview-v6.mp4'
CAPTIONS = P / 'episode-01-theme-preview-v6.srt'
QC = P / 'intermediate/qc-v6-theme'
E = json.loads((P / 'episode-01-edit-decisions-v6.json').read_text())
HOOK_FRAMES, TITLE_FRAMES, OUTRO_FRAMES = 305, 158, 323
LEAD = HOOK_FRAMES + TITLE_FRAMES
TOTAL = LEAD + E['total_frames'] + OUTRO_FRAMES


def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as file:
        for block in iter(lambda: file.read(8 * 1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def seconds(value):
    h, m, rest = value.split(':')
    return int(h) * 3600 + int(m) * 60 + float(rest.replace(',', '.'))


assert VIDEO.exists() and CAPTIONS.exists()
if not (QC / 'report.json').exists():
    if QC.exists():
        raise SystemExit(f'Incomplete QC requires inspection: {QC}')
    subprocess.run(['python3', str(ROOT / '.agents/skills/oood-episode-producer/scripts/media_job.py'),
                    'qc', str(VIDEO), '--out', str(QC)], check=True)
report = json.loads((QC / 'report.json').read_text())
video = next(s for s in report['probe']['streams'] if s['codec_type'] == 'video')
audio = next(s for s in report['probe']['streams'] if s['codec_type'] == 'audio')
duration = float(video['duration'])
frames = int(video['nb_frames'])
level = report['loudness']
cues = []
for block in re.split(r'\n\s*\n', CAPTIONS.read_text().strip()):
    lines = block.splitlines()
    index = int(lines[0])
    start, end = (seconds(item) for item in lines[1].split(' --> '))
    cues.append((index, start, end, lines[2:]))
for i, (index, start, end, body) in enumerate(cues, 1):
    assert index == i and 0 <= start < end <= TOTAL / 30 + 0.002
    assert len(body) <= 2 and all(len(line) <= 42 for line in body)
    if i > 1:
        assert start >= cues[i-2][1]

times = [0.5, HOOK_FRAMES / 30 + 0.2, LEAD / 30 + 0.2,
         (LEAD + E['total_frames']) / 30 - 0.2,
         (LEAD + E['total_frames']) / 30 + 0.2,
         TOTAL / 30 - 0.25]
for cue in E['graphics']:
    times.append((LEAD + cue['start_frame']) / 30 + 0.5)
images = []
for time in times:
    data = subprocess.check_output(['ffmpeg', '-nostdin', '-hide_banner', '-loglevel', 'error',
        '-ss', f'{time:.6f}', '-i', str(VIDEO), '-frames:v', '1', '-vf', 'scale=480:-2',
        '-f', 'image2pipe', '-vcodec', 'mjpeg', '-'])
    images.append(Image.open(io.BytesIO(data)).convert('RGB'))
w, h = images[0].size
sheet = Image.new('RGB', (3*w, 4*(h+24)), 'white')
draw = ImageDraw.Draw(sheet)
for i, (time, frame) in enumerate(zip(times, images)):
    x = i % 3 * w
    y = i // 3 * (h+24)
    sheet.paste(frame, (x, y))
    draw.text((x+5, y+h+4), f'{int(time//60):02}:{time%60:06.3f}', fill='black')
sample = P / 'intermediate/v6-theme-sampled-frames.jpg'
assert not sample.exists(), f'Preserving existing sample: {sample}'
sheet.save(sample, quality=90)

checks = {
    'exact_frame_count': frames == TOTAL,
    'exact_duration': abs(duration - TOTAL/30) <= 1/30 + 0.001,
    'audio_video_within_50ms': report['audio_video_duration_delta'] <= 0.05,
    'loudness_within_one_lu': abs(float(level['input_i']) + 16) <= 1,
    'true_peak_below_minus_one_db': float(level['input_tp']) <= -1,
    'chapters_present': len(report['probe'].get('chapters', [])) >= 20,
    'captions_ordered': len(cues) > 1100,
    'main_master_present': (P / 'episode-01-master-v6.mp4').exists(),
}
body = f'''# Episode 1 v6 theme preview: automated quality check

Checked 2026-09-28. This is a **private host-review comparison** because public rights for the proposed theme are unconfirmed.

| Check | Result |
|---|---|
| Video | `episode-01-theme-preview-v6.mp4`, 1080p30, {frames:,} frames, {duration:.3f}s, SHA-256 `{sha(VIDEO)}` |
| Audio | AAC stereo {audio['sample_rate']} Hz; {level['input_i']} LUFS; {level['input_tp']} dBTP true peak; video/audio duration delta {report['audio_video_duration_delta']:.6f}s |
| Chapters and captions | {len(report['probe'].get('chapters', []))} embedded chapters; {len(cues)} structurally checked SRT cues, not auditory-proofread |
| Complete decode | Passed; {len(report['black_spans'])} machine black spans and {len(report['silence_events'])} silence event markers. Logs in `intermediate/qc-v6-theme/` |
| Timeline | 00:00–00:10.167 cold open; 00:10.167–00:15.433 title/theme; 00:15.433–53:40.333 complete clean v6 cut; 53:40.333–53:51.100 two-ask outro/music |
| Sampled picture | `intermediate/v6-theme-sampled-frames.jpg` covers hook, title, episode boundaries, four pop-ups and outro |

Checks: `{checks}`.

These machine checks do not establish continuous viewing quality, every join's sound, speaker balance, lip sync or exact caption wording. Both hosts should review the selected export and proof the captions by ear. The outro card text is “What should we try next? Tell us in the comments” and “Know someone figuring out AI? Send this their way”. No upload, scheduling or publication is claimed.
'''
out = P / 'episode-01-theme-preview-quality-check-v6.md'
assert not out.exists(), f'Preserving existing report: {out}'
out.write_text(body)
print(json.dumps({'checks': checks, 'sample': str(sample), 'report': str(out)}, indent=2))
assert all(checks.values()), checks
