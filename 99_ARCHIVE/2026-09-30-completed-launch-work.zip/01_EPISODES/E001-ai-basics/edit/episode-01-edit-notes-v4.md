# Episode 1 v4: mostly intact edit notes

**Superseded 2026-09-28:** The Demis CEO and sandbox-escape factual determinations below were wrong. The current v5 proposal restores those five source ranges. See `episode-01-removed-footage-v5.md` for the complete current cut list and `../../../02_RESEARCH/episode-01-v5-source-correction-2026-09-28.md` for primary-source evidence.

Josh and Mary requested a close-to-raw Episode 1, starting and ending with Mary covering the camera, with their specified flubs removed and no pop-ups. This v4 is a **review proposal**, not approval or publication. It uses the original 55:47.233 shoot only. The Hallie academic-advisor story remains intact at the hosts' request. No on-screen graphics are added.

The new cut is **00:47:30.600** (85,518 frames, 1080p30), retaining **85%** of the source's elapsed time. There are 24 retained source ranges and 23 internal joins, with four-frame picture/audio crossfades (0.133 seconds) at each join. The hand-cover boundaries are kept as source picture, not generated graphics. Short dissolves are a starting editorial treatment; hosts should judge each join in playback.

The key technical determinations are in `../../../02_RESEARCH/episode-01-v4-source-addendum-2026-09-27.md`. In particular, Mary's 06:46 explanation is misleading and is removed. The main NVIDIA account is kept, with its imprecise hardware detour removed. Josh's distinction between open source and open weights was wrong under the OSI definition, so that line is removed while the local-hosting discussion stays. Demis Hassabis remains Google DeepMind CEO; the false departure premise is removed. The safety escape and OpenAI-structure overclaims are also removed.

## Source cuts

All ranges below are half-open **raw-source** timecodes. Output join time already accounts for previous cuts and four-frame dissolves. Exact frame values, reasons and retained segments are in `episode-01-edit-decisions-v4.json`.

| Raw cut | Output join | Removed | Reason |
|---|---:|---:|---|
| 00:00:00.000–00:00:15.000 | 00:00:00.000 | 15.000s | Requested hand-cover opening |
| 00:01:46.633–00:02:22.467 | 00:01:31.500 | 35.833s | Unsourced blanket provider ranking and false all-models-closed claim |
| 00:06:30.733–00:06:34.533 | 00:05:39.633 | 3.800s | OpenAI also has open-weight models |
| 00:06:46.033–00:07:51.867 | 00:05:51.000 | 65.833s | Misleading description of model weights and product modes |
| 00:11:51.367–00:11:59.667 | 00:09:50.367 | 8.300s | Unsourced blanket open-versus-closed quality ranking |
| 00:12:32.200–00:13:33.433 | 00:10:22.767 | 61.233s | Unsupported claims about named specialist products |
| 00:14:34.500–00:14:38.833 | 00:11:23.700 | 4.333s | Stronger model does not inherently mean more tokens |
| 00:15:03.733–00:15:15.100 | 00:11:48.467 | 11.367s | Model choice and usage limits conflated |
| 00:28:54.967–00:29:17.833 | 00:25:28.200 | 22.867s | Battery analogy and erroneous chips-versus-GPUs distinction |
| 00:29:46.033–00:29:48.833 | 00:25:56.267 | 2.800s | GPU expands to graphics, not graphical, processing unit |
| 00:31:22.767–00:31:44.067 | 00:27:30.067 | 21.300s | Unqualified permission advice and Mary lost her train of thought |
| 00:33:02.300–00:33:24.833 | 00:28:48.167 | 22.533s | Open source without open weights claim is wrong under OSI definition |
| 00:34:17.800–00:34:34.833 | 00:29:41.000 | 17.033s | Unsupported blanket open-model quality comparison |
| 00:35:11.433–00:35:24.600 | 00:30:17.467 | 13.167s | Unsourced government-subsidy speculation |
| 00:35:48.533–00:36:03.467 | 00:30:41.267 | 14.933s | Unsupported blanket revenue comparison |
| 00:36:59.867–00:37:06.433 | 00:31:37.533 | 6.567s | On-premises is not automatically more secure |
| 00:39:29.167–00:39:46.767 | 00:34:00.133 | 17.600s | Requested Demis/Dario name slip and restart |
| 00:40:58.167–00:41:10.533 | 00:35:11.400 | 12.367s | Unsupported real-world model-escape claim |
| 00:45:06.133–00:45:15.300 | 00:39:06.867 | 9.167s | Requested Josh lost-train-of-thought passage |
| 00:46:37.167–00:47:30.567 | 00:40:28.600 | 53.400s | Misleading OpenAI nonprofit-structure summary and unverified attributed motive |
| 00:49:44.167–00:49:49.233 | 00:42:42.067 | 5.067s | False claim Demis stepped down |
| 00:50:22.033–00:50:34.567 | 00:43:14.733 | 12.533s | False repeat of Demis departure premise |
| 00:50:58.233–00:51:04.567 | 00:43:38.267 | 6.333s | False reference to Demis no longer leading |
| 00:51:33.267–00:52:17.933 | 00:44:06.833 | 44.667s | Speculation based on nonexistent Demis departure |
| 00:55:41.700–00:55:47.233 | end | 5.533s | Requested hand-cover ending |

No source was overwritten. V1–v3 remain comparison exports. The full source transcript and original ASR are machine-generated, not verbatim certified. The v4 captions and transcript are remapped drafts, not a listening proofread. Review the entire v4 cut continuously for join feel, audio/visual sync, captions, personal details and the remaining opinions before approval.
