# Episode 1 fuller review cut v3: quality check

Checked 2026-09-27. This is a **technically checked review cut**, not a host-approved release master. It is the recommended 25:20.567 version; the 9:58.367 v2 remains for comparison.

## Final export

| Check | Result |
|---|---|
| Video | `episode-01-master-v3.mp4`, H.264, 1920 × 1080, 30 fps, 45,617 frames, 25:20.567 container duration |
| Audio | Stereo AAC, 48 kHz; encoded audio and video streams both report 25:20.566. The 0.001-second container rounding difference is harmless. |
| Separate audio | 48 kHz/24-bit WAV has exactly 72,987,200 samples (25:20.566667); MP3 has the same reported duration. |
| Loudness | −16.94 LUFS integrated; −1.66 dBTP encoded true peak; 4.30 LU loudness range. Within the working −16 ±1 LUFS and ≤−1 dBTP targets. |
| Full-file decode | Passed. Fourteen embedded chapters; no detected black span ≥0.1 second. |
| File identity | Final MP4 SHA-256 `b50ebcb8d47c147a43259084f25ea6f51fc32b194b7c3c18ef6983a9ee747980`. WAV SHA-256 `584d5c359368e3079514aa65585d7aeb41a9c20cb4e710f037f4836fd2d0100b`. |
| Source preservation | `/Users/je/Movies/Episode 1 Raw.mp4` remains SHA-256 `9f58d3a39c91ce4499fd3215355ddc9873051e6e32a5b26a6c73ce05caf93107`. Forty-one reversible source ranges are in `episode-01-edit-decisions-v3.json`. |

The initial assembly exposed a slightly high AAC true peak and an audio tail one video frame short. The final MP4 uses a small AAC headroom adjustment and sample-exact WAV padding. The full automated check ran on the final candidate, then that file was moved unchanged to the review path; its measured SHA-256 matches the path above. Machine report: `intermediate/qc-v3-final-candidate/report.json`.

Two quiet spans were detected at **24:14.525–24:16.096** and **24:52.687–24:54.426** (below −48 dB for at least 1.5 seconds). Both are in the closing chat exchange. Listen to decide whether they are natural pauses or should be shortened; silence detection alone is not a defect finding.

## Picture, captions and editorial review

Fourteen frames sampled just after chapter starts show the expected two-host shot throughout; a separate early-card sample showed the explanatory graphics. The contact sheet is `intermediate/v3-final-frame-review/final-contact-sheet.jpg`. Sampled frames and full-file decode do not establish continuous picture quality, original camera lip sync or the naturalness of all 41 joins.

The 533-cue SRT/VTT drafts are ordered, within the 25:20.567 timeline, at most two lines and 42 characters per line. They use source-recording ASR token timing mapped through the exact v3 frame list, with explicit name/word overrides in `episode-01-caption-overrides-v3.json`. Auditory proofreading remains open, particularly rapid overlaps and the closing prompt described as `nonprofit [unclear] AI stats`. No speaker attribution was invented.

Josh and Mary should watch and listen to this exact version continuously, including start/middle/end lip sync, all joins, graphics, the two quiet spans, the work-to-hardware-to-safety arc, and caption wording. They should approve Mary's coding-class/grade and dyslexia details, job opinions, the hypothetical paperclip example, mild profanity, thumbnail and description. A brief spoken reminder is an optional pickup, not something inserted into this cut: “Use one tool for a real task, and check anything important before you act on its answer.” The research qualifications are in `02_RESEARCH/episode-01-ai-basics-source-checks-2026-09-26.md`.

No upload, scheduling, publication or host approval has been verified.
