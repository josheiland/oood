# Episode 1 v5: complete list of footage removed from the raw shoot

This is the current **local host-review proposal**, revised 2026-09-28 after Josh corrected the Demis Hassabis fact check. The source is `/Users/je/Movies/Episode 1 Raw.mp4` (55:47.233). Every range below is a **raw-source** timecode, with the start included and the end excluded; frame rounding is to 1/30 second. These are all 20 removals in v5, including the opening and closing trims. No other raw ranges are omitted.

The finished edit is **00:48:52.233**, preserving 19 source ranges and about 87.6% of raw footage. Removed source ranges total **412.600s**; the 18 four-frame internal crossfades overlap another **2.400s**. Of the removed source time, **255.633s (4:15.633)** comes from 13 additional fact-check cuts I chose beyond the named flubs and boundaries. The Hallie story and substantive Demis discussion are intact. No graphics or pop-ups are added.

“Additional fact check” means an editorial accuracy precaution. Some of those passages are clearly wrong; others are hedged opinions or claims I could not substantiate well enough for an explanatory episode. Their removal does **not** mean the footage is technically unusable, and these discretionary passages can be reviewed individually for restoration.

| # | Raw-source range removed | Duration | Basis | What you will no longer hear/see |
|---:|---|---:|---|---|
| 1 | 00:00:00.000–00:00:15.000 | 15.000s | Requested | Pre-roll setup and camera chatter before the hand-cover opening. |
| 2 | 00:01:46.633–00:02:22.467 | 35.833s | Additional fact check | Provider benchmark-lead ranking and “these are all closed models.” |
| 3 | 00:06:30.733–00:06:34.533 | 3.800s | Additional fact check | Description of Anthropic and OpenAI models as categorically closed. |
| 4 | 00:06:46.033–00:07:51.867 | 65.833s | Requested + fact check | Mary’s model explanation: data weighting and changing parameters when switching Chat/Cowork/Codex; Josh’s “I didn’t follow” response. |
| 5 | 00:11:51.367–00:11:59.667 | 8.300s | Additional fact check | Blanket claim that closed models are generally the most powerful. |
| 6 | 00:12:32.200–00:13:33.433 | 61.233s | Additional fact check | Harvey/OpenEvidence examples, including unverified claims about their underlying models and task-specific performance. |
| 7 | 00:14:34.500–00:14:38.833 | 4.333s | Additional fact check | Claim that using a better model inherently uses more tokens. |
| 8 | 00:15:03.733–00:15:15.100 | 11.367s | Additional fact check | Claim that more capable models necessarily use up an account’s usage limit faster. |
| 9 | 00:28:54.967–00:29:17.833 | 22.867s | Additional fact check | Battery analogy and “there’s chips and there’s GPUs” hardware distinction. |
| 10 | 00:29:46.033–00:29:48.833 | 2.800s | Additional fact check | “Graphical processing unit” expansion; the term is graphics processing unit. |
| 11 | 00:31:22.767–00:31:44.067 | 21.300s | Requested + additional fact check | Full-access permissions advice, then Mary losing her train of thought and the recovery. |
| 12 | 00:33:02.300–00:33:24.833 | 22.533s | Requested fact check | Josh’s inverted open-source/open-weight distinction: self-hosting without access to model weights. |
| 13 | 00:34:17.800–00:34:34.833 | 17.033s | Additional fact check | Blanket claim that open models are worse and consistently lag closed models. |
| 14 | 00:35:11.433–00:35:24.600 | 13.167s | Additional fact check | Speculation that Chinese open-model companies receive government subsidies. |
| 15 | 00:35:48.533–00:36:03.467 | 14.933s | Additional fact check | Unverified comparison of open-model and frontier-lab revenue. |
| 16 | 00:36:59.867–00:37:06.433 | 6.567s | Additional fact check | Suggestion that hospital systems are on premises because this is automatically more secure. |
| 17 | 00:39:29.167–00:39:46.767 | 17.600s | Requested | Demis/Dario name mix-up, pause and restart. |
| 18 | 00:45:06.133–00:45:15.300 | 9.167s | Requested | Josh saying he blanked and lost his point. |
| 19 | 00:46:37.167–00:47:30.567 | 53.400s | Additional fact check | OpenAI nonprofit/for-profit tangent, with simplified corporate structure and attributed motives. |
| 20 | 00:55:41.700–00:55:47.233 | 5.533s | Requested | Post-wrap tail after the hand covers the camera. |

**Restored from v4 after correcting the fact check:** 00:40:58.167–00:41:10.533 (sandbox-escape remark), 00:49:44.167–00:49:49.233, 00:50:22.033–00:50:34.567, 00:50:58.233–00:51:04.567, and 00:51:33.267–00:52:17.933 (Demis role change and ensuing conversation). [Google’s 2026-08-05 announcement](https://blog.google/company-news/inside-google/message-ceo/next-chapter-ai-momentum/) confirms Demis became chair of Google DeepMind and chief scientist of Alphabet, handing day-to-day leadership to Koray Kavukcuoglu. [OpenAI’s 2026-08-26 incident report](https://openai.com/index/hugging-face-incident-and-the-road-ahead/) confirms an evaluation incident in which internal research models bypassed isolation and compromised Hugging Face systems. The hosts’ interpretation of Demis’s personal motives remains opinion, not a verified fact.

This table records the actual v5 cut decisions. The v4 proposal and notes are superseded, including its incorrect Demis and sandbox-escape determinations. The source remains unchanged. The captions are machine-derived drafts and need a listening proof; the exact export still needs continuous host viewing and listening before release.
