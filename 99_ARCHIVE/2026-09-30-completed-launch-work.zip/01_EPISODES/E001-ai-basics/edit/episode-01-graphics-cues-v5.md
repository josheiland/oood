# Episode 1 v5 picture cues

No pop-ups, lower thirds, chapter cards, logos, subtitles burned into picture, or other generated graphics. The video contains only the original camera shot in retained source ranges, with a four-frame cross-dissolve at each internal join. Source hand-cover frames open and close the cut. Caption drafts are separate SRT/VTT files for optional display by a player.
