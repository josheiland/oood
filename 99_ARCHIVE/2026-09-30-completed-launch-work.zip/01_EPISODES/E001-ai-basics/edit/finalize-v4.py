"""Add v4 chapters, create audio companion, and record automated export QC."""
from pathlib import Path
import hashlib
import json
import subprocess
import sys

P=Path(__file__).resolve().parent
ROOT=P.parents[2]
E=json.loads((P/'episode-01-edit-decisions-v4.json').read_text())
MASTER=P/'episode-01-master-v4.mp4'
MP3=P/'episode-01-audio-v4.mp3'
QC=P/'intermediate/qc-v4-final'
LEVEL_MARK=P/'intermediate/v4-audio-level-applied.json'

def run(args):
    subprocess.run(args,check=True)

def probe(path):
    return json.loads(subprocess.check_output(['ffprobe','-v','error','-show_streams',
                                               '-show_format','-show_chapters','-of','json',str(path)]))

def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda:f.read(8*1024*1024),b''):h.update(chunk)
    return h.hexdigest()

assert MASTER.exists(),f'Missing {MASTER}'
p=probe(MASTER)
if not p.get('chapters'):
    temp=P/'intermediate/episode-01-master-v4-chaptered.mp4'
    if temp.exists():temp.unlink()
    run(['ffmpeg','-nostdin','-hide_banner','-loglevel','error','-y',
         '-i',str(MASTER),'-i',str(P/'intermediate/v4-chapters.ffmeta'),
         '-map','0:v:0','-map','0:a:0','-map_metadata','1','-map_chapters','1',
         '-c','copy','-movflags','+faststart',str(temp)])
    assert len(probe(temp)['chapters'])>=10
    temp.replace(MASTER)
    p=probe(MASTER)
applied=False
if LEVEL_MARK.exists():
    applied=json.loads(LEVEL_MARK.read_text()).get('master_sha256')==sha(MASTER)
if not applied:
    temp=P/'intermediate/episode-01-master-v4-levelled.mp4'
    if temp.exists():temp.unlink()
    run(['ffmpeg','-nostdin','-hide_banner','-loglevel','error','-y',
         '-i',str(MASTER),'-map','0:v:0','-map','0:a:0','-map_metadata','0',
         '-map_chapters','0','-c:v','copy',
         '-af',f'loudnorm=I=-16:TP=-1.7:LRA=11,aresample=48000,'
               f'apad=whole_len={E["total_frames"]*1600},'
               f'atrim=end_sample={E["total_frames"]*1600},asetpts=N/SR/TB',
         '-c:a','aac','-b:a','256k','-movflags','+faststart',str(temp)])
    assert abs(float(probe(temp)['format']['duration'])-E['duration_seconds'])<.05
    temp.replace(MASTER)
    LEVEL_MARK.write_text(json.dumps({'master_sha256':sha(MASTER),
                                      'filter':'loudnorm -16 LUFS / -1.7 dBTP with exact sample padding'},indent=2)+'\n')
    p=probe(MASTER)
if MP3.exists() and MP3.stat().st_mtime<MASTER.stat().st_mtime:
    MP3.unlink()
if not MP3.exists():
    run(['ffmpeg','-nostdin','-hide_banner','-loglevel','error','-y',
         '-i',str(MASTER),'-vn','-c:a','libmp3lame','-b:a','192k',
         '-metadata',f'title={E["title"]}',str(MP3)])
if not (QC/'report.json').exists():
    if QC.exists():
        raise SystemExit(f'Incomplete QC directory requires inspection: {QC}')
    run(['python3',str(ROOT/'.agents/skills/oood-episode-producer/scripts/media_job.py'),
         'qc',str(MASTER),'--out',str(QC)])
report=json.loads((QC/'report.json').read_text())
v=next(s for s in report['probe']['streams'] if s['codec_type']=='video')
a=next(s for s in report['probe']['streams'] if s['codec_type']=='audio')
frames=int(v['nb_frames'])
duration=float(v['duration'])
level=report['loudness']
checks={
    'frames_match_edl':frames==E['total_frames'],
    'duration_within_one_frame':abs(duration-E['duration_seconds'])<=1/E['fps']+0.001,
    'audio_video_within_50ms':report['audio_video_duration_delta']<=.05,
    'loudness_within_one_lu':abs(float(level['input_i'])+16)<=1,
    'true_peak_below_minus_one_db':float(level['input_tp'])<=-1,
    'chapters_present':len(report['probe'].get('chapters',[]))>=10,
    'source_hash_unchanged':sha(Path(E['source']))==E['source_sha256'],
    'no_generated_graphics':E['graphics']==[],
}
captions=(P/'episode-01-captions-v4.srt').read_text().strip().split('\n\n')
def time(s):
    h,m,sec=s.replace(',','.').split(':')
    return int(h)*3600+int(m)*60+float(sec)
last=0.0
for i,block in enumerate(captions,1):
    lines=block.splitlines()
    assert int(lines[0])==i
    start,end=map(time,lines[1].split(' --> '))
    assert last-.002<=start<end<=E['duration_seconds']+.002
    assert len(lines[2:])<=2 and all(len(line)<=42 for line in lines[2:])
    last=end
checks['caption_structure']=True
assert all(checks.values()),checks

body=f'''# Episode 1 v4: automated quality check

Checked after the final chaptered export. This is a **technically checked review cut**, not a host-approved release master.

| Check | Result |
|---|---|
| Master | `episode-01-master-v4.mp4`, H.264, {v['width']} × {v['height']}, {E['fps']} fps, {frames:,} frames, {duration:.3f}s |
| Sound | Stereo AAC, {a['sample_rate']} Hz; encoded audio/video duration difference {report['audio_video_duration_delta']:.6f}s |
| Loudness | {level['input_i']} LUFS integrated; {level['input_tp']} dBTP true peak; LRA {level['input_lra']} LU |
| Chapters | {len(report['probe'].get('chapters',[]))} embedded chapters; separate Markdown list matches v4 timing |
| Captions | {len(captions)} structurally valid ordered SRT cues, source-ASR-derived and **not listening-proofread**; VTT and transcript drafts alongside |
| Full-file decode | Passed. Machine black spans: {len(report['black_spans'])}; silence events: {len(report['silence_events'])}. See `intermediate/qc-v4-final/` for exact data. The intentional hand-cover ending can look dark. |
| File identity | Master SHA-256 `{report['sha256']}`; source unchanged SHA-256 `{E['source_sha256']}` |
| Picture treatment | Source camera only, no overlays/pop-ups; 23 internal four-frame picture/audio crossfades |

Automated checks: `{checks}`.

The script decoded the full exported audio and video, checked durations, measured encoded loudness/true peak, scanned for black/silent spans, and validated captions structurally. This does **not** establish naturalness of every join, lip sync, intelligibility, speaker balance, caption wording, or continuous picture quality. Josh and Mary should watch and listen to this exact export continuously, including all joins and the opening/closing hand covers, and proof the captions by ear. The v4 research addendum documents the remaining medical-comparison caveat and dated/subjective claims. No upload, scheduling, publication or exact-export host approval is claimed.
'''
(P/'episode-01-quality-check-v4.md').write_text(body)
print(json.dumps({'master':str(MASTER),'mp3':str(MP3),'checks':checks,
                  'sha256':report['sha256'],'frames':frames,'duration':duration},indent=2))
