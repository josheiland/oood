# Episode 1 clean review v7: technical check

Checked 2026-09-28. This is a **host-review comparison**, not an approved release.

The v7 copy uses the exact same H.264 picture bitstream as `episode-01-master-v6.mp4`; only the AAC audio was re-encoded 0.6 dB lower for more headroom. The source v6 video's full decode, black/silence scan, chapter and caption checks are in `intermediate/qc-v6-final/report.json`. The v7 audio was decoded end-to-end for loudness and true-peak measurement. A selected public master should receive a final true-peak limiter pass if its encoded peak remains above the preferred −1 dBTP ceiling.

| Check | Result |
|---|---|
| Review video | `episode-01-clean-review-v7.mp4`, 1080p30, 96147 frames, 3204.900s; SHA-256 `bbd84334ff403162142ba2847b257fc98c909b41b5d4e1ced5994f7e4256f6f7` |
| Picture packets | Identical SHA-256 `d111a81595229aedcb728c9fcdc3013d02e15c63ec04203d66556aab8b0da588` in source and review copy |
| Audio | AAC stereo 48000 Hz, -17.13 LUFS, -0.86 dBTP true peak, 3204.900000s |
| Chapters and captions | 19 embedded chapters; 1136 matching-timeline draft SRT cues |

Checks: `{'picture_bitstream_identical': True, 'exact_frame_count': True, 'exact_video_duration': True, 'audio_video_within_50ms': True, 'true_peak_below_minus_point_eight_db': True, 'dialogue_loudness_near_target': True, 'chapters_present': True, 'captions_present': True}`.

The picture samples and seven exact source removals are documented beside the clean v6 edit. The four on-screen corrections remain present in both review versions. Continuous viewing and listening, auditory caption proof, personal-detail comfort and host approval remain open. The theme version uses proposed music whose public rights remain unconfirmed. No upload, scheduling or publication is claimed.
