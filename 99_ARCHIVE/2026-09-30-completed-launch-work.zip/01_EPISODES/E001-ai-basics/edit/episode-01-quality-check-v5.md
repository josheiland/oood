# Episode 1 v5: automated quality check

Checked 2026-09-28 after the final chaptered export. This is a **technically checked review cut**, not a host-approved release master.

| Check | Result |
|---|---|
| Master | `episode-01-master-v5.mp4`, H.264, 1920 × 1080, 30 fps, 87,967 frames, 2932.233s |
| Sound | Stereo AAC, 48000 Hz; encoded audio/video duration difference 0.000000s |
| Loudness | -16.52 LUFS integrated; -1.11 dBTP true peak; LRA 4.80 LU |
| Chapters | 19 embedded chapters; separate Markdown list matches v5 timing |
| Captions | 1034 structurally valid ordered SRT cues, source-ASR-derived and **not listening-proofread**; VTT and transcript drafts alongside |
| Full-file decode | Passed. Machine black spans: 0; quiet spans: 3. See `intermediate/qc-v5-final/` for exact data. The intentional hand-cover ending can look dark. |
| File identity | Master SHA-256 `d9186c21c021611410045466211ba26e1529dcddd7ee197c3350af404e585e9a`; source unchanged SHA-256 `9f58d3a39c91ce4499fd3215355ddc9873051e6e32a5b26a6c73ce05caf93107` |
| Picture treatment | Source camera only, no overlays/pop-ups; 18 internal four-frame picture/audio crossfades |
| Sampled picture review | 25 frames across the opening, closing and each join examined in `intermediate/v5-sampled-frames.jpg`; no black flash or added graphic in those samples |

Automated checks: `{'frames_match_edl': True, 'duration_within_one_frame': True, 'audio_video_within_50ms': True, 'loudness_within_one_lu': True, 'true_peak_below_minus_one_db': True, 'chapters_present': True, 'source_hash_unchanged': True, 'no_generated_graphics': True, 'caption_structure': True}`.

The three machine-detected quiet spans are at output 1081.7–1083.3s, 2701.0–2702.6s, 2901.4–2903.1s; each is under two seconds and occurs within retained conversation, so they were left intact. The script decoded the full exported audio and video, checked durations, measured encoded loudness/true peak, scanned for black/silent spans, and validated captions structurally. This does **not** establish naturalness of every join, lip sync, intelligibility, speaker balance, caption wording, or continuous picture quality. Josh and Mary should watch and listen to this exact export continuously, including all joins and the opening/closing hand covers, and proof the captions by ear. The episode source addenda document the remaining medical-comparison caveat and dated/subjective claims. No upload, scheduling, publication or exact-export host approval is claimed.
