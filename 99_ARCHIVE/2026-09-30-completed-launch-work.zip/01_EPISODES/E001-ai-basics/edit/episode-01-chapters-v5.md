# Episode 1 v5 chapters

Review-cut timeline; no on-screen cards or pop-ups.

- 00:00 Opening and the AI landscape
- 01:00 Companies, models, and apps
- 05:31 Open and closed models
- 05:51 How a model learns
- 07:59 The engine analogy
- 10:22 Choosing a model
- 12:16 Work and human skills
- 17:14 Learning by asking
- 20:28 The coding-class story
- 21:48 What skills matter
- 24:52 NVIDIA and GPUs
- 28:09 Open weights and local models
- 30:43 On-prem and cloud
- 32:38 The people behind the companies
- 35:03 Safety, limits, and optimism
- 39:19 The founders and their reputations
- 42:34 A rapid-fire ranking
- 45:58 Our recent chats
- 46:35 A real use case from Mary
