# Episode 1 graphics cues v3

The supplied OOOD kit governs Teachers, blue/cream, square two-line logo and safe placement. Existing v1 artwork is unchanged; v3 changes only the export timestamps. No music is added.

| Export start–end | Asset | Job | Check |
|---|---|---|---|
| 00:09.000–00:15.000 | `intermediate/lower-third.mov` | Identify hosts with 300ms wipe. | Existing composite/legibility sampled in v2; verify exact v3 timeline. |
| 00:35.400–00:45.330 | `graphics/company-model-app.png` | Simple taxonomy introduced by the company statement. | Existing composite/legibility sampled in v2; verify exact v3 timeline. |
| 01:31.233–01:49.333 | `graphics/car-analogy.png` | Show the maker/engine/car analogy during its spoken recap. | Existing composite/legibility sampled in v2; verify exact v3 timeline. |
| 07:16.267–07:23.267 | `graphics/model-names.png` | Reinforce the spoken correction after the name mix-up. | Existing composite/legibility sampled in v2; verify exact v3 timeline. |

No new graphic illustrates the work or safety discussion. The hosts remain on camera and the dialogue carries those sections. The `check-output.png` and `tokens.png` cards are designed assets but not used in this master because they do not coincide with a precise spoken definition/pickup.
