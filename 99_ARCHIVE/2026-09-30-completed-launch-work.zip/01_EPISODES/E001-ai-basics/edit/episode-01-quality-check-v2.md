# Episode 1 review-cut quality check v2

**Status:** Technically checked local proposal, ready for Josh and Mary's continuous review. This is not a host-approved release master. Check date: 2026-09-26.

## Source and deliverable

| Item | Finding |
|---|---|
| Source | `/Users/je/Movies/Episode 1 Raw.mp4`, 55:47.233, 1920 × 1080, 30 fps; SHA-256 `9f58d3a39c91ce4499fd3215355ddc9873051e6e32a5b26a6c73ce05caf93107` |
| Audio source | Four identical stereo mixes by stream hash; only one used. Independent speaker tracks are unavailable. |
| Proposed video | `episode-01-master-v2.mp4`, 9:58.367, 1920 × 1080, 30 fps H.264/AAC; SHA-256 `7aa20349617f55947b13b25b5024bdcf3c76f6cbfc1b363498eab21e693bae92` |
| Other deliverables | v2 WAV/MP3, SRT/VTT, final-timeline transcript, chapters; v1 branded thumbnail and graphics unchanged by the v2 splice fix. |

## Automated checks

- Full video and audio decode completed. The encoded master measures **-16.63 LUFS integrated** and **-1.13 dBTP**. Audio ends 0.033 seconds before video.
- No black spans were detected in the master. Video and audio packet decode timestamps increase strictly; largest absolute presentation gap versus the expected cadence is about one microsecond.
- Four source-to-output audio waveform samples at 00:20, 04:40, 07:40 and 09:32 each matched with zero measured offset. This checks edit placement, not original camera lip sync.
- Two quiet gaps of about 1.57 and 1.74 seconds were flagged at **08:52.325–08:53.896** and **09:30.487–09:32.226**. These occur within the closing recent-prompts exchange; judge their pacing in continuous playback.
- Captions contain 212 ordered cues, at most two lines of 42 characters. They were reconciled to the source transcript and remapped to v2 timing. Names and splice boundaries received targeted corrections. They have **not** received an auditory proofread.
- Source frames across the shoot, selected joins and the branded graphics were sampled, and the thumbnail was inspected at reduced size. No continuous picture-and-sound viewing was performed. Automated results cannot establish natural pacing, original lip sync, voice quality, caption accuracy or editorial approval.

Evidence: `intermediate/qc-v2/report.json`, `episode-01-packet-check-v2.json`, `episode-01-audio-alignment-v2.json`, `episode-01-caption-corrections-v2.json` and the reversible `episode-01-edit-decisions-v2.json`. The source file was not modified.

## Review on the exact v2 export

1. Watch and listen continuously, especially every join, the two closing pauses, the first company/model/app explanation and the end card/farewell.
2. Check original camera lip sync at the beginning, middle and end. The waveform check cannot answer this.
3. Proofread the captions against speech. Focus on **00:49** (harness), **05:44** (overlap), **08:15–08:24** (grade story), **08:37** (overlap), **09:10** (nonprofit prompt), and **09:52** (unclear closing phrase). The machine-aided wording is a draft.
4. Josh and Mary should decide whether to keep the coding-class grade/dyslexia story and mild profanity, and whether the 9:58 selection retains enough of their relationship and the lesson. The 55:47 source and v1 proposal remain available for changes.
5. Decide whether to record a short accuracy reminder. Suggested spoken pickup, in the hosts' own words: **“Start with one ordinary task. Ask questions as you go, and check anything important before you act on it.”** No synthetic line or pickup is in the master. The same caution appears in draft description copy.
6. Approve title, thumbnail, claims, captions and release copy before any upload or publication.

No host approval, scheduling, upload or publication has been verified.
