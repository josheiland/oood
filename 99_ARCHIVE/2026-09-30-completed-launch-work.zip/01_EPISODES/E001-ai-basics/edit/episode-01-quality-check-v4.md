# Episode 1 v4: automated quality check

**Superseded editorial proposal:** This file verifies the v4 export technically, but v4 incorrectly excluded verified Demis and sandbox-escape discussion. See the current v5 cut and its complete source-cut list.

Checked after the final chaptered export. This is a **technically checked review cut**, not a host-approved release master.

| Check | Result |
|---|---|
| Master | `episode-01-master-v4.mp4`, H.264, 1920 × 1080, 30 fps, 85,518 frames, 2850.600s |
| Sound | Stereo AAC, 48000 Hz; encoded audio/video duration difference 0.000000s |
| Loudness | -16.54 LUFS integrated; -1.09 dBTP true peak; LRA 4.80 LU |
| Chapters | 19 embedded chapters; separate Markdown list matches v4 timing |
| Captions | 1012 structurally valid ordered SRT cues, source-ASR-derived and **not listening-proofread**; VTT and transcript drafts alongside |
| Full-file decode | Passed. Machine black spans: 0; silence events: 4. See `intermediate/qc-v4-final/` for exact data. The intentional hand-cover ending can look dark. |
| File identity | Master SHA-256 `2d67e31aed70bcdae8496bd133386b1a7ddd2d7c1e78b0756223e7ff70965f4b`; source unchanged SHA-256 `9f58d3a39c91ce4499fd3215355ddc9873051e6e32a5b26a6c73ce05caf93107` |
| Picture treatment | Source camera only, no overlays/pop-ups; 23 internal four-frame picture/audio crossfades |

Automated checks: `{'frames_match_edl': True, 'duration_within_one_frame': True, 'audio_video_within_50ms': True, 'loudness_within_one_lu': True, 'true_peak_below_minus_one_db': True, 'chapters_present': True, 'source_hash_unchanged': True, 'no_generated_graphics': True, 'caption_structure': True}`.

The script decoded the full exported audio and video, checked durations, measured encoded loudness/true peak, scanned for black/silent spans, and validated captions structurally. This does **not** establish naturalness of every join, lip sync, intelligibility, speaker balance, caption wording, or continuous picture quality. Josh and Mary should watch and listen to this exact export continuously, including all joins and the opening/closing hand covers, and proof the captions by ear. The v4 research addendum documents the remaining medical-comparison caveat and dated/subjective claims. No upload, scheduling, publication or exact-export host approval is claimed.
