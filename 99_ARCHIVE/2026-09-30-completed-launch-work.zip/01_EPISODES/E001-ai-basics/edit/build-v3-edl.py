"""Build the fuller Episode 1 review EDL from exact v2 ranges and new source ranges."""
from copy import deepcopy
from pathlib import Path
import json

p=Path(__file__).resolve().parent
base=json.loads((p/'episode-01-edit-decisions-v2.json').read_text())
by_id={s['id']:s for s in base['segments']}
items=[]
def old(id, *, chapter=None, start=None, end=None):
    s=deepcopy(by_id[id]);s.pop('timeline_frame',None)
    if start is not None:s['in_frame']=round(start*30)
    if end is not None:s['out_frame']=round(end*30)
    if chapter is not None:s['chapter']=chapter
    items.append((s,[deepcopy(g) for g in base['graphics'] if g['segment']==id]))
def new(start,end,chapter,reason,affects):
    def frame(t):
        m,s=t.split(':');return round((int(m)*60+float(s))*30)
    a,b=frame(start),frame(end)
    assert b>a
    items.append(({'in_frame':a,'out_frame':b,'chapter':chapter,'reason':reason,'affects':affects},[]))

old('01')
old('02')
old('03')
old('04')
new('06:22.320','06:30.700','Open and closed models','Introduce availability of model weights without the inaccurate all-vendor blanket claim.','claim')
new('06:34.540','06:46.040',None,'Keep the core closed-weight distinction.','claim')
new('11:30.020','11:51.380',None,'Keep Mary\'s engine analogy and her preference for a ready-to-use tool.','analogy and host judgment')
new('11:59.660','12:29.660',None,'Explain why someone might adapt open weights; omit unsourced universal quality ranking.','claim')
old('05')
old('06',end=573.84)
new('09:33.840','09:54.480',None,'Include the concise multimodal explanation; review qualification that capabilities vary by model.','claim')
old('07')
old('08')
old('09',start=815.96)
old('10')
new('15:43.020','15:52.180','What changes for people?','Keep Mary\'s segue into the jobs discussion without the unsourced unsolved-problem premise.','transition')
new('15:57.900','16:43.380',None,'Keep the provocative take, immediate retraction/qualification, Good Will Hunting exchange and opening pushback.','host disagreement and opinion')
new('17:54.420','19:41.060',None,'Keep Josh\'s view of human judgment and Mary\'s partial reconsideration; the forecasts remain opinions.','host disagreement and opinion')
old('11',chapter='Learning by asking',start=1240.66,end=1282.1333333333)
new('21:22.140','22:23.240',None,'Keep Mary\'s personal concern about unequal access and why the show should make learning approachable.','host perspective')
old('12',start=1343.2333333333)
new('25:14.860','25:42.700','What skills matter?','Set up Mary\'s question about preparing for change versus hype.','host question')
new('25:50.780','27:49.200',None,'Keep her personal argument for communication, human connection and task-level learning.','host perspective')
new('27:49.380','28:19.220','Beyond the chatbot','Introduce Mary\'s switching-cost question as an opinion, not a market conclusion.','host question')
new('28:19.220','28:27.960',None,'Move from software to chips without the time-sensitive company valuation claim or incomplete hardware setup.','transition')
new('29:18.450','30:17.980',None,'Explain the role and graphics origins of GPUs; omit the interrupted battery analogy and imprecise chip-versus-GPU passage.','claim')
new('30:37.500','31:12.200',None,'Retain the moat/advantage joke and low-friction product switching as host observation.','host interaction and opinion')
new('33:24.820','34:17.800','Local models and the cloud','Keep Josh\'s failed attempt to run local models on his MacBook Air as personal experience.','host experience')
new('34:45.600','35:07.030',None,'Keep the consumer-choice reason for open models; omit unsupported quality ranking.','opinion')
new('35:24.600','35:48.520',None,'Explain that a provider can host a model even when weights are available.','claim')
new('36:05.200','36:33.960',None,'Keep Mary\'s direct open-model versus on-prem question.','host question')
new('36:33.960','36:51.560',None,'Explain on-prem as a location/hosting choice before the cloud example.','claim')
new('37:06.440','37:42.100',None,'Use Run Your City apps and the cloud joke for an accessible location distinction; omit blanket hospital-security assertion.','example and host interaction')
new('41:15.870','41:31.180','Caution and curiosity','Keep Mary\'s personal admission that she undervalues privacy.','host perspective')
new('41:37.300','41:48.750',None,'Keep her question about anthropomorphizing a model, then omit an absolute claim about feelings or incentives.','host perspective')
new('42:13.380','42:45.200',None,'Keep human responsibility for goals and guardrails as the hosts\' interpretation.','host perspective')
new('43:16.900','44:43.880',None,'Keep the clearly hypothetical paperclip example and Mary\'s response about balancing fear and optimism.','hypothetical and host disagreement')
old('13',chapter='One tool, one real task',start=1905.41)
old('14',chapter='What are you actually asking?',start=3168.16)
old('15')
old('16')

edl={k:deepcopy(base[k]) for k in ['source','source_sha256','fps','width','height','audio_stream','status']}
edl['title']='Out of Our Depth | Episode 1: AI basics and what changes for us'
edl['revision']='v3 fuller review proposal after Josh asked for a 25-30 minute episode. V2 remains the short comparison cut. New sections cover open weights, work and learning, GPUs, local/cloud, and a clearly hypothetical safety discussion.'
edl['segments']=[];edl['graphics']=[]
position=0
for i,(s,graphics) in enumerate(items,1):
    id=f'{i:02}';s['id']=id;s['timeline_frame']=position
    for g in graphics:
        g['segment']=id
        g['output_start']=position/30+g['start'];g['output_end']=position/30+g['end']
        edl['graphics'].append(g)
    edl['segments'].append(s)
    position+=s['out_frame']-s['in_frame']
edl['total_frames']=position
assert 25*60*30<=position<=30*60*30,position
assert len({s['id'] for s in edl['segments']})==len(edl['segments'])
source_frames=int(json.loads((p/'episode-01-source-inventory-v1.json').read_text())['metadata']['streams'][0]['nb_frames'])
assert all(0<=s['in_frame']<s['out_frame']<=source_frames for s in edl['segments'])
assert all(a['out_frame']<=b['in_frame'] or a['in_frame']>=b['out_frame'] for a,b in zip(edl['segments'],edl['segments'][1:])), 'Adjacent source ranges overlap'
assert all(o['end']<=next(s for s in edl['segments'] if s['id']==o['segment'])['out_frame']/30-next(s for s in edl['segments'] if s['id']==o['segment'])['in_frame']/30+0.001 for o in edl['graphics'])
(p/'episode-01-edit-decisions-v3.json').write_text(json.dumps(edl,indent=2)+'\n')
print(f'{len(items)} segments; {position/30:.3f} seconds ({position/1800:.2f} min); {len(edl["graphics"])} graphics')
