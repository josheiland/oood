# Episode 1 v6 theme preview: automated quality check

Checked 2026-09-28. This is a **private host-review comparison** because public rights for the proposed theme are unconfirmed.

| Check | Result |
|---|---|
| Video | `episode-01-theme-preview-v6.mp4`, 1080p30, 96,933 frames, 3231.100s, SHA-256 `068a7d129f04ad42d1dca616c0d8e0d93390019c839fcb62bdc8d93ca8adbd1e` |
| Audio | AAC stereo 48000 Hz; -16.56 LUFS; -0.07 dBTP true peak; video/audio duration delta 0.000000s |
| Chapters and captions | 22 embedded chapters; 1144 structurally checked SRT cues, not auditory-proofread |
| Complete decode | Passed; 0 machine black spans and 6 silence event markers. Logs in `intermediate/qc-v6-theme/` |
| Timeline | 00:00–00:10.167 cold open; 00:10.167–00:15.433 title/theme; 00:15.433–53:40.333 complete clean v6 cut; 53:40.333–53:51.100 two-ask outro/music |
| Sampled picture | `intermediate/v6-theme-sampled-frames.jpg` covers hook, title, episode boundaries, four pop-ups and outro |

Checks: `{'exact_frame_count': True, 'exact_duration': True, 'audio_video_within_50ms': True, 'loudness_within_one_lu': True, 'true_peak_below_minus_one_db': False, 'chapters_present': True, 'captions_ordered': True, 'main_master_present': True}`.

These machine checks do not establish continuous viewing quality, every join's sound, speaker balance, lip sync or exact caption wording. Both hosts should review the selected export and proof the captions by ear. The outro card text is “What should we try next? Tell us in the comments” and “Know someone figuring out AI? Send this their way”. No upload, scheduling or publication is claimed.
