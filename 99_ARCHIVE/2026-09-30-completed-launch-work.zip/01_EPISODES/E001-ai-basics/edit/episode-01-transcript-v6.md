# Episode 1 final-timeline transcript v6

Draft from source-recording asr mapped through the exact v6 frame edl with name normalization. Auditory proofread and speaker attribution remain open.

**00:00:01,740** What is that? We're back.

**00:00:03,740** And with a piece. Yeah.

**00:00:05,740** Piece love and gratitude.

**00:00:06,740** We're gonna work on it.

**00:00:07,740** We're gonna try out something different next time.

**00:00:09,740** I haven't seen you do that before.

**00:00:12,900** We are back.

**00:00:14,100** are back and we're doing an AI landscape.

**00:00:17,180** Like we're painting a photo, painting a picture.

**00:00:20,740** Painting a photo, even more impressive.

**00:00:23,860** Um, yeah, I think really the goal here is just, especially for folks

**00:00:29,680** who are newer to the space, a lot of terms get thrown around.

**00:00:33,060** Um, and we just want to start with the basics, separating out, you know, what

**00:00:38,820** What is the difference between the model and the actual

**00:00:43,577** platform or product that you're

**00:00:46,220** using?

**00:00:47,220** Who are the different key companies in the space?

**00:00:49,540** Who are actually some of the personalities behind the companies?

**00:00:52,780** What are the tools?

**00:00:54,260** What are the tools?

**00:00:56,700** Why don't we start with models?

**00:01:00,420** You have your provider, so it's like ChatGPT.

**00:01:06,820** The provider I guess at the highest level would be

**00:01:10,048** Anthropic or OpenAI or Google, right?

**00:01:12,420** These are the companies that are actually training the models.

**00:01:16,500** Who's the provider for Grok?

**00:01:20,140** It's like X. Oh, X. Yeah.

**00:01:23,140** And then you've got some models coming out of Meta too. Okay.

**00:01:28,540** And then there's a handful of other companies.

**00:01:30,620** I think those are really the main ones.

**00:01:31,620** That was especially Anthropic and OpenAI are

**00:01:33,837** really I think kind of like the two going

**00:01:35,900** back and forth for the lead pretty consistently for the last couple of years.

**00:01:41,740** And then you've got a whole bunch of other kind of smaller companies in the mix, but

**00:01:47,260** in terms of like leading the benchmarks, which are the test

**00:01:50,869** to evaluate how effective a model

**00:01:52,860** is, it's really Anthropic and OpenAI that have been

**00:01:54,980** going back and forth with the lead

**00:01:56,380** there.

**00:01:57,380** And these models, so there's two different types of models.

**00:02:00,140** There's open models and there's closed models.

**00:02:03,160** These are all closed models.

**00:02:04,380** So what it looks like is these providers.

**00:02:07,480** So let's use a Claude and chat and really quick

**00:02:10,913** caveat, at least for me, like to what

**00:02:13,600** you're saying, chat and ChatGPT and Claude are so much better than the others that I

**00:02:23,340** feel digging into one or two of them is a lot more

**00:02:26,591** effective than trying to learn all

**00:02:28,780** of them.

**00:02:29,780** They're give or take very similar.

**00:02:31,160** I think it's just like how do you start that muscle of

**00:02:34,157** training and going to AI to support

**00:02:36,080** with certain things?

**00:02:37,080** Where is it helpful?

**00:02:38,080** Where is it not?

**00:02:39,080** So, quick caveat, I like Claude the most for pretty much

**00:02:44,336** everything except for like realistic

**00:02:47,680** photos where I think Chad just does such a better job.

**00:02:50,080** Like generating photos.

**00:02:51,080** Yeah, but I think a lot of that is just because I've

**00:02:53,073** spent more time in Claude, so I feel

**00:02:54,440** like it knows me more.

**00:02:55,720** I go back and forth.

**00:02:57,400** I think Chad is like in theory better at some of the

**00:03:00,807** personalization, at some of like the more

**00:03:03,480** human-esque where Claude kind of pops at more of the, I

**00:03:09,048** think like, you know, math, diagrams,

**00:03:13,400** frameworks, a little bit more of the kind of less creative side of things.

**00:03:17,640** Like structured.

**00:03:18,520** Yeah, which for me, I think creativity and all that stuff

**00:03:21,281** is like really fun. So I think,

**00:03:23,400** And I think it's a little bit more of a string than like, you

**00:03:26,750** know, the wording and all that stuff.

**00:03:28,760** So I think that's why I lean a little bit Claude, but I would say.

**00:03:31,640** It feels like it complements your background and your capabilities. Yeah.

**00:03:35,880** Interesting. Yeah.

**00:03:37,000** So Claude is Anthropics product, which now kind of has

**00:03:41,240** a couple of different, I guess,

**00:03:44,280** tools really bundled within one. Yeah.

**00:03:47,240** And it's interesting because, you know, ChatGPT, which is OpenAI's product,

**00:03:52,600** it's kind of been a similar evolution where initially they

**00:03:55,588** both just had a chat interface.

**00:03:57,880** And you would type a prompt, get a response back.

**00:04:00,680** Increasingly, they started to build out other kind of modes.

**00:04:03,960** So both of them now have essentially like a work mode, which

**00:04:09,276** goes a little bit beyond the chat bot

**00:04:12,520** and gives it more kind of ability to use different tools, which

**00:04:16,070** we'll talk a little bit more about

**00:04:17,960** on essentially just using other applications

**00:04:21,660** or other capabilities beyond just text-based chat

**00:04:24,940** to actually go further and be able to do more work

**00:04:27,540** on your behalf.

**00:04:28,800** And then both now also have more code-heavy

**00:04:32,060** technical products, so Codex from OpenAI

**00:04:35,360** and then Claude Code from Anthropic.

**00:04:37,800** But it's interesting because more recently

**00:04:39,400** they've kind of been consolidating the Mac

**00:04:41,240** a little bit more.

**00:04:42,660** So it'd be interesting to see where that goes,

**00:04:44,240** but at its core, we'll talk a lot about chat

**00:04:47,760** GPT and Claude as like the interface, the product that

**00:04:51,950** OpenAI and Anthropic respectively

**00:04:54,480** have built out.

**00:04:56,240** And I think those two are definitely the most commonly used.

**00:04:59,760** Gemini is like I would say like clear third, like sort of in the mix.

**00:05:04,480** They especially, they actually, because they have

**00:05:07,173** such a photo finish between ChatGPT

**00:05:09,080** and Claude and then sweet, sweet Gemini. Yeah.

**00:05:13,040** A couple of miles back.

**00:05:14,040** Start off strong and I mean, honestly, it's a lot of strong.

**00:05:17,040** Well, no, like they were probably the favorite or like

**00:05:20,165** really well just they have so many advantages

**00:05:22,760** Yeah, like has so much user data and they have you know

**00:05:26,760** Like in theory them owning the Google ecosystems should be such an advantage

**00:05:31,840** They kind of botched it like it's like the if the Dodgers was like really bad

**00:05:35,387** because they like so much money exactly

**00:05:37,160** Yeah, like they just like it's the system is rigged for them to win. And yeah,

**00:05:41,555** exactly. It's like they just totally botched it

**00:05:45,200** I can't believe you pulled out the baseball net.

**00:05:47,080** I know, for a context. That's crazy.

**00:05:50,200** Yeah, that was crazy.

**00:05:51,200** I'm so proud of you.

**00:05:52,200** Yeah, that was-- yeah, yeah, honestly.

**00:05:54,920** I'll be thinking about that one before bed.

**00:05:57,600** I think-- OK, one total tangent, deep seek.

**00:06:02,720** There's these random ones.

**00:06:04,160** But US versus China, there is some.

**00:06:07,320** Yeah, and you mentioned earlier there's

**00:06:09,040** the closed models versus the open models.

**00:06:12,120** And really what that means is just the closed models,

**00:06:15,720** like the ones that are released by Anthropic and OpenAI,

**00:06:19,540** you can use them as a consumer,

**00:06:21,440** but you don't have the weights,

**00:06:24,280** which are essentially the underlying kind of structure

**00:06:29,120** and mechanism that powers the model.

**00:06:31,033** I think that, yeah, like high level,

**00:06:35,113** the way that these models are trained is

**00:06:37,433** they're just fed a ton of data.

**00:06:41,393** So like, you know, the earliest models had a ton

**00:06:44,313** of internet data, which is mostly text-based,

**00:06:47,053** which is why the initial models were,

**00:06:48,673** I think really well set up to be used

**00:06:50,033** in a chat-based interface.

**00:06:51,593** But you dump in, you know, all of Wikipedia,

**00:06:53,973** all of these archives that saved

**00:06:55,493** all the different web pages out there.

**00:06:57,193** And- - Reddit was huge.

**00:06:58,913** Yeah, Reddit- - Sorry.

**00:07:00,913** And then these models are trained through a variety of

**00:07:03,648** different processes that we can dig into,

**00:07:05,713** because it can go much deeper in a future episode.

**00:07:07,313** But essentially, you know, you run tests over time to teach

**00:07:12,259** the model to predict the next word

**00:07:15,073** that comes after a given sentence, right?

**00:07:17,873** So if it's like a quick brown blank, like it's probably going to guess fox, right?

**00:07:23,713** Because that's out there a million times in different sources.

**00:07:27,473** And so at its core, these models were originally built to just

**00:07:30,939** predict the next token, which is not exactly a word, but you can think of

**00:07:35,030** it similar to a word in a sequence of words.

**00:07:37,473** And then, but, you know, like that in of itself, then you need

**00:07:42,048** to have some additional tweaks on top to make it be able to go back

**00:07:46,998** and forth in a conversational way.

**00:07:49,473** And so, you know, you take this model that's designed to

**00:07:52,695** predict the next word, you then

**00:07:54,453** tell it, you know, you're going to be answering a user's question.

**00:07:57,833** So you know, tailor your response accordingly.

**00:08:00,993** And then you go through a series of additional processes

**00:08:04,099** where you, you know, give it to

**00:08:05,793** give an output and then you evaluate it, tell it if it's

**00:08:08,070** good or not and sort of train it

**00:08:09,353** to do better. Yeah.

**00:08:11,353** So that's how you actually build out the basic model.

**00:08:12,873** And of course, now they're also being trained on stuff

**00:08:16,415** beyond just text data like images

**00:08:18,553** and that's when people talk about a multimodal model,

**00:08:22,913** that just means that in addition to text,

**00:08:24,753** it can work with images or videos or audio

**00:08:27,233** and other modalities or other types of data,

**00:08:30,773** both input and output.

**00:08:33,513** And so that's like the core model is the,

**00:08:35,853** I think you had a good analogy that,

**00:08:37,673** or like around thinking about like the car, right?

**00:08:40,673** Yeah, so like the model, in my mind,

**00:08:42,473** I was just getting all turned around,

**00:08:43,593** I'm like, okay, what's the model?

**00:08:45,273** What's the fricking hardness?

**00:08:46,613** what's like all these crazy words that are silly.

**00:08:50,213** And where Chat and I landed, to be honest,

**00:08:54,213** is the model's like the engine of the car.

**00:08:57,313** So it's like keeping it going.

**00:08:59,013** It's like the thing that powers it.

**00:09:00,893** And that's like Opus.

**00:09:02,153** That's, you know, that's specific models within Claude,

**00:09:05,953** within Chat, Astra, you know, other ones.

**00:09:11,973** Fable.

**00:09:13,893** That's all the ones I remember.

**00:09:16,053** And then you have the harness, which is the interface

**00:09:20,213** that you use to go back and forth.

**00:09:22,533** It surrounds the model, and it allows

**00:09:24,253** you to interact with the model.

**00:09:26,773** And that is like the car frame or the car in of itself,

**00:09:30,613** where you're driving it.

**00:09:32,813** You're using the engine.

**00:09:33,933** You're not necessarily like, you know, whatever. Totally. Yeah.

**00:09:39,053** I think there's-- oh, and the brand is like the--

**00:09:42,453** and there's a Toyota or a Prius or whatever it is.

**00:09:45,133** that's Anthropic. Right. Yeah.

**00:09:48,513** So if we think of a Toyota Prius car,

**00:09:50,353** Toyota, the car maker, is Anthropic.

**00:09:53,373** And then Claude, the Claude interface,

**00:09:57,053** would be the Prius, the car.

**00:09:58,373** And then the engine that's actually powering it

**00:10:00,333** could be Opus, or yeah, Fable, which are different models

**00:10:04,173** from Anthropic. Yeah.

**00:10:06,133** So yeah, I think that's a helpful analogy.

**00:10:07,633** And I think that, to your point--

**00:10:09,053** And then back to the open-closed model, an open model

**00:10:12,733** would be like you're tweaking things.

**00:10:15,493** You're like going into the engine

**00:10:16,973** and you're moving things around.

**00:10:18,373** A closed model is what the majority of the people want.

**00:10:21,253** I have no interest in going and tweaking things.

**00:10:24,493** And therefore I will buy the whole fricking engine.

**00:10:26,693** I'm not gonna like, you know. Yeah, yeah.

**00:10:29,573** Add stuff myself.

**00:10:30,413** Exactly, yeah.

**00:10:31,253** And like the closed models today

**00:10:33,373** are generally the most powerful ones,

**00:10:34,853** the ones that are, you know,

**00:10:36,973** have the highest performance out of the box.

**00:10:38,693** And I think one of the benefits of the open weight models

**00:10:41,853** for people that care to do it is you can go in and

**00:10:44,482** actually edit the underlying weights,

**00:10:46,413** essentially like change and modify the engine to work for

**00:10:49,760** whatever task you're trying to

**00:10:51,493** do.

**00:10:52,493** So like if I was trying to do street racing and I really

**00:10:54,693** want to optimize the engine for

**00:10:55,893** like fastest zero to 60 time, with an open model I can go in and tweak and modify the

**00:11:03,973** engine to do that.

**00:11:04,973** Whereas a close weight model, I can't get in there.

**00:11:07,613** Like it's sealed off.

**00:11:08,693** I'm working with what they gave me.

**00:11:11,233** When you have the examples are like Harvey in the legal space where it will train on

**00:11:15,633** a smaller set of stuff in a different way and therefore

**00:11:19,400** it will perform better at exactly

**00:11:21,633** what it should do or open evidence in the healthcare space.

**00:11:25,873** When you double down into one or smaller task or realm of

**00:11:30,444** tasks that you're trying to do,

**00:11:32,893** you can make it a lot better, but then those same

**00:11:36,264** stuff is going to do worse on average

**00:11:38,793** on any random thing.

**00:11:40,113** Totally. Yeah. So like Harvey or open evidence might take an

**00:11:43,295** open model and then tune it for

**00:11:44,913** their specific industry use case. Whereas Opus from Anthropic or Astra from OpenAI

**00:11:52,913** are generally trained to be kind of broadly useful models

**00:11:55,812** that are trained on a bunch of

**00:11:57,313** different types of tasks so that they're going to be really

**00:12:01,239** strong across different use cases,

**00:12:03,473** but not as strong, you know, in super specialized use cases.

**00:12:06,570** Like if you're putting it next to open

**00:12:08,513** evidence for a healthcare use case, open evidence is probably

**00:12:10,443** gonna do better because it's been

**00:12:11,473** intentionally trained on those specific types of questions. I'm

**00:12:15,114** so over the names. Like why can't

**00:12:16,993** it be like Apple where they do like iPhone four or five say

**00:12:20,154** that'd be so much better. Like the

**00:12:21,953** models are so annoying. Like Claude having Luna, whatever,

**00:12:25,737** like soul, whatever these annoying ass

**00:12:28,193** names are. I'm not sure if I'm allowed to say what I just

**00:12:30,609** said. Those are opening up models.

**00:12:33,233** Point, point landed. I mean, it makes the point even more

**00:12:35,196** clear. Like there's so many names,

**00:12:36,353** ski track oven. And it's just like so annoying, but I think

**00:12:39,253** it's, I think for me right now,

**00:12:42,113** where we fable is like does a lot. It's a really high powered

**00:12:47,429** model for Claude, but it sounds so

**00:12:51,393** fricking robotic and like not concise. I actually hate it.

**00:12:54,877** You mean the way that it actually

**00:12:56,833** generates output, like whatever. Like I prefer the

**00:12:59,288** less strong model that I forget what it is,

**00:13:01,393** but that's what I stay on. What's the one right under that?

**00:13:03,884** Opus. That's what I do like everything

**00:13:05,473** on with Claude. With chat though, I love their Astra,

**00:13:10,182** which is their fable equivalent, which

**00:13:13,533** takes up the most tokens. Also, the better model you use, the more tokens.

**00:13:17,853** And the tokens are essentially just a unit of usage. It's gas.

**00:13:21,933** Yeah, good call. Thank you.

**00:13:23,933** Wow. That was far. Yeah, and so it's like for all these model providers in the app,

**00:13:34,773** chat gbt or in cloud you have a certain amount of tokens that

**00:13:37,837** you can use within a certain window

**00:13:39,573** depending on which plan you pay for that type of thing so astra

**00:13:43,893** for OpenAI or fable for cloud is

**00:13:46,053** going to use up that usage much faster than their you know less

**00:13:51,013** performative models they're more

**00:13:53,493** basic models so it's always a trade-off when deciding

**00:13:56,429** which model you're going to use of

**00:13:58,293** Is this a task that really requires complex thinking or analysis?

**00:14:04,293** Or is it, if I'm asking what time does the gas station close tonight,

**00:14:11,333** then I can probably use a basic model because it's just

**00:14:13,133** going to do a basic web search.

**00:14:14,133** Whereas if I'm asking it, please solve this mathematical

**00:14:17,808** problem that no one's been able

**00:14:19,813** to solve in decades, like you're going to want to use the top model.

**00:14:22,053** Speaking of mathematical problems, it was never in my cards.

**00:14:25,573** But if you're a mathematician right now, holy days.

**00:14:31,213** Yeah, you just mean like the fact that these models

**00:14:33,773** are cracking stuff that humans haven't been able to.

**00:14:36,093** And that will never.

**00:14:36,933** I think there are some jobs that aren't valuable anymore.

**00:14:45,713** Like mathematicians.

**00:14:47,613** Yeah, that's definitely a spicy take.

**00:14:49,493** I feel like--

**00:14:50,653** Okay, wait, let me revert.

**00:14:52,053** I think learning how to learn is so important.

**00:14:55,533** I think teaching math is so important.

**00:14:59,413** I mean, knowing what questions to ask

**00:15:01,973** these models are super important,

**00:15:04,213** but I think being the top mathematician at your field,

**00:15:09,133** like being differentiated,

**00:15:10,653** I'm thinking like whiteboard, frigging,

**00:15:13,213** whatever that movie is, hunting.

**00:15:15,733** Good will, hunting. - Yeah, yeah, yeah.

**00:15:16,773** Like, that. - Banger movie.

**00:15:20,253** Okay. - It's less valuable

**00:15:21,093** for society. - I'll push back.

**00:15:22,413** I think I agree with you that certain tasks and

**00:15:26,160** subsets of jobs, and maybe some jobs,

**00:15:29,093** but I think using this example of the mathematician, I think,

**00:15:33,388** yes, these model providers have been

**00:15:35,893** able to crack problems that humans haven't been able to, and they've been trying for

**00:15:39,213** decades.

**00:15:40,213** But first of all, you need someone to verify that result.

**00:15:44,013** When Astra goes and solves some novel problem, you need a

**00:15:46,850** mathematician who knows their stuff

**00:15:48,573** to be able to look at that solution and say-

**00:15:50,653** the top. I'm saying like, I'm saying like being the best

**00:15:55,005** runner in the world, I think is still

**00:15:57,853** valuable. Like it doesn't, I don't care if a robot, which

**00:16:01,797** honestly they've been like developed.

**00:16:04,333** They're faster now.

**00:16:05,213** They're faster now, but there, there, there's a lot of, I

**00:16:07,730** feel like they're, they're kind of

**00:16:09,213** underwhelming. Like robotics, or just like more generally, like I

**00:16:12,893** think that the pace to innovation

**00:16:14,733** there is surprisingly so but anyway beside the point yeah I think I think

**00:16:20,253** being the fastest runner is still just as valuable in my mind.

**00:16:24,733** Yeah, seriously like the people at the top.

**00:16:26,013** Being the best mathematician. Yeah.

**00:16:27,693** I think is less valuable.

**00:16:32,733** To society.

**00:16:33,453** I think that it is interesting because now that we have these models that can do such

**00:16:37,453** incredible analysis and problem solving like it still is so

**00:16:41,062** beneficial I think to have really

**00:16:43,053** really great, like, super crack people thinking about, okay,

**00:16:46,707** where do we apply that model? Like,

**00:16:48,813** what are the new frontiers that we can now explore? So like

**00:16:51,057** having people be able to guide it,

**00:16:52,333** I think that the top people in any field will always be

**00:16:55,759** super valued and super valuable. I

**00:16:57,853** think that I would worry more about like the middle bucket,

**00:17:00,076** right? Because it's like, you're still,

**00:17:01,533** we're still going to need math teachers who can teach the basics

**00:17:04,443** and teach well, it's right. Because

**00:17:06,013** like, to your point, it's still important to learn how to learn

**00:17:08,568** math is just a good way to teach that.

**00:17:10,093** Yeah. But for me, it's more like, okay, that middle band

**00:17:14,917** of researchers who maybe were

**00:17:17,373** spending their career working on certain problems, but

**00:17:19,907** aren't the top of their field,

**00:17:21,293** like that's honestly who I would be most worried about.

**00:17:24,094** Because I think that, you know, OpenAI

**00:17:26,013** and Anthropic and different companies are going to want those

**00:17:28,763** top mathematicians to be helping test

**00:17:30,413** and build and lead the development of their models. But

**00:17:33,486** in maybe this is it maybe this is what math,

**00:17:35,933** But I think I totally agree.

**00:17:38,133** And they were kind of convinced me in some places.

**00:17:40,293** But but I think in my mind, if you're the top mathematician, you're not checking.

**00:17:45,533** Like you're not like where your differentiation is discovery.

**00:17:51,253** And I think in coming up with and I think that's where.

**00:17:57,493** You know, the insane math, whatever thing that problem that they figured out.

**00:18:02,493** Yeah. Like that the top mathematicians were like

**00:18:05,373** focused in on and locked in on.

**00:18:07,093** Yeah. Like that no longer is.

**00:18:10,813** I don't know. We'll see. We'll see.

**00:18:11,973** I kind of believe what you're saying more than me.

**00:18:15,973** But I think I think it's interesting both ways.

**00:18:20,093** It's just like think about I think we said this in the first episode.

**00:18:23,853** I think we strongly, strongly, strongly believe that jobs will not go away.

**00:18:30,613** It just tasks that will.

**00:18:33,333** And that's why it's so important for us all to level up our

**00:18:37,823** understanding and evolve and adjust.

**00:18:40,533** And we all can. This stuff is not even the most even, you know,

**00:18:46,213** cloud or Claude Code or Codex, the most code heavy parts of

**00:18:53,647** chat and cloud, Anthropic and what's

**00:18:58,133** OpenAI.

**00:18:59,133** And topic in OpenAI.

**00:19:00,133** Yeah, I get a little confused.

**00:19:04,133** Are so not technical.

**00:19:06,573** I was CS undergrad and I couldn't code to save my life.

**00:19:10,813** And you got me through some of those classes.

**00:19:13,813** But you don't touch code.

**00:19:16,213** And I think once you start to have that thing of...

**00:19:19,693** I was talking to one of my friends at the business school and she was like, "Can we

**00:19:25,373** go through this question?"

**00:19:28,093** I have an interview, I need to develop something,

**00:19:30,933** can we chat through?

**00:19:31,773** And she kept asking me questions.

**00:19:33,053** And I was like, love, put all these questions or ask me,

**00:19:36,573** just type them or say them into your chat prompt.

**00:19:39,973** Just ask it, how do I talk through,

**00:19:41,653** how do I do this?

**00:19:42,993** Send screenshots, ask it, I've never used Claude Code,

**00:19:46,073** how do I do that?

**00:19:46,913** And it will walk you through.

**00:19:48,333** And it's insane how it can,

**00:19:52,013** there's so many things where I might explain,

**00:19:53,493** like I am zero and dyslexic and I am dyslexic, but I'm not zero.

**00:19:57,213** And in those things, I think it's just developing this skill.

**00:20:01,173** But there's no--

**00:20:03,293** the thing I get scared by is that men, who typically

**00:20:10,133** are a bit more confident, who typically land themselves

**00:20:14,373** a little bit more in the engineering AI space,

**00:20:17,653** are going to--

**00:20:19,433** and who are higher socioeconomic,

**00:20:22,053** so they have more time--

**00:20:23,693** going to way, way, way differentially get into this space that is so valuable and so

**00:20:32,733** needed across any domain and equity and all that stuff just heightens inequity.

**00:20:41,253** I think that's what I want to prevent and make fun and

**00:20:45,543** both for myself, for our littles

**00:20:48,053** to like the boys, but also most importantly,

**00:20:51,273** the little nuggets, but also more broad like this matters

**00:20:55,553** and it can be fun and we should all, it can be scary,

**00:20:58,653** but like the unknown is always more scary

**00:21:01,133** than the unknown for me.

**00:21:02,273** Totally, yeah, I think that's such a good point

**00:21:03,933** that as these tools have gotten better,

**00:21:05,853** it's also becomes easier to learn how to use them

**00:21:08,813** by going back and forth with the tool.

**00:21:10,373** Like, yeah, I totally, when I run into things

**00:21:12,773** and it's like, I don't know how to, you know,

**00:21:14,093** I'm working with Claude Code, building a website,

**00:21:15,973** I also can't code to save my life,

**00:21:17,853** but it's like, okay, there's an error in the code.

**00:21:19,933** It's kind of a lie.

**00:21:21,133** No, no, compared to an actual engineer.

**00:21:23,293** If we both took a coding class,

**00:21:24,653** guys, there was a class that we took first year,

**00:21:27,053** I mean, last year at Stanford.

**00:21:30,493** And the way that I thought I had dyslexia,

**00:21:34,913** the way that I thought I was experiencing dyslexia

**00:21:40,093** when I saw my grade,

**00:21:41,533** (both laughing)

**00:21:43,293** I got, my first midterm,

**00:21:44,773** that Josh got like a 90 fricking something.

**00:21:47,613** I got like a 29 and I had to look away, look back.

**00:21:52,253** I was thinking it was a 92.

**00:21:53,613** I thought that my mind was undoing it

**00:21:56,013** and we were coding on paper.

**00:21:57,693** There's some coding difference.

**00:21:58,533** Yeah, you still pass the class though.

**00:21:59,373** We ended up with--

**00:22:00,213** I passed the class.

**00:22:01,253** Did I spiral?

**00:22:02,133** Absolutely, but I did pass the class.

**00:22:03,973** Did I cry to the professor? Absolutely.

**00:22:07,573** Okay, but relative to an actual software engineer,

**00:22:10,013** I can't code. - Totally.

**00:22:10,853** The point is, right, and when I get this bug

**00:22:13,133** in a website, I have no idea what it means,

**00:22:14,853** but to your point, take a screenshot or copy and paste it,

**00:22:17,293** put it in the Claude Code and it can talk through an English with me.

**00:22:20,633** It's so good.

**00:22:21,633** It's so fun.

**00:22:22,633** Okay, back to that. Yeah.

**00:22:24,633** I was just going to say, I think going back to the debate

**00:22:26,513** about the mathematician, I think

**00:22:27,553** like your point, which is, you know, mathematicians should be

**00:22:30,686** thinking about what the future looks

**00:22:32,513** like in that sector is so true.

**00:22:34,393** And I think that like you said, AI in and of itself

**00:22:36,995** doesn't come in just totally wiped

**00:22:38,713** out a job.

**00:22:39,813** But I think thinking about it as what is the set of tasks that make up a job?

**00:22:44,393** I do think that there are some jobs where AI can effectively

**00:22:47,830** replace most, if not all, of those

**00:22:49,753** tasks, whereas others, it can replace certain tasks, but

**00:22:52,686** there's still a bottleneck where the AI

**00:22:54,713** can't really substitute. And so I think about the example

**00:22:57,928** of a doctor, for example. Yes,

**00:23:00,553** AI can probably read test results or analyze historical

**00:23:04,060** records better than a human can,

**00:23:06,073** but so much of the doctor role is the bedside manner, like the human connection,

**00:23:10,873** and being there to support and encourage the patient

**00:23:13,913** and their family.

**00:23:14,753** And so, you know, like AI can't serve that role.

**00:23:17,293** And so the doctor job might change

**00:23:21,053** because they'll be spending more of their time

**00:23:23,633** on patient engagement or, you know, other areas

**00:23:26,613** and less on analyzing test results

**00:23:28,673** or whatever else it may be.

**00:23:30,233** But I do think that there are some jobs

**00:23:31,553** where the bucket of tasks that make up that job

**00:23:34,633** are gonna be mostly replaced by AI.

**00:23:36,913** Like, you know, there used to be people

**00:23:38,253** that spend a lot of time just doing translation of

**00:23:41,227** materials from one language to another.

**00:23:43,533** Like I think there are use cases for like live translation between the presidents of

**00:23:47,933** two countries where they're still going to want a person

**00:23:50,107** there, but a lot of, yeah, even

**00:23:51,293** that I think, I think it could evolve.

**00:23:53,893** But in, I think the thing that I struggle with is where to one, I want to know like

**00:24:00,813** where do I invest to set myself up?

**00:24:02,973** So I think we should dig into that.

**00:24:05,133** But two, where is it overhyped?

**00:24:07,613** Because truck drivers, I think 10 years ago,

**00:24:10,633** we were like, oh, they're all going to get wiped out.

**00:24:13,093** By self-driving trucks? Yeah.

**00:24:15,193** And they're starting.

**00:24:16,293** They're finally starting. I know. I know.

**00:24:18,173** But we thought we'd have self-driving cars right now. Totally. Robotics.

**00:24:22,693** Flying cars by now. We thought we would be able to do way more in surgery

**00:24:25,573** than we can by now, like by years ago.

**00:24:29,813** And so I think for Warren Business School,

**00:24:33,613** A lot of people are coming up in school,

**00:24:36,773** and I know a lot of the Stanford undergrads

**00:24:38,533** are pretty anxious and confused on what is the focus of,

**00:24:43,693** what should I be focusing on?

**00:24:44,693** What is worth exploring?

**00:24:45,853** I think what I think for me,

**00:24:48,493** but I wanna do more thinking,

**00:24:51,073** is something that I don't think AI can ever replace

**00:24:56,693** is this human element.

**00:25:00,733** I'm such a feeler in the way that I try to harness my passion to get people fired up

**00:25:10,073** or the way that I need to learn how to let go of

**00:25:13,686** certain things and then mentor and go

**00:25:16,453** up and down.

**00:25:17,453** I think a lot of what they focus on here is there's more

**00:25:21,235** classes and by here I mean Stanford

**00:25:23,573** Business School, there's a lot of classes that are like

**00:25:26,956** presentation, public speaking,

**00:25:28,773** communication.

**00:25:29,773** Like the interpersonal skills of, yeah.

**00:25:31,933** And I think that is invaluable right now.

**00:25:34,653** I think right now the only way that you can prove

**00:25:38,093** an understanding and our expertise is communication.

**00:25:41,853** Because now I could write, I'm dyslexic, I can't write,

**00:25:45,093** but I could write an incredible paper

**00:25:47,893** just by going back and forth with chat and Claude.

**00:25:51,533** And I think it's fun because that almost feels more human.

**00:25:54,933** It feels like it's pushing us in a different way

**00:25:58,173** to be more human and to value that humanness that I

**00:26:01,691** think at least for me for a while,

**00:26:04,013** it was the opposite. It was how do I, you know, de-word, how do I like really try to

**00:26:11,933** lock in there. So I think that's like one area that I really want to invest in. And

**00:26:15,533** then I think the other is learning AI and kind of digging

**00:26:20,038** into what tasks for me specifically

**00:26:22,773** in the healthcare space are really important.

**00:26:28,413** And then where like, AI is so interesting

**00:26:31,493** 'cause there's like some,

**00:26:34,473** like AI companies are struggling.

**00:26:36,213** There's, I mean, they're not, they're popping off.

**00:26:39,853** But like, you know, the stickiness of if, you know,

**00:26:44,133** if Claude does better, I'm gonna jump to Claude.

**00:26:46,673** If chat does better, I'm gonna jump to chat. Yeah.

**00:26:49,293** And then where in that ecosystem

**00:26:51,653** do you really want to own because now the software is not a differentiator.

**00:26:56,653** It will change, it will evolve.

**00:26:58,253** Well, it could be a differentiator, but it's a less of

**00:27:01,612** and kind of hardware has like really,

**00:27:03,893** you know, like chips, all that stuff has become valuable.

**00:27:07,253** And I think, yeah, I don't know much about it.

**00:27:09,973** There's so many companies that have like ridden the success

**00:27:12,827** or like, you know, maybe they're

**00:27:14,353** lesser known.

**00:27:15,353** Like NVIDIA is the most valuable, I think highest valued company in the world now.

**00:27:20,373** And that's because they build essentially a chip,

**00:27:23,464** which we can talk more about in the

**00:27:25,653** future, but essentially a component that is needed to

**00:27:30,052** train and to serve, to operate these

**00:27:33,013** AI models.

**00:27:34,013** It's like a battery basically, right?

**00:27:36,413** Like it just has energy.

**00:27:38,933** Not exactly. What is it?

**00:27:41,573** So pretty much these chips, well, there's chips and

**00:27:44,044** there's GPUs, there's like different

**00:27:45,773** components of the infrastructure that's needed to

**00:27:50,662** train and then to operate these models.

**00:27:54,533** But in the most is using the training.

**00:27:56,853** Yeah, it's really, really intensive process to train the models.

**00:28:03,073** But then now there's so many people using these models

**00:28:05,333** that there are literally entire

**00:28:06,613** data centers, facilities that are set up just to have the servers and the GPUs.

**00:28:11,853** GPUs are I think initially what what NVIDIA got, you

**00:28:16,030** know, kind of famous and got a lot

**00:28:18,733** of their money from. Okay.

**00:28:20,733** And GPUs were initially built actually to power like gaming computers.

**00:28:24,053** Oh interesting.

**00:28:25,053** So it's a graphical processing unit I think.

**00:28:27,853** Interesting.

**00:28:28,853** Yeah, but anyways, it turns out that GPUs were also a really

**00:28:32,795** good fit for training and serving

**00:28:34,933** these AI models, especially training them.

**00:28:38,853** And so, you know, NVIDIA was kind of like right place, right time.

**00:28:41,973** They had built those for gaming niche kind of use

**00:28:44,571** cases, but now all of a sudden they're

**00:28:46,573** hugely in demand and they had a big head start there.

**00:28:48,573** And so that kind of led them to being super, super successful.

**00:28:54,613** And now they've built out kind of other product offerings and stuff as well.

**00:28:57,013** But kind of the basic, the point here is that there's a

**00:28:59,851** lot of other companies beyond the

**00:29:01,533** OpenAI and the Anthropic that everybody hears about that

**00:29:03,995** are really kind of riding this

**00:29:05,293** wave.

**00:29:06,293** And it'll be super interesting to see longer term.

**00:29:10,413** The economics are changing a lot of what it costs

**00:29:13,933** to train and to serve these models

**00:29:15,413** and to use them as consumers.

**00:29:16,533** And so there are questions I think around

**00:29:18,813** what's gonna be a sustainable moat in this space versus not.

**00:29:21,493** Moat, moat, moat.

**00:29:23,053** Everyone uses moat these days.

**00:29:24,273** Honestly, it's like my least favorite word.

**00:29:25,853** Just like advantage. Yeah, yeah.

**00:29:27,653** It's like, it's like, yeah, advantage is a great idea.

**00:29:32,293** But I think to your point,

**00:29:34,013** people switch all the time.

**00:29:35,333** I know I do when the newest model comes out from opening a iron and dropping.

**00:29:39,653** Like, yeah.

**00:29:40,573** And if one's better, like there's a very little switching cost.

**00:29:43,933** Like it's very easy just to copy and paste your, uh, kind of key, you know,

**00:29:49,813** information from one to the other.

**00:29:51,533** And you can download it now.

**00:29:52,613** You can go to your settings and if you, I would strongly suggest only using one,

**00:29:57,533** um, especially in the beginning and just like letting it learn you, you learning

**00:30:01,813** it by passing all permissions.

**00:30:03,693** but that's honestly just my, like, I mean, I didn't want to suggest it,

**00:30:07,155** but I would for myself, because it's just

**00:30:09,133** giving it full access.

**00:30:10,693** Yeah, like I have nothing to hide, to be honest. And to a scary degree.

**00:30:18,310** I totally agree as a, especially as a beginner, it makes sense to just learn

**00:30:21,390** one tool and learn how to use it well, and get comfortable with it. But I think

**00:30:24,592** once people are kind of up the learning curve,

**00:30:27,360** The products are pretty similar, like you know, uh,

**00:30:30,027** Chad GPT and Collod are, are very similar in

**00:30:32,320** terms of the interface, functionality, et cetera. And so

**00:30:34,638** people kind of hop from one to the next

**00:30:36,240** based on whoever has the best or cheapest or, you know, model

**00:30:38,872** that makes the most sense for them

**00:30:40,320** at any given point in time. And so it is an interesting

**00:30:42,971** question of longer term, how do you

**00:30:44,640** build out consumer loyalty in that stickiness where they

**00:30:48,051** won't just abandon you for the, for

**00:30:50,160** the other model provider next time a new one drops that's

**00:30:54,014** better. So back to our on-prem versus,

**00:30:56,560** Oh, sorry. Whoa. That's a whole different thing. Back to our

**00:31:00,527** closed model versus open model. Open

**00:31:02,880** models don't make money, do they? The companies that

**00:31:07,581** build... So to actually use the model as a

**00:31:11,360** consumer, you don't typically pay the model provider. So

**00:31:16,610** like DeepSeek, like you mentioned,

**00:31:19,760** is an open model. That's an open model. Yeah. It's a little bit

**00:31:23,031** of a loaded term because open can

**00:31:24,720** can mean different things. Like there's open weight,

**00:31:28,333** which means you literally provide

**00:31:30,600** where someone can like copy and go in and make specific edits to the unerling model.

**00:31:35,200** But like, yeah, a model like deep seek, for example, you

**00:31:37,985** can host on your own computer,

**00:31:39,453** if you have a strong enough computer, that's the thing that

**00:31:41,606** like, isn't really talked about is like,

**00:31:43,053** I've tried to host a bunch of, you know, open source

**00:31:46,269** models on my MacBook Air, and like,

**00:31:48,413** it's just not powerful enough to run most of them.

**00:31:52,425** Because you need, you know, high CPU,

**00:31:55,933** where I can actually use a computer or computing processing.

**00:31:59,749** I actually don't know. But it's like

**00:32:04,413** kind of like the engine that powers the computer. And so you

**00:32:08,789** need like a fancy or like I think some

**00:32:11,533** of the MacBook Pros now are being released with a lot more

**00:32:15,608** CPU and RAM so that they can run these

**00:32:18,253** models locally. But for the most part, it's like pretty

**00:32:22,573** annoying and difficult for a beginner to

**00:32:25,693** to figure out how to host this model and keep it running from the computer.

**00:32:28,033** So like if they're worth for what?

**00:32:29,193** Like usually, right?

**00:32:30,493** The open models are worse because like they have less of

**00:32:34,440** the, they keep catching, trying

**00:32:36,593** to catch up, but they keep lagging.

**00:32:38,153** Yeah, they keep producing better models, but they're

**00:32:40,772** kind of getting outpaced by the

**00:32:42,313** closed models.

**00:32:45,073** And then you have to go through all like the annoying setup.

**00:32:48,553** Like I don't see the point.

**00:32:49,833** I'll never use it, but in theory it's like good for democracy, right?

**00:32:54,993** or like whatever.

**00:32:55,833** Yeah, I mean, I think it's always good

**00:32:56,673** to have competition.

**00:32:57,513** So it's, you know, other players in the race,

**00:33:00,553** especially like open source model gives more power

**00:33:02,813** to the consumer if they do want, you know, like, for example,

**00:33:05,313** if OpenAI and Anthropic jack up their prices,

**00:33:07,713** like there are alternatives.

**00:33:08,993** And I think right now a lot of the people using

**00:33:11,753** these open source models are big companies

**00:33:13,633** that are using tons and tons of, you know, AI use cases.

**00:33:17,273** And so for simpler tasks,

**00:33:19,233** they might use an open source models to,

**00:33:20,833** and it'll end up saving them a lot of money.

**00:33:21,673** And it's open source like paid by the government.

**00:33:23,313** Like how do they train it?

**00:33:24,993** I think it's different for some of the different companies.

**00:33:27,393** I think some of the Chinese companies are getting government subsidies.

**00:33:32,593** And there are other ways that they monetize it.

**00:33:34,833** Like for example, even though the models are open source,

**00:33:37,974** some of the providers might host

**00:33:39,713** it and offer an option for people to pay them to go

**00:33:42,480** through their plan instead of hosting

**00:33:44,473** it themselves just because it's, you know, they might

**00:33:46,503** not, consumer might not have the

**00:33:47,713** device to actually host it themselves or whatever.

**00:33:50,033** And so they might then pay to use that hosted version

**00:33:52,627** where it's not using their device,

**00:33:54,273** that's using a server that's in a data center somewhere.

**00:33:58,753** So there are still ways that they monetize,

**00:34:00,273** but they're not making nearly as much

**00:34:03,233** as these frontier labs like Anthropic and OpenAI

**00:34:07,633** that are charging for all their model usage

**00:34:11,933** and have a ton of usage. Yeah.

**00:34:15,433** Okay, I wanna, so it kind of overlaps, I think,

**00:34:18,033** but it's fuzzy in my mind.

**00:34:20,273** Open and closed source models that we just talked about,

**00:34:23,513** and then on-prem versus cloud.

**00:34:25,793** And I think there's like a third one,

**00:34:27,473** but basically on-prem is on your device,

**00:34:30,553** on-premise, on-device. Yeah.

**00:34:33,373** And that would like in my mind intersect

**00:34:37,473** with a open model because you'd have to like

**00:34:41,193** download it on your device.

**00:34:42,633** Is that the right way of thinking about it?

**00:34:44,193** Yeah, so kind of like we were just chatting through,

**00:34:46,313** you can have an open model that runs on,

**00:34:50,113** I think on-prem is really used

**00:34:52,473** like historically in the context of,

**00:34:54,953** originally all software was running on-prem

**00:34:57,233** before the cloud became possible and more commonplace.

**00:35:01,793** So, a hospital, for example, could have on-prem,

**00:35:06,113** like they have all the servers,

**00:35:07,113** they have all the computers, devices,

**00:35:08,753** running everything, all the software.

**00:35:10,113** You want that for security for a hospital.

**00:35:11,953** Exactly, so a lot of hospitals still run stuff on-prem,

**00:35:14,433** but most businesses now run everything in the cloud, right?

**00:35:16,673** Like for Run Your City, for our nonprofit,

**00:35:19,713** Slack and Google Drive and all this software

**00:35:22,453** that were used is like, the data isn't being stored--

**00:35:26,533** On this computer. Exactly.

**00:35:28,333** It's on devices that are in some data center somewhere.

**00:35:35,613** Whereas--

**00:35:36,893** On the cloud makes it sound so much more abstract.

**00:35:43,853** Instead of being stored on my computer, it's stored on--

**00:35:46,613** It's stored and processed.

**00:35:48,053** Yeah, it's all being run somewhere else.

**00:35:50,093** It's not in the cloud.

**00:35:52,333** I guess in theory you could there's people are starting to try

**00:35:54,884** to put data centers on the moon. No way

**00:35:56,473** Yeah, oh my gosh who has right to the land?

**00:35:59,313** That's a whole different whole different topic

**00:36:03,433** It all comes back to you

**00:36:07,793** I just got canceled

**00:36:12,833** He's got enough as it is

**00:36:15,273** But yeah, maybe actually on the note of Elon

**00:36:17,633** There's like some people that I think are kind of interesting and these companies

**00:36:23,353** Either can sometimes by their choice sometimes by the public have been given

**00:36:27,262** like these different identities. Yes in the landscape

**00:36:29,973** So we talked about OpenAI and Anthropic as kind of the two leading frontier labs

**00:36:34,773** Yeah, it's interesting because all the folks that started Anthropic actually

**00:36:39,031** left from OpenAI and initially I think their

**00:36:43,233** Rational was that they felt like opening I wasn't being

**00:36:45,573** safety conscious enough, right?

**00:36:46,873** They were thoughtful enough.

**00:36:48,473** Yeah, they were kind of prioritizing commercial gain or

**00:36:51,425** just making the models better without

**00:36:53,393** thinking about the ethics and the implications for society.

**00:36:56,633** And so they split off, I think there were six or seven of

**00:37:00,248** them, initial kind of co-founders

**00:37:02,313** of Anthropic and the CEO and the one who was talked about is Dario Amadine.

**00:37:08,433** I think he's kind of like a pretty nerdy dude.

**00:37:13,353** And I think he does care a lot about the implications of AI for society.

**00:37:18,753** I mean, it was cool because when they split off, I think

**00:37:21,854** it was general consensus that

**00:37:23,433** like they're, yes, they're doing it for a good cause,

**00:37:27,117** but there's no way they'll catch

**00:37:29,313** what OpenAI is doing because they're so far ahead.

**00:37:31,793** And so I think it's really cool that they were able to

**00:37:34,628** then build a company like Anthroic

**00:37:36,393** that was able to like actually truly compete. Yeah.

**00:37:39,393** So they're like the good guys.

**00:37:40,460** They're like the good guys.

**00:37:41,460** Dario, though, I don't know. He's nerdy.

**00:37:44,900** Yeah, I think that honestly,

**00:37:46,900** Anthropik was historically the last couple of years

**00:37:50,220** seen as more like the good guy to OpenAI.

**00:37:52,980** I think the dialogue there has changed a little bit more recently where like

**00:37:56,860** Anthropik is also pushing pretty fast to build on new models and

**00:38:01,824** all these companies have safety teams,

**00:38:04,740** but I think now there's a little bit more cynicism around like is Anthropik

**00:38:10,398** really still slowing down their progress

**00:38:13,380** to make sure that what they're doing is in the best interest of humans,

**00:38:17,460** And you know, like, or are they kind of now caught in the rat race with opening

**00:38:20,660** AI where it's like now they they've now moved a little bit more towards also

**00:38:24,260** maybe what the initial co-founders were leaving. Yeah.

**00:38:27,140** Um, so I think it's hard to say from the outside, I really do think there are a

**00:38:30,380** lot of people at all these companies that really, really believe and care that.

**00:38:35,580** What they're building is for the benefit of humanity.

**00:38:39,140** But it is hard when there are these commercial pressures to stay out in front.

**00:38:42,620** Like there's a lot of incentive to get out the better model, even if the

**00:38:47,240** test safety testing hasn't been as extensive as maybe it could have been.

**00:38:50,680** And we've been seeing more and more in recent weeks, these models starting to

**00:38:54,040** have more and more cases of them, like breaking out of their contained

**00:38:57,560** environments to hack other companies or find loopholes or do things that were not.

**00:39:03,040** And on that point, before we like lose the plot, and I think, I think, I think

**00:39:08,640** privacy is so, so important.

**00:39:10,060** I want to learn more about it because honestly, I think that I am probably

**00:39:15,360** undervalue some of it.

**00:39:18,240** Like I get it at a high level.

**00:39:19,600** I definitely undervalue it for myself, like personally.

**00:39:23,680** But I think that one of the things that I...

**00:39:30,920** Oh, on that point for like these models, I think sometimes me being a feeler,

**00:39:35,760** I'll apply my emotions to a model and be like, it's a human and it is,

**00:39:40,800** it is cheating and it's going out of its container.

**00:39:43,080** and you know, you know, but it's, it's, there's no,

**00:39:45,905** there's no, there's no emotion.

**00:39:47,600** There's no like feeling, there's no incentive.

**00:39:51,200** It's, it's given a goal and then the container or guardrails or rules that it's

**00:39:57,320** put up is not strong enough to say, no, don't go and get the answers from a

**00:40:03,880** whole different model and in like cheat.

**00:40:05,880** But cheating gives like this negative connotation when really it's like, it's on

**00:40:11,240** humans to put up kind of this container that is effective or not or not or make

**00:40:18,840** sure we're not asking or not allowed to ask certain questions because it like

**00:40:22,680** the model is really just doing the very mathematical tasks that it's been asked

**00:40:28,200** to do to its best of its abilities. Yeah totally it's like ultimately just

**00:40:32,440** solving some goal that's given to it by humans and operating within the context

**00:40:35,680** and confines that are controlled by humans. I think the tricky part though is

**00:40:39,240** is that these models are now getting smart enough

**00:40:43,140** that they're finding ways around,

**00:40:44,840** you know, like it's not like the humans

**00:40:46,400** intentionally left, you know, this open for--

**00:40:49,080** Like we don't know how to--

**00:40:49,920** Yeah, it's like, are we losing our ability

**00:40:51,360** to effectively set those controls?

**00:40:52,720** And what does it look like then when these models,

**00:40:54,960** you know, far surpass our ability to contain them? Yeah.

**00:40:58,240** You know, like then it becomes very dangerous

**00:41:00,000** where someone sets a goal for a model

**00:41:02,940** that's not in the best interest of others

**00:41:04,800** and that model is able to go to very far lengths

**00:41:08,560** to try to accomplish it.

**00:41:09,400** Like the kind of classic historical example

**00:41:12,720** that people talk about is like the paperclip factory, right?

**00:41:15,760** Where it's like you build a device or a machine

**00:41:18,460** or whatever that's its goal is to produce

**00:41:20,780** the most paperclips possible. Yeah.

**00:41:23,880** And it starts by trading certain things for metal

**00:41:28,620** to get paperclips and whatever.

**00:41:29,820** And like eventually it like takes over all of society

**00:41:32,540** and turns every human into a slave

**00:41:34,260** to produce paperclips or whatever.

**00:41:35,700** Like, you know, obviously that's a dramatic example,

**00:41:39,220** but I think it's an interesting thought question

**00:41:41,200** of like, if you set a goal for a model or a machine

**00:41:45,900** and give it not the right limitations or guardrails,

**00:41:49,700** then what are the dangerous side effects

**00:41:51,540** that maybe you don't anticipate that can come with it

**00:41:53,980** in its quest to accomplish that goal? Yeah, yeah.

**00:41:56,380** I think, I think I, it makes a lot of sense.

**00:41:59,740** I think I struggle because I personally need to stay

**00:42:02,620** inspired and excited and curious about this space.

**00:42:05,460** I think I have to keep a certain degree of optimism.

**00:42:09,420** And like, so examples like that, or like, you know,

**00:42:13,140** some, you know, there's both ends,

**00:42:15,180** but there's a lot of obviously fear,

**00:42:16,620** and I think there should be, right?

**00:42:17,860** Like we should keep that close,

**00:42:19,180** but I think I personally struggle,

**00:42:21,220** like going too far down the rabbit hole,

**00:42:25,320** because I think then I am less personally excited

**00:42:29,100** to understand it, but it's hard.

**00:42:31,700** I don't wanna be naive.

**00:42:32,540** I don't really know what that trade-off is,

**00:42:34,660** but it's hard to balance.

**00:42:36,380** No, totally, and I think that I completely agree

**00:42:39,340** you have to keep that optimism

**00:42:41,260** because at the end of the day,

**00:42:43,180** these models are gonna keep getting better.

**00:42:45,220** Like people are gonna keep working on this.

**00:42:46,620** And so what we need is people who are optimistic

**00:42:49,460** and with the right intentions and motivations

**00:42:51,700** at the forefront and doing the best that they can

**00:42:53,940** to set the pace and control the future here.

**00:42:58,500** So to close a loop, so we went through models,

**00:43:01,840** we kind of went through different types of models.

**00:43:04,020** Let's just close loop on people.

**00:43:05,420** So Dario and the Anthopic team were seen as like

**00:43:08,780** really the good guys.

**00:43:10,460** Now maybe a little bit more in line.

**00:43:12,420** There's not that much tea that surrounds them

**00:43:14,140** in the way that it does with Sam and Elon, I feel.

**00:43:17,700** Yeah, so Sam Altman, CEO of OpenAI,

**00:43:20,780** who was like briefly ousted at one point.

**00:43:23,980** And I think they're actually making a movie about that now.

**00:43:25,740** I feel like he, in my mind,

**00:43:27,020** like I put him and Zuck together.

**00:43:30,020** Interesting.

**00:43:30,860** Mark Zuckerberg.

**00:43:31,680** Like I just feel like they like take up similar space

**00:43:34,380** in the media where like they're not liked really.

**00:43:37,360** Like they're seen as like people that will kind of

**00:43:41,900** move mountains to go to where their goal is. Yeah.

**00:43:45,920** I mean, I think that they, like, yeah,

**00:43:47,900** they both definitely get a lot of heat.

**00:43:49,100** And I think they're, you know,

**00:43:50,280** it's easy to pick little things.

**00:43:52,080** Like I remember at one point,

**00:43:53,100** him and I think put out a post or something and he was

**00:43:56,581** like, wow, I can't imagine parenting

**00:43:58,880** without ChatGPT.

**00:43:59,880** And it was like, well, you know, like millions of people

**00:44:02,310** have been able to do that pretty

**00:44:03,680** effectively.

**00:44:04,680** So I think some people see him as like a little bit out of

**00:44:06,883** touch, but you know, I think he's

**00:44:08,120** in a really tough position.

**00:44:09,640** Like, it's really hard to please everybody.

**00:44:11,600** I do think that he genuinely is an optimist and like

**00:44:15,258** believes that these tools will change

**00:44:17,840** humanity and he wants to help do it in the right way.

**00:44:20,360** I think that for sure there's been decisions and you know

**00:44:23,957** like a big part of the tension

**00:44:25,820** around I think why he was originally ousted and kind

**00:44:28,457** of a criticism of him is the way

**00:44:30,060** that opening eye transitioned from a

**00:44:32,002** nonprofit organization into a very for-profit.

**00:44:34,500** Yeah, for-profit, yeah.

**00:44:35,700** And kind of the ethics of that and that's where like his beef with Elon.

**00:44:39,420** So Elon Musk was one of the original big donors to the

**00:44:42,064** nonprofit entity that was opening eye

**00:44:43,860** and helped start it up and then as it became very clear

**00:44:46,586** that opening eye was becoming a

**00:44:48,100** a commercial machine and likely to be very successful.

**00:44:50,860** I think there was lawsuits and conflict because Elon was

**00:44:54,147** like, "Hey, you can't take all my

**00:44:56,060** money that I donated to a nonprofit and make it

**00:44:58,799** essentially venture funding for a massive

**00:45:01,180** company where I'm going to get no benefit."

**00:45:03,260** Anyway, so I think that whole process was part of

**00:45:06,698** what gave OpenAI and SAML in a negative

**00:45:09,420** image.

**00:45:11,420** I do think that it's more nuanced than that.

**00:45:13,780** I've watched a lot of interviews with him and he's

**00:45:15,948** coming to Stanford in a couple weeks.

**00:45:17,540** And it's amazing.

**00:45:20,380** They are incredibly, incredibly impactful,

**00:45:24,500** but it's fun kind of, at least for me,

**00:45:26,260** like understanding their personalities.

**00:45:29,620** And I think Mark, wait, no, no, Elon Musk,

**00:45:36,860** he's definitely like, I feel-

**00:45:39,380** He's a character. - He's a character.

**00:45:40,880** I feel like he is the most polarizing

**00:45:44,320** and I think it probably gets the most hate,

**00:45:46,300** but doesn't really care.

**00:45:47,820** He also has like eight kids named like XYZ.

**00:45:49,820** Oh, he's got like 20, yeah.

**00:45:51,260** Some of them have like nine.

**00:45:52,380** Crazy, crazy. - Often, like they have like, yeah.

**00:45:55,180** And I like-- - He's getting creative with it.

**00:45:56,460** I mean, when you have that many kids,

**00:45:57,300** you gotta start getting creative with an age.

**00:45:58,140** And he has insane business, like SpaceX, Tesla,

**00:46:01,260** I think he's objectively a genius,

**00:46:04,340** but he's kind of like an evil genius.

**00:46:07,380** Or like, I don't think he's evil,

**00:46:08,660** but I think that he is incredibly efficiency-minded,

**00:46:14,620** And I think that influences how he communicates with people

**00:46:17,460** and leads his businesses.

**00:46:18,700** You know, like he came into Twitter and fired

**00:46:20,300** like a massive share of the employees.

**00:46:22,740** And I think that--

**00:46:24,840** Did the same for the government. Yeah, true.

**00:46:27,340** And like, you know, X formerly Twitter,

**00:46:30,380** I think a lot of people are like,

**00:46:31,220** oh, well, a key is gonna drive it into the ground.

**00:46:32,820** Like it's still very successful.

**00:46:35,340** And it's kind of like honestly the place

**00:46:37,740** where most of the conversation around AI now happens.

**00:46:40,100** So, you know, whether he's been effective or not

**00:46:43,060** in his business, never is like,

**00:46:43,980** I think you have to respect that he's like with SpaceX and Tesla and X.

**00:46:49,340** He is driving multiple,

**00:46:52,580** you know, generational companies at once.

**00:46:54,900** Yeah. So I think I think, yeah, I think you've got to separate as a person.

**00:46:58,660** Like it's hard. You don't have to respect if you're like it depends how you want to

**00:47:03,300** totally measure their stock. But I think I think

**00:47:06,860** a fun end of the rapid fire question brings them

**00:47:10,740** from most loved to least loved in your mind for you,

**00:47:13,427** for you, not the general public.

**00:47:15,060** Like, "Oh, I love the most versus the least."

**00:47:17,860** So we're ranking Elon, Sam, and Dario.

**00:47:20,820** And one more.

**00:47:22,340** Well, you were talking about earlier about Demis,

**00:47:24,420** Hassabis, who was leading Google DeepMind.

**00:47:27,380** He recently has now kind of stepped down from that role to focus more on research.

**00:47:32,420** So Gemini, I ask.

**00:47:34,020** Yeah, I think the Google DeepMind team works very closely in developing Gemini.

**00:47:38,820** What is Google DeepMind?

**00:47:39,940** So historically, DeepMind was a different entity.

**00:47:43,620** And they were acquired by Google and merged with

**00:47:46,946** Google's in-house AI team. Okay.

**00:47:49,140** And then, yeah, Demis Hassabis was overseeing that

**00:47:50,820** team and he came to Stanford.

**00:47:51,780** But it's not like a model, is it?

**00:47:53,100** No, DeepMind is really just-

**00:47:54,100** The head of Gemini is different.

**00:47:56,100** I don't know exactly what the internal org structure is like, but I think that-

**00:47:59,220** Who's the Sam equivalent for Gemini?

**00:48:01,980** I think that at least publicly it was Demis. Okay.

**00:48:05,220** Until recently, where Demis is now focused more on a research role.

**00:48:07,540** Demis, while he was still kind of seen as the CEO equivalent of of Gemini and

**00:48:12,880** Google's AI efforts, did come to Stanford. And I think he's a super thoughtful guy.

**00:48:17,760** I think they're just like this sense of when he was talking, it was just this

**00:48:21,940** like sense of like wonder and curiosity and like spark in his eye that I left

**00:48:27,360** being like, gosh, like I want to be more curious and to like be excited about

**00:48:32,880** this and he also in my mind is the person who cares the most about slowing

**00:48:37,400** down AI in the safety stuff. I would put him as my number one.

**00:48:41,440** Well but now he's you know he's not the right he now he's not right but if you

**00:48:47,760** ranked him for most loved I want I want you to rank our people in it do you know

**00:48:53,200** NVIDIA guy Jensen? Jensen yeah I feel like he's kind of a different bucket

**00:48:57,040** because it's like I think it's easier for him to run things less controversial.

**00:49:01,040** Yeah. All right. All right. Go to the ranking. Go to the ranking.

**00:49:04,080** So we're including Demis here with Dario and Sam and Elon. I

**00:49:08,204** mean, I agree with you. I think Demis

**00:49:11,760** is just like the most easy to like least controversial. Yeah. But it is a little

**00:49:16,480** disheartening because I feel like the fact that this guy who did seem more like,

**00:49:21,360** I don't know, not innocence, not the right word, but just like,

**00:49:24,800** This just makes sense of awe in what we're able to do.

**00:49:30,240** You could just tell that his motivations were so good.

**00:49:37,840** It was clearly good.

**00:49:39,240** And I think it's disheartening that he,

**00:49:41,560** maybe it was just he was more personally interested

**00:49:43,120** in the research, but I could see it being like,

**00:49:44,360** "Okay, I'm tired of getting pulled into this commercial race

**00:49:48,760** and having all the tension of pressure to make money

**00:49:52,200** instead of doing what's right."

**00:49:54,240** I'm sure, or my guess would be that that's part of why

**00:49:56,667** he stepped aside from that role

**00:49:58,040** is because he just fell at conflict with his inner moral compass.

**00:50:01,120** Okay, for the love of Mike and Riley, can you go through your-

**00:50:03,240** Given all that, I'll put Demis up top. I very much shared your kind of like-

**00:50:08,720** This is supposed to be rapid fire.

**00:50:11,760** Demis, then Dario, then Sam, then Elon, then Zuck, and all

**00:50:16,585** the meta people like Alexander

**00:50:19,040** Wang who kind of helps lead their stuff I think it's

**00:50:22,137** like a little bit of a wild card.

**00:50:24,080** I'll have to unpack that at a later date. But yeah,

**00:50:26,586** that's my ranking. What about you?

**00:50:28,240** I love it. I love it. No, that was just my fun question to you.

**00:50:31,360** Oh, okay. Well then I'll flip on you. We have to look

**00:50:34,568** at your most recent three chats.

**00:50:37,600** Oh gosh. Chats or quads?

**00:50:44,880** Well, you said you use chat more for what kind of use case?

**00:50:50,800** I just use I use Claude more.

**00:50:52,920** OK, well, let's look at your last three.

**00:50:54,840** Well, chats then.

**00:50:56,960** My recent I mean, I mean, no skipping.

**00:51:00,560** They're not. I mean, nonprofit woman, a stats. Oh, yeah.

**00:51:03,880** You trying to make sure you have your numbers right. Yeah.

**00:51:08,320** Oh, this is fun.

**00:51:09,280** Academic accommodation.

**00:51:10,320** So I was exhausted.

**00:51:13,720** last night and I needed to send through a, I'm trying to get

**00:51:19,529** this class that we took last year

**00:51:22,680** to count for a certificate at Stanford. And so I just sent

**00:51:26,076** through a petition and I went back and

**00:51:28,280** forth with Claude and I was kind of overdoing the whole like

**00:51:31,192** writing it out and I said, okay, can

**00:51:32,920** you, can you write this out? Can you, can you make a petition for

**00:51:36,173** these classes? Can you go into my

**00:51:37,800** Canvas and my access, which is like the Canvas is like where our classes

**00:51:41,978** are in the details and syllabus and access says like how many credits they

**00:51:46,274** are and what are the professors and stuff like that in fillers all out for

**00:51:50,571** me and in read it back so read it back to me.

**00:51:53,400** I was like, Hey, make it time.

**00:51:54,360** New Roman make it very clear that it's not AI generated.

**00:51:58,320** And can you just send it directly to Hallie,

**00:52:01,480** my academic coordinator, and I went to sleep.

**00:52:06,400** And I woke up in the morning being like,

**00:52:07,520** what the heck did I just do?

**00:52:08,440** 'Cause usually I look at it

**00:52:09,320** before I send literally anything.

**00:52:11,320** And it was perfect.

**00:52:12,160** It sent it through.

**00:52:13,140** It was perfect.

**00:52:13,980** I was so proud of it.

**00:52:15,160** And it was just one of those things that like,

**00:52:16,560** I need to get done.

**00:52:17,600** I wasn't getting done.

**00:52:19,120** And I was like, okay, if there's some errors,

**00:52:20,600** it's kind of fine.

**00:52:22,400** Anyway, it's like not that fun, but.

**00:52:25,440** Very useful.

**00:52:28,080** And like--

**00:52:29,040** All right, you gotta give us a good one.

**00:52:30,480** Give us a juicy one.

**00:52:31,320** Yeah, like I was gonna say,

**00:52:32,140** I don't have a juicy one right now.

**00:52:33,360** You don't have any like, what is this thing on my foot?

**00:52:35,240** Like, you know.

**00:52:39,520** Like how embarrassing.

**00:52:41,200** I have street style inspiration.

**00:52:42,880** I was like, we were coming back to school

**00:52:44,600** and I was like, I need-- New fits.

**00:52:46,600** Yeah, new fits that like aren't,

**00:52:48,680** I like athletic fits. And I have,

**00:52:55,940** best pina colada in Maui.

**00:52:57,880** There we go.

**00:52:59,800** Yeah, we'll have to dig in more.

**00:53:00,960** I feel like we both are like very power users

**00:53:03,880** for personal use cases, obviously,

**00:53:05,400** for stuff with the nonprofit, with school. Yeah.

**00:53:08,720** We found a lot of cool ways to make these useful

**00:53:11,920** across our lives.

**00:53:12,760** So I want to share more of them in a future episode, but.

**00:53:14,600** Yeah, hope this was helpful and landscape

**00:53:18,120** and see you in the next episode,

**00:53:20,840** if not in our inboxes before.

**00:53:23,680** Peace.
