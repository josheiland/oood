"""Map source chapter anchors through the v4 frame edit."""
from pathlib import Path
import json

P=Path(__file__).resolve().parent
edl=json.loads((P/'episode-01-edit-decisions-v4.json').read_text())
anchors=[
 (15,'Opening and the AI landscape'),
 (75.42,'Companies, models, and apps'),
 (382.32,'Open and closed models'),
 (471.88,'How a model learns'),
 (600.00,'The engine analogy'),
 (813.44,'Choosing a model'),
 (943.02,'Work and human skills'),
 (1240.66,'Learning by asking'),
 (1435.00,'The coding-class story'),
 (1514.86,'What skills matter'),
 (1699.22,'NVIDIA and GPUs'),
 (1943.66,'Open weights and local models'),
 (2165.20,'On-prem and cloud'),
 (2287.40,'The people behind the companies'),
 (2450.12,'Safety, limits, and optimism'),
 (2715.30,'The founders and their reputations'),
 (2963.66,'A rapid-fire ranking'),
 (3168.16,'Our recent chats'),
 (3205.12,'A real use case from Mary'),
]

def map_time(t):
    f=round(t*edl['fps'])
    for s in edl['segments']:
        if s['in_frame']<=f<s['out_frame']:
            return (s['timeline_frame']+f-s['in_frame'])/edl['fps']
    return None

chapters=[(map_time(t),name) for t,name in anchors]
chapters=[(t,name) for t,name in chapters if t is not None]
def stamp(t):
    m,s=divmod(int(t),60)
    return f'{m:02}:{s:02}'
body='# Episode 1 v4 chapters\n\nReview-cut timeline; no on-screen cards or pop-ups.\n\n'
body+='\n'.join(f'- {stamp(t)} {name}' for t,name in chapters)+'\n'
(P/'episode-01-chapters-v4.md').write_text(body)
meta=[';FFMETADATA1',f'title={edl["title"]}','artist=Josh and Mary']
for i,(t,name) in enumerate(chapters):
    end=chapters[i+1][0] if i+1<len(chapters) else edl['duration_seconds']
    meta+=['[CHAPTER]','TIMEBASE=1/30000',f'START={round(t*30000)}',
           f'END={round(end*30000)}',f'title={name}']
(P/'intermediate/v4-chapters.ffmeta').write_text('\n'.join(meta)+'\n')
print(body)
