"""Frame-based E001 v6 render with four-frame joins and four brief cards."""
from pathlib import Path
import json
import subprocess
import sys

P = Path(__file__).resolve().parent
edl = json.loads((P/'episode-01-edit-decisions-v6.json').read_text())
segments = edl['segments']
fps = edl['fps']
fade_frames = edl['transition']['frames']
fade = fade_frames / fps
out = P/'episode-01-master-v6.mp4'
if out.exists() and '--test' not in sys.argv:
    raise SystemExit(f'Preserving existing export: {out}')

args = ['ffmpeg', '-nostdin', '-hide_banner', '-y']
for s in segments:
    start = s['in_frame']/fps
    duration = s['raw_frames']/fps
    args += ['-ss', f'{start:.9f}', '-t', f'{duration:.9f}', '-i', edl['source']]
for cue in edl['graphics']:
    asset=P/cue['asset']
    assert asset.is_file(),asset
    card_seconds=(cue['end_frame']-cue['start_frame'])/fps
    args += ['-loop','1','-framerate',str(fps),'-t',f'{card_seconds+0.5:.9f}',
             '-i',str(asset)]

filters = []
for i,s in enumerate(segments):
    frames = s['raw_frames']
    samples = frames*1600
    filters += [f'[{i}:v:0]fps={fps},trim=end_frame={frames},setpts=PTS-STARTPTS,format=yuv420p[v{i}]',
                f'[{i}:a:0]aformat=sample_rates=48000:channel_layouts=stereo,'
                f'apad=whole_len={samples},atrim=end_sample={samples},asetpts=N/SR/TB[a{i}]']

vlast='v0'; alast='a0'; cumulative=segments[0]['raw_frames']
for i,s in enumerate(segments[1:],1):
    vnext=f'vx{i}'; anext=f'ax{i}'
    offset=(cumulative-i*fade_frames)/fps
    filters.append(f'[{vlast}][v{i}]xfade=transition=fade:duration={fade:.9f}:offset={offset:.9f}[{vnext}]')
    filters.append(f'[{alast}][a{i}]acrossfade=d={fade:.9f}:c1=tri:c2=tri[{anext}]')
    vlast=vnext; alast=anext; cumulative+=s['raw_frames']
intervals=[]
cursor=0
for card_index,cue in enumerate(edl['graphics']):
    assert cursor<=cue['start_frame']<cue['end_frame']<=edl['total_frames']
    if cursor<cue['start_frame']:
        intervals.append((cursor,cue['start_frame'],None))
    intervals.append((cue['start_frame'],cue['end_frame'],card_index))
    cursor=cue['end_frame']
if cursor<edl['total_frames']:
    intervals.append((cursor,edl['total_frames'],None))
filters.append(f'[{vlast}]split={len(intervals)}'+''.join(f'[base{i}]' for i in range(len(intervals))))
for i,(start,end,card_index) in enumerate(intervals):
    trimmed=f'trim{i}' if card_index is not None else f'seg{i}'
    filters.append(f'[base{i}]trim=start_frame={start}:end_frame={end},'
                   f'setpts=PTS-STARTPTS[{trimmed}]')
    if card_index is not None:
        cue=edl['graphics'][card_index]
        card=f'card{card_index}'
        filters.append(f'[{len(segments)+card_index}:v:0]format=rgba,setsar=1[{card}]')
        filters.append(f"[{trimmed}][{card}]overlay=x={cue['overlay_x']}:"
                       f"y={cue['overlay_y']}:format=auto:shortest=1:repeatlast=0,"
                       f'format=yuv420p[seg{i}]')
filters.append(''.join(f'[seg{i}]' for i in range(len(intervals)))+
               f'concat=n={len(intervals)}:v=1:a=0,format=yuv420p[vout]')
filters.append(f'[{alast}]highpass=f=60,loudnorm=I=-16:TP=-1.7:LRA=11,'
               f'aresample=48000,apad=whole_len={edl["total_frames"]*1600},'
               f'atrim=end_sample={edl["total_frames"]*1600},asetpts=N/SR/TB[aout]')
graph=P/'intermediate/v6-filtergraph.txt'
graph.write_text(';'.join(filters)+'\n')
args += ['-filter_complex_threads','2','-filter_complex_script',str(graph),
         '-map','[vout]','-map','[aout]',
         '-c:v','libx264','-threads','4','-preset','veryfast','-crf','19',
         '-profile:v','high','-pix_fmt','yuv420p','-r',str(fps),'-fps_mode','cfr',
         '-video_track_timescale','30000','-color_primaries','bt709',
         '-color_trc','bt709','-colorspace','bt709',
         '-c:a','aac','-b:a','256k','-ar','48000',
         '-map_metadata','-1','-metadata',f'title={edl["title"]}',
         '-movflags','+faststart']
if '--test' in sys.argv:
    args += ['-t','150',str(P/'intermediate/v6-popup-test.mp4')]
else:
    args += [str(out)]
print(f'Rendering {edl["duration_seconds"]:.3f}s from {len(segments)} segments',flush=True)
subprocess.run(args,check=True,stdout=(P/'intermediate/v6-render-stdout.log').open('w'),
               stderr=(P/'intermediate/v6-render-stderr.log').open('w'))
print('Render complete',flush=True)
