# Episode 1 final-timeline transcript v3

Draft from source-recording asr mapped through the exact v3 frame edl with name normalization. Auditory proofread and speaker attribution remain open.

**00:00:00,067** We are back and we're doing an AI landscape.

**00:00:03,147** Like we're painting a photo, painting a picture.

**00:00:06,707** Painting a photo, even more impressive.

**00:00:09,827** Um, yeah, I think really the goal here is just, especially for folks

**00:00:15,647** who are newer to the space, a lot of terms get thrown around.

**00:00:19,027** Um, and we just want to start with the basics, separating out, you know, what

**00:00:24,787** What is the difference between the model and the actual

**00:00:29,544** platform or product that you're

**00:00:32,187** using?

**00:00:33,187** Who are the different key companies in the space

**00:00:35,453** The provider I guess at the highest level would be

**00:00:38,681** Anthropic or OpenAI or Google, right?

**00:00:41,053** These are the companies that are actually training the models.

**00:00:45,440** Yeah, so like the model, in my mind,

**00:00:47,240** I was just getting all turned around,

**00:00:48,360** I'm like, okay, what's the model?

**00:00:50,040** What's the freaking harness?

**00:00:51,380** what's like all these crazy words that are silly.

**00:00:54,980** And where Chat and I landed, to be honest,

**00:00:58,980** is the model's like the engine of the car.

**00:01:02,080** So it's like keeping it going.

**00:01:03,780** It's like the thing that powers it.

**00:01:05,660** And that's like Opus.

**00:01:06,920** That's, you know, that's specific models within Claude,

**00:01:10,720** within Chat, Astra, you know, other ones.

**00:01:16,740** Fable.

**00:01:18,660** That's all the ones I remember. Totally. Yeah.

**00:01:22,053** I think there's-- oh, and the brand is like the--

**00:01:25,453** and there's a Toyota or a Prius or whatever it is.

**00:01:28,133** that's Anthropic. Right. Yeah.

**00:01:31,513** So if we think of a Toyota Prius car,

**00:01:33,353** Toyota, the car maker, is Anthropic.

**00:01:36,373** And then Claude, the Claude interface,

**00:01:40,053** would be the Prius, the car.

**00:01:41,373** And then the engine that's actually powering it

**00:01:43,333** could be Opus, or yeah, Fable, which are different models

**00:01:47,173** from Anthropic. Yeah.

**00:01:49,133** So yeah, I think that's a helpful analogy

**00:01:50,467** Yeah, and you mentioned earlier there's

**00:01:52,173** the closed models versus the open models.

**00:01:55,253** And really what that means is just the closed models,

**00:01:58,840** you can use them as a consumer,

**00:02:00,740** but you don't have the weights,

**00:02:03,580** which are essentially the underlying kind of structure

**00:02:08,420** and mechanism that powers the model.

**00:02:10,333** And then back to the open-closed model, an open model

**00:02:14,000** would be like you're tweaking things.

**00:02:16,760** You're like going into the engine

**00:02:18,240** and you're moving things around.

**00:02:19,640** A closed model is what the majority of the people want.

**00:02:22,520** I have no interest in going and tweaking things.

**00:02:25,760** And therefore I will buy the whole fricking engine.

**00:02:27,960** I'm not gonna like, you know. Yeah, yeah.

**00:02:30,840** Add stuff myself.

**00:02:31,667** And I think one of the benefits of the open weight models

**00:02:34,820** for people that care to do it is you can go in and

**00:02:37,449** actually edit the underlying weights,

**00:02:39,380** essentially like change and modify the engine to work for

**00:02:42,727** whatever task you're trying to

**00:02:44,460** do.

**00:02:45,460** So like if I was trying to do street racing and I really

**00:02:47,660** want to optimize the engine for

**00:02:48,860** like fastest zero to 60 time, with an open model I can go in and tweak and modify the

**00:02:56,940** engine to do that.

**00:02:57,940** Whereas a close weight model, I can't get in there.

**00:03:00,580** Like it's sealed off.

**00:03:01,667** like high level,

**00:03:02,647** the way that these models are trained is

**00:03:04,967** they're just fed a ton of data.

**00:03:07,813** And then these models are trained through a variety of

**00:03:10,548** different processes that we can dig into,

**00:03:12,613** because it can go much deeper in a future episode.

**00:03:14,213** But essentially, you know, you run tests over time to teach

**00:03:19,159** the model to predict the next word

**00:03:21,973** that comes after a given sentence, right?

**00:03:24,773** So if it's like a quick brown blank, like it's probably going to guess fox, right?

**00:03:30,613** Because that's out there a million times in different sources.

**00:03:34,373** And so at its core, these models were originally built to just

**00:03:37,839** predict the next token, which is not exactly a word, but you can think of

**00:03:41,930** it similar to a word in a sequence of words.

**00:03:44,373** And then, but, you know, like that in of itself, then you need

**00:03:48,948** to have some additional tweaks on top to make it be able to go back

**00:03:53,898** and forth in a conversational way.

**00:03:56,373** And so, you know, you take this model that's designed to

**00:03:59,595** predict the next word, you then

**00:04:01,353** tell it, you know, you're going to be answering a user's question.

**00:04:04,733** So you know, tailor your response accordingly.

**00:04:07,893** And then you go through a series of additional processes

**00:04:10,999** where you, you know, give it to

**00:04:12,693** give an output and then you evaluate it, tell it if it's

**00:04:14,970** good or not and sort of train it

**00:04:16,253** to do better. Yeah.

**00:04:18,253** So that's how you actually build out the basic model.

**00:04:19,773** And of course, now they're also being trained on stuff

**00:04:23,315** beyond just text data like images

**00:04:25,453** and that's when people talk about a multimodal model,

**00:04:29,813** that just means that in addition to text,

**00:04:31,653** it can work with images or videos or audio

**00:04:34,133** and other modalities or other types of data,

**00:04:37,673** both input and output.

**00:04:40,400** So Claude is Anthropics product, which now kind of has

**00:04:44,619** a couple of different, I guess,

**00:04:47,647** tools really bundled within one. Yeah.

**00:04:50,607** And it's interesting because, you know, ChatGPT, which is OpenAI's product,

**00:04:55,967** it's kind of been a similar evolution where initially they

**00:04:58,955** both just had a chat interface.

**00:05:01,247** And you would type a prompt, get a response back.

**00:05:04,047** Increasingly, they started to build out other kind of modes.

**00:05:07,327** So both of them now have essentially like a work mode, which

**00:05:12,643** goes a little bit beyond the chat bot

**00:05:15,887** and gives it more kind of ability to use different tools, which

**00:05:19,437** we'll talk a little bit more about

**00:05:21,327** on essentially just using other applications

**00:05:25,027** or other capabilities beyond just text-based chat

**00:05:28,307** to actually go further and be able to do more work

**00:05:30,907** on your behalf.

**00:05:32,167** And then both now also have more code-heavy

**00:05:35,427** technical products, so Codex from OpenAI

**00:05:38,727** and then Claude Code from Anthropic.

**00:05:41,167** But it's interesting because more recently

**00:05:42,767** they've kind of been consolidating the Mac

**00:05:44,607** a little bit more.

**00:05:46,027** So it'd be interesting to see where that goes,

**00:05:47,607** but at its core, we'll talk a lot about chat

**00:05:51,127** GPT and Claude as like the interface, the product that

**00:05:55,317** OpenAI and Anthropic respectively

**00:05:57,847** have built out.

**00:05:59,657** , quick caveat, I like Claude the most for pretty much

**00:06:04,632** everything except for like realistic

**00:06:08,047** photos where I think Chat just does such a better job.

**00:06:10,447** Like generating photos.

**00:06:11,447** Yeah, but I think a lot of that is just because I've

**00:06:13,440** spent more time in Claude, so I feel

**00:06:14,807** like it knows me more.

**00:06:16,087** I go back and forth.

**00:06:17,767** I think Chat is, in theory, better at some of the

**00:06:21,283** personalization, at some of the more

**00:06:23,847** human-esque where Claude kind of pops at more of the, I

**00:06:29,415** think like, you know, math, diagrams,

**00:06:33,767** frameworks, a little bit more of the kind of less creative side of things.

**00:06:38,007** Like structured.

**00:06:38,887** Yeah, which for me, I think creativity and all that stuff

**00:06:41,648** is like really fun. So I think,

**00:06:43,767** And I think it's a little bit more of a string than like, you

**00:06:47,117** know, the wording and all that stuff.

**00:06:49,127** So I think that's why I lean a little bit Claude, but I would say.

**00:06:52,007** It feels like it complements your background and your capabilities. Yeah.

**00:06:56,247** Interesting. Yeah.

**00:06:57,267** I'm so over the names. Like why can't

**00:06:59,260** it be like Apple where they do like iPhone four or five say

**00:07:02,421** that'd be so much better. Like the

**00:07:04,220** models are so annoying. Like Claude having Luna, whatever,

**00:07:08,045** like Sol, whatever these annoying-ass

**00:07:10,460** names are. I'm not sure if I'm allowed to say what I

**00:07:12,764** just said. Those are OpenAI models.

**00:07:15,500** Point, point landed. I mean, it makes the point even more

**00:07:17,463** clear. Like there's so many names,

**00:07:18,620** ski track oven. And it's just like so annoying, but I think

**00:07:21,520** it's, I think for me right now,

**00:07:24,380** where we fable is like does a lot. It's a really high powered

**00:07:29,696** model for Claude, but it sounds so

**00:07:33,660** fricking robotic and like not concise. I actually hate it.

**00:07:37,144** You mean the way that it actually

**00:07:39,100** generates output, like whatever. Like I prefer the

**00:07:41,555** less strong model that I forget what it is,

**00:07:43,660** but that's what I stay on. What's the one right under that?

**00:07:46,151** Opus. That's what I do like everything

**00:07:47,740** on with Claude. With

**00:07:49,133** always a trade-off when deciding which model you're going to use of

**00:07:52,860** Is this a task that really requires complex thinking or analysis?

**00:07:58,860** Or is it, if I'm asking what time does the gas station close tonight,

**00:08:05,900** then I can probably use a basic model because it's just

**00:08:07,700** going to do a basic web search.

**00:08:08,700** Speaking of mathematical problems, it was never in my cards.

**00:08:12,207** But if you're a mathematician right now, holy days.

**00:08:17,833** I think there are some jobs that aren't valuable anymore.

**00:08:26,613** Like mathematicians.

**00:08:28,513** Yeah, that's definitely a spicy take.

**00:08:30,393** I feel like--

**00:08:31,553** Okay, wait, let me revert.

**00:08:32,953** I think learning how to learn is so important.

**00:08:36,433** I think teaching math is so important.

**00:08:40,313** I mean, knowing what questions to ask

**00:08:42,873** these models are super important,

**00:08:45,113** but I think being the top mathematician at your field,

**00:08:50,033** like being differentiated,

**00:08:51,553** I'm thinking like whiteboard, frigging,

**00:08:54,113** whatever that movie is, hunting.

**00:08:56,633** Good will, hunting. - Yeah, yeah, yeah.

**00:08:57,673** Like, that. - Banger movie.

**00:09:01,153** Okay. - It's less valuable

**00:09:01,993** for society. - I'll push back.

**00:09:03,300** I think that it is interesting because now that we have these models that can do such

**00:09:07,287** incredible analysis and problem solving like it still is so

**00:09:10,896** beneficial I think to have really

**00:09:12,887** really great, like, super crack people thinking about, okay,

**00:09:16,541** where do we apply that model? Like,

**00:09:18,647** what are the new frontiers that we can now explore? So like

**00:09:20,891** having people be able to guide it,

**00:09:22,167** I think that the top people in any field will always be

**00:09:25,593** super valued and super valuable. I

**00:09:27,687** think that I would worry more about like the middle bucket,

**00:09:29,910** right? Because it's like, you're still,

**00:09:31,367** we're still going to need math teachers who can teach the basics

**00:09:34,277** and teach well, it's right. Because

**00:09:35,847** like, to your point, it's still important to learn how to learn

**00:09:38,402** math is just a good way to teach that.

**00:09:39,927** Yeah. But for me, it's more like, okay, that middle band

**00:09:44,751** of researchers who maybe were

**00:09:47,207** spending their career working on certain problems, but

**00:09:49,741** aren't the top of their field,

**00:09:51,127** like that's honestly who I would be most worried about.

**00:09:53,928** Because I think that, you know, OpenAI

**00:09:55,847** and Anthropic and different companies are going to want those

**00:09:58,597** top mathematicians to be helping test

**00:10:00,247** and build and lead the development of their models. But

**00:10:03,320** in maybe this is it maybe this is what math,

**00:10:05,767** But I think I totally agree.

**00:10:07,967** And they were kind of convinced me in some places.

**00:10:10,127** But but I think in my mind, if you're the top mathematician, you're not checking.

**00:10:15,367** Like you're not like where your differentiation is discovery.

**00:10:21,087** And I think in coming up with and I think that's where.

**00:10:27,327** You know, the insane math, whatever thing that problem that they figured out.

**00:10:32,327** Yeah. Like that the top mathematicians were like

**00:10:35,207** focused in on and locked in on.

**00:10:36,927** Yeah. Like that no longer is.

**00:10:40,647** I don't know. We'll see. We'll see.

**00:10:41,807** I kind of believe what you're saying more than me.

**00:10:45,807** But I think I think it's interesting both ways.

**00:10:49,933** I was talking to one of my friends at the business school and she was like, "Can we

**00:10:55,607** go through this question?"

**00:10:58,327** I have an interview, I need to develop something,

**00:11:01,167** can we chat through?

**00:11:02,007** And she kept asking me questions.

**00:11:03,287** And I was like, love, put all these questions or ask me,

**00:11:06,807** just type them or say them into your chat prompt.

**00:11:10,207** Just ask it, how do I talk through,

**00:11:11,887** how do I do this?

**00:11:13,227** Send screenshots, ask it, I've never used Claude Code,

**00:11:16,307** how do I do that?

**00:11:17,147** And it will walk you through.

**00:11:18,567** And it's insane how it can,

**00:11:22,247** there's so many things where I might explain,

**00:11:23,727** like I am zero and dyslexic and I am dyslexic, but I'm not zero.

**00:11:27,447** And in those things, I think it's just developing this skill.

**00:11:31,407** But there's no--

**00:11:33,527** the thing I get scared by is that men, who typically

**00:11:40,367** are a bit more confident, who typically land themselves

**00:11:44,607** a little bit more in the engineering AI space,

**00:11:47,887** are going to--

**00:11:49,667** and who are higher socioeconomic,

**00:11:52,287** so they have more time--

**00:11:53,927** going to way, way, way differentially get into this space that is so valuable and so

**00:12:02,967** needed across any domain and equity and all that stuff just heightens inequity.

**00:12:11,487** I think that's what I want to prevent and make fun and

**00:12:15,777** both for myself, for our littles

**00:12:18,287** to like the boys, but also most importantly,

**00:12:21,507** the little nuggets, but also more broad like this matters

**00:12:25,787** and it can be fun and we should all, it can be scary,

**00:12:28,887** but like the unknown is always more scary

**00:12:31,367** than the unknown for me.

**00:12:32,507** Totally, yeah, I think that's such a good point

**00:12:34,167** that as these tools have gotten better,

**00:12:36,087** it's also becomes easier to learn how to use them

**00:12:39,047** by going back and forth with the tool.

**00:12:40,607** Like, yeah, I totally, when I run into things

**00:12:43,007** and it's like, I don't know how to, you know,

**00:12:44,327** I'm working with Claude Code, building a website,

**00:12:46,207** I also can't code to save my life,

**00:12:48,087** but it's like, okay, there's an error in the code.

**00:12:50,167** It's kind of a lie.

**00:12:51,367** No, no, compared to an actual engineer.

**00:12:53,527** If we both took a coding class,

**00:12:54,887** guys, there was a class that we took first year,

**00:12:57,287** I mean, last year at Stanford.

**00:13:00,727** And the way that I thought I had dyslexia,

**00:13:05,147** the way that I thought I was experiencing dyslexia

**00:13:10,327** when I saw my grade,

**00:13:11,767** (both laughing)

**00:13:13,527** I got, my first midterm,

**00:13:15,007** that Josh got like a 90 fricking something.

**00:13:17,847** I got like a 29 and I had to look away, look back.

**00:13:22,487** I was thinking it was a 92.

**00:13:23,847** I thought that my mind was undoing it

**00:13:26,247** and we were coding on paper.

**00:13:27,927** There's some coding difference.

**00:13:28,767** Yeah, you still pass the class though.

**00:13:29,607** We ended up with--

**00:13:30,447** I passed the class.

**00:13:31,487** Did I spiral?

**00:13:32,367** Absolutely, but I did pass the class.

**00:13:34,207** Did I cry to the professor? Absolutely.

**00:13:37,807** Okay, but relative to an actual software engineer,

**00:13:40,247** I can't code. - Totally.

**00:13:41,087** The point is, right, and when I get this bug

**00:13:43,367** in a website, I have no idea what it means,

**00:13:45,087** but to your point, take a screenshot or copy and paste it,

**00:13:47,527** put it in the Claude Code and it can talk through an English with me.

**00:13:50,867** It's so good. It's so fun

**00:13:52,600** But in, I think the thing that I struggle with is where to one, I want to know like

**00:13:59,513** where do I invest to set myself up?

**00:14:01,673** So I think we should dig into that.

**00:14:03,833** But two, where is it overhyped?

**00:14:06,313** Because truck drivers, I think 10 years ago,

**00:14:09,333** we were like, oh, they're all going to get wiped out.

**00:14:11,793** By self-driving trucks? Yeah.

**00:14:13,893** And they're starting.

**00:14:14,993** They're finally starting. I know. I know.

**00:14:16,873** But we thought we'd have self-driving cars right now.

**00:14:20,447** And so I think, we're in business school,

**00:14:24,247** A lot of people are coming up in school,

**00:14:27,407** and I know a lot of the Stanford undergrads

**00:14:29,167** are pretty anxious and confused on what is the focus of,

**00:14:34,327** what should I be focusing on?

**00:14:35,327** What is worth exploring?

**00:14:36,487** I think what I think for me,

**00:14:39,127** but I wanna do more thinking,

**00:14:41,707** is something that I don't think AI can ever replace

**00:14:47,327** is this human element.

**00:14:51,367** I'm such a feeler in the way that I try to harness my passion to get people fired up

**00:15:00,707** or the way that I need to learn how to let go of

**00:15:04,320** certain things and then mentor and go

**00:15:07,087** up and down.

**00:15:08,087** I think a lot of what they focus on here is there's more

**00:15:11,869** classes and by here I mean Stanford

**00:15:14,207** Business School, there's a lot of classes that are like

**00:15:17,590** presentation, public speaking,

**00:15:19,407** communication.

**00:15:20,407** Like the interpersonal skills of, yeah.

**00:15:22,567** And I think that is invaluable right now.

**00:15:25,287** I think right now the only way that you can prove

**00:15:28,727** an understanding and our expertise is communication.

**00:15:32,487** Because now I could write, I'm dyslexic, I can't write,

**00:15:35,727** but I could write an incredible paper

**00:15:38,527** just by going back and forth with chat and Claude.

**00:15:42,167** And I think it's fun because that almost feels more human.

**00:15:45,567** It feels like it's pushing us in a different way

**00:15:48,807** to be more human and to value that humanness that I

**00:15:52,325** think at least for me for a while,

**00:15:54,647** it was the opposite. It was how do I, you know, de-word, how do I like really try to

**00:16:02,567** lock in there. So I think that's like one area that I really want to invest in. And

**00:16:06,167** then I think the other is learning AI and kind of digging

**00:16:10,672** into what tasks for me specifically

**00:16:13,407** in the healthcare space are really important.

**00:16:18,880** And then where like, AI is so interesting

**00:16:21,960** 'cause there's like some,

**00:16:24,940** like AI companies are struggling.

**00:16:26,680** There's, I mean, they're not, they're popping off.

**00:16:30,320** But like, you know, the stickiness of if, you know,

**00:16:34,600** if Claude does better, I'm gonna jump to Claude.

**00:16:37,140** If chat does better, I'm gonna jump to chat. Yeah.

**00:16:39,760** And then where in that ecosystem

**00:16:42,120** do you really want to own because now the software is not a differentiator.

**00:16:47,120** It will change, it will evolve.

**00:16:48,733** Well, it could be a differentiator, but it's a less of

**00:16:52,084** and kind of hardware has like really,

**00:16:54,360** you know, like chips, all that stuff has become valuable

**00:16:57,467** it's really, really intensive process to train the models.

**00:17:03,040** But then now there's so many people using these models

**00:17:05,300** that there are literally entire

**00:17:06,580** data centers, facilities that are set up just to have the servers and the GPUs.

**00:17:11,820** GPUs are I think initially what what NVIDIA got, you

**00:17:15,997** know, kind of famous and got a lot

**00:17:18,700** of their money from. Okay.

**00:17:20,700** And GPUs were initially built actually to power like gaming computers.

**00:17:24,020** Oh interesting.

**00:17:25,020** So it's a graphical processing unit I think.

**00:17:27,820** Interesting.

**00:17:28,820** Yeah, but anyways, it turns out that GPUs were also a really

**00:17:32,762** good fit for training and serving

**00:17:34,900** these AI models, especially training them.

**00:17:38,820** And so, you know, NVIDIA was kind of like right place, right time.

**00:17:41,940** They had built those for gaming niche kind of use

**00:17:44,538** cases, but now all of a sudden they're

**00:17:46,540** hugely in demand and they had a big head start there.

**00:17:48,540** And so that kind of led them to being super, super successful.

**00:17:54,580** And now they've built out kind of other product offerings and stuff as well.

**00:17:56,967** And so there are questions I think around

**00:17:59,247** what's gonna be a sustainable moat in this space versus not.

**00:18:01,927** Moat, moat, moat.

**00:18:03,487** Everyone uses moat these days.

**00:18:04,707** Honestly, it's like my least favorite word.

**00:18:06,287** Just like advantage. Yeah, yeah.

**00:18:08,087** It's like, it's like, yeah, advantage is a great idea.

**00:18:12,727** But I think to your point,

**00:18:14,447** people switch all the time.

**00:18:15,767** I know I do when the newest model comes out from opening a iron and dropping.

**00:18:20,087** Like, yeah.

**00:18:21,007** And if one's better, like there's a very little switching cost.

**00:18:24,367** Like it's very easy just to copy and paste your, uh, kind of key, you know,

**00:18:30,247** information from one to the other.

**00:18:31,667** But like, yeah, a model like deep seek, for example, you

**00:18:34,539** can host on your own computer,

**00:18:36,053** if you have a strong enough computer, that's the thing that

**00:18:38,206** like, isn't really talked about is like,

**00:18:39,653** I've tried to host a bunch of, you know, open source

**00:18:42,869** models on my MacBook Air, and like,

**00:18:45,013** it's just not powerful enough to run most of them.

**00:18:49,025** Because you need, you know, high CPU,

**00:18:52,533** where I can actually use a computer or computing processing.

**00:18:56,349** I actually don't know. But it's like

**00:19:01,013** kind of like the engine that powers the computer. And so you

**00:19:05,389** need like a fancy or like I think some

**00:19:08,133** of the MacBook Pros now are being released with a lot more

**00:19:12,208** CPU and RAM so that they can run these

**00:19:14,853** models locally. But for the most part, it's like pretty

**00:19:19,173** annoying and difficult for a beginner to

**00:19:22,293** to figure out how to host this model and keep it running from the computer.

**00:19:24,633** Yeah, I mean, I think it's always good

**00:19:25,473** to have competition.

**00:19:26,313** So it's, you know, other players in the race,

**00:19:29,353** especially like open source model gives more power

**00:19:31,613** to the consumer if they do want, you know, like, for example,

**00:19:34,113** if OpenAI and Anthropic jack up their prices,

**00:19:36,513** like there are alternatives.

**00:19:37,793** And I think right now a lot of the people using

**00:19:40,553** these open source models are big companies

**00:19:42,433** that are using tons and tons of, you know, AI use cases.

**00:19:46,067** Like for example, even though the models are open source,

**00:19:49,208** some of the providers might host

**00:19:50,947** it and offer an option for people to pay them to go

**00:19:53,714** through their plan instead of hosting

**00:19:55,707** it themselves just because it's, you know, they might

**00:19:57,737** not, consumer might not have the

**00:19:58,947** device to actually host it themselves or whatever.

**00:20:01,267** And so they might then pay to use that hosted version

**00:20:03,861** where it's not using their device,

**00:20:05,507** that's using a server that's in a data center somewhere.

**00:20:10,000** Okay, I wanna, so it kind of overlaps, I think,

**00:20:12,600** but it's fuzzy in my mind.

**00:20:14,840** Open and closed source models that we just talked about,

**00:20:18,080** and then on-prem versus cloud.

**00:20:20,360** And I think there's like a third one,

**00:20:22,040** but basically on-prem is on your device,

**00:20:25,120** on-premise, on-device. Yeah.

**00:20:27,940** And that would like in my mind intersect

**00:20:32,040** with a open model because you'd have to like

**00:20:35,760** download it on your device.

**00:20:37,200** Is that the right way of thinking about it?

**00:20:38,767** Yeah, so kind of like we were just chatting through,

**00:20:40,880** you can have an open model that runs on,

**00:20:44,680** I think on-prem is really used

**00:20:47,040** like historically in the context of,

**00:20:49,520** originally all software was running on-prem

**00:20:51,800** before the cloud became possible and more commonplace.

**00:20:56,373** Like for Run Your City, for our nonprofit,

**00:20:59,413** Slack and Google Drive and all this software

**00:21:02,153** that were used is like, the data isn't being stored--

**00:21:06,233** On this computer. Exactly.

**00:21:08,033** It's on devices that are in some data center somewhere.

**00:21:15,313** Whereas--

**00:21:16,593** On the cloud makes it sound so much more abstract.

**00:21:23,553** Instead of being stored on my computer, it's stored on--

**00:21:26,313** It's stored and processed.

**00:21:27,753** Yeah, it's all being run somewhere else.

**00:21:29,793** It's not in the cloud.

**00:21:32,307** privacy is so, so important.

**00:21:33,727** I want to learn more about it because honestly, I think that I am probably

**00:21:39,027** undervalue some of it.

**00:21:41,907** Like I get it at a high level.

**00:21:43,267** I definitely undervalue it for myself, like personally.

**00:21:48,453** Oh, on that point for like these models, I think sometimes me being a feeler,

**00:21:53,293** I'll apply my emotions to a model and be like, it's a human and it is,

**00:21:58,333** it is cheating

**00:21:58,780** But cheating gives like this negative connotation when really it's like, it's on

**00:22:04,140** humans to put up kind of this container that is effective or not or not or make

**00:22:11,740** sure we're not asking or not allowed to ask certain questions because it like

**00:22:15,580** the model is really just doing the very mathematical tasks that it's been asked

**00:22:21,100** to do to its best of its abilities. Yeah totally it's like ultimately just

**00:22:25,340** solving some goal that's given to it by humans and operating within the context

**00:22:28,580** and confines that are controlled by humans.

**00:22:30,600** Like the kind of classic historical example

**00:22:33,920** that people talk about is like the paperclip factory, right?

**00:22:36,960** Where it's like you build a device or a machine

**00:22:39,660** or whatever that's its goal is to produce

**00:22:41,980** the most paperclips possible. Yeah.

**00:22:45,080** And it starts by trading certain things for metal

**00:22:49,820** to get paperclips and whatever.

**00:22:51,020** And like eventually it like takes over all of society

**00:22:53,740** and turns every human into a slave

**00:22:55,460** to produce paperclips or whatever.

**00:22:56,900** Like, you know, obviously that's a dramatic example,

**00:23:00,420** but I think it's an interesting thought question

**00:23:02,400** of like, if you set a goal for a model or a machine

**00:23:07,100** and give it not the right limitations or guardrails,

**00:23:10,900** then what are the dangerous side effects

**00:23:12,740** that maybe you don't anticipate that can come with it

**00:23:15,180** in its quest to accomplish that goal? Yeah, yeah.

**00:23:17,580** I think, I think I, it makes a lot of sense.

**00:23:20,940** I think I struggle because I personally need to stay

**00:23:23,820** inspired and excited and curious about this space.

**00:23:26,660** I think I have to keep a certain degree of optimism.

**00:23:30,620** And like, so examples like that, or like, you know,

**00:23:34,340** some, you know, there's both ends,

**00:23:36,380** but there's a lot of obviously fear,

**00:23:37,820** and I think there should be, right?

**00:23:39,060** Like we should keep that close,

**00:23:40,380** but I think I personally struggle,

**00:23:42,420** like going too far down the rabbit hole,

**00:23:46,520** because I think then I am less personally excited

**00:23:50,300** to understand it, but it's hard.

**00:23:52,900** I don't wanna be naive.

**00:23:53,740** I don't really know what that trade-off is,

**00:23:55,860** but it's hard to balance.

**00:23:57,577** I totally agree as a, especially as a beginner, it makes sense to just learn one

**00:24:00,474** tool and learn how to use it well, and get comfortable with it.

**00:24:03,133** Oh, okay. Well then I'll flip on you. We have to look

**00:24:06,337** at your most recent three chats.

**00:24:09,367** Oh gosh. Chats or quads?

**00:24:16,647** Well, you said you use chat more for what kind of use case?

**00:24:22,567** I just use I use Claude more.

**00:24:24,687** OK, well, let's look at your last three.

**00:24:26,607** Well, chats then.

**00:24:28,727** My recent I mean, I mean, no skipping.

**00:24:32,327** They're not. I mean, nonprofit [unclear] AI stats. Oh, yeah.

**00:24:35,647** You trying to make sure you have your numbers right. Yeah.

**00:24:38,220** Like how embarrassing.

**00:24:39,900** I have street style inspiration.

**00:24:41,580** I was like, we were coming back to school

**00:24:43,300** and I was like, I need-- New fits.

**00:24:45,300** Yeah, new fits that like aren't,

**00:24:47,380** I like athletic fits. And I have,

**00:24:54,640** best pina colada in Maui.

**00:24:56,580** There we go.

**00:24:58,500** Yeah, we'll have to dig in more.

**00:24:59,660** I feel like we both are like very power users

**00:25:02,580** for personal use cases, obviously,

**00:25:04,100** for stuff with the nonprofit, with school. Yeah.

**00:25:07,420** We found a lot of cool ways to make these useful

**00:25:10,620** across our lives.

**00:25:11,460** So I want to share more of them in a future episode, but.

**00:25:13,300** Yeah, hope this was helpful and landscape

**00:25:16,820** and see you in the next episode, Peace.
