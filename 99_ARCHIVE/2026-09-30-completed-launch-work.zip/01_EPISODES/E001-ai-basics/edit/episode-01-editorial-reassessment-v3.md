# Episode 1 length reassessment

2026-09-26. Josh asked whether the 9:58 cut meant only ten minutes of the 55:47 source were usable, and stated a preference for episodes around 25–30 minutes. **No:** the short version was an editorially narrow first proposal. The source contains enough coherent, engaging material for a fuller proposed **25:20.567** episode. The exact v3 selection is reversible in `episode-01-edit-decisions-v3.json`; v2 remains for comparison.

## What the fuller version restores

| Source span | Material worth keeping | Editorial treatment |
|---|---|---|
| 06:22–06:46; 11:30–12:30 | Mary extends the car analogy to open and closed models; Josh explains why downloadable weights matter. | Keep the intelligible definition and the hosts' division of labor. Remove the blanket suggestion that OpenAI only releases closed models and the universal quality ranking. |
| 09:34–09:54 | A concise explanation that models can work with more than text. | Keep as a basic concept; do not imply identical capabilities in every model. |
| 15:43–19:40 | Mary's provocative mathematician/job take, Josh's substantive disagreement and Mary's partial change of mind. | Preserve the real disagreement and self-correction. Remove the unsupported assertion about a named model solving a long-unsolved problem. Career predictions remain labeled as their views. |
| 21:22–22:23 | Mary connects unequal access and intimidation to why she wants the show to feel approachable. | Keep her concern as her perspective, with the coding-class conversation that surrounds it. |
| 25:15–27:48 | Mary asks what skills to invest in, then makes a personal case for communication and human connection. | Retain the concrete GSB/dyslexia perspective; cut a short prediction tangent. |
| 27:49–31:12 | Mary asks how products differ; the GPU explanation leads to her reaction and their joke about “moat.” | Keep the graphics-to-AI GPU explanation and real host interaction. Remove the time-sensitive valuation and the battery exchange, whose setup and correction did not join cleanly. |
| 33:25–37:40 | Josh describes the difficulty of running a model on his laptop; Mary asks what “on-prem” and “cloud” really mean. | Retain a lived example and the useful distinction. Remove unverified performance rankings, unsupported subsidy claim and a blanket hospital-security statement. |
| 41:16–44:44 | Mary reflects on privacy and anthropomorphizing tools; Josh gives a clearly hypothetical paperclip example; she explains why she needs optimism too. | Keep it as a conversation about caution, not a report of real-world model escape. Remove a categorical claim about AI feelings and the earlier claim that current systems have hacked companies. |

The existing company/model/app explanation, model-name mix-up and spoken correction, app differences, Mary’s taste judgment, learning/coding story and recent ordinary prompts also remain. Together they make an **AI landscape** episode with a clear beginner entry point and a larger question: what changes for these two hosts and their audience?

## What should stay out of this version

- Camera/closing setup and duplicate starts; unfulfilled topic promises and repeated explanations.
- Blanket usage/benchmark rankings, the false idea that choosing app mode changes the model's trained weights, and the misleading open-source/open-weight distinction. These require spoken corrections or a new discussion, not a graphic over the old speech.
- The longer founder-motive/personality ranking: it contains time-sensitive role claims, unverifiable interpretations of people's intentions and a substantial topic shift. Some real banter could work in a separately researched segment.
- The academic petition/email story: a potentially strong personal anecdote, but it includes account access, sending without prior inspection and AI-authorship language that require Mary to verify and approve the exact details before release.

This does **not** mean everything outside v3 is bad footage. Some of it could support a separate discussion with fresh sourcing and spoken pickups. More minutes alone would weaken this particular episode if they introduced a third or fourth thesis.

## Review emphasis

The 25–30 minute preference is a working target, not a mandate to pad every recording. Judge v3 for energy and coherence, especially the move from basics into work and safety, the length of the hardware section, and whether both hosts like the personal details shared. Only continuous viewing/listening and host review can settle those questions. The sampled picture shows both hosts consistently on camera; sampled frames and text cannot certify delivery or pacing.
