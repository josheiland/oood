"""Build a fuller-episode thumbnail from an authentic source frame and OOOD kit."""
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
import subprocess

P = Path(__file__).resolve().parent
FONT = P.parents[2] / '03_ASSETS/brand-fonts/teachers.ttf'
BLUE, CREAM, FOAM, NAVY = '#38B6FF', '#FBF1E5', '#FDF8F2', '#0B2A45'

def face(size, weight=800):
    f = ImageFont.truetype(str(FONT), size)
    f.set_variation_by_axes([weight])
    return f

def tight(draw, xy, text, f, color, tracking=-.02):
    x, y = xy
    for char in text:
        draw.text((x, y), char, font=f, fill=color)
        x += draw.textlength(char, font=f) + f.size * tracking

def text_width(draw, text, f, tracking=-.02):
    return sum(draw.textlength(ch, font=f) + f.size * tracking for ch in text)

source = '/Users/je/Movies/Episode 1 Raw.mp4'
frame = P / 'intermediate/v3-thumbnail-source.jpg'
subprocess.run(['ffmpeg', '-nostdin', '-v', 'error', '-y', '-ss', '1360', '-i', source,
                '-frames:v', '1', '-q:v', '2', str(frame)], check=True)

canvas = Image.new('RGB', (1280, 720), CREAM)
draw = ImageDraw.Draw(canvas)
for title, y, color in [('AI BASICS', 15, BLUE), ('IN REAL LIFE', 170, NAVY)]:
    size = 133
    while text_width(draw, title, face(size)) > 1220:
        size -= 1
    tight(draw, (40, y), title, face(size), color)

picture = Image.open(frame).convert('RGB')
picture = picture.resize((840, 473), Image.Resampling.LANCZOS)
picture = picture.crop((0, 28, 840, 435))
canvas.paste(picture, (440, 313))
draw = ImageDraw.Draw(canvas)
draw.rectangle((0, 424, 439, 719), fill=FOAM)

icon = Image.new('RGB', (141, 141), BLUE)
idraw = ImageDraw.Draw(icon)
for words, font_size, y, tracking in [('OUT OF OUR', 11, 45, .02), ('DEPTH', 31, 59, -.02)]:
    f = face(font_size)
    width = text_width(idraw, words, f, tracking)
    tight(idraw, ((141-width)/2, y), words, f, CREAM, tracking)
canvas.paste(icon, (40, 539))
canvas.save(P / 'episode-01-thumbnail-v3.jpg', quality=92, subsampling=0)
print(P / 'episode-01-thumbnail-v3.jpg')
