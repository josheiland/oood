# Episode 1 v6 chapters

Review-cut timeline; four brief clarification pop-ups, no chapter cards.

- 00:00 Opening and the AI landscape
- 01:00 Companies, models, and apps
- 06:07 Open and closed models
- 06:30 How a model learns
- 08:39 The engine analogy
- 12:12 Choosing a model
- 14:22 Work and human skills
- 19:19 Learning by asking
- 22:34 The coding-class story
- 23:53 What skills matter
- 26:58 NVIDIA and GPUs
- 30:56 Open weights and local models
- 34:15 On-prem and cloud
- 36:17 The people behind the companies
- 38:42 Safety, limits, and optimism
- 42:58 The founders and their reputations
- 47:06 A rapid-fire ranking
- 50:31 Our recent chats
- 51:08 A real use case from Mary
