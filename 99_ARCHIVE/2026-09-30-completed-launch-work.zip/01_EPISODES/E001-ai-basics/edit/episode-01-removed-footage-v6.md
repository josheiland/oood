# Episode 1 v6: complete raw-footage removal list

Picture edit used in both current local review videos, following Josh’s 2026-09-28 direction to keep footage unless clearly wrong or a requested flub. All ranges below are half-open times from the original 55:47.233 raw shoot, frame-rounded to 30 fps. These **seven ranges are the entire removal list** for the clean v7 and theme v8 reviews. The source is unchanged.

V6 retains six continuous source ranges and runs **00:53:24.900**. It removes **141.667s** of source footage; five four-frame internal crossfades overlap another **0.667s**.

| # | Raw-source range removed | Duration | What is removed |
|---:|---|---:|---|
| 1 | 00:00:00.000–00:00:15.000 | 15.000s | Pre-roll and setup before hand-cover opening. |
| 2 | 00:06:46.033–00:07:51.867 | 65.833s | Mary’s misleading model-weights/product-modes explanation and the confused response. |
| 3 | 00:31:39.400–00:31:45.400 | 6.000s | Mary loses her train of thought; her permissions preference stays. |
| 4 | 00:33:02.300–00:33:24.833 | 22.533s | Josh’s reversed open-source/open-weight explanation; the rest of the section stays. |
| 5 | 00:39:29.167–00:39:46.767 | 17.600s | Demis/Dario name mix-up and restart. |
| 6 | 00:45:06.133–00:45:15.300 | 9.167s | Josh loses his train of thought. |
| 7 | 00:55:41.700–00:55:47.233 | 5.533s | Post-wrap tail after closing hand cover. |

Restored from v5: the provider ranking, Harvey/OpenEvidence discussion, token/usage intuition, battery/GPU conversation, Mary’s personal permissions practice, general open-versus-closed quality comparison, Chinese AI subsidy comment, on-prem hospital remark, OpenAI nonprofit/for-profit discussion, and all other v5 discretionary trims. Brief branded cards now clarify model access, that a GPU is a chip, the graphics-processing-unit expansion, and OpenAI’s current structure. The Hallie story and Demis role-change discussion remain.

The preceding v5 cut list is historical, not a description of v6. The v6 captions are machine-derived and need a listening proof; the exact export needs host audiovisual review.
