"""Make the Episode 1 private theme comparison from the finished v6 cut."""
from pathlib import Path
import json
import re
import subprocess

P = Path(__file__).resolve().parent
ROOT = P.parents[2]
MUSIC = ROOT / '03_ASSETS/music'
E = json.loads((P / 'episode-01-edit-decisions-v6.json').read_text())
MAIN = P / 'episode-01-master-v6.mp4'
TITLE = P / 'graphics/v6-theme-title.png'
OUTRO = P / 'graphics/v6-theme-outro-two-asks.png'
OUTPUT = P / 'episode-01-theme-preview-v6.mp4'
CAPTIONS = P / 'episode-01-theme-preview-v6.srt'
META = P / 'intermediate/v6-theme-chapters.ffmeta'
GRAPH = P / 'intermediate/v6-theme-filtergraph.txt'

FPS = 30
HOOK_START_FRAME = 22039  # Output 12:14.633, the names/Apple exchange.
HOOK_FRAMES = 305
TITLE_FRAMES = 158
OUTRO_FRAMES = 323
MAIN_FRAMES = E['total_frames']
LEAD_FRAMES = HOOK_FRAMES + TITLE_FRAMES
TOTAL_FRAMES = LEAD_FRAMES + MAIN_FRAMES + OUTRO_FRAMES


def stamp(seconds):
    millis = round(seconds * 1000)
    hours, millis = divmod(millis, 3600000)
    minutes, millis = divmod(millis, 60000)
    secs, millis = divmod(millis, 1000)
    return f'{hours:02}:{minutes:02}:{secs:02},{millis:03}'


def seconds(value):
    hours, minutes, rest = value.split(':')
    return int(hours) * 3600 + int(minutes) * 60 + float(rest.replace(',', '.'))


def write_captions():
    source = (P / 'episode-01-captions-v6.srt').read_text()
    cues = []
    for block in re.split(r'\n\s*\n', source.strip()):
        lines = block.splitlines()
        a, b = lines[1].split(' --> ')
        cues.append((seconds(a), seconds(b), '\n'.join(lines[2:])))
    hook_start = HOOK_START_FRAME / FPS
    hook_end = (HOOK_START_FRAME + HOOK_FRAMES) / FPS
    themed = [(max(a, hook_start) - hook_start,
               min(b, hook_end) - hook_start, body)
              for a, b, body in cues if a < hook_end and b > hook_start]
    themed.append((HOOK_FRAMES / FPS, LEAD_FRAMES / FPS,
                   '[Instrumental theme music]'))
    lead = LEAD_FRAMES / FPS
    themed.extend((a + lead, b + lead, body) for a, b, body in cues)
    outro_start = (LEAD_FRAMES + MAIN_FRAMES) / FPS
    themed.extend([
        (outro_start, outro_start + 5.1,
         'What should we try next?\nTell us in the comments'),
        (outro_start + 5.1, TOTAL_FRAMES / FPS,
         'Know someone figuring out AI?\nSend this their way'),
    ])
    assert not CAPTIONS.exists(), f'Preserving existing captions: {CAPTIONS}'
    themed = [(a, b, body) for a, b, body in themed if b > a]
    CAPTIONS.write_text('\n\n'.join(
        f'{i}\n{stamp(a)} --> {stamp(b)}\n{body}'
        for i, (a, b, body) in enumerate(themed, 1)) + '\n')


def write_metadata():
    raw = (P / 'intermediate/v6-chapters.ffmeta').read_text()
    chapters = []
    for block in raw.split('[CHAPTER]')[1:]:
        fields = dict(line.split('=', 1) for line in block.strip().splitlines()
                      if '=' in line)
        chapters.append((int(fields['START']) + LEAD_FRAMES * 1000,
                         fields['title']))
    chapters = [(0, 'Cold open'), (HOOK_FRAMES * 1000, 'Theme and title'),
                *chapters, ((LEAD_FRAMES + MAIN_FRAMES) * 1000, 'Outro')]
    lines = [';FFMETADATA1', f'title={E["title"]} (theme preview)',
             'artist=Josh and Mary']
    for index, (start, title) in enumerate(chapters):
        end = chapters[index + 1][0] if index + 1 < len(chapters) else TOTAL_FRAMES * 1000
        lines.extend(['[CHAPTER]', 'TIMEBASE=1/30000', f'START={start}',
                      f'END={end}', f'title={title}'])
    assert not META.exists(), f'Preserving existing metadata: {META}'
    META.write_text('\n'.join(lines) + '\n')


def render():
    assert MAIN.is_file() and TITLE.is_file() and OUTRO.is_file()
    assert (MUSIC / 'oood-sting-5s.wav').is_file()
    assert (MUSIC / 'oood-outro-11s.wav').is_file()
    assert not OUTPUT.exists(), f'Preserving existing export: {OUTPUT}'
    assert not GRAPH.exists(), f'Preserving existing graph: {GRAPH}'
    assert not META.exists() and not CAPTIONS.exists(), 'Preview sidecar already exists'
    probe = json.loads(subprocess.check_output(['ffprobe', '-v', 'error',
        '-select_streams', 'v:0', '-show_entries', 'stream=nb_frames,duration',
        '-of', 'json', str(MAIN)]))
    assert int(probe['streams'][0]['nb_frames']) == MAIN_FRAMES
    write_metadata()
    write_captions()
    hook_seconds = HOOK_FRAMES / FPS
    title_seconds = TITLE_FRAMES / FPS
    outro_seconds = OUTRO_FRAMES / FPS
    graph = ';'.join([
        f'[0:v]fps={FPS},trim=end_frame={HOOK_FRAMES},setpts=N/(30*TB),format=yuv420p,setsar=1[hv]',
        f'[0:a]aresample=48000,apad=whole_len={HOOK_FRAMES*1600},'
        f'atrim=end_sample={HOOK_FRAMES*1600},asetpts=N/SR/TB,'
        f'afade=t=in:d=0.02,afade=t=out:st={hook_seconds-0.05:.6f}:d=0.05[ha]',
        f'[1:v]fps={FPS},trim=end_frame={MAIN_FRAMES},setpts=N/(30*TB),format=yuv420p,setsar=1[mv]',
        f'[1:a]aresample=48000,apad=whole_len={MAIN_FRAMES*1600},'
        f'atrim=end_sample={MAIN_FRAMES*1600},asetpts=N/SR/TB[ma]',
        f'[2:v]trim=end_frame={TITLE_FRAMES},setpts=N/(30*TB),format=yuv420p,setsar=1[tv]',
        f'[3:a]volume=-1.6dB,aresample=48000,apad=whole_len={TITLE_FRAMES*1600},'
        f'atrim=end_sample={TITLE_FRAMES*1600},asetpts=N/SR/TB[ta]',
        f'[4:v]trim=end_frame={OUTRO_FRAMES},setpts=N/(30*TB),format=yuv420p,setsar=1[ov]',
        f'[5:a]volume=-3.3dB,aresample=48000,apad=whole_len={OUTRO_FRAMES*1600},'
        f'atrim=end_sample={OUTRO_FRAMES*1600},asetpts=N/SR/TB,'
        f'afade=t=out:st={outro_seconds-0.7:.6f}:d=0.7[oa]',
        '[hv][ha][tv][ta][mv][ma][ov][oa]concat=n=4:v=1:a=1[v][a]',
    ])
    GRAPH.write_text(graph + '\n')
    args = ['ffmpeg', '-nostdin', '-hide_banner', '-y',
            '-ss', f'{HOOK_START_FRAME/FPS:.9f}', '-i', str(MAIN),
            '-i', str(MAIN),
            '-loop', '1', '-framerate', str(FPS), '-t', f'{title_seconds:.9f}', '-i', str(TITLE),
            '-i', str(MUSIC / 'oood-sting-5s.wav'),
            '-loop', '1', '-framerate', str(FPS), '-t', f'{outro_seconds:.9f}', '-i', str(OUTRO),
            '-i', str(MUSIC / 'oood-outro-11s.wav'),
            '-i', str(META),
            '-filter_complex_threads', '2', '-filter_complex_script', str(GRAPH),
            '-map', '[v]', '-map', '[a]', '-map_metadata', '6', '-map_chapters', '6',
            '-frames:v', str(TOTAL_FRAMES), '-r', str(FPS), '-fps_mode', 'cfr',
            '-c:v', 'libx264', '-threads', '4', '-preset', 'veryfast', '-crf', '19',
            '-profile:v', 'high', '-pix_fmt', 'yuv420p',
            '-color_primaries', 'bt709', '-color_trc', 'bt709', '-colorspace', 'bt709',
            '-c:a', 'aac', '-b:a', '256k', '-ar', '48000', '-movflags', '+faststart',
            str(OUTPUT)]
    print(f'Rendering {TOTAL_FRAMES/FPS:.3f}s theme preview', flush=True)
    stdout = P / 'intermediate/v6-theme-render-stdout.log'
    stderr = P / 'intermediate/v6-theme-render-stderr.log'
    with stdout.open('w') as out, stderr.open('w') as err:
        subprocess.run(args, check=True, stdout=out, stderr=err)
    print(f'Render complete: {OUTPUT}', flush=True)


if __name__ == '__main__':
    render()
