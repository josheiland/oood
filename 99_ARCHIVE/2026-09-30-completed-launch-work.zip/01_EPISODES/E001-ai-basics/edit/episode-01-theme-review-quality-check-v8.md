# Episode 1 theme review v8: technical check

Checked 2026-09-28. This is a **private host-review comparison**, because public rights for the candidate music are unconfirmed.

The 53:51.100 review copy has exactly the same H.264 picture packets as the fully decoded v6 theme export. Only AAC audio changed: the 10.167-second cold open is 1.8 dB lower, while the title, complete episode and outro are 0.6 dB lower. The higher v6 peak came from the cold open, not from the music cards. The v6 full-file decode, black/silence scan, caption structure and sampled title/outro frames are in `intermediate/qc-v6-theme/` and `intermediate/v6-theme-sampled-frames.jpg`.

| Check | Result |
|---|---|
| Final video | `episode-01-theme-review-v8.mp4`, 1080p30, 96933 frames, 3231.100000s; SHA-256 `badcf5071373563703cb543d892f19a05aecf38847538c6f31897c1fecd663d5` |
| Picture bitstream | Identical packet SHA-256 `f7183f7c55751070fb0e3a729af2ab02e5cd4692005bb56e2164744dc3737b82` in v6 source and v8 review |
| Audio | AAC stereo 48000 Hz, -17.19 LUFS, -1.29 dBTP true peak, 3231.100000s |
| Chapters and captions | 22 embedded chapters; 1144 matching-timeline draft SRT cues |

Checks: `{'same_complete_picture_stream': True, 'exact_96933_frames': True, 'exact_3231_point_1_seconds': True, 'audio_video_within_50ms': True, 'true_peak_below_minus_one_db': True, 'integrated_loudness_near_target': True, 'chapters_present': True, 'matching_captions_present': True}`.

The outro card contains both exact asks: “What should we try next? Tell us in the comments” and “Know someone figuring out AI? Send this their way”. Caption wording still needs an auditory proof, and both hosts should watch and listen to the exact selected file. A final public-delivery audio pass may be needed if true peak is above the preferred −1 dBTP ceiling. No upload, scheduling or publication is claimed.
