"""Reversible E001 render from frame EDL; content-addressed local segment cache."""
from pathlib import Path
import subprocess, json, re, hashlib, sys

P=Path(__file__).resolve().parent
T=P/'intermediate'
G=P/'graphics'
VERSION=sys.argv[1] if len(sys.argv)>1 else 'v1'
assert VERSION in ['v1','v2','v3']
EDL=P/f'episode-01-edit-decisions-{VERSION}.json'
edl=json.loads(EDL.read_text())
SRC=edl['source']; FPS=edl['fps']; total=edl['total_frames']/FPS

def run(args, name):
    with (T/(name+'.log')).open('w') as f:
        subprocess.run(['ffmpeg','-nostdin','-hide_banner','-y',*args],stdout=f,stderr=f,check=True)

out=P/f'episode-01-master-{VERSION}.mp4'
if out.exists():
    raise SystemExit('Existing master preserved. Version the script/manifest/output before revising.')
clips=[]
for i,s in enumerate(edl['segments']):
    a=s['in_frame']/FPS; dur=(s['out_frame']-s['in_frame'])/FPS
    overlays=[o for o in edl['graphics'] if o['segment']==s['id']]
    sig=hashlib.sha256(json.dumps({'segment':s,'overlays':overlays,'source_hash':edl['source_sha256'],'render':'x264-veryfast-crf18-stereo48k-v1'},sort_keys=True).encode()).hexdigest()[:12]
    target=T/f'segment-{s["id"]}-{sig}.mov'
    if target.exists():
        try:
            pr=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_streams','-of','json',str(target)],stderr=subprocess.DEVNULL))
            if int(pr['streams'][0].get('nb_frames',0))==s['out_frame']-s['in_frame']:
                clips.append(target); print('Reused',s['id'],flush=True);continue
        except (subprocess.CalledProcessError, ValueError, KeyError, IndexError):
            pass  # Interrupted renders can leave an incomplete cache file.
        target.unlink()
    inputs=['-threads','2','-ss',str(a),'-i',SRC,'-ss',str(a),'-i',str(T/'leveled-source.wav')]
    filters=['[0:v]setpts=PTS-STARTPTS[v0]']
    for j,o in enumerate(overlays):
        asset=T/'lower-third.mov' if o['asset']=='lower-third.mov' else G/o['asset']
        if asset.suffix=='.png':inputs+=['-loop','1','-framerate',str(FPS)]
        inputs+=['-i',str(asset)]
        if asset.suffix=='.mov':
            filters.append(f'[{j+2}:v]setpts=PTS-STARTPTS+{o["start"]}/TB[g{j}]')
        else:filters.append(f'[{j+2}:v]setpts=PTS-STARTPTS[g{j}]')
        filters.append(f'[v{j}][g{j}]overlay={o["x"]}:{o["y"]}:eof_action=pass:enable=\'between(t,{o["start"]},{o["end"]})\'[v{j+1}]')
    last=f'v{len(overlays)}'
    if i==len(edl['segments'])-1:
        filters.append(f'[{last}]fade=t=out:st={dur-.4}:d=0.4[vfinal]'); last='vfinal'
    fade=.4 if i==len(edl['segments'])-1 else .008
    filters.append(f'[1:a]atrim=duration={dur},asetpts=PTS-STARTPTS,afade=t=in:d=0.008,afade=t=out:st={dur-fade}:d={fade}[a]')
    run([*inputs,'-filter_complex_threads','2','-filter_complex',';'.join(filters),'-map',f'[{last}]','-map','[a]','-t',str(dur),'-c:v','libx264','-threads','3','-preset','veryfast','-crf','18','-profile:v','high','-pix_fmt','yuv420p','-r',str(FPS),'-fps_mode','cfr','-video_track_timescale','30000','-color_primaries','bt709','-color_trc','bt709','-colorspace','bt709','-c:a','pcm_s24le','-ar','48000','-map_metadata','-1',str(target)],f'segment-{s["id"]}')
    clips.append(target); print(f'Rendered {i+1}/{len(edl["segments"])}: {s["id"]}',flush=True)
concat=T/'concat.txt';concat.write_text(''.join(f"file '{x}'\n" for x in clips))
run(['-f','concat','-safe','0','-i',str(concat),'-vn','-af','loudnorm=I=-16:TP=-1.7:LRA=11:print_format=json','-f','null','-'],'loudness-pass1')
stats=json.loads(re.findall(r'\{[^{}]+\}',(T/'loudness-pass1.log').read_text())[-1])
(P/f'episode-01-loudness-pass1-{VERSION}.json').write_text(json.dumps(stats,indent=2)+'\n')
target_samples=edl['total_frames']*1600  # 48 kHz stereo: exactly 1600 samples per 30 fps video frame.
flt=f"loudnorm=I=-16:TP=-1.7:LRA=11:measured_I={stats['input_i']}:measured_TP={stats['input_tp']}:measured_LRA={stats['input_lra']}:measured_thresh={stats['input_thresh']}:offset={stats['target_offset']}:linear=true,aresample=48000,apad=whole_len={target_samples},atrim=end_sample={target_samples},asetpts=N/SR/TB"
wav=P/f'episode-01-audio-master-{VERSION}.wav'
run(['-f','concat','-safe','0','-i',str(concat),'-vn','-af',flt,'-ar','48000','-c:a','pcm_s24le',str(wav)],'audio-master')
chapters=[s for s in edl['segments'] if s.get('chapter')]
meta=[';FFMETADATA1','title='+edl['title'],'artist=Josh and Mary']
for n,s in enumerate(chapters):
    end=chapters[n+1]['timeline_frame'] if n+1<len(chapters) else edl['total_frames']
    meta+=['[CHAPTER]','TIMEBASE=1/30000',f'START={s["timeline_frame"]*1000}',f'END={end*1000}',f'title={s["chapter"]}']
(T/'chapters.ffmeta').write_text('\n'.join(meta)+'\n')
peak_headroom=['-af','volume=-0.35dB'] if VERSION=='v3' else []
run(['-f','concat','-safe','0','-i',str(concat),'-i',str(wav),'-i',str(T/'chapters.ffmeta'),'-map','0:v','-map','1:a','-map_metadata','2','-map_chapters','2','-c:v','copy',*peak_headroom,'-c:a','aac','-b:a','256k','-movflags','+faststart',str(out)],'final-mux')
run(['-i',str(wav),'-af','volume=-.4dB','-c:a','libmp3lame','-b:a','192k','-metadata','title='+edl['title'],str(P/f'episode-01-audio-{VERSION}.mp3')],'audio-mp3')
print(f'Complete: {total:.3f}s; {edl["total_frames"]} frames',flush=True)
