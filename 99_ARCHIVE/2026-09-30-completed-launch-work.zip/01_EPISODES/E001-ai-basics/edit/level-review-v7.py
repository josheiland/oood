"""Make audio-headroom review copies from the v6 picture-locked comparisons."""
from pathlib import Path
import subprocess
import sys

P = Path(__file__).resolve().parent
spec = {
    'clean': ('episode-01-master-v6.mp4', 'episode-01-clean-review-v7.mp4', 96147),
    'theme': ('episode-01-theme-preview-v6.mp4', 'episode-01-theme-preview-v7.mp4', 96933),
}


def run(which):
    source_name, out_name, frames = spec[which]
    source = P / source_name
    out = P / out_name
    assert source.exists(), source
    assert not out.exists(), f'Preserving existing output: {out}'
    samples = frames * 1600
    audio_filter = (f'volume=-0.6dB,aresample=48000,apad=whole_len={samples},'
                    f'atrim=end_sample={samples},asetpts=N/SR/TB')
    subprocess.run(['ffmpeg', '-nostdin', '-hide_banner', '-loglevel', 'error',
                    '-i', str(source), '-map', '0:v:0', '-map', '0:a:0',
                    '-map_metadata', '0', '-map_chapters', '0', '-c:v', 'copy',
                    '-af', audio_filter, '-c:a', 'aac', '-b:a', '256k',
                    '-movflags', '+faststart', str(out)], check=True)
    print(out)


if __name__ == '__main__':
    if len(sys.argv) != 2 or sys.argv[1] not in spec:
        raise SystemExit('Usage: python3 level-review-v7.py clean|theme')
    run(sys.argv[1])
