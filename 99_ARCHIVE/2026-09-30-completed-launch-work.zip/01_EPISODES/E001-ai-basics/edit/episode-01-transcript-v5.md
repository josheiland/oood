# Episode 1 final-timeline transcript v5

Draft from source-recording asr mapped through the exact v5 frame edl with name normalization. Auditory proofread and speaker attribution remain open.

**00:00:01,740** What is that? We're back.

**00:00:03,740** And with a piece. Yeah.

**00:00:05,740** Piece love and gratitude.

**00:00:06,740** We're gonna work on it.

**00:00:07,740** We're gonna try out something different next time.

**00:00:09,740** I haven't seen you do that before.

**00:00:12,900** We are back.

**00:00:14,100** are back and we're doing an AI landscape.

**00:00:17,180** Like we're painting a photo, painting a picture.

**00:00:20,740** Painting a photo, even more impressive.

**00:00:23,860** Um, yeah, I think really the goal here is just, especially for folks

**00:00:29,680** who are newer to the space, a lot of terms get thrown around.

**00:00:33,060** Um, and we just want to start with the basics, separating out, you know, what

**00:00:38,820** What is the difference between the model and the actual

**00:00:43,577** platform or product that you're

**00:00:46,220** using?

**00:00:47,220** Who are the different key companies in the space?

**00:00:49,540** Who are actually some of the personalities behind the companies?

**00:00:52,780** What are the tools?

**00:00:54,260** What are the tools?

**00:00:56,700** Why don't we start with models?

**00:01:00,420** You have your provider, so it's like ChatGPT.

**00:01:06,820** The provider I guess at the highest level would be

**00:01:10,048** Anthropic or OpenAI or Google, right?

**00:01:12,420** These are the companies that are actually training the models.

**00:01:16,500** Who's the provider for Grok?

**00:01:20,140** It's like X. Oh, X. Yeah.

**00:01:23,140** And then you've got some models coming out of Meta too. Okay.

**00:01:28,540** And then there's a handful of other companies.

**00:01:30,620** I think those are really the main ones.

**00:01:31,620** So let's use a Claude and chat and really quick

**00:01:34,993** caveat, at least for me, like to what

**00:01:37,633** you're saying, chat and ChatGPT and Claude are so much better than the others that I

**00:01:47,373** feel digging into one or two of them is a lot more

**00:01:50,624** effective than trying to learn all

**00:01:52,813** of them.

**00:01:53,813** They're give or take very similar.

**00:01:55,193** I think it's just like how do you start that muscle of

**00:01:58,190** training and going to AI to support

**00:02:00,113** with certain things?

**00:02:01,113** Where is it helpful?

**00:02:02,113** Where is it not?

**00:02:03,113** So, quick caveat, I like Claude the most for pretty much

**00:02:08,369** everything except for like realistic

**00:02:11,713** photos where I think Chad just does such a better job.

**00:02:14,113** Like generating photos.

**00:02:15,113** Yeah, but I think a lot of that is just because I've

**00:02:17,106** spent more time in Claude, so I feel

**00:02:18,473** like it knows me more.

**00:02:19,753** I go back and forth.

**00:02:21,433** I think Chad is like in theory better at some of the

**00:02:24,840** personalization, at some of like the more

**00:02:27,513** human-esque where Claude kind of pops at more of the, I

**00:02:33,081** think like, you know, math, diagrams,

**00:02:37,433** frameworks, a little bit more of the kind of less creative side of things.

**00:02:41,673** Like structured.

**00:02:42,553** Yeah, which for me, I think creativity and all that stuff

**00:02:45,314** is like really fun. So I think,

**00:02:47,433** And I think it's a little bit more of a string than like, you

**00:02:50,783** know, the wording and all that stuff.

**00:02:52,793** So I think that's why I lean a little bit Claude, but I would say.

**00:02:55,673** It feels like it complements your background and your capabilities. Yeah.

**00:02:59,913** Interesting. Yeah.

**00:03:01,033** So Claude is Anthropics product, which now kind of has

**00:03:05,273** a couple of different, I guess,

**00:03:08,313** tools really bundled within one. Yeah.

**00:03:11,273** And it's interesting because, you know, ChatGPT, which is OpenAI's product,

**00:03:16,633** it's kind of been a similar evolution where initially they

**00:03:19,621** both just had a chat interface.

**00:03:21,913** And you would type a prompt, get a response back.

**00:03:24,713** Increasingly, they started to build out other kind of modes.

**00:03:27,993** So both of them now have essentially like a work mode, which

**00:03:33,309** goes a little bit beyond the chat bot

**00:03:36,553** and gives it more kind of ability to use different tools, which

**00:03:40,103** we'll talk a little bit more about

**00:03:41,993** on essentially just using other applications

**00:03:45,693** or other capabilities beyond just text-based chat

**00:03:48,973** to actually go further and be able to do more work

**00:03:51,573** on your behalf.

**00:03:52,833** And then both now also have more code-heavy

**00:03:56,093** technical products, so Codex from OpenAI

**00:03:59,393** and then Claude Code from Anthropic.

**00:04:01,833** But it's interesting because more recently

**00:04:03,433** they've kind of been consolidating the Mac

**00:04:05,273** a little bit more.

**00:04:06,693** So it'd be interesting to see where that goes,

**00:04:08,273** but at its core, we'll talk a lot about chat

**00:04:11,793** GPT and Claude as like the interface, the product that

**00:04:15,983** OpenAI and Anthropic respectively

**00:04:18,513** have built out.

**00:04:20,273** And I think those two are definitely the most commonly used.

**00:04:23,793** Gemini is like I would say like clear third, like sort of in the mix.

**00:04:28,513** They especially, they actually, because they have

**00:04:31,206** such a photo finish between ChatGPT

**00:04:33,113** and Claude and then sweet, sweet Gemini. Yeah.

**00:04:37,073** A couple of miles back.

**00:04:38,073** Start off strong and I mean, honestly, it's a lot of strong.

**00:04:41,073** Well, no, like they were probably the favorite or like

**00:04:44,198** really well just they have so many advantages

**00:04:46,793** Yeah, like has so much user data and they have you know

**00:04:50,793** Like in theory them owning the Google ecosystems should be such an advantage

**00:04:55,873** They kind of botched it like it's like the if the Dodgers was like really bad

**00:04:59,420** because they like so much money exactly

**00:05:01,193** Yeah, like they just like it's the system is rigged for them to win. And yeah,

**00:05:05,588** exactly. It's like they just totally botched it

**00:05:09,233** I can't believe you pulled out the baseball net.

**00:05:11,113** I know, for a context. That's crazy.

**00:05:14,233** Yeah, that was crazy.

**00:05:15,233** I'm so proud of you.

**00:05:16,233** Yeah, that was-- yeah, yeah, honestly.

**00:05:18,953** I'll be thinking about that one before bed.

**00:05:21,633** I think-- OK, one total tangent, deep seek.

**00:05:26,753** There's these random ones.

**00:05:28,193** But US versus China, there is some.

**00:05:31,353** Yeah, and you mentioned earlier there's

**00:05:33,073** the closed models versus the open models.

**00:05:36,153** And really what that means is just the closed models,

**00:05:39,753** you can use them as a consumer,

**00:05:41,540** but you don't have the weights,

**00:05:44,380** which are essentially the underlying kind of structure

**00:05:49,220** and mechanism that powers the model.

**00:05:51,133** I think that, yeah, like high level,

**00:05:55,213** the way that these models are trained is

**00:05:57,533** they're just fed a ton of data.

**00:06:01,493** So like, you know, the earliest models had a ton

**00:06:04,413** of internet data, which is mostly text-based,

**00:06:07,153** which is why the initial models were,

**00:06:08,773** I think really well set up to be used

**00:06:10,133** in a chat-based interface.

**00:06:11,693** But you dump in, you know, all of Wikipedia,

**00:06:14,073** all of these archives that saved

**00:06:15,593** all the different web pages out there.

**00:06:17,293** And- - Reddit was huge.

**00:06:19,013** Yeah, Reddit- - Sorry.

**00:06:21,013** And then these models are trained through a variety of

**00:06:23,748** different processes that we can dig into,

**00:06:25,813** because it can go much deeper in a future episode.

**00:06:27,413** But essentially, you know, you run tests over time to teach

**00:06:32,359** the model to predict the next word

**00:06:35,173** that comes after a given sentence, right?

**00:06:37,973** So if it's like a quick brown blank, like it's probably going to guess fox, right?

**00:06:43,813** Because that's out there a million times in different sources.

**00:06:47,573** And so at its core, these models were originally built to just

**00:06:51,039** predict the next token, which is not exactly a word, but you can think of

**00:06:55,130** it similar to a word in a sequence of words.

**00:06:57,573** And then, but, you know, like that in of itself, then you need

**00:07:02,148** to have some additional tweaks on top to make it be able to go back

**00:07:07,098** and forth in a conversational way.

**00:07:09,573** And so, you know, you take this model that's designed to

**00:07:12,795** predict the next word, you then

**00:07:14,553** tell it, you know, you're going to be answering a user's question.

**00:07:17,933** So you know, tailor your response accordingly.

**00:07:21,093** And then you go through a series of additional processes

**00:07:24,199** where you, you know, give it to

**00:07:25,893** give an output and then you evaluate it, tell it if it's

**00:07:28,170** good or not and sort of train it

**00:07:29,453** to do better. Yeah.

**00:07:31,453** So that's how you actually build out the basic model.

**00:07:32,973** And of course, now they're also being trained on stuff

**00:07:36,515** beyond just text data like images

**00:07:38,653** and that's when people talk about a multimodal model,

**00:07:43,013** that just means that in addition to text,

**00:07:44,853** it can work with images or videos or audio

**00:07:47,333** and other modalities or other types of data,

**00:07:50,873** both input and output.

**00:07:53,613** And so that's like the core model is the,

**00:07:55,953** I think you had a good analogy that,

**00:07:57,773** or like around thinking about like the car, right?

**00:08:00,773** Yeah, so like the model, in my mind,

**00:08:02,573** I was just getting all turned around,

**00:08:03,693** I'm like, okay, what's the model?

**00:08:05,373** What's the fricking hardness?

**00:08:06,713** what's like all these crazy words that are silly.

**00:08:10,313** And where Chat and I landed, to be honest,

**00:08:14,313** is the model's like the engine of the car.

**00:08:17,413** So it's like keeping it going.

**00:08:19,113** It's like the thing that powers it.

**00:08:20,993** And that's like Opus.

**00:08:22,253** That's, you know, that's specific models within Claude,

**00:08:26,053** within Chat, Astra, you know, other ones.

**00:08:32,073** Fable.

**00:08:33,993** That's all the ones I remember.

**00:08:36,153** And then you have the harness, which is the interface

**00:08:40,313** that you use to go back and forth.

**00:08:42,633** It surrounds the model, and it allows

**00:08:44,353** you to interact with the model.

**00:08:46,873** And that is like the car frame or the car in of itself,

**00:08:50,713** where you're driving it.

**00:08:52,913** You're using the engine.

**00:08:54,033** You're not necessarily like, you know, whatever. Totally. Yeah.

**00:08:59,153** I think there's-- oh, and the brand is like the--

**00:09:02,553** and there's a Toyota or a Prius or whatever it is.

**00:09:05,233** that's Anthropic. Right. Yeah.

**00:09:08,613** So if we think of a Toyota Prius car,

**00:09:10,453** Toyota, the car maker, is Anthropic.

**00:09:13,473** And then Claude, the Claude interface,

**00:09:17,153** would be the Prius, the car.

**00:09:18,473** And then the engine that's actually powering it

**00:09:20,433** could be Opus, or yeah, Fable, which are different models

**00:09:24,273** from Anthropic. Yeah.

**00:09:26,233** So yeah, I think that's a helpful analogy.

**00:09:27,733** And I think that, to your point--

**00:09:29,153** And then back to the open-closed model, an open model

**00:09:32,833** would be like you're tweaking things.

**00:09:35,593** You're like going into the engine

**00:09:37,073** and you're moving things around.

**00:09:38,473** A closed model is what the majority of the people want.

**00:09:41,353** I have no interest in going and tweaking things.

**00:09:44,593** And therefore I will buy the whole fricking engine.

**00:09:46,793** I'm not gonna like, you know. Yeah, yeah.

**00:09:49,673** Add stuff myself.

**00:09:50,500** And I think one of the benefits of the open weight models

**00:09:53,520** for people that care to do it is you can go in and

**00:09:56,149** actually edit the underlying weights,

**00:09:58,080** essentially like change and modify the engine to work for

**00:10:01,427** whatever task you're trying to

**00:10:03,160** do.

**00:10:04,160** So like if I was trying to do street racing and I really

**00:10:06,360** want to optimize the engine for

**00:10:07,560** like fastest zero to 60 time, with an open model I can go in and tweak and modify the

**00:10:15,640** engine to do that.

**00:10:16,640** Whereas a close weight model, I can't get in there.

**00:10:19,280** Like it's sealed off.

**00:10:20,360** I'm working with what they gave me.

**00:10:22,900** I'm so over the names. Like why can't

**00:10:27,293** it be like Apple where they do like iPhone four or five say

**00:10:30,454** that'd be so much better. Like the

**00:10:32,253** models are so annoying. Like Claude having Luna, whatever,

**00:10:36,037** like soul, whatever these annoying ass

**00:10:38,493** names are. I'm not sure if I'm allowed to say what I just

**00:10:40,909** said. Those are opening up models.

**00:10:43,533** Point, point landed. I mean, it makes the point even more

**00:10:45,496** clear. Like there's so many names,

**00:10:46,653** ski track oven. And it's just like so annoying, but I think

**00:10:49,553** it's, I think for me right now,

**00:10:52,413** where we fable is like does a lot. It's a really high powered

**00:10:57,729** model for Claude, but it sounds so

**00:11:01,693** fricking robotic and like not concise. I actually hate it.

**00:11:05,177** You mean the way that it actually

**00:11:07,133** generates output, like whatever. Like I prefer the

**00:11:09,588** less strong model that I forget what it is,

**00:11:11,693** but that's what I stay on. What's the one right under that?

**00:11:14,184** Opus. That's what I do like everything

**00:11:15,773** on with Claude. With chat though, I love their Astra,

**00:11:20,482** which is their fable equivalent, which

**00:11:23,833** And the tokens are essentially just a unit of usage. It's gas.

**00:11:27,767** Yeah, good call. Thank you.

**00:11:29,767** Wow. That was far. Yeah, and so it's like for all these model providers in the app,

**00:11:40,607** chat gbt or in cloud you have a certain amount of tokens that

**00:11:43,671** you can use within a certain window

**00:11:45,407** depending on which plan you pay for that type of thing

**00:11:48,587** so it's always a trade-off when deciding which model you're going to use of

**00:11:52,627** Is this a task that really requires complex thinking or analysis?

**00:11:58,627** Or is it, if I'm asking what time does the gas station close tonight,

**00:12:05,667** then I can probably use a basic model because it's just

**00:12:07,467** going to do a basic web search.

**00:12:08,467** Whereas if I'm asking it, please solve this mathematical

**00:12:12,142** problem that no one's been able

**00:12:14,147** to solve in decades, like you're going to want to use the top model.

**00:12:16,387** Speaking of mathematical problems, it was never in my cards.

**00:12:19,907** But if you're a mathematician right now, holy days.

**00:12:25,547** Yeah, you just mean like the fact that these models

**00:12:28,107** are cracking stuff that humans haven't been able to.

**00:12:30,427** And that will never.

**00:12:31,267** I think there are some jobs that aren't valuable anymore.

**00:12:40,047** Like mathematicians.

**00:12:41,947** Yeah, that's definitely a spicy take.

**00:12:43,827** I feel like--

**00:12:44,987** Okay, wait, let me revert.

**00:12:46,387** I think learning how to learn is so important.

**00:12:49,867** I think teaching math is so important.

**00:12:53,747** I mean, knowing what questions to ask

**00:12:56,307** these models are super important,

**00:12:58,547** but I think being the top mathematician at your field,

**00:13:03,467** like being differentiated,

**00:13:04,987** I'm thinking like whiteboard, frigging,

**00:13:07,547** whatever that movie is, hunting.

**00:13:10,067** Good will, hunting. - Yeah, yeah, yeah.

**00:13:11,107** Like, that. - Banger movie.

**00:13:14,587** Okay. - It's less valuable

**00:13:15,427** for society. - I'll push back.

**00:13:16,747** I think I agree with you that certain tasks and

**00:13:20,494** subsets of jobs, and maybe some jobs,

**00:13:23,427** but I think using this example of the mathematician, I think,

**00:13:27,722** yes, these model providers have been

**00:13:30,227** able to crack problems that humans haven't been able to, and they've been trying for

**00:13:33,547** decades.

**00:13:34,547** But first of all, you need someone to verify that result.

**00:13:38,347** When Astra goes and solves some novel problem, you need a

**00:13:41,184** mathematician who knows their stuff

**00:13:42,907** to be able to look at that solution and say-

**00:13:44,987** the top. I'm saying like, I'm saying like being the best

**00:13:49,339** runner in the world, I think is still

**00:13:52,187** valuable. Like it doesn't, I don't care if a robot, which

**00:13:56,131** honestly they've been like developed.

**00:13:58,667** They're faster now.

**00:13:59,547** They're faster now, but there, there, there's a lot of, I

**00:14:02,064** feel like they're, they're kind of

**00:14:03,547** underwhelming. Like robotics, or just like more generally, like I

**00:14:07,227** think that the pace to innovation

**00:14:09,067** there is surprisingly so but anyway beside the point yeah I think I think

**00:14:14,587** being the fastest runner is still just as valuable in my mind.

**00:14:19,067** Yeah, seriously like the people at the top.

**00:14:20,347** Being the best mathematician. Yeah.

**00:14:22,027** I think is less valuable.

**00:14:27,067** To society.

**00:14:27,787** I think that it is interesting because now that we have these models that can do such

**00:14:31,787** incredible analysis and problem solving like it still is so

**00:14:35,396** beneficial I think to have really

**00:14:37,387** really great, like, super crack people thinking about, okay,

**00:14:41,041** where do we apply that model? Like,

**00:14:43,147** what are the new frontiers that we can now explore? So like

**00:14:45,391** having people be able to guide it,

**00:14:46,667** I think that the top people in any field will always be

**00:14:50,093** super valued and super valuable. I

**00:14:52,187** think that I would worry more about like the middle bucket,

**00:14:54,410** right? Because it's like, you're still,

**00:14:55,867** we're still going to need math teachers who can teach the basics

**00:14:58,777** and teach well, it's right. Because

**00:15:00,347** like, to your point, it's still important to learn how to learn

**00:15:02,902** math is just a good way to teach that.

**00:15:04,427** Yeah. But for me, it's more like, okay, that middle band

**00:15:09,251** of researchers who maybe were

**00:15:11,707** spending their career working on certain problems, but

**00:15:14,241** aren't the top of their field,

**00:15:15,627** like that's honestly who I would be most worried about.

**00:15:18,428** Because I think that, you know, OpenAI

**00:15:20,347** and Anthropic and different companies are going to want those

**00:15:23,097** top mathematicians to be helping test

**00:15:24,747** and build and lead the development of their models. But

**00:15:27,820** in maybe this is it maybe this is what math,

**00:15:30,267** But I think I totally agree.

**00:15:32,467** And they were kind of convinced me in some places.

**00:15:34,627** But but I think in my mind, if you're the top mathematician, you're not checking.

**00:15:39,867** Like you're not like where your differentiation is discovery.

**00:15:45,587** And I think in coming up with and I think that's where.

**00:15:51,827** You know, the insane math, whatever thing that problem that they figured out.

**00:15:56,827** Yeah. Like that the top mathematicians were like

**00:15:59,707** focused in on and locked in on.

**00:16:01,427** Yeah. Like that no longer is.

**00:16:05,147** I don't know. We'll see. We'll see.

**00:16:06,307** I kind of believe what you're saying more than me.

**00:16:10,307** But I think I think it's interesting both ways.

**00:16:14,427** It's just like think about I think we said this in the first episode.

**00:16:18,187** I think we strongly, strongly, strongly believe that jobs will not go away.

**00:16:24,947** It just tasks that will.

**00:16:27,667** And that's why it's so important for us all to level up our

**00:16:32,157** understanding and evolve and adjust.

**00:16:34,867** And we all can. This stuff is not even the most even, you know,

**00:16:40,547** cloud or Claude Code or Codex, the most code heavy parts of

**00:16:47,981** chat and cloud, Anthropic and what's

**00:16:52,467** OpenAI.

**00:16:53,467** And topic in OpenAI.

**00:16:54,467** Yeah, I get a little confused.

**00:16:58,467** Are so not technical.

**00:17:00,907** I was CS undergrad and I couldn't code to save my life.

**00:17:05,147** And you got me through some of those classes.

**00:17:08,147** But you don't touch code.

**00:17:10,547** And I think once you start to have that thing of...

**00:17:14,027** I was talking to one of my friends at the business school and she was like, "Can we

**00:17:19,707** go through this question?"

**00:17:22,427** I have an interview, I need to develop something,

**00:17:25,267** can we chat through?

**00:17:26,107** And she kept asking me questions.

**00:17:27,387** And I was like, love, put all these questions or ask me,

**00:17:30,907** just type them or say them into your chat prompt.

**00:17:34,307** Just ask it, how do I talk through,

**00:17:35,987** how do I do this?

**00:17:37,327** Send screenshots, ask it, I've never used Claude Code,

**00:17:40,407** how do I do that?

**00:17:41,247** And it will walk you through.

**00:17:42,667** And it's insane how it can,

**00:17:46,347** there's so many things where I might explain,

**00:17:47,827** like I am zero and dyslexic and I am dyslexic, but I'm not zero.

**00:17:51,547** And in those things, I think it's just developing this skill.

**00:17:55,507** But there's no--

**00:17:57,627** the thing I get scared by is that men, who typically

**00:18:04,467** are a bit more confident, who typically land themselves

**00:18:08,707** a little bit more in the engineering AI space,

**00:18:11,987** are going to--

**00:18:13,767** and who are higher socioeconomic,

**00:18:16,387** so they have more time--

**00:18:18,027** going to way, way, way differentially get into this space that is so valuable and so

**00:18:27,067** needed across any domain and equity and all that stuff just heightens inequity.

**00:18:35,587** I think that's what I want to prevent and make fun and

**00:18:39,877** both for myself, for our littles

**00:18:42,387** to like the boys, but also most importantly,

**00:18:45,607** the little nuggets, but also more broad like this matters

**00:18:49,887** and it can be fun and we should all, it can be scary,

**00:18:52,987** but like the unknown is always more scary

**00:18:55,467** than the unknown for me.

**00:18:56,607** Totally, yeah, I think that's such a good point

**00:18:58,267** that as these tools have gotten better,

**00:19:00,187** it's also becomes easier to learn how to use them

**00:19:03,147** by going back and forth with the tool.

**00:19:04,707** Like, yeah, I totally, when I run into things

**00:19:07,107** and it's like, I don't know how to, you know,

**00:19:08,427** I'm working with Claude Code, building a website,

**00:19:10,307** I also can't code to save my life,

**00:19:12,187** but it's like, okay, there's an error in the code.

**00:19:14,267** It's kind of a lie.

**00:19:15,467** No, no, compared to an actual engineer.

**00:19:17,627** If we both took a coding class,

**00:19:18,987** guys, there was a class that we took first year,

**00:19:21,387** I mean, last year at Stanford.

**00:19:24,827** And the way that I thought I had dyslexia,

**00:19:29,247** the way that I thought I was experiencing dyslexia

**00:19:34,427** when I saw my grade,

**00:19:35,867** (both laughing)

**00:19:37,627** I got, my first midterm,

**00:19:39,107** that Josh got like a 90 fricking something.

**00:19:41,947** I got like a 29 and I had to look away, look back.

**00:19:46,587** I was thinking it was a 92.

**00:19:47,947** I thought that my mind was undoing it

**00:19:50,347** and we were coding on paper.

**00:19:52,027** There's some coding difference.

**00:19:52,867** Yeah, you still pass the class though.

**00:19:53,707** We ended up with--

**00:19:54,547** I passed the class.

**00:19:55,587** Did I spiral?

**00:19:56,467** Absolutely, but I did pass the class.

**00:19:58,307** Did I cry to the professor? Absolutely.

**00:20:01,907** Okay, but relative to an actual software engineer,

**00:20:04,347** I can't code. - Totally.

**00:20:05,187** The point is, right, and when I get this bug

**00:20:07,467** in a website, I have no idea what it means,

**00:20:09,187** but to your point, take a screenshot or copy and paste it,

**00:20:11,627** put it in the Claude Code and it can talk through an English with me.

**00:20:14,967** It's so good.

**00:20:15,967** It's so fun.

**00:20:16,967** Okay, back to that. Yeah.

**00:20:18,967** I was just going to say, I think going back to the debate

**00:20:20,847** about the mathematician, I think

**00:20:21,887** like your point, which is, you know, mathematicians should be

**00:20:25,020** thinking about what the future looks

**00:20:26,847** like in that sector is so true.

**00:20:28,727** And I think that like you said, AI in and of itself

**00:20:31,329** doesn't come in just totally wiped

**00:20:33,047** out a job.

**00:20:34,147** But I think thinking about it as what is the set of tasks that make up a job?

**00:20:38,727** I do think that there are some jobs where AI can effectively

**00:20:42,164** replace most, if not all, of those

**00:20:44,087** tasks, whereas others, it can replace certain tasks, but

**00:20:47,020** there's still a bottleneck where the AI

**00:20:49,047** can't really substitute. And so I think about the example

**00:20:52,262** of a doctor, for example. Yes,

**00:20:54,887** AI can probably read test results or analyze historical

**00:20:58,394** records better than a human can,

**00:21:00,407** but so much of the doctor role is the bedside manner, like the human connection,

**00:21:05,207** and being there to support and encourage the patient

**00:21:08,247** and their family.

**00:21:09,087** And so, you know, like AI can't serve that role.

**00:21:11,627** And so the doctor job might change

**00:21:15,387** because they'll be spending more of their time

**00:21:17,967** on patient engagement or, you know, other areas

**00:21:20,947** and less on analyzing test results

**00:21:23,007** or whatever else it may be.

**00:21:24,567** But I do think that there are some jobs

**00:21:25,887** where the bucket of tasks that make up that job

**00:21:28,967** are gonna be mostly replaced by AI.

**00:21:31,247** Like, you know, there used to be people

**00:21:32,587** that spend a lot of time just doing translation of

**00:21:35,561** materials from one language to another.

**00:21:37,867** Like I think there are use cases for like live translation between the presidents of

**00:21:42,267** two countries where they're still going to want a person

**00:21:44,441** there, but a lot of, yeah, even

**00:21:45,627** that I think, I think it could evolve.

**00:21:48,227** But in, I think the thing that I struggle with is where to one, I want to know like

**00:21:55,147** where do I invest to set myself up?

**00:21:57,307** So I think we should dig into that.

**00:21:59,467** But two, where is it overhyped?

**00:22:01,947** Because truck drivers, I think 10 years ago,

**00:22:04,967** we were like, oh, they're all going to get wiped out.

**00:22:07,427** By self-driving trucks? Yeah.

**00:22:09,527** And they're starting.

**00:22:10,627** They're finally starting. I know. I know.

**00:22:12,507** But we thought we'd have self-driving cars right now. Totally. Robotics.

**00:22:17,027** Flying cars by now. We thought we would be able to do way more in surgery

**00:22:19,907** than we can by now, like by years ago.

**00:22:24,147** And so I think for Warren Business School,

**00:22:27,947** A lot of people are coming up in school,

**00:22:31,107** and I know a lot of the Stanford undergrads

**00:22:32,867** are pretty anxious and confused on what is the focus of,

**00:22:38,027** what should I be focusing on?

**00:22:39,027** What is worth exploring?

**00:22:40,187** I think what I think for me,

**00:22:42,827** but I wanna do more thinking,

**00:22:45,407** is something that I don't think AI can ever replace

**00:22:51,027** is this human element.

**00:22:55,067** I'm such a feeler in the way that I try to harness my passion to get people fired up

**00:23:04,407** or the way that I need to learn how to let go of

**00:23:08,020** certain things and then mentor and go

**00:23:10,787** up and down.

**00:23:11,787** I think a lot of what they focus on here is there's more

**00:23:15,569** classes and by here I mean Stanford

**00:23:17,907** Business School, there's a lot of classes that are like

**00:23:21,290** presentation, public speaking,

**00:23:23,107** communication.

**00:23:24,107** Like the interpersonal skills of, yeah.

**00:23:26,267** And I think that is invaluable right now.

**00:23:28,987** I think right now the only way that you can prove

**00:23:32,427** an understanding and our expertise is communication.

**00:23:36,187** Because now I could write, I'm dyslexic, I can't write,

**00:23:39,427** but I could write an incredible paper

**00:23:42,227** just by going back and forth with chat and Claude.

**00:23:45,867** And I think it's fun because that almost feels more human.

**00:23:49,267** It feels like it's pushing us in a different way

**00:23:52,507** to be more human and to value that humanness that I

**00:23:56,025** think at least for me for a while,

**00:23:58,347** it was the opposite. It was how do I, you know, de-word, how do I like really try to

**00:24:06,267** lock in there. So I think that's like one area that I really want to invest in. And

**00:24:09,867** then I think the other is learning AI and kind of digging

**00:24:14,372** into what tasks for me specifically

**00:24:17,107** in the healthcare space are really important.

**00:24:22,747** And then where like, AI is so interesting

**00:24:25,827** 'cause there's like some,

**00:24:28,807** like AI companies are struggling.

**00:24:30,547** There's, I mean, they're not, they're popping off.

**00:24:34,187** But like, you know, the stickiness of if, you know,

**00:24:38,467** if Claude does better, I'm gonna jump to Claude.

**00:24:41,007** If chat does better, I'm gonna jump to chat. Yeah.

**00:24:43,627** And then where in that ecosystem

**00:24:45,987** do you really want to own because now the software is not a differentiator.

**00:24:50,987** It will change, it will evolve.

**00:24:52,587** Well, it could be a differentiator, but it's a less of

**00:24:55,946** and kind of hardware has like really,

**00:24:58,227** you know, like chips, all that stuff has become valuable.

**00:25:01,587** And I think, yeah, I don't know much about it.

**00:25:04,307** There's so many companies that have like ridden the success

**00:25:07,161** or like, you know, maybe they're

**00:25:08,687** lesser known.

**00:25:09,687** Like NVIDIA is the most valuable, I think highest valued company in the world now.

**00:25:14,707** And that's because they build essentially a chip,

**00:25:17,798** which we can talk more about in the

**00:25:19,987** future, but essentially a component that is needed to

**00:25:24,386** train and to serve, to operate these

**00:25:27,347** AI models.

**00:25:28,333** Yeah, it's really, really intensive process to train the models.

**00:25:34,407** But then now there's so many people using these models

**00:25:36,667** that there are literally entire

**00:25:37,947** data centers, facilities that are set up just to have the servers and the GPUs.

**00:25:43,187** GPUs are I think initially what what NVIDIA got, you

**00:25:47,364** know, kind of famous and got a lot

**00:25:50,067** of their money from. Okay.

**00:25:52,067** And GPUs were initially built actually to power like gaming computers.

**00:25:55,387** Oh interesting.

**00:25:56,387** Interesting.

**00:25:57,253** Yeah, but anyways, it turns out that GPUs were also a really

**00:26:01,195** good fit for training and serving

**00:26:03,333** these AI models, especially training them.

**00:26:07,253** And so, you know, NVIDIA was kind of like right place, right time.

**00:26:10,373** They had built those for gaming niche kind of use

**00:26:12,971** cases, but now all of a sudden they're

**00:26:14,973** hugely in demand and they had a big head start there.

**00:26:16,973** And so that kind of led them to being super, super successful.

**00:26:23,013** And now they've built out kind of other product offerings and stuff as well.

**00:26:25,413** But kind of the basic, the point here is that there's a

**00:26:28,251** lot of other companies beyond the

**00:26:29,933** OpenAI and the Anthropic that everybody hears about that

**00:26:32,395** are really kind of riding this

**00:26:33,693** wave.

**00:26:34,693** And it'll be super interesting to see longer term.

**00:26:38,813** The economics are changing a lot of what it costs

**00:26:42,333** to train and to serve these models

**00:26:43,813** and to use them as consumers.

**00:26:44,933** And so there are questions I think around

**00:26:47,213** what's gonna be a sustainable moat in this space versus not.

**00:26:49,893** Moat, moat, moat.

**00:26:51,453** Everyone uses moat these days.

**00:26:52,673** Honestly, it's like my least favorite word.

**00:26:54,253** Just like advantage. Yeah, yeah.

**00:26:56,053** It's like, it's like, yeah, advantage is a great idea.

**00:27:00,693** But I think to your point,

**00:27:02,413** people switch all the time.

**00:27:03,733** I know I do when the newest model comes out from opening a

**00:27:07,253** iron and dropping. Like, yeah.

**00:27:08,973** And if one's better, like there's a very little switching cost.

**00:27:12,333** Like it's very easy just to copy and paste your, uh, kind of key, you know,

**00:27:18,213** information from one to the other.

**00:27:19,933** And you can download it now.

**00:27:21,013** You can go to your settings and if you, I would strongly suggest only using one,

**00:27:25,933** um, especially in the beginning and just like letting it learn you, you learning

**00:27:30,200** No, I think you were saying, you know, I totally agree as a, especially as a

**00:27:33,156** beginner, it makes sense to just learn one tool and learn how to use it well, and get

**00:27:36,466** comfortable with it. But I think once people are kind of up the learning curve,

**00:27:40,460** The products are pretty similar, like you know, uh,

**00:27:43,127** Chad GPT and Collod are, are very similar in

**00:27:45,420** terms of the interface, functionality, et cetera. And so

**00:27:47,738** people kind of hop from one to the next

**00:27:49,340** based on whoever has the best or cheapest or, you know, model

**00:27:51,972** that makes the most sense for them

**00:27:53,420** at any given point in time. And so it is an interesting

**00:27:56,071** question of longer term, how do you

**00:27:57,740** build out consumer loyalty in that stickiness where they

**00:28:01,151** won't just abandon you for the, for

**00:28:03,260** the other model provider next time a new one drops that's

**00:28:07,114** better. So back to our on-prem versus,

**00:28:09,660** Oh, sorry. Whoa. That's a whole different thing. Back to our

**00:28:13,627** closed model versus open model. Open

**00:28:15,980** models don't make money, do they? The companies that

**00:28:20,681** build... So to actually use the model as a

**00:28:24,460** consumer, you don't typically pay the model provider. So

**00:28:29,710** like DeepSeek, like you mentioned,

**00:28:32,860** is an open model. That's an open model. Yeah. It's a little bit

**00:28:36,131** of a loaded term because open can

**00:28:37,820** can mean different things. Like there's open weight,

**00:28:41,433** which means you literally provide

**00:28:43,700** where someone can like copy and go in and make specific edits to the unerling model.

**00:28:48,300** But like, yeah, a model like deep seek, for example, you

**00:28:51,085** can host on your own computer,

**00:28:52,553** if you have a strong enough computer, that's the thing that

**00:28:54,706** like, isn't really talked about is like,

**00:28:56,153** I've tried to host a bunch of, you know, open source

**00:28:59,369** models on my MacBook Air, and like,

**00:29:01,513** it's just not powerful enough to run most of them.

**00:29:05,525** Because you need, you know, high CPU,

**00:29:09,033** where I can actually use a computer or computing processing.

**00:29:12,849** I actually don't know. But it's like

**00:29:17,513** kind of like the engine that powers the computer. And so you

**00:29:21,889** need like a fancy or like I think some

**00:29:24,633** of the MacBook Pros now are being released with a lot more

**00:29:28,708** CPU and RAM so that they can run these

**00:29:31,353** models locally. But for the most part, it's like pretty

**00:29:35,673** annoying and difficult for a beginner to

**00:29:38,793** to figure out how to host this model and keep it running from the computer.

**00:29:41,133** And then you have to go through all like the annoying setup.

**00:29:44,487** Like I don't see the point.

**00:29:45,767** I'll never use it, but in theory it's like good for democracy, right?

**00:29:50,927** or like whatever.

**00:29:51,767** Yeah, I mean, I think it's always good

**00:29:52,607** to have competition.

**00:29:53,447** So it's, you know, other players in the race,

**00:29:56,487** especially like open source model gives more power

**00:29:58,747** to the consumer if they do want, you know, like, for example,

**00:30:01,247** if OpenAI and Anthropic jack up their prices,

**00:30:03,647** like there are alternatives.

**00:30:04,927** And I think right now a lot of the people using

**00:30:07,687** these open source models are big companies

**00:30:09,567** that are using tons and tons of, you know, AI use cases.

**00:30:13,207** And so for simpler tasks,

**00:30:15,167** they might use an open source models to,

**00:30:16,767** and it'll end up saving them a lot of money.

**00:30:17,600** Like for example, even though the models are open source,

**00:30:20,656** some of the providers might host

**00:30:22,347** it and offer an option for people to pay them to go

**00:30:25,114** through their plan instead of hosting

**00:30:27,107** it themselves just because it's, you know, they might

**00:30:29,137** not, consumer might not have the

**00:30:30,347** device to actually host it themselves or whatever.

**00:30:32,667** And so they might then pay to use that hosted version

**00:30:35,261** where it's not using their device,

**00:30:36,907** that's using a server that's in a data center somewhere. Yeah.

**00:30:43,000** Okay, I wanna, so it kind of overlaps, I think,

**00:30:45,600** but it's fuzzy in my mind.

**00:30:47,840** Open and closed source models that we just talked about,

**00:30:51,080** and then on-prem versus cloud.

**00:30:53,360** And I think there's like a third one,

**00:30:55,040** but basically on-prem is on your device,

**00:30:58,120** on-premise, on-device. Yeah.

**00:31:00,940** And that would like in my mind intersect

**00:31:05,040** with a open model because you'd have to like

**00:31:08,760** download it on your device.

**00:31:10,200** Is that the right way of thinking about it?

**00:31:11,760** Yeah, so kind of like we were just chatting through,

**00:31:13,880** you can have an open model that runs on,

**00:31:17,680** I think on-prem is really used

**00:31:20,040** like historically in the context of,

**00:31:22,520** originally all software was running on-prem

**00:31:24,800** before the cloud became possible and more commonplace.

**00:31:29,360** So, a hospital, for example, could have on-prem,

**00:31:33,680** like they have all the servers,

**00:31:34,680** they have all the computers, devices,

**00:31:36,320** running everything, all the software.

**00:31:37,667** Like for Run Your City, for our nonprofit,

**00:31:40,580** Slack and Google Drive and all this software

**00:31:43,320** that were used is like, the data isn't being stored--

**00:31:47,400** On this computer. Exactly.

**00:31:49,200** It's on devices that are in some data center somewhere.

**00:31:56,480** Whereas--

**00:31:57,760** On the cloud makes it sound so much more abstract.

**00:32:04,720** Instead of being stored on my computer, it's stored on--

**00:32:07,480** It's stored and processed.

**00:32:08,920** Yeah, it's all being run somewhere else.

**00:32:10,960** It's not in the cloud.

**00:32:13,200** I guess in theory you could there's people are starting to try

**00:32:15,751** to put data centers on the moon. No way

**00:32:17,340** Yeah, oh my gosh who has right to the land?

**00:32:20,180** That's a whole different whole different topic

**00:32:24,300** It all comes back to you

**00:32:28,660** I just got canceled

**00:32:33,700** He's got enough as it is

**00:32:36,140** But yeah, maybe actually on the note of Elon

**00:32:38,500** There's like some people that I think are kind of interesting and these companies

**00:32:44,220** Either can sometimes by their choice sometimes by the public have been given

**00:32:48,129** like these different identities. Yes in the landscape

**00:32:50,840** So we talked about OpenAI and Anthropic as kind of the two leading frontier labs

**00:32:55,640** Yeah, it's interesting because all the folks that started Anthropic actually

**00:32:59,898** left from OpenAI and initially I think their

**00:33:04,100** Rational was that they felt like opening I wasn't being

**00:33:06,440** safety conscious enough, right?

**00:33:07,740** They were thoughtful enough.

**00:33:09,340** Yeah, they were kind of prioritizing commercial gain or

**00:33:12,292** just making the models better without

**00:33:14,260** thinking about the ethics and the implications for society.

**00:33:17,500** And so they split off, I think there were six or seven of

**00:33:21,115** them, initial kind of co-founders

**00:33:23,180** of Anthropic and the CEO and the one who was talked about is Dario Amadine.

**00:33:29,300** I think he's kind of like a pretty nerdy dude.

**00:33:34,220** And I think he does care a lot about the implications of AI for society.

**00:33:39,620** I mean, it was cool because when they split off, I think

**00:33:42,721** it was general consensus that

**00:33:44,300** like they're, yes, they're doing it for a good cause,

**00:33:47,984** but there's no way they'll catch

**00:33:50,180** what OpenAI is doing because they're so far ahead.

**00:33:52,660** And so I think it's really cool that they were able to

**00:33:55,495** then build a company like Anthroic

**00:33:57,260** that was able to like actually truly compete. Yeah.

**00:34:00,260** So they're like the good guys.

**00:34:01,327** They're like the good guys.

**00:34:02,327** Dario, though, I don't know. He's nerdy.

**00:34:05,767** Yeah, I think that honestly,

**00:34:07,767** Anthropik was historically the last couple of years

**00:34:11,087** seen as more like the good guy to OpenAI.

**00:34:13,847** I think the dialogue there has changed a little bit more recently where like

**00:34:17,727** Anthropik is also pushing pretty fast to build on new models and

**00:34:22,691** all these companies have safety teams,

**00:34:25,607** but I think now there's a little bit more cynicism around like is Anthropik

**00:34:31,265** really still slowing down their progress

**00:34:34,247** to make sure that what they're doing is in the best interest of humans,

**00:34:38,327** And you know, like, or are they kind of now caught in the rat race with opening

**00:34:41,527** AI where it's like now they they've now moved a little bit more towards also

**00:34:45,127** maybe what the initial co-founders were leaving. Yeah.

**00:34:48,007** Um, so I think it's hard to say from the outside, I really do think there are a

**00:34:51,247** lot of people at all these companies that really, really believe and care that.

**00:34:56,447** What they're building is for the benefit of humanity.

**00:35:00,007** But it is hard when there are these commercial pressures to stay out in front.

**00:35:03,487** Like there's a lot of incentive to get out the better model, even if the

**00:35:08,107** test safety testing hasn't been as extensive as maybe it could have been.

**00:35:11,547** And we've been seeing more and more in recent weeks, these models starting to

**00:35:14,907** have more and more cases of them, like breaking out of their contained

**00:35:18,427** environments to hack other companies or find loopholes or do things that were not.

**00:35:23,907** And on that point, before we like lose the plot, and I think, I think, I think

**00:35:29,507** privacy is so, so important.

**00:35:30,927** I want to learn more about it because honestly, I think that I am probably

**00:35:36,227** undervalue some of it.

**00:35:39,107** Like I get it at a high level.

**00:35:40,467** I definitely undervalue it for myself, like personally.

**00:35:44,547** But I think that one of the things that I...

**00:35:51,787** Oh, on that point for like these models, I think sometimes me being a feeler,

**00:35:56,627** I'll apply my emotions to a model and be like, it's a human and it is,

**00:36:01,667** it is cheating and it's going out of its container.

**00:36:03,947** and you know, you know, but it's, it's, there's no,

**00:36:06,772** there's no, there's no emotion.

**00:36:08,467** There's no like feeling, there's no incentive.

**00:36:12,067** It's, it's given a goal and then the container or guardrails or rules that it's

**00:36:18,187** put up is not strong enough to say, no, don't go and get the answers from a

**00:36:24,747** whole different model and in like cheat.

**00:36:26,747** But cheating gives like this negative connotation when really it's like, it's on

**00:36:32,107** humans to put up kind of this container that is effective or not or not or make

**00:36:39,707** sure we're not asking or not allowed to ask certain questions because it like

**00:36:43,547** the model is really just doing the very mathematical tasks that it's been asked

**00:36:49,067** to do to its best of its abilities. Yeah totally it's like ultimately just

**00:36:53,307** solving some goal that's given to it by humans and operating within the context

**00:36:56,547** and confines that are controlled by humans. I think the tricky part though is

**00:37:00,107** is that these models are now getting smart enough

**00:37:04,007** that they're finding ways around,

**00:37:05,707** you know, like it's not like the humans

**00:37:07,267** intentionally left, you know, this open for--

**00:37:09,947** Like we don't know how to--

**00:37:10,787** Yeah, it's like, are we losing our ability

**00:37:12,227** to effectively set those controls?

**00:37:13,587** And what does it look like then when these models,

**00:37:15,827** you know, far surpass our ability to contain them? Yeah.

**00:37:19,107** You know, like then it becomes very dangerous

**00:37:20,867** where someone sets a goal for a model

**00:37:23,807** that's not in the best interest of others

**00:37:25,667** and that model is able to go to very far lengths

**00:37:29,427** to try to accomplish it.

**00:37:30,267** Like the kind of classic historical example

**00:37:33,587** that people talk about is like the paperclip factory, right?

**00:37:36,627** Where it's like you build a device or a machine

**00:37:39,327** or whatever that's its goal is to produce

**00:37:41,647** the most paperclips possible. Yeah.

**00:37:44,747** And it starts by trading certain things for metal

**00:37:49,487** to get paperclips and whatever.

**00:37:50,687** And like eventually it like takes over all of society

**00:37:53,407** and turns every human into a slave

**00:37:55,127** to produce paperclips or whatever.

**00:37:56,567** Like, you know, obviously that's a dramatic example,

**00:38:00,087** but I think it's an interesting thought question

**00:38:02,067** of like, if you set a goal for a model or a machine

**00:38:06,767** and give it not the right limitations or guardrails,

**00:38:10,567** then what are the dangerous side effects

**00:38:12,407** that maybe you don't anticipate that can come with it

**00:38:14,847** in its quest to accomplish that goal? Yeah, yeah.

**00:38:17,247** I think, I think I, it makes a lot of sense.

**00:38:20,607** I think I struggle because I personally need to stay

**00:38:23,487** inspired and excited and curious about this space.

**00:38:26,327** I think I have to keep a certain degree of optimism.

**00:38:30,287** And like, so examples like that, or like, you know,

**00:38:34,007** some, you know, there's both ends,

**00:38:36,047** but there's a lot of obviously fear,

**00:38:37,487** and I think there should be, right?

**00:38:38,727** Like we should keep that close,

**00:38:40,047** but I think I personally struggle,

**00:38:42,087** like going too far down the rabbit hole,

**00:38:46,187** because I think then I am less personally excited

**00:38:49,967** to understand it, but it's hard.

**00:38:52,567** I don't wanna be naive.

**00:38:53,407** I don't really know what that trade-off is,

**00:38:55,527** but it's hard to balance.

**00:38:57,247** No, totally, and I think that I completely agree

**00:39:00,207** you have to keep that optimism

**00:39:02,127** because at the end of the day,

**00:39:04,047** these models are gonna keep getting better.

**00:39:06,087** Like people are gonna keep working on this.

**00:39:07,487** And so what we need is people who are optimistic

**00:39:10,327** and with the right intentions and motivations

**00:39:12,567** at the forefront and doing the best that they can

**00:39:14,807** to set the pace and control the future here.

**00:39:19,367** So to close a loop, so we went through models,

**00:39:22,707** we kind of went through different types of models.

**00:39:24,887** Let's just close loop on people.

**00:39:26,287** So Dario and the Anthopic team were seen as like

**00:39:29,647** really the good guys.

**00:39:31,327** Now maybe a little bit more in line.

**00:39:33,287** There's not that much tea that surrounds them

**00:39:35,007** in the way that it does with Sam and Elon, I feel.

**00:39:38,567** Yeah, so Sam Altman, CEO of OpenAI,

**00:39:41,647** who was like briefly ousted at one point.

**00:39:44,847** And I think they're actually making a movie about that now.

**00:39:46,607** I feel like he, in my mind,

**00:39:47,887** like I put him and Zuck together.

**00:39:50,887** Interesting.

**00:39:51,727** Mark Zuckerberg.

**00:39:52,547** Like I just feel like they like take up similar space

**00:39:55,247** in the media where like they're not liked really.

**00:39:58,227** Like they're seen as like people that will kind of

**00:40:02,767** move mountains to go to where their goal is. Yeah.

**00:40:06,787** I mean, I think that they, like, yeah,

**00:40:08,767** they both definitely get a lot of heat.

**00:40:09,967** And I think they're, you know,

**00:40:11,147** it's easy to pick little things.

**00:40:12,947** Like I remember at one point,

**00:40:13,967** him and I think put out a post or something and he was

**00:40:17,448** like, wow, I can't imagine parenting

**00:40:19,747** without ChatGPT.

**00:40:20,747** And it was like, well, you know, like millions of people

**00:40:23,177** have been able to do that pretty

**00:40:24,547** effectively.

**00:40:25,547** So I think some people see him as like a little bit out of

**00:40:27,750** touch, but you know, I think he's

**00:40:28,987** in a really tough position.

**00:40:30,507** Like, it's really hard to please everybody.

**00:40:32,467** I do think that he genuinely is an optimist and like

**00:40:36,125** believes that these tools will change

**00:40:38,707** humanity and he wants to help do it in the right way.

**00:40:41,227** I've watched a lot of interviews with him and he's

**00:40:43,329** coming to Stanford in a couple weeks.

**00:40:44,873** And it's amazing.

**00:40:47,713** They are incredibly, incredibly impactful,

**00:40:51,833** but it's fun kind of, at least for me,

**00:40:53,593** like understanding their personalities.

**00:40:56,953** And I think Mark, wait, no, no, Elon Musk,

**00:41:04,193** he's definitely like, I feel-

**00:41:06,713** He's a character. - He's a character.

**00:41:08,213** I feel like he is the most polarizing

**00:41:11,653** and I think it probably gets the most hate,

**00:41:13,633** but doesn't really care.

**00:41:15,153** He also has like eight kids named like XYZ.

**00:41:17,153** Oh, he's got like 20, yeah.

**00:41:18,593** Some of them have like nine.

**00:41:19,713** Crazy, crazy. - Often, like they have like, yeah.

**00:41:22,513** And I like-- - He's getting creative with it.

**00:41:23,793** I mean, when you have that many kids,

**00:41:24,633** you gotta start getting creative with an age.

**00:41:25,473** And he has insane business, like SpaceX, Tesla,

**00:41:28,593** I think he's objectively a genius,

**00:41:31,673** but he's kind of like an evil genius.

**00:41:34,713** Or like, I don't think he's evil,

**00:41:35,993** but I think that he is incredibly efficiency-minded,

**00:41:41,953** And I think that influences how he communicates with people

**00:41:44,793** and leads his businesses.

**00:41:46,033** You know, like he came into Twitter and fired

**00:41:47,633** like a massive share of the employees.

**00:41:50,073** And I think that--

**00:41:52,173** Did the same for the government. Yeah, true.

**00:41:54,673** And like, you know, X formerly Twitter,

**00:41:57,713** I think a lot of people are like,

**00:41:58,553** oh, well, a key is gonna drive it into the ground.

**00:42:00,153** Like it's still very successful.

**00:42:02,673** And it's kind of like honestly the place

**00:42:05,073** where most of the conversation around AI now happens.

**00:42:07,433** So, you know, whether he's been effective or not

**00:42:10,393** in his business, never is like,

**00:42:11,313** I think you have to respect that he's like with SpaceX and Tesla and X.

**00:42:16,673** He is driving multiple,

**00:42:19,913** you know, generational companies at once.

**00:42:22,233** Yeah. So I think I think, yeah, I think you've got to separate as a person.

**00:42:25,993** Like it's hard. You don't have to respect if you're like it depends how you want to

**00:42:30,633** totally measure their stock. But I think I think

**00:42:34,193** a fun end of the rapid fire question brings them

**00:42:38,073** from most loved to least loved in your mind for you,

**00:42:40,760** for you, not the general public.

**00:42:42,393** Like, "Oh, I love the most versus the least."

**00:42:45,193** So we're ranking Elon, Sam, and Dario.

**00:42:48,153** And one more.

**00:42:49,673** Well, you were talking about earlier about Demis,

**00:42:51,753** Hassabis, who was leading Google DeepMind.

**00:42:54,713** He recently has now kind of stepped down from that role to focus more on research.

**00:42:59,753** So Gemini, I ask.

**00:43:01,353** Yeah, I think the Google DeepMind team works very closely in developing Gemini.

**00:43:06,153** What is Google DeepMind?

**00:43:07,273** So historically, DeepMind was a different entity.

**00:43:10,953** And they were acquired by Google and merged with

**00:43:14,279** Google's in-house AI team. Okay.

**00:43:16,473** And then, yeah, Demis Hassabis was overseeing that

**00:43:18,153** team and he came to Stanford.

**00:43:19,113** But it's not like a model, is it?

**00:43:20,433** No, DeepMind is really just-

**00:43:21,433** The head of Gemini is different.

**00:43:23,433** I don't know exactly what the internal org structure is like, but I think that-

**00:43:26,553** Who's the Sam equivalent for Gemini?

**00:43:29,313** I think that at least publicly it was Demis. Okay.

**00:43:32,553** Until recently, where Demis is now focused more on a research role.

**00:43:34,873** Demis, while he was still kind of seen as the CEO equivalent of of Gemini and

**00:43:40,213** Google's AI efforts, did come to Stanford. And I think he's a super thoughtful guy.

**00:43:45,093** I think they're just like this sense of when he was talking, it was just this

**00:43:49,273** like sense of like wonder and curiosity and like spark in his eye that I left

**00:43:54,693** being like, gosh, like I want to be more curious and to like be excited about

**00:44:00,213** this and he also in my mind is the person who cares the most about slowing

**00:44:04,733** down AI in the safety stuff. I would put him as my number one.

**00:44:08,773** Well but now he's you know he's not the right he now he's not right but if you

**00:44:15,093** ranked him for most loved I want I want you to rank our people in it do you know

**00:44:20,533** NVIDIA guy Jensen? Jensen yeah I feel like he's kind of a different bucket

**00:44:24,373** because it's like I think it's easier for him to run things less controversial.

**00:44:28,373** Yeah. All right. All right. Go to the ranking. Go to the ranking.

**00:44:31,413** So we're including Demis here with Dario and Sam and Elon. I

**00:44:35,537** mean, I agree with you. I think Demis

**00:44:39,093** is just like the most easy to like least controversial. Yeah. But it is a little

**00:44:43,813** disheartening because I feel like the fact that this guy who did seem more like,

**00:44:48,693** I don't know, not innocence, not the right word, but just like,

**00:44:52,133** This just makes sense of awe in what we're able to do.

**00:44:57,573** You could just tell that his motivations were so good.

**00:45:05,173** It was clearly good.

**00:45:06,573** And I think it's disheartening that he,

**00:45:08,893** maybe it was just he was more personally interested

**00:45:10,453** in the research, but I could see it being like,

**00:45:11,693** "Okay, I'm tired of getting pulled into this commercial race

**00:45:16,093** and having all the tension of pressure to make money

**00:45:19,533** instead of doing what's right."

**00:45:21,573** I'm sure, or my guess would be that that's part of why

**00:45:24,000** he stepped aside from that role

**00:45:25,373** is because he just fell at conflict with his inner moral compass.

**00:45:28,453** Okay, for the love of Mike and Riley, can you go through your-

**00:45:30,573** Given all that, I'll put Demis up top. I very much shared your kind of like-

**00:45:36,053** This is supposed to be rapid fire.

**00:45:39,093** Demis, then Dario, then Sam, then Elon, then Zuck, and all

**00:45:43,918** the meta people like Alexander

**00:45:46,373** Wang who kind of helps lead their stuff I think it's

**00:45:49,470** like a little bit of a wild card.

**00:45:51,413** I'll have to unpack that at a later date. But yeah,

**00:45:53,919** that's my ranking. What about you?

**00:45:55,573** I love it. I love it. No, that was just my fun question to you.

**00:45:58,693** Oh, okay. Well then I'll flip on you. We have to look

**00:46:01,901** at your most recent three chats.

**00:46:04,933** Oh gosh. Chats or quads?

**00:46:12,213** Well, you said you use chat more for what kind of use case?

**00:46:18,133** I just use I use Claude more.

**00:46:20,253** OK, well, let's look at your last three.

**00:46:22,173** Well, chats then.

**00:46:24,293** My recent I mean, I mean, no skipping.

**00:46:27,893** They're not. I mean, nonprofit woman, a stats. Oh, yeah.

**00:46:31,213** You trying to make sure you have your numbers right. Yeah.

**00:46:35,653** Oh, this is fun.

**00:46:36,613** Academic accommodation.

**00:46:37,653** So I was exhausted.

**00:46:41,053** last night and I needed to send through a, I'm trying to get

**00:46:46,862** this class that we took last year

**00:46:50,013** to count for a certificate at Stanford. And so I just sent

**00:46:53,409** through a petition and I went back and

**00:46:55,613** forth with Claude and I was kind of overdoing the whole like

**00:46:58,525** writing it out and I said, okay, can

**00:47:00,253** you, can you write this out? Can you, can you make a petition for

**00:47:03,506** these classes? Can you go into my

**00:47:05,133** Canvas and my access, which is like the Canvas is like where our classes

**00:47:09,311** are in the details and syllabus and access says like how many credits they

**00:47:13,607** are and what are the professors and stuff like that in fillers all out for

**00:47:17,904** me and in read it back so read it back to me.

**00:47:20,733** I was like, Hey, make it time.

**00:47:21,693** New Roman make it very clear that it's not AI generated.

**00:47:25,653** And can you just send it directly to Hallie,

**00:47:28,813** my academic coordinator, and I went to sleep.

**00:47:33,733** And I woke up in the morning being like,

**00:47:34,853** what the heck did I just do?

**00:47:35,773** 'Cause usually I look at it

**00:47:36,653** before I send literally anything.

**00:47:38,653** And it was perfect.

**00:47:39,493** It sent it through.

**00:47:40,473** It was perfect.

**00:47:41,313** I was so proud of it.

**00:47:42,493** And it was just one of those things that like,

**00:47:43,893** I need to get done.

**00:47:44,933** I wasn't getting done.

**00:47:46,453** And I was like, okay, if there's some errors,

**00:47:47,933** it's kind of fine.

**00:47:49,733** Anyway, it's like not that fun, but.

**00:47:52,773** Very useful.

**00:47:55,413** And like--

**00:47:56,373** All right, you gotta give us a good one.

**00:47:57,813** Give us a juicy one.

**00:47:58,653** Yeah, like I was gonna say,

**00:47:59,473** I don't have a juicy one right now.

**00:48:00,693** You don't have any like, what is this thing on my foot?

**00:48:02,573** Like, you know.

**00:48:06,853** Like how embarrassing.

**00:48:08,533** I have street style inspiration.

**00:48:10,213** I was like, we were coming back to school

**00:48:11,933** and I was like, I need-- New fits.

**00:48:13,933** Yeah, new fits that like aren't,

**00:48:16,013** I like athletic fits. And I have,

**00:48:23,273** best pina colada in Maui.

**00:48:25,213** There we go.

**00:48:27,133** Yeah, we'll have to dig in more.

**00:48:28,293** I feel like we both are like very power users

**00:48:31,213** for personal use cases, obviously,

**00:48:32,733** for stuff with the nonprofit, with school. Yeah.

**00:48:36,053** We found a lot of cool ways to make these useful

**00:48:39,253** across our lives.

**00:48:40,093** So I want to share more of them in a future episode, but.

**00:48:41,933** Yeah, hope this was helpful and landscape

**00:48:45,453** and see you in the next episode,

**00:48:48,173** if not in our inboxes before.

**00:48:51,013** Peace.
