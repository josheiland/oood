# Episode 1 final-timeline transcript v2

Source-assisted caption transcript. Uncertain wording is marked; auditory proofread remains open. Speaker labels omitted where overlaps make attribution uncertain.

**00:00:00,000** We are back and we're doing an AI landscape.

**00:00:03,240** Like we're painting a photo, painting a picture.

**00:00:06,800** Painting a photo, even more impressive.

**00:00:11,520** Yeah, I think really the goal here is just,

**00:00:14,760** especially for folks who are newer to the space,

**00:00:17,280** a lot of terms get thrown around

**00:00:19,120** and we just wanna start with the basics,

**00:00:22,200** separating out what is the difference between

**00:00:27,320** the model and the actual platform or product that you're using?

**00:00:32,980** Who are the different key companies in the space?

**00:00:35,400** The provider, I guess at the highest level, would be Anthropic or OpenAI or

**00:00:40,083** Google,

**00:00:40,520** right? These are the companies that are actually training the models.

**00:00:45,400** Yeah, so like the model, in my mind, I was just getting all turned around like,

**00:00:48,600** Okay, what's the model? What's the freaking harness? What's like all

**00:00:51,800** these crazy words

**00:00:52,760** that are silly. And where chat and I landed, to be honest, is the model's

**00:01:01,000** like the engine of the

**00:01:01,720** car. So it's like keeping it going. It's like the thing that powers it.

**00:01:05,560** And that's like Opus.

**00:01:07,560** You know, that's specific models within Claude, within Chat, Astra, other ones.

**00:01:14,760** Fable.

**00:01:18,600** That's all the ones I remember. Totally. Yeah.

**00:01:22,100** I think there was... oh, and the brand is like the...

**00:01:25,480** And there's a Toyota or a Prius or whatever it is,

**00:01:28,160** that's Anthropic. Right.

**00:01:31,040** Yeah, so if we think of a Toyota Prius car,

**00:01:33,160** like Toyota, the car maker, is like Anthropic.

**00:01:36,400** And then Claude, like the Claude interface,

**00:01:40,080** would be the Prius, the car.

**00:01:41,400** And then the engine that's actually powering it

**00:01:43,360** could be Opus or...

**00:01:44,800** Yeah, Fable, which are different models from Anthropic. Yeah.

**00:01:48,980** So yeah, I think that's a helpful analogy.

**00:01:50,467** High level, the way that these models are trained

**00:01:53,420** is they're just fed a ton of data.

**00:01:56,467** And then these models are trained

**00:01:58,860** through a variety of different processes

**00:02:00,620** that we can dig into because it can go much deeper

**00:02:02,660** in a future episode.

**00:02:03,540** But essentially, you run tests over time

**00:02:06,980** to teach the model to predict the next word that

**00:02:11,180** comes after a given sentence.

**00:02:13,820** So if it's like a quick brown blank,

**00:02:17,620** It's probably going to guess fox, right?

**00:02:19,660** Because that's out there a million times in different sources.

**00:02:23,340** And so at its core, these models were originally

**00:02:26,140** built to just predict the next token, which is not exactly

**00:02:29,620** a word, but you can think of it similar to a word

**00:02:32,100** in a sequence of words.

**00:02:33,660** And then, but that in and of itself,

**00:02:37,780** then you need to have some additional tweaks on top

**00:02:42,460** to make it be able to go back and forth

**00:02:44,020** in a conversational way.

**00:02:45,860** And so you take this model that's

**00:02:48,480** designed to predict the next word, you then tell it,

**00:02:51,480** you're going to be answering a user's question.

**00:02:53,440** So tailor your response accordingly.

**00:02:56,640** And then you go through a series of additional processes

**00:02:58,920** where you give it to give an output.

**00:03:02,380** And then you evaluate it, tell it if it's good or not,

**00:03:04,460** and sort of train it to do better.

**00:03:06,220** So that's how you actually build out the basic model.

**00:03:09,260** So Claude is Anthropic's product, which now kind of

**00:03:14,040** has a couple of different, I guess, tools really

**00:03:17,040** bundled within one.

**00:03:19,520** And it's interesting because ChatGPT, which is OpenAI's

**00:03:23,920** product, it's kind of been a similar evolution where

**00:03:26,840** initially they both just had a chat interface.

**00:03:30,040** And you would type a prompt, get a response back.

**00:03:32,840** Increasingly, they started to build out other modes.

**00:03:36,120** So both of them now have essentially a work mode,

**00:03:41,920** which goes a little bit beyond the chat bot

**00:03:44,720** and gives it more kind of ability to use different tools,

**00:03:49,080** which we'll talk a little bit more about essentially

**00:03:50,580** just using other applications or other capabilities

**00:03:54,780** beyond just text-based chat to actually go further

**00:03:58,780** and be able to do more work on your behalf.

**00:04:00,860** And then both now also have more

**00:04:02,880** kind of like code-heavy technical products.

**00:04:05,440** So, Codex from OpenAI and then Claude Code from Anthropic.

**00:04:09,860** But it's interesting because more recently

**00:04:11,460** they've kind of been consolidating them back a little bit more.

**00:04:14,700** So it'd be interesting to see where that goes, but at its core, you know,

**00:04:18,860** we'll talk a lot about ChatGPT and Claude as like the interface,

**00:04:22,360** the product that OpenAI and Anthropic respectively have built out.

**00:04:28,300** So a quick caveat.

**00:04:30,300** I like Claude the most for pretty much everything except for

**00:04:36,100** like realistic photos, where I think chat just does such a better job.

**00:04:39,100** Like generating photos.

**00:04:40,340** Yeah, but I think a lot of that is just because I've spent more time in Claude.

**00:04:43,300** So I feel like it knows me more.

**00:04:44,820** I go back and forth.

**00:04:46,580** I think, I think Chat is like in theory better at, at some of the

**00:04:49,580** personalization, at some of the more human-esque, where Claude kind

**00:04:54,980** of pops at, at more of the, um, I think like, you know, math, diagrams,

**00:05:02,580** frameworks, a little bit more of the kind of, um, less creative side of things.

**00:05:06,980** Like structured. Yeah.

**00:05:07,980** which for me, I think creativity and all that stuff is really fun.

**00:05:11,500** So I think it's a little bit more of a strength than the wording and all that

**00:05:17,512** stuff.

**00:05:17,980** So I think that's why I lean a little bit, Claude.

**00:05:19,620** But I would say-

**00:05:20,780** It feels like it complements your background and your capabilities.

**00:05:24,580** Interesting. Yeah.

**00:05:26,080** I'm so over the names.

**00:05:27,540** Why can't it be like Apple where they do iPhone 4 or 5, that would be so

**00:05:31,180** much better.

**00:05:32,300** The models are so annoying.

**00:05:34,060** Like Claude having Luna, whatever, like Sol,

**00:05:37,180** whatever these annoying ass names are.

**00:05:40,580** I'm not sure if I'm allowed to say what I just said.

**00:05:41,980** Those are OpenAI models.

**00:05:44,060** Point landed. - Potato, potato.

**00:05:45,100** I mean, it makes the point even more clear.

**00:05:46,420** Like there's so many names to keep track of.

**00:05:48,220** And it's just like so annoying,

**00:05:49,700** but I think it's, I think for me right now,

**00:05:52,900** where we, Fable is like, does a lot.

**00:05:56,300** It's a really high powered model for Claude,

**00:05:59,460** but it sounds so fricking robotic

**00:06:03,820** and not concise.

**00:06:05,460** I actually hate it.

**00:06:06,460** You mean the way that it actually generates output? Yeah.

**00:06:09,180** I prefer the less strong model that I forget what it is. But that's what I stay

**00:06:13,072** on.

**00:06:13,220** What's the one right under that? Opus. Opus.

**00:06:15,340** That's what I do everything on with Claude. Yeah.

**00:06:17,700** So it's always a trade-off when deciding which model

**00:06:20,240** you're going to use of, is this a task that really

**00:06:22,680** requires complex thinking or analysis?

**00:06:27,520** Or is it, you know, if I'm asking, you know,

**00:06:31,000** what time does the gas station close tonight,

**00:06:34,560** then I can probably use a basic model

**00:06:36,040** 'cause it's just gonna do a basic web search.

**00:06:37,280** I was talking to one of my friends

**00:06:39,560** at the business school and she was like,

**00:06:42,000** like, can we go through this, like, this question?

**00:06:45,200** Like, I have an interview,

**00:06:46,320** I need to like develop something, can we chat through?

**00:06:48,960** And she kept asking me questions.

**00:06:50,240** And I was like, love, put all these questions you're asking me,

**00:06:53,760** just like type them or say them into your chat prompt.

**00:06:57,040** Like just ask it, how do I talk through,

**00:06:58,880** how do I do this?

**00:07:00,240** Send screenshots, ask it, I've never used Claude Code, how do I do that?

**00:07:04,160** And it will walk you through and it's insane

**00:07:07,280** how it can, you know, like there's so many things

**00:07:10,040** where I might explain like I am zero and dyslexic

**00:07:12,760** and I am dyslexic, but I'm not zero.

**00:07:14,440** And like in those things,

**00:07:16,560** I think it's just developing this skill.

**00:07:18,520** Totally, yeah, I think that's such a good point

**00:07:20,160** that as these tools have gotten better,

**00:07:22,080** it's also becomes easier to learn how to use them

**00:07:25,040** by going back and forth with the tool.

**00:07:26,600** Like, yeah, I totally, when I run into things

**00:07:29,040** and it's like, I don't know how to, you know,

**00:07:30,320** I'm working with Claude Code, building a website.

**00:07:32,200** I also can't code to save my life, but it's like, okay,

**00:07:35,240** there's an error in the code. It's kind of a lie. No, no.

**00:07:38,360** Compared to an actual engineer.

**00:07:39,520** We both took a coding class. Guys,

**00:07:41,280** there was a class that we took first year,

**00:07:43,280** I mean, last year at Stanford.

**00:07:46,720** And the way that I thought I had dyslexia,

**00:07:51,160** the way that I thought I was experiencing dyslexia

**00:07:56,320** when I saw my grade, I got, my first midterm that Josh got like a 90 fricking

**00:08:02,850** something.

**00:08:03,820** I got like a 29 and I was, I like had to like look away, look back.

**00:08:08,480** I was thinking it was a 92.

**00:08:09,840** I thought, I thought that my mind was undoing it and we were coding on paper.

**00:08:13,320** There's some coding difference.

**00:08:14,750** You still passed the class, though. We ended up with...

**00:08:16,500** I passed the class.

**00:08:17,680** Did I spiral? Absolutely.

**00:08:19,680** But I did pass the class.

**00:08:20,680** Did I cry to the professor? Absolutely.

**00:08:22,680** Okay, but like relative to an actual software engineer, I can't code. Totally.

**00:08:27,760** The point is right, like, and when I get this bug in a website, I have no

**00:08:30,300** idea what it means,

**00:08:31,200** but I, to your point, take a screenshot or copy and paste it, put it in Claude Code

**00:08:34,280** and it can talk through in English with me.

**00:08:36,840** What's wrong? It's so good. It's so fun.

**00:08:38,600** I totally agree. As a, especially as a beginner,

**00:08:41,130** it makes sense to just learn one tool and learn how to use it well

**00:08:43,170** and get comfortable with it.

**00:08:44,440** We have to look at your most recent three chats. Oh gosh.

**00:08:51,040** Chat or Claude?

**00:08:54,420** Well, you said you'd use Chat more

**00:08:57,460** for what kind of use case?

**00:09:00,500** I just use, I use Claude more.

**00:09:02,540** Okay, well let's look at your last three.

**00:09:04,060** Okay. - Claude chats then.

**00:09:06,660** My recent, I mean, I mean.

**00:09:09,020** No skipping.

**00:09:10,260** They're not, I mean, nonprofit [unclear] AI stats. Oh yeah, yeah.

**00:09:13,840** Trying to make sure you had your numbers right.

**00:09:15,420** Yeah, like how embarrassing.

**00:09:17,700** I have street style inspiration.

**00:09:19,380** And I was like, we were coming back to school

**00:09:21,100** and I was like, I need new fits.

**00:09:22,740** Yeah, new fits that aren't athletic fits. And I have,

**00:09:32,440** best pina colada in Maui. There we go.

**00:09:36,300** Yeah, we'll have to dig in more.

**00:09:37,460** I feel like we both are like very power users

**00:09:40,400** for personal use cases, obviously for stuff

**00:09:42,420** with the nonprofit, with school. Yeah.

**00:09:45,200** We found a lot of cool ways to make these useful

**00:09:48,420** across our lives. So yeah, to share more of that in a future episode, but yeah,

**00:09:51,860** Hope this was helpful, an AI landscape.

**00:09:54,580** And see you in the next episode. Peace.
