# Episode 1 graphic cues v1

All times refer to final export. Teachers, exact kit palette; cards use an internal cream/foam waterline. No chapter interstitials or reaction effects. Definition cards add no new spoken claim.

| Output in-out | Asset | Placement | Purpose |
|---|---|---|---|
| 00:09.000-00:15.000 | graphics/lower-third.mov | 96,740 | Identify hosts with 300ms wipe. |
| 00:35.400-00:45.330 | graphics/company-model-app.png | 96,660 | Simple taxonomy introduced by the company statement. |
| 01:31.233-01:49.333 | graphics/car-analogy.png | 96,660 | Show the maker/engine/car analogy during its spoken recap. |
| 05:45.000-05:52.000 | graphics/model-names.png | 96,660 | Reinforce the spoken correction after the name mix-up. |

The animated lower third is generated in `intermediate/lower-third.mov` from `graphics/host-lower-third.png`. Other generated cards are unused design assets, not a claim of inclusion. Thumbnail: 1280 x 720, actual source frame at 23:24; three words, native square logo; checked at 210px wide.
