#!/usr/bin/env python3
"""Decode every video frame and reject changing or unspecified SDR color tags."""
import argparse
from collections import Counter
import json
from pathlib import Path
import subprocess

parser = argparse.ArgumentParser()
parser.add_argument("video", type=Path)
parser.add_argument("--report", type=Path)
args = parser.parse_args()
if args.report and args.report.exists():
    raise FileExistsError(args.report)
cmd = ["ffprobe", "-v", "error", "-select_streams", "v:0", "-show_frames",
       "-show_entries", "frame=best_effort_timestamp_time,color_range,color_space,color_primaries,color_transfer",
       "-of", "csv=p=0", str(args.video)]
result = subprocess.run(cmd, capture_output=True, text=True, check=True)
if result.stderr.strip():
    raise RuntimeError(result.stderr)
counts = Counter()
changes = []
previous = None
last = -1.0
frames = 0
for line in result.stdout.splitlines():
    values = line.split(",")
    if len(values) < 5:
        continue
    try:
        seconds = float(values[0])
    except ValueError:
        continue
    color = tuple(values[1:5])
    if seconds <= last:
        raise ValueError(f"Non-increasing frame timestamp: {seconds}")
    counts[color] += 1
    frames += 1
    if color != previous:
        changes.append({"time": seconds, "color": color})
        previous = color
    last = seconds
report = {"frames": frames, "color_combinations": {str(k): v for k, v in counts.items()},
          "changes": changes, "last_frame_time": last,
          "strictly_increasing_frame_times": True}
if frames == 0 or len(counts) != 1 or next(iter(counts)) != ("tv", "bt709", "bt709", "bt709"):
    raise ValueError(json.dumps(report, indent=2))
if args.report:
    with args.report.open("x") as output:
        json.dump(report, output, indent=2)
        output.write("\n")
print(json.dumps(report, indent=2))
