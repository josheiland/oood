# Episode 001 Spotify upload repair QC

Prepared 2026-09-30. Same final edit as the prior v2, **52:25.733**, with color-tag-only repair. No successful Spotify retry is established.

## Diagnosis

The source keyframe audit decoded 381 keyframes. 379 had `tv/bt709/bt709/bt709` range, matrix, primaries and transfer. The two outro keyframes changed to `tv/bt709/unknown/unknown`, starting at **3134.966667 seconds (52:14.967)**. This is the start of the replacement Episode 000 outro. Source stream-level color metadata alone still reported BT.709; it hid the internal change.

## Repair and integrity

- H.264 parameter-set range/matrix/primaries/transfer normalized to explicit limited BT.709 with `h264_metadata`, plus matching container tags. Existing coded picture and AAC are copied without recompression.
- Picture stays 1920 x 1080, progressive 30 fps, 8-bit 4:2:0. Frame count remains **94,372**. Audio stays AAC-LC 48 kHz stereo. Both durations remain **3145.733 seconds**.
- All **22 embedded chapters** compare exactly, including titles and times. The existing v2 SRT and current detailed description chapters retain their timing.
- Hash of the Annex-B coded picture slice payloads (NAL types 1-5) is identical before/after: `4e9a739f1fff1f4c75074db90b21e5356d87a7af3f2b21cb21cf32c879f83a94`.
- Hash of compressed AAC is identical: `c9dc169d01c456dce08e3ee254891731d13b7866982f24491fa8de07b5590488`.
- All **241,830 media packets** preserve stream index, PTS, DTS and duration exactly. Their combined timing-table hash is `a2fd67e04b511775d54b4f9225885585180c3ce90000a5d8ef296634e575c7cb`.
- Separate final-outro frame sampling found 351 decoded frames all explicitly limited BT.709, with no decoder errors.
- Source SHA-256: `7ec3e550bb4350b63b69eab7b35ba96571e2ff221ecaef85ac968d20c9d44e05`.
- Repaired file SHA-256: `181624da06b3255f393fb3dbbe36bfe9f154e9c83fef32fcb5a9ebb6aeb3e87d`.

The repair tool issued a four-byte trailing AVCC-header warning. Coded slices are unchanged and the final video decode/color audit determines successful media validation. See `full-frame-color-audit.json` for the completed all-frame result. No subjective continuous viewing/listening pass or new host approval is implied. Audio/edits are unmodified; no new loudness processing was necessary.

## Completed full-frame check

The final file decoded all **94,372 video frames** without reported errors. Every frame reports exactly `tv/bt709/bt709/bt709`; no mid-file changes or unspecified color values remain. Frame timestamps strictly increase from 0.000 to 3145.700 seconds. This passes the local check for the specific Spotify error. Platform acceptance still requires a retry in Spotify.
