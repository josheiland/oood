# Episode 001 Spotify color repair

Use [episode-001-spotify-upload.mp4](episode-001-spotify-upload.mp4) when retrying the upload. It is the same **52:25.733** Episode 001 final v2 edit with corrected video color metadata. It retains the exact saved hook, covered-lens conversation start, NVIDIA cut and Episode 000 outro.

## Cause and repair

Josh reported Spotify's upload rejection: color range, space, primaries and/or transfer characteristics change during the video. A keyframe audit found the exact mismatch at **52:14.967**, where the newly encoded Episode 000 outro begins: the range/matrix stay limited/BT.709, but primaries and transfer change from BT.709 to unspecified. The previous QC examined overall stream metadata and decode/timing but missed this internal metadata change.

The repair sets limited range and explicit BT.709 matrix, primaries and transfer in every H.264 parameter set and the MP4 color metadata. It copies the existing compressed picture and audio without recompression; no color conversion or editorial/timing change was needed. The source v2, raw media and all previous files are preserved. `repair-command.json` records the exact operation. The upload file retains all 22 embedded chapters; use the unchanged v2 SRT from the preceding folder and the current detailed YouTube description chapters.

`integrity-checks.json` records unchanged duration/frame count/chapters, exact picture-slice and AAC hashes, and exact media packet timestamps. `full-frame-color-audit.json` records the completed full decode: all 94,372 frames have the same explicit limited BT.709 tags, with no errors or changes. `verify-color-consistency.py` is a reusable read-only full-frame guard; future segmented exports should pass it, because a stream-header check alone cannot detect color tags changing at an internal join.

The source H.264 AVCC parser emitted a four-byte trailing-header warning during repair. The repaired video decoded fully without reported errors, every frame passed color consistency, and coded picture slices and original AAC bytes are verified unchanged.

## Platform references

- [Spotify video specs](https://support.spotify.com/us/creators/article/video-specs/), Spotify, publication date not shown, accessed 2026-09-30: recommends H.264/H.265, 1080p, Rec.709 SDR, progressive picture and stereo AAC; allows variable bitrates. This file is H.264, 1080p30, 8-bit 4:2:0, limited BT.709 and stereo AAC-LC.
- [Spotify troubleshooting](https://support.spotify.com/us/creators/article/troubleshooting-video-errors/), Spotify, publication date not shown, accessed 2026-09-30: recommends compatible re-export settings, including 8-bit 4:2:0 for unrecognized color formats.
- [FFmpeg bitstream-filter documentation](https://ffmpeg.org/ffmpeg-bitstream-filters.html#h264_005fmetadata), FFmpeg, live documentation, accessed 2026-09-30: `h264_metadata` can modify range/primaries/transfer/matrix inside an H.264 stream without decoding/reencoding.

No Spotify account was changed or file uploaded by Codex. Successful retry/processing still needs Spotify confirmation. Existing continuous host review and auditory caption proofreading status are unchanged.
