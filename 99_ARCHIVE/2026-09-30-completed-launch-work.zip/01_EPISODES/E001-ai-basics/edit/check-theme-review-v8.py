"""Verify the final Episode 1 theme review copy and cold-open audio headroom."""
from pathlib import Path
import hashlib
import json
import re
import subprocess

P = Path(__file__).resolve().parent
SOURCE = P / 'episode-01-theme-preview-v6.mp4'
VIDEO = P / 'episode-01-theme-review-v8.mp4'
CAPTIONS = P / 'episode-01-theme-preview-v6.srt'
QC = P / 'intermediate/qc-v6-theme/report.json'
LOG = P / 'intermediate/v8-theme-loudness.log'
REPORT = P / 'episode-01-theme-review-quality-check-v8.md'


def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as file:
        for block in iter(lambda: file.read(8 * 1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def picture_hash(path):
    result = subprocess.check_output(['ffmpeg', '-nostdin', '-v', 'error',
        '-i', str(path), '-map', '0:v:0', '-c', 'copy', '-f', 'hash',
        '-hash', 'sha256', '-'], text=True)
    return result.strip().split('=', 1)[1]


assert SOURCE.is_file() and VIDEO.is_file() and CAPTIONS.is_file() and QC.is_file()
if not LOG.exists():
    with LOG.open('w') as file:
        subprocess.run(['ffmpeg', '-nostdin', '-hide_banner', '-nostats',
                        '-v', 'info', '-i', str(VIDEO), '-vn', '-af',
                        'loudnorm=I=-16:TP=-1.5:LRA=11:print_format=json',
                        '-f', 'null', '-'], stderr=file, check=True)
matches = re.findall(r'\{[^{}]+\}', LOG.read_text())
assert matches, f'Audio measurement missing: {LOG}'
level = json.loads(matches[-1])
probe = json.loads(subprocess.check_output(['ffprobe', '-v', 'error',
    '-show_streams', '-show_chapters', '-show_format', '-of', 'json', str(VIDEO)]))
video = next(s for s in probe['streams'] if s['codec_type'] == 'video')
audio = next(s for s in probe['streams'] if s['codec_type'] == 'audio')
source_hash, review_hash = picture_hash(SOURCE), picture_hash(VIDEO)
captions = re.split(r'\n\s*\n', CAPTIONS.read_text().strip())
checks = {
    'same_complete_picture_stream': source_hash == review_hash,
    'exact_96933_frames': int(video['nb_frames']) == 96933,
    'exact_3231_point_1_seconds': abs(float(video['duration']) - 3231.1) < .001,
    'audio_video_within_50ms': abs(float(video['duration']) - float(audio['duration'])) <= .05,
    'true_peak_below_minus_one_db': float(level['input_tp']) <= -1,
    'integrated_loudness_near_target': -18 <= float(level['input_i']) <= -15,
    'chapters_present': len(probe.get('chapters', [])) == 22,
    'matching_captions_present': len(captions) == 1144,
}
assert not REPORT.exists(), f'Preserving existing report: {REPORT}'
REPORT.write_text(f'''# Episode 1 theme review v8: technical check

Checked 2026-09-28. This is a **private host-review comparison**, because public rights for the candidate music are unconfirmed.

The 53:51.100 review copy has exactly the same H.264 picture packets as the fully decoded v6 theme export. Only AAC audio changed: the 10.167-second cold open is 1.8 dB lower, while the title, complete episode and outro are 0.6 dB lower. The higher v6 peak came from the cold open, not from the music cards. The v6 full-file decode, black/silence scan, caption structure and sampled title/outro frames are in `intermediate/qc-v6-theme/` and `intermediate/v6-theme-sampled-frames.jpg`.

| Check | Result |
|---|---|
| Final video | `episode-01-theme-review-v8.mp4`, 1080p30, {video['nb_frames']} frames, {video['duration']}s; SHA-256 `{sha(VIDEO)}` |
| Picture bitstream | Identical packet SHA-256 `{review_hash}` in v6 source and v8 review |
| Audio | AAC stereo {audio['sample_rate']} Hz, {level['input_i']} LUFS, {level['input_tp']} dBTP true peak, {audio['duration']}s |
| Chapters and captions | {len(probe.get('chapters', []))} embedded chapters; {len(captions)} matching-timeline draft SRT cues |

Checks: `{checks}`.

The outro card contains both exact asks: “What should we try next? Tell us in the comments” and “Know someone figuring out AI? Send this their way”. Caption wording still needs an auditory proof, and both hosts should watch and listen to the exact selected file. A final public-delivery audio pass may be needed if true peak is above the preferred −1 dBTP ceiling. No upload, scheduling or publication is claimed.
''')
print(json.dumps({'checks': checks, 'report': str(REPORT)}, indent=2))
assert all(checks.values()), checks
