# Episode brief: AI basics and what changes for us

- **Episode ID:** E001
- **Status:** fuller 25:20.567 review cut technically checked; host review pending
- **Owner:** Josh and Mary; local production by Codex at Josh's request
- **Recording:** Source supplied 2026-09-26; file creation metadata 2026-09-26
- **Target publication:** Proposed launch target 2026-09-27, not a confirmed schedule
- **Content lane:** foundational deep dive
- **Primary audience:** Curious people who want to understand AI tools and what they might change in daily life

## One-sentence promise

Untangle the basic AI terms, then explore what these tools might change through Josh and Mary's real questions, disagreements and experiments.

## Why now

This is the foundational episode between the host introduction and the practical context/connectors/skills episode. It should make the names less intimidating while showing what spending time with Josh and Mary feels like.

## Core question

What are we actually talking about when we say AI, and what should an ordinary person do with it?

## Working thesis

A car analogy and personal examples create an accessible starting point. The fuller cut moves through learning and work, hardware and the cloud, and caution and curiosity, with both hosts evaluating what matters. It remains an introductory conversation, not a comprehensive survey of AI.

## Audience starting point

No technical knowledge assumed. The same brand can name a family of models and an app. The hosts also find the names confusing.

## Proposed story arc

1. The painting-a-photo exchange and episode route.
2. Company, model and app through Mary's car analogy and Josh's restatement.
3. Open and closed weights; a concise explanation of training, next-token prediction and multimodal models.
4. Chat, work and code products; Mary's preferences and the model-name mix-up, including the spoken correction.
5. What changes for people: a provocative job prediction, Josh's pushback and Mary's partial reconsideration.
6. Learning by asking: unequal access, the full coding-class anecdote and both hosts' practical response.
7. Human communication and task-level skills, then GPUs, local models and the cloud.
8. Privacy, a clearly hypothetical safety example and optimism; one-tool advice and recent real prompts.

## Must-support claims

| Claim | Evidence | Status |
|---|---|---|
| Named companies, models and apps are distinct layers | Current official provider documentation | Checked in `02_RESEARCH/episode-01-ai-basics-source-checks-2026-09-26.md` |
| Language-model training includes next-token prediction and further tuning | Primary research explanation | Supported as a simplified introduction; no claim of a complete modern training recipe |
| Chat, work and coding interfaces offer different tool capabilities | OpenAI and Anthropic product documentation | Broad distinction checked; no promise of identical tools or permissions |
| Open weights, GPU use and cloud/on-prem distinctions | Official model, GPU and cloud documentation | Supported at the introductory level; see dated source checks and preserve qualifications |
| Work predictions and AI-risk examples | Host opinions; hypothetical framing | Not evidence of present outcomes or real-world model escape |
| Mary's preferred outputs and both hosts' coding/learning experiences | The supplied recording | Self-reported; hosts approve exact personal details |

## Host experience to include

- Josh: explains the company/model/app relationship and training, pushes back on a job prediction, describes learning from errors and a failed local-model attempt, and gives the safety hypothetical.
- Mary: supplies the car analogy, evaluates writing style and usefulness, questions job and access implications, tells the coding-class story, asks about chips and the cloud, and balances privacy concerns with optimism.
- Run Your City: one brief recent-prompt example, not the audience boundary.

## Visuals

Sparse Teachers/blue/cream lower third and explanatory cards. Authentic host-frame thumbnail. Dialogue-only master with caption sidecars. No unapproved music, invented demonstrations or fabricated reactions.

## Clip candidates

The model-name correction, job disagreement, coding-class story, cloud question and caution/curiosity exchange. Exact output positions are in `PUBLISHING-v3.md`. Separate clips are not requested or rendered.

## Risks and remaining choices

- The 9:58.367 v2 proposal was too narrow for Josh's 25–30 minute working preference. V3 is the recommended review cut; the full source remains intact and every cut is reversible.
- Hosts should judge whether the broader arc feels coherent and whether the hardware section earns its time. The length target alone is not a quality verdict.
- Continuous audiovisual review, original lip-sync judgment and an auditory caption proofread remain necessary.
- Hosts should approve the personal grade/dyslexia story, work predictions, safety hypothetical and the retained mild profanity.
- A brief spoken reminder to verify AI answers would improve the beginner takeaway. No synthetic pickup has been inserted. See the exact suggested wording in the quality report.

## Definition of ready

- [x] Clear thesis and route
- [x] Claim register and dated sources
- [x] Substantive contributions from both hosts
- [x] Source preserved; reversible edit documented
- [ ] Continuous audiovisual and caption review of this exact version
- [ ] Host approval
- [ ] Publication action separately authorized and verified
