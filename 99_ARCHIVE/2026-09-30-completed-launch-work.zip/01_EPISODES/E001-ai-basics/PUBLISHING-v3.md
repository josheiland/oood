# Episode 1 fuller release draft v3

Status: proposed 25:20.567 package technically checked and ready for host review; host approval and continuous audiovisual review pending. No upload, scheduling or publication is claimed. The 9:58 short cut remains documented in `PUBLISHING.md` for comparison.

## Title and thumbnail

Recommended title: **AI basics, without the alphabet soup | Out of Our Depth 001**

Alternative: **AI basics in real life: what changes for us? | OOOD 001**

Thumbnail: `edit/episode-01-thumbnail-v3.jpg`, an authentic two-host frame with **AI BASICS / IN REAL LIFE** in the blue-and-cream kit. The v1 **AI NAMES EXPLAINED** thumbnail remains for comparison. Host approval of the exact image and words is pending.

## Description draft

Try one ordinary task in a tool you already have. Ask follow-up questions until you understand the answer, and check anything important before acting on it.

What is the difference between an AI company, a model and the app on your screen? Josh and Mary start with a car analogy, then follow the questions that came up while trying to use these tools themselves.

They talk about why model names get so confusing, what "open" means, how a language model learns, and the difference between chatting with a tool and asking it to do work. Mary and Josh disagree about what AI might change for mathematicians, revisit a coding class they remember very differently, and ask which human skills are worth investing in. They also try to make sense of GPUs, running models locally, the cloud, privacy, and why caution and curiosity both matter.

The hosts' tool preferences, work predictions and stories are their own views, not a product ranking or employment forecast. The paperclip example is a hypothetical. Features and names change. Check important AI answers before relying on them.

00:00 The AI-name problem
00:45 Company, model, app
01:50 Open and closed models
03:01 How a language model learns
04:40 Chat, work, and code
05:59 Which tool feels useful?
08:08 What changes for people?
10:49 Learning by asking
13:52 What skills matter?
16:18 Beyond the chatbot
18:31 Local models and the cloud
21:32 Caution and curiosity
24:03 What are you actually asking?

## Clip candidates from v3

These are recommendations only; no standalone clips have been rendered. Final-timeline ranges come from the frame EDL and need editorial review with sound and picture.

| Moment | Approximate v3 time | Treatment |
|---|---|---|
| Model names defeat us | 06:57–07:49 | Keep Mary's preference, the spoken correction and Josh's response together. |
| Do we still need mathematicians? | 08:08–10:50 | Keep Mary's self-correction and Josh's pushback; mark forecasts as opinions. |
| We remember coding class differently | 12:32–13:53 | Keep the setup, grade-reversal story, reaction and learning takeaway. Personal-detail approval required. |
| "The cloud" isn't in a cloud | 20:10–21:32 | Keep Mary's real question and Run Your City example; avoid blanket security claims. |
| Caution and curiosity | 21:32–23:58 | The paperclip story is hypothetical; don't cut it into a claim about a real incident. |

## Release review

- Exact v3 video, WAV/MP3, caption drafts, transcript, chapters, thumbnail and quality report are linked in `README.md`.
- Review all factual caveats in `02_RESEARCH/episode-01-ai-basics-source-checks-2026-09-26.md` and cut continuity in `edit/episode-01-edit-notes-v3.md`.
- Both hosts should watch/listen continuously, proofread captions, approve the coding-class and dyslexia details, mild profanity, title, thumbnail and description.
- Confirm whether this broader AI-landscape episode still has a satisfying single throughline. The duration meets the working target but is not itself a quality verdict.

No release date or platform state is asserted.
