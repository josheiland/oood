# Episode 001 YouTube chapter audit

Prepared 2026-09-30 for the current **52:25.733** export, `edit/codex-handcover-episode0-outro-2026-09-30/episode-001-full-review-v2.mp4` (SHA-256 `7ec3e550bb4350b63b69eab7b35ba96571e2ff221ecaef85ac968d20c9d44e05`).

This description is a local draft, not a live YouTube update. Chapters use whole-second anchors at the start of a retained topic's setup, with final-v2 SRT cues as evidence. The 00:14 chapter begins the conversation/greeting; the landscape framing follows within it. The 8.767-second hook and 5.267-second intro are combined to satisfy the ten-second minimum. This check does not replace the still-open auditory caption proof or continuous host review.

Changes from Josh's supplied older description: removed GPUs from the opening list; clarified the engine/car analogy; separated the open/closed explanation from that analogy; renamed the NVIDIA chapter to match the retained brief market setup; renamed the ranking chapter to avoid calling every participant a current CEO; retimed each topic from final-v2 cues; fixed the Demis source and removed the unverified current peer-review-status assertion. Plain HTTPS URLs are visible in the copy. User-supplied organization URLs are retained; no claim of complete site reachability is made (OOOD web fetch unavailable, Stanford returned 403).

| Chapter | Topic | Final-caption/boundary evidence |
|---|---|---|
| 00:00 | Data centers on the moon? (hook and intro) | 0.000s: People are starting to try |
| 00:14 | The AI landscape, explained | 14.033s: Post-title conversation picture begins on the covered lens; greeting at 14.940, landscape introduction at 26.100. |
| 01:09 | Who actually builds the models | 69.900s: Why don't we start with models? |
| 02:20 | Claude vs. ChatGPT: what we actually use | 140.680s: So let's use a Claude and chat and really quick |
| 05:12 | Gemini, the Dodgers of AI | 312.960s: Gemini is like I would say like clear third, like sort of in the mix. |
| 06:20 | Open vs. closed models | 380.520s: Yeah, and you mentioned earlier there's |
| 06:44 | How models actually learn | 404.233s: I think that, yeah, like high level, |
| 08:49 | The car analogy: models vs. apps | 529.053s: I think you had a good analogy that, |
| 12:28 | Why are the model names so bad? | 748.314s: so over the names. Like why can't |
| 13:26 | Tokens are gas | 806.733s: takes up the most tokens. Also, the better model you use, the more tokens. |
| 14:35 | Are mathematicians out of a job? | 875.253s: Speaking of mathematical problems, it was never in my cards. |
| 18:33 | Jobs vs. tasks | 1113.293s: It's just like think about I think we said this in the first episode. |
| 20:16 | Who gets left behind | 1216.493s: the thing I get scared by is that men, who typically |
| 21:36 | Mary's coding midterm (29 or 92?) | 1296.493s: If we both took a coding class, |
| 24:18 | What's overhyped | 1458.333s: But two, where is it overhyped? |
| 24:59 | What we're betting on: being human | 1499.053s: I think what I think for me, |
| 27:14 | NVIDIA and the wider AI market | 1634.812s: and kind of hardware has like really, |
| 28:22 | Why it's so easy to switch | 1702.360s: But I think to your point, |
| 29:44 | How do open models make money? | 1784.081s: better. So back to our on-prem versus, |
| 33:05 | On-prem vs. the cloud (and the moon) | 1985.500s: Okay, I wanna, so it kind of overlaps, I think, |
| 35:05 | Dario and the Anthropic origin story | 2105.340s: But yeah, maybe actually on the note of Elon |
| 37:40 | When AI breaks the rules | 2260.747s: And we've been seeing more and more in recent weeks, these models starting to |
| 42:07 | Sam, Zuck, and Elon | 2527.767s: Yeah, so Sam Altman, CEO of OpenAI, |
| 45:56 | Ranking the AI leaders | 2756.927s: a fun end of the rapid fire question brings them |
| 49:21 | Mary's last three AI chats | 2961.427s: Oh, okay. Well then I'll flip on you. We have to look |
| 52:04 | See you next time | 3124.667s: Yeah, hope this was helpful and landscape |

Validation: 26 chapters; first 00:00; ascending; every chapter at least 10 seconds including the last; all within the final export. Description is 2567 characters, below YouTube's 5,000-character limit. No rerender or embedded-video chapter change was required; these are the detailed YouTube-description chapters.

YouTube chapter-format reference: https://support.google.com/youtube/answer/9884579?hl=en (YouTube Help, publication date not displayed, accessed 2026-09-30).
