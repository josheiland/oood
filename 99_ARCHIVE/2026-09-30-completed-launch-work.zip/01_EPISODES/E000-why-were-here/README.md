# Episode 000: current release archive

**Published on YouTube and Spotify**, confirmed by Josh 2026-09-30. The canonical final video, matching captions, published thumbnail, saved description/chapters and manifest are in [Drive](https://drive.google.com/drive/folders/1BtzCXPB2v8w1y7SWS3PoUIzOsoKfaAqy). Local video exports and render intermediates were removed after checksum verification to free space. Original recordings remain in [Drive Raw](https://drive.google.com/drive/folders/1KrXgS2Ms6MSz6KXF5YWz1M3fZ_6_fshm); download a source before rebuilding.

[Archive receipt](../codex-drive-archive-2026-09-30/README.md) identifies the exact versions and verification. Lightweight project/edit records, brand templates and small selected hooks remain local. Older local media links below are historical and may no longer resolve; publication-status statements below describe their original review stage.

## Historical production notes

# Episode 0: Why we are here

Recorded source supplied by Josh on 2026-09-26. This is a short introduction/teaser, not a full-length lesson.

The current re-upload file is `release/episode-000.mp4`, updated 2026-09-30 with Josh's approved recurring cards. The intro now says `FIGURING OUT AI TOGETHER` with no episode-number label. The outro omits its top show-name label and raises the three prompts 48 pixels. Josh's exact `Hook_Final.mp4` opening, the complete callout-free conversation, centered dialogue, music, 11:20.867 runtime, captions and chapter timing are unchanged. See [PUBLISHING.md](PUBLISHING.md) for platform copy and `edit/codex-mono-mirrored/episode-000-recurring-cards-v11-qc.md` for verification. The prior version was published on YouTube and Spotify on 2026-09-29 per Josh, as recorded in `00_CONTEXT/DECISIONS.md`. This revised local video has not been uploaded by Codex.

The original was restored to `/Users/je/Movies/Episode 0 Raw.mp4` after its verified Drive upload. Superseded Episode 000 comparison media were removed at Josh's explicit request; the raw and edit records remain. Media and render intermediates are excluded from Git.

The current thumbnail is `release/episode-000-thumbnail.jpg`, built from Josh's clean copy of Mary's posed photo with native Teachers text. Its reusable template is in `03_ASSETS/codex-mary-thumbnail-template/`. Superseded thumbnail exports were removed at Josh's request on 2026-09-29.

Josh compared three short previews, found that the first shortened versions still included the next “we,” and trimmed `edit/Hook_Final.mp4` himself. It is the authoritative hook for the current full export. Earlier render comparisons were removed at Josh's request on 2026-09-29; their edit notes remain in context.

The [current shared YouTube/Spotify description](codex-description-final-cut-2026-09-30.txt) is a snapshot of Josh's curated Google Doc, verified on 2026-09-30. Its ten chapters begin at 00:00, have a minimum 42-second start gap and a 52.867-second final chapter. The [chapter-spacing audit](../../02_RESEARCH/codex-prior-descriptions-chapter-audit-2026-09-30.md) records the final-cut checks. Earlier proposals in PUBLISHING.md remain references. No platform copy was changed.
