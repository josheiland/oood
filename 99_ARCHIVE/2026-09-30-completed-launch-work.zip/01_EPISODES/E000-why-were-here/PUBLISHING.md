# Episode 000 release package

Updated 2026-09-30 for the card revision of the full **11:20.867 episode**. `release/episode-000.mp4` now uses the approved recurring native Teachers intro with `FIGURING OUT AI TOGETHER` and no episode-number label. Its outro removes the small top show-name label and moves the three existing prompts 48 pixels up. Josh's precise `Hook_Final.mp4` honeymoon opening, full callout-free conversation, centered dialogue, theme music and final fade remain, with no timing changes. The SRT, thumbnail and chapters are unchanged. Music rights were confirmed by Josh on 2026-09-28. The prior episode version was live on YouTube and Spotify per Josh on 2026-09-29; this revised local file has not been re-uploaded by Codex. The descriptions below remain saved proposals, not a record of platform copy used.

## Title and thumbnail

Recommended: **Meet Josh and Mary | Out of Our Depth, Episode 000**

Other directions: **Why we're learning AI out loud | Episode 000**; **Out of Our Depth starts here**.

Thumbnail: `release/episode-000-thumbnail.jpg`, 1280 × 720, using Josh's clean version of Mary's posed photo and native Teachers type. Copy: **#000 WHY WE’RE HERE**. Superseded thumbnail exports were removed at Josh's request. The current thumbnail does not depict the private AI-generated family images.

## Proposed YouTube description

Draft for host review, matched to the 11:20.867 theme cut. Confirm the website destination and exact contact spelling before upload.

```text
We just got married, we run Run Your City together, and we're learning AI out loud. Episode 000 is a quick hello from Josh and Mary: who we are, why we're making Out of Our Depth, and what we want to figure out with you.

We talk about making AI feel less intimidating, the mix of news and hands-on experiments we hope to try, and how our work at a youth sports nonprofit shaped the idea for this show. We also get into foster puppies, an Elon Musk mix-up, and the honeymoon experiment where Josh asked AI to imagine family holiday photos. We had mixed feelings about the result.

What should we try or explain next? Tell us in the comments or email us at hi@outofourdepth.com.

Chapters
00:00 Cold open and title
00:11 Why we're here
01:14 Why learn AI together
02:08 Making it fun and accessible
03:45 Meet Josh and Mary
05:01 Run Your City
06:00 What to expect
06:48 Curious and skeptical
08:05 Fun facts
08:47 The honeymoon AI photo experiment
10:28 Closing invitation
11:10 Outro

Out of Our Depth: https://outofourdepth.com
Run Your City: https://www.runyourcity.org/
AI@GSB, Stanford GSB's Applied AI Initiative: https://www.gsb.stanford.edu/experience/learning/applied-ai

Research note: Our on-air "20% behind" reference is about an approximate relative gap in generative AI use reported in a 2025 analysis of 18 studies, not a 20-point gap or a measure of skill. A 2026 update reports a smaller recent-period estimate. Original study: https://www.hbs.edu/ris/Publication%20Files/25023_52957d6c-0378-4796-99fa-aab684b3b2f8.pdf | 2026 update: https://www.hbs.edu/ris/Publication%20Files/25-023_be8fb517-3dd5-40aa-97f9-4e42e1c8e6ff.pdf
```

## Proposed Spotify description

Draft for host review, matched to the same cut. Confirm the website destination and exact contact spelling before upload.

```text
We're Josh and Mary: newly married, running a youth sports nonprofit together, and trying to make sense of AI as we go. Episode 000 is our hello. We share why we're starting Out of Our Depth, what we're curious and skeptical about, and the mix of news and real-life experiments we hope to bring you. There are also foster puppies and an AI honeymoon photo experiment that got a little too generous with us.

Have a question or something we should try? Email hi@outofourdepth.com. Find us at https://outofourdepth.com, Run Your City at https://www.runyourcity.org/, and AI@GSB at https://www.gsb.stanford.edu/experience/learning/applied-ai.

Source note: The on-air "20% behind" comment refers to an approximate relative gap in generative AI use in a 2025 study, not a skills gap or 20 percentage points: https://www.hbs.edu/ris/Publication%20Files/25023_52957d6c-0378-4796-99fa-aab684b3b2f8.pdf
```

## Description / show notes

**Try this:** Tell us one everyday AI question or experiment you'd want us to explore.

We're Josh and Mary. We're newly married, back at Stanford Business School, and running Run Your City together. We started Out of Our Depth because AI is changing quickly and we want to learn what matters, test what is useful, and make the process more fun to follow.

This first conversation is a chance to get to know us. We talk about our backgrounds, the nonprofit, why we want to learn out loud, and the kind of show we're hoping to make. Along the way there are puppies, an Elon/Musk mix-up, and a honeymoon experiment where Josh used AI to imagine family holiday photos. We leave the detours in because they are part of who we are together.

Our plan is to try a mix of AI news and deeper dives into tools and ideas. We'll see what works and let the format evolve.

| Time | Chapter |
|---|---|
| 00:00 | Honeymoon AI photo cold open and title |
| 00:11 | Opening: why we are here |
| 01:14 | Why learn AI together |
| 02:08 | Make it fun and accessible |
| 03:45 | Meet Josh and Mary |
| 05:01 | Run Your City and the show |
| 06:00 | What to expect |
| 06:48 | Curious and skeptical |
| 08:05 | Fun facts |
| 08:47 | The honeymoon AI experiment |
| 10:28 | Closing invitation |
| 11:10 | Outro |

AI@GSB, Stanford GSB's Applied AI Initiative: https://www.gsb.stanford.edu/experience/learning/applied-ai

Run Your City: https://www.runyourcity.org/

Out of Our Depth: https://outofourdepth.com

Email Josh and Mary: hi@outofourdepth.com

The "20% behind" reference comes from Otis and colleagues' 2025 analysis of 18 studies covering about 143,000 people: women were approximately 20% less likely than men to **use** generative AI. That is a relative usage gap, not 20 percentage points or a measure of skill. The updated 2026 analysis estimated a roughly 16% relative gap in recent periods. The research does not establish the screenshot's specific explanation of why the gap exists.

2025 study: https://www.hbs.edu/ris/Publication%20Files/25023_52957d6c-0378-4796-99fa-aab684b3b2f8.pdf

2026 update: https://www.hbs.edu/ris/Publication%20Files/25-023_be8fb517-3dd5-40aa-97f9-4e42e1c8e6ff.pdf

The AI family pictures are described, not shown; they are imagined images, not depictions of real future people.

## Platform copy drafts

### LinkedIn

We started recording a quick hello and ended up sharing why we're learning AI together, what we're curious about, and a very strange experiment from our honeymoon.

We're Josh and Mary. We're newlyweds, Stanford business students, and nonprofit operators. Out of Our Depth is our way of making sense of AI in public and making it a little more fun to learn along the way.

Episode 000 is the unhurried introduction to who we are and the conversations we want to have. What would you want us to try or explain? [Add verified episode link only after publication.]

### Instagram

We kept the detours in our first episode. That's where you actually meet us.
We're Josh and Mary, learning AI out loud and figuring out this show together.
What should we try next?

### X

Episode 000 is our hello: who we are, why we're learning AI together, and a honeymoon experiment that got a little weird. What should we try next? [Add verified episode link after publication.]

## Clip candidates

The clean v6 output matches source timing because it is one continuous segment. In the current theme review, the full episode begins at 00:10.700, so add that offset to these source times. No clips have been rendered or approved for posting.

| Rank | Source / clean v6 range | Setup and payoff | Edit note |
|---|---|---|---|
| 1 | 08:37–10:18 | Honeymoon AI-photo experiment and both hosts' mixed, affectionate reaction. | Include setup and Mary's response. Confirm comfort with the full personal story; do not insert private generated pictures. |
| 2 | 02:15–02:40 | The hosts want the AI conversation to be fun, then correct the Elon/Musk mix-up. | Keep the correction and laugh; do not turn the mistake into a false quote. |
| 3 | 06:41–07:35 | Mary raises skepticism and Josh argues that learning helps people critique AI better. | Keep the environmental/jobs caveat and both voices. |

## Upload files and release checks

- Updated re-upload video: `release/episode-000.mp4`, 11:20.867, using `edit/Hook_Final.mp4` and the approved recurring cards. Card transitions, full decode, identical AAC audio, unchanged captions and chapters were checked. No re-upload performed.
- Captions: `release/episode-000.srt`. These are optional captions, not burned into the picture, and still need a listening proofread.
- Thumbnail: `release/episode-000-thumbnail.jpg`; editable source and reusable renderer: `03_ASSETS/codex-mary-thumbnail-template/`.
- Editorial record: `edit/render-episode-00-comparison.py`, `edit/episode-00-quality-check-v6.md`, and `edit/codex-mono-mirrored/episode-000-recurring-cards-v11-qc.md`.
- Editable current card templates: `03_ASSETS/codex-mono-mirrored-3digit/` at the repo root. Keep the recurring tagline and hidden top labels for later episodes. Three-digit numbering remains in metadata and thumbnails.
- Source/claim register: `02_RESEARCH/episode-00-source-checks-2026-09-26.md`.

Prior editorial review notes (not a new check of the published release): confirm that the spoken “20% behind” line means the approximate *relative usage* gap explained above, or record a correction. Josh confirmed the inbox is live; verify the website is live before posting its link and the episode. Proofread captions against audio, and have both hosts approve the chosen exact cut and personal story. Josh confirmed music rights are cleared for the proposed theme. The nonprofit adoption comparison remains a host perspective rather than a checked sector statistic. The claim register distinguishes their opinions from checked facts.
