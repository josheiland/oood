# Episode 0 current production

`render-episode-00-comparison.py` built the clean and original theme comparison from the unchanged `/Users/je/Movies/Episode 0 Raw.mp4`. It verifies the raw hash, trims the old v5 ending by exactly three seconds, centers both voices, and makes no callouts. The original theme preview uses the existing short clips of Josh's proposed theme with earlier blue/white cards. It adds a cold-open excerpt before the full clean episode, so that moment appears again in its original place.

`codex-mono-mirrored/render-episode-00.py` built the first card-format comparison from an earlier extended video and two-digit templates. It changed only the title/outro picture; `codex-mono-mirrored/episode-00-card-qc.md` records the historical checks. The superseded comparison media and two-digit templates were removed at Josh's request on 2026-09-29. The current reusable cards are in `03_ASSETS/codex-mono-mirrored-3digit/`.

Current handoff files are in `../release/`; exact checks and outstanding review are in `episode-00-quality-check-v6.md`. `caption-source-v5.srt` remains here only to reproduce the new caption files. V5's script and QC record remain as history; its media and the superseded music test were removed after v6 checks. Preserve the raw recording.

`codex-hook-comparison/` retains the edit notes and builders for historical short opening comparisons. Josh later selected his own `Hook_Final.mp4`; the obsolete preview MP4s were removed at his request on 2026-09-29.

Josh subsequently trimmed `Hook_Final.mp4` himself and requested that exact boundary for the complete theme review. `codex-mono-mirrored/render-user-hook-v9.py` verifies the user file and clean-master hashes, matches its 163 picture frames to original-resolution footage, preserves its audio, and builds the full review with the current title/outro, captions and chapters. The v9 QC record is alongside the script. The user source remains preserved.

`codex-mono-mirrored/render-episode-000-card-v10.py` historically used that checked v9 review as source and replaced only the intro picture (frames 163–320) with the new three-digit native-font card. The current export and matching SRT are `../release/episode-000.mp4` and `../release/episode-000.srt`; its QC record is `codex-mono-mirrored/episode-000-card-v10-qc.md`. Superseded preview media were removed at Josh's request.

`codex-mono-mirrored/render-recurring-cards-v11.py` stages the 2026-09-30 approved recurring cards from the checked v10 source, copies AAC and chapter timing, and preserves the final half-second picture fade. After full decode, audio/chapter checks and sampled boundary inspection, the stable `../release/episode-000.mp4` was replaced to retain one current video. See `codex-mono-mirrored/episode-000-recurring-cards-v11-qc.md`. The v10 source media is superseded; the builder deliberately checks its original hash before running. No re-upload was performed.
