#!/bin/bash
# Episode 0 extended, honeymoon hook (3 pieces from the clean episode, cut in silences):
#   517.700-520.067 "Recently on our honeymoon,"
#   555.300-560.067 "Yeah, it was like from the first kid being born through like us being dead."
#   581.500-590.867 "The issue though is that Chat was too generous with us... We were both ugly babies." / "It's like Instagram reality."
# -> blue title + sting -> full clean episode -> blue thank-you (comment + share asks) + outro.
set -e
cd "$(dirname "$0")"
CLEAN=../../release/episode-00-clean.mp4
M=../../../../03_ASSETS/music
f(){ echo "atrim=start=$1:end=$2,asetpts=PTS-STARTPTS,afade=t=in:d=0.012,afade=t=out:st=$(python3 -c "print($2-$1-0.03)"):d=0.03,aresample=48000,aformat=channel_layouts=stereo"; }
ffmpeg -nostdin -v error -y \
 -ss 517 -i "$CLEAN" -ss 555 -i "$CLEAN" -ss 581 -i "$CLEAN" -i "$CLEAN" -i title-card.mp4 -i outro-card.mp4 -i "$M/oood-sting-5s.wav" -i "$M/oood-outro-11s.wav" \
 -filter_complex "\
[0:v]trim=start=0.7:end=3.0667,setpts=PTS-STARTPTS,format=yuv420p,setsar=1[h1v];[0:a]$(f 0.7 3.0667)[h1a];\
[1:v]trim=start=0.3:end=5.0667,setpts=PTS-STARTPTS,format=yuv420p,setsar=1[h2v];[1:a]$(f 0.3 5.0667)[h2a];\
[2:v]trim=start=0.5:end=9.8667,setpts=PTS-STARTPTS,format=yuv420p,setsar=1[h3v];[2:a]$(f 0.5 9.8667)[h3a];\
[4:v]format=yuv420p,setsar=1[tv];[6:a]volume=-1.6dB,aresample=48000,aformat=channel_layouts=stereo,apad=whole_dur=5.266667,atrim=end=5.266667[ta];\
[3:v]format=yuv420p,setsar=1[bv];[3:a]aresample=48000,aformat=channel_layouts=stereo[ba];\
[5:v]format=yuv420p,setsar=1[ov];[7:a]volume=-3.3dB,aresample=48000,aformat=channel_layouts=stereo,atrim=end=10.733333[oa];\
[h1v][h1a][h2v][h2a][h3v][h3a][tv][ta][bv][ba][ov][oa]concat=n=6:v=1:a=1[v][a]" \
 -map "[v]" -map "[a]" -map_chapters -1 -map_metadata -1 -c:v libx264 -preset medium -crf 18 -profile:v high -pix_fmt yuv420p -r 30 \
 -color_primaries bt709 -color_trc bt709 -colorspace bt709 -c:a aac -b:a 256k -movflags +faststart episode-00-extended-honeymoon-hook.mp4
