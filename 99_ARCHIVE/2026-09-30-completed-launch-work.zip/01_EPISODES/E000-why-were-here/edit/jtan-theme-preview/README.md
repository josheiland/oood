---
tags: [oood, episode-00, theme]
---

# Episode 0 extended, with jtan's outro card (2026-09-28)

The superseded preview MP4s, temporary card MP4s, and matching SRTs described below were removed on 2026-09-29 at Josh's direct request to reduce storage and visual clutter. This README and the historical builders remain as an edit record. The current full export is `../../release/episode-000.mp4` with `../../release/episode-000.srt`.

**Review version, not approved or published.** Josh preferred jtan's outro wording to the "Please comment or share" card in `../../release/episode-00-extended.mp4` (ChatGPT's v6 theme preview, renamed).

`episode-00-extended-jtan-outro.mp4`, 11:25.566, MD5 `c5004a11a058ebce632ec6721d238daa`:

| Time | Part |
|---|---|
| 0:00–0:10.167 | Hook: the Elon/Musk "we're clearly learning" moment (clean 2:19.433–2:29.600) |
| 0:10.167–0:15.433 | Blue title card, white type, with the 5.25 s sting |
| 0:15.433–11:14.833 | Full clean episode (`../../release/episode-00-clean.mp4`) |
| 11:14.833–11:25.566 | Blue thank-you card: "What should we try next? Tell us in the comments. / Know someone figuring out AI? Send this their way." Outro music, fade to black |

Frame-identical to `episode-00-extended.mp4` up to the outro (sampled frames match at PSNR 53+ dB); only the last card differs. Captions: `episode-00-extended-jtan-outro.srt`, which is ChatGPT's theme-preview SRT with the final music cue ended one frame earlier. Full decode clean; −16.5 LUFS, −1.8 dBTP. Rebuild: `./build.sh` (cards: `python3 -c "from cards import *; build()"`).

This folder is protected under the AGENTS.md rule for multiple agents: other agents flag, they don't delete. The theme's usage rights are still unconfirmed (free plan).

## Caffeine-hook version (2026-09-28)

Josh and Mary worried the Elon/Musk hook would confuse new viewers. `episode-00-extended-caffeine-hook.mp4` (11:28.7) swaps in the fun-facts exchange, clean 8:03.3–8:16.6: "Any other fun facts?" "Fun facts. I inhale caffeine. Josh doesn't touch it." (deadpan pause, kept on purpose because the next line depends on it) "Dang, we're not that fun." "We're not that fun." "We're kind of fun." "We're a lot of fun." Everything after the hook is identical to the jtan-outro version, shifted by 3.133 s. Captions: `episode-00-extended-caffeine-hook.srt`. Rebuild: `./build-caffeine-hook.sh`. Runner-up hook, not built: the honeymoon AI-kids story (8:36 setup, 9:40 punchline), which would need two moments joined.

## Honeymoon-hook version (2026-09-28): Josh's pick

`episode-00-extended-honeymoon-hook.mp4` (11:32.0). The hook is three pieces of the honeymoon AI-kids story, each cut in a silence:

| Hook time | Clean source | Line |
|---|---|---|
| 0:00.0–0:02.4 | 8:37.700–8:40.067 | Mary: "Recently on our honeymoon," |
| 0:02.4–0:07.1 | 9:15.300–9:20.067 | Josh: "Yeah, it was like from the first kid being born through like us being…" Mary: "Us being dead." |
| 0:07.1–0:16.5 | 9:41.500–9:50.867 | Mary: "The issue though is that Chat was too generous with us. 'Cause those kids were way better looking than our kids are gonna be. We were both ugly babies." Josh: "It's like Instagram reality." |

Then the blue title and sting, the full clean episode, and the blue thank-you card, as in the other versions (everything after the hook is shifted +6.333 s). Captions: `episode-00-extended-honeymoon-hook.srt`. Rebuild: `./build-honeymoon-hook.sh`. The finished hook was retranscribed; "dead" is quiet under the overlap but present. **Before public use, Mary should confirm she's comfortable leading the episode with the future-kids story.**

## Continuous honeymoon hook (2026-09-28): Josh's preference, "leave it as one"

`episode-00-extended-honeymoon-continuous.mp4` (11:51.0). The hook is one uncut take, clean 9:15.300–9:50.867 (35.6 s), from Josh's "Yeah, it was like from the first kid being born…" to "It's like Instagram reality." It includes "us being dead," the Thanksgiving and Christmas cards, the plaid outfits, "I kind of loved it, I kind of hated it," and the ugly-babies line. Then the title and sting, the full clean episode, and the thank-you card (everything shifted +25.4 s). Captions: `episode-00-extended-honeymoon-continuous.srt`; hook lines corrected by hand at the edges. Rebuild: `./build-honeymoon-continuous.sh`. Supersedes the three-piece hook version, which stays for comparison. Mary's OK on leading with the future-kids story is still needed.

## "Too generous" hook (2026-09-28): Josh's latest pick

`episode-00-extended-too-generous-hook.mp4` (11:26.7). The hook is one uncut take, clean 9:41.500–9:52.833 (11.3 s): Mary "The issue though is that Chat was too generous with us. 'Cause those kids were way better looking than our kids are gonna be. We were both ugly babies." Josh "It's like Instagram reality. Like Instagram versus reality." It ends in a small audio dip before Josh's "Like, that's the Instagram version." Then the title and sting, the full clean episode, and the thank-you card (everything shifted +1.167 s). Captions: `episode-00-extended-too-generous-hook.srt`. Rebuild: `./build-too-generous-hook.sh`.
