---
tags: [oood, episode-00, music-test]
---

# Episode 0 music test (jtan, 2026-09-28)

**A look-and-feel test Josh asked for. Not a release candidate.** It's built from ChatGPT's current `../../release/episode-00-review-v5.mp4`, which is left untouched.

`episode-00-music-test.mp4`, 11:28.6:

| Time | Part | Source |
|---|---|---|
| 0:00–0:10.2 | Hook: "I want the tea. What's the beef between Elon and Musk… Well, first, last… We're clearly learning." | v5 2:19.4–2:29.6, cut in silence at both ends |
| 0:10.2–0:15.4 | Blue title card, white type, with the 5.25 s theme sting | `cards.py`, `03_ASSETS/music/oood-sting-5s.wav` (−1.6 dB) |
| 0:15.4–11:17.8 | Full v5 episode, unchanged | v5 |
| 11:17.8–11:28.6 | Blue thank-you card: comment and share asks, with the 10.75 s outro, fading to black | `cards.py`, `oood-outro-11s.wav` (−3.3 dB) |

Checks: full decode clean. −16.5 LUFS, −1.8 dBTP. Frames sampled in every section. No chapters: v5's markers were stripped because the new opening would have shifted them. Rebuild with `build-music-test.sh`.

Notes:
- The type is white on blue, as Josh asked; the kit's reversed color on blue is cream.
- The theme's usage rights are unconfirmed (free plan).
- The hook replays at 2:19 inside the episode, which is intentional for a cold open.
