#!/bin/bash
# Episode 0 extended, "too generous" hook (one uncut take, clean 581.500-592.833): Mary "The issue though is that Chat was too generous with us..." to Josh "...like Instagram versus reality."
# -> blue title + sting -> full clean episode -> blue thank-you (comment + share asks) + outro.
set -e
cd "$(dirname "$0")"
CLEAN=../../release/episode-00-clean.mp4
M=../../../../03_ASSETS/music
ffmpeg -nostdin -v error -y \
 -ss 581 -i "$CLEAN" -i "$CLEAN" -i title-card.mp4 -i outro-card.mp4 -i "$M/oood-sting-5s.wav" -i "$M/oood-outro-11s.wav" \
 -filter_complex "\
[0:v]trim=start=0.5:end=11.8333,setpts=PTS-STARTPTS,format=yuv420p,setsar=1[hv];\
[0:a]atrim=start=0.5:end=11.8333,asetpts=PTS-STARTPTS,afade=t=in:d=0.012,afade=t=out:st=11.3033:d=0.03,aresample=48000,aformat=channel_layouts=stereo[ha];\
[2:v]format=yuv420p,setsar=1[tv];[4:a]volume=-1.6dB,aresample=48000,aformat=channel_layouts=stereo,apad=whole_dur=5.266667,atrim=end=5.266667[ta];\
[1:v]format=yuv420p,setsar=1[bv];[1:a]aresample=48000,aformat=channel_layouts=stereo[ba];\
[3:v]format=yuv420p,setsar=1[ov];[5:a]volume=-3.3dB,aresample=48000,aformat=channel_layouts=stereo,atrim=end=10.733333[oa];\
[hv][ha][tv][ta][bv][ba][ov][oa]concat=n=4:v=1:a=1[v][a]" \
 -map "[v]" -map "[a]" -map_chapters -1 -map_metadata -1 -c:v libx264 -preset medium -crf 18 -profile:v high -pix_fmt yuv420p -r 30 \
 -color_primaries bt709 -color_trc bt709 -colorspace bt709 -c:a aac -b:a 256k -movflags +faststart episode-00-extended-too-generous-hook.mp4
