# Episode 0 v5 quality and release status

Checked 2026-09-27. **11:02.400 review export, technically checked; not published or host-approved.** It retains the continuous source from 00:00 through the “Peace” sign-off and excludes only the post-wrap seconds. The video adds four brief blue-and-cream cards at the relevant speech, including the spoken podcast site and email. Josh confirmed the inbox is live and the site will be live by publication. The site is not independently verified as live now.

| Check | Result |
|---|---|
| Source | `/Users/je/Movies/Episode 0 Raw.mp4`; SHA-256 `428bd4c2979482c540e585cddec6f4e336783284b9b1e602c5b2a78acedba15b` before render |
| Video | 1920 × 1080 H.264 High, yuv420p BT.709, constant 30fps, 19,872 frames |
| Duration | Picture and AAC both 662.400 seconds; zero reported duration difference |
| Full decode | Video and audio decoded to null without error; no flagged black or silence spans |
| AAC loudness | −16.47 LUFS integrated, −1.74 dBTP, 6.10 LU range |
| MP3 audio | 662.400 seconds; −16.72 LUFS integrated, −2.06 dBTP; full decode passed |
| Audio channels | Source stream 1's hard-panned microphones were summed equally into left and right; decoded output channels have equal full-program RMS and peak levels, with only −104.95 dBFS RMS difference from AAC quantization |
| Chapters | Ten embedded chapters; opening and closing match the chapter list |
| Captions | 216 ordered, nonoverlapping SRT cues; all within runtime, at most two lines and 42 characters per line. The visible site/email wording was corrected to the candidate addresses in the recording. Listening proofread remains open. |
| Graphics | Actual output frames sampled at 00:47, 01:40, 05:00 and 10:28; the four cards are visible at the intended moments, clear of faces and the optional caption area. The contact card is absent by 10:33, before the hosts' joke about the site. |

The 2025 source behind the “20% behind” line concerns an approximate *relative usage* gap, not a percentage-point gap or skill measure. Its 2026 revision estimates a smaller recent-period gap. The video card uses the 2025 attribution, with both papers linked and qualified in `PUBLISHING.md`. It does not repeat the supplied screenshot's causal explanation. The broader nonprofit comparison at 01:45–01:56 is not sourced as a sector-wide measured result.

Before public release, both hosts should review this exact video and its captions. Specifically confirm Mary's comfort with the full personal story, that “20% behind” was meant as approximate relative use, and the on-screen spelling of `outofourdepth.com` and `hi@outofourdepth.com`. Confirm the site is live and points to the intended podcast destination before posting the episode and link. No music, outside footage, generated host voice or private generated family image was added. Cards provide visible text; full clickable links belong in the platform description.

Current video SHA-256: `c08f406681d0ba1b30e1c98d0897a9dc51f47f01e2595578c30b3f1258cc5e5b`. The AAC bitstream is identical to v4; current MP3 SHA-256: `cc56b455a7c6353a96af4a29b77135cd9eee034dd21fd08edb3be982c853ad77`.
