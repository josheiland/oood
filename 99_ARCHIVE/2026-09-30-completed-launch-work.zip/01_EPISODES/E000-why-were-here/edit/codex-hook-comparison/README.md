# Episode 0 opening comparison

The sixteen superseded preview MP4s described below were removed on 2026-09-29 at Josh's request to reduce storage and visual clutter. The notes and builders remain as an edit record. Josh's selected `../Hook_Final.mp4` and the current `../../release/episode-000.mp4` are preserved.

The folder contains 720p private review samples. Each uses the same 5.267-second blue title/music segment and the existing callout-free Episode 0 cut. They stop shortly after the episode resumes; none changes the full release videos. There is no outro in these samples.

| File | Before the title | After the title |
|---|---|---|
| `01-natural-opening.mp4` | Source 00:00.000–00:07.267: “And we're live … Scary.” | Resumes at 00:07.267 through 00:25.700, so the opening conversation appears once. |
| `02-mary-ai-creative.mp4` | Source 07:40.000–07:48.400: AI feels bland; make it cute and creative. | Original episode 00:00.000–00:15.933. |
| `03-caffeine-banter.mp4` | Source 08:03.300–08:16.600: fun-facts setup, caffeine contrast and “we're a lot of fun.” | Original episode 00:00.000–00:15.933. |
| `04-title-first.mp4` | No cold open. | Original episode 00:00.000–00:15.933. |
| `05-current-elon-reference.mp4` | Source 02:19.433–02:29.600: current Elon/Musk cold open, for an equal-length comparison. | Original episode 00:00.000–00:15.933. |
| `06-scary-to-whats-up.mp4` | Source 00:00.000–00:08.000, ending after Mary's “Scary.” | Jumps past a short pause to source 00:08.600–00:25.700, beginning with “What is up, everyone?” |
| `07-action-to-whats-up.mp4` | Source 00:00.000–00:01.900: Mary says “action” over “And we're live”; cut in the following pause. | Source 00:08.600–00:25.700, beginning with “What is up, everyone?” The “We're doing it” and “Scary” section is omitted. |
| `08-chat-too-generous.mp4` | Source 09:42.933–09:48.600: first “Chat was too generous” attempt; Josh heard an awkward partial lead-in to the next sentence. | Original episode 00:00.000–00:15.933. Superseded by `09` and `10`. |
| `09-chat-before-ugly-babies.mp4` | Source 09:42.933–09:48.500: ends after “our kids are gonna be,” before “We were both …” | Original episode 00:00.000–00:15.933. |
| `10-chat-includes-ugly-babies.mp4` | Source 09:42.933–09:49.600: includes the complete “We were both ugly babies” sentence. | Original episode 00:00.000–00:15.933. |
| `11-chat-ends-at-be.mp4` | Source 09:42.933–09:48.467: ends immediately after “our kids are gonna be,” before the “We were both” sentence. | Original episode 00:00.000–00:15.933. Current short comparison. |
| `12-chat-through-instagram.mp4` | Source 09:42.933–09:52.767: keeps “We were both ugly babies” and Mary's full “Instagram versus reality” line. | Original episode 00:00.000–00:15.933. Current longer comparison. |

The Mary, caffeine and Elon/Musk moments would repeat later if their cold opens were used with the full episode; the natural-opening version moves the original first seven seconds before the title and resumes after them. Its post-title excerpt runs about 18 seconds so the sentence can finish cleanly; the other excerpts run about 16 seconds. The title-first sample keeps the original conversation in order. `build-previews.py` uses the current clean and extended review files read-only, refuses to replace outputs, and retains no extra render assets. These are editorial comparisons, not selected release masters; the theme's public usage rights remain unconfirmed.

Josh clarified that the additional comparison should cut after “Scary” and return directly on “What is up, everyone?” The earlier `01-natural-opening.mp4` was placed using draft caption timing and may divide the last word. `06-scary-to-whats-up.mp4` uses a measured pause from 00:08.000–00:08.600 for the two edit boundaries. This is the corrected version to assess for that approach; the earlier comparison remains for history under the repository's no-cleanup rule.

Josh then corrected the intended hook: Mary's “action” overlaps the initial “And we're live.” `07-action-to-whats-up.mp4` follows that instruction, ending the hook at 00:01.900 in the first pause and resuming at 00:08.600 after the title. It supersedes `06-scary-to-whats-up.mp4` for the requested comparison. The earlier samples remain untouched under the repository's no-cleanup rule.

`08-chat-too-generous.mp4` was the first comparison Josh requested. It opens on the word “Chat,” but Josh heard the ending as a partial lead-in to the next thought. If this hook is selected for a full cut, the later occurrence of the moment would need an editorial decision because this short preview resumes at the original episode opening.

After reviewing `08`, Josh heard the transition as interrupting “We were both …” and asked for two clean boundaries. `09` cuts immediately after the preceding sentence; `10` lets “We were both ugly babies” finish. These two replace `08` for the hook comparison. The original remains untouched under the repository's no-cleanup rule.

Josh then asked for the short version to end earlier and the longer one to include Mary's “Instagram versus reality” response. A literal half-second earlier cut removed part of “our kids are gonna be,” so `11` uses the last frame of that phrase and excludes the next sentence. `12` runs through Mary's complete response. These are the two current comparisons; `09` and `10` remain unchanged for history.

Josh subsequently selected the longer `12` ending for the complete Episode 0 theme comparison. `../codex-mono-mirrored/render-honeymoon-font-v8.py` uses the original 1080p clean-source frames 17,488–17,782 for that opening, followed by the corrected native-font title, full conversation and outro. The 720p preview remains an earlier review sample.

Josh then asked to compare three *short testers* before choosing the final hook length. These all use the current native-font Mono, Mirrored intro card with 5.267 seconds of the proposed theme, then the same first 15.933 seconds of the clean episode. They are 720p private comparison clips, with no outro or burned-in captions.

| File | Hook before title | Hook length | Total clip |
|---|---|---:|---:|
| `13-honeymoon-full-story.mp4` | Continuous source 09:23.833–09:52.767: Thanksgiving/Christmas cards through Mary's “Instagram versus reality” response. | 28.933 s | 50.133 s |
| `14-honeymoon-setup-payoff.mp4` | Source 09:03.600–09:09.700 (Chat making future family Thanksgiving photos), then a jump cut to 09:41.767–09:52.767 (the too-generous results and Mary's response). | 17.100 s | 38.300 s |
| `15-honeymoon-short-punchline.mp4` | Continuous source 09:42.933–09:48.467: intended to end after “our kids are gonna be,” but Josh hears the start of the next “we.” Superseded for exact-boundary review by `16`. | 5.533 s | 26.733 s |

The middle version is the editorial recommendation to test first: it keeps a clear AI-photo setup and the two-host payoff at a shorter length. The direct cut between setup and punchline is intentional. The three MP4s were fully decoded; 30 fps picture counts, audio lengths, and sampled hook/title/body joins match the table. `build-honeymoon-native-font-testers.py` can reproduce them without overwriting the earlier options. No hook length has been finally approved.

Josh chose the brief punchline direction, but found that `15` runs into his next “we.” The corrected single review clip is `16-honeymoon-short-ends-after-be.mp4`: source frames 17,488–17,651, ending at 09:48.400, two video frames / 67 ms earlier than `15`. Its last 20 ms of hook audio fades into the same 5.267-second native-font title/music and the same first 15.933 seconds of the episode. Total 26.667 seconds, 800 frames at 720p30, AAC stereo. Full decode, frame/audio duration, ASR spot-check of the hook wording and the first title frame passed. The exact boundary still needs Josh's listening review before any new full-length export. The older short test remains untouched under the shared-work rule.

Josh reviewed `16`, still heard “we,” and made `../Hook_Final.mp4` himself. That 5.416-second, 163-frame user file is now the authoritative hook. The complete review cut using it is `../../release/episode-00-honeymoon-hook-review-codex-v9.mp4`; the original 1080p picture frames match Josh's selected 720p frames, while the hook audio is taken directly from his file. All testers in this folder remain historical comparisons.
