"""Build small Episode 0 opening comparisons without changing release cuts."""

import hashlib
import subprocess
from pathlib import Path


HERE = Path(__file__).resolve().parent
EPISODE = HERE.parents[1]
CLEAN = EPISODE / 'release/episode-00-clean.mp4'
EXTENDED = EPISODE / 'release/episode-00-extended.mp4'
EXPECTED = {
    CLEAN: '1c36a34e67c9b2a46133cbb9c0fac3cd8b9987970c532c14f66aaec3833b3b57',
    EXTENDED: '6cb3068d9b93c7546c34311fd4c24df4ca6742ec0b442dacb44fa3224ea7a866',
}
FPS = 30
TITLE_START = 305 / FPS
TITLE_FRAMES = 158
PREVIEWS = [
    ('01-natural-opening.mp4', 0, 218, 218, 771),
    ('02-mary-ai-creative.mp4', 13800, 14052, 0, 478),
    ('03-caffeine-banter.mp4', 14499, 14898, 0, 478),
    ('04-title-first.mp4', None, None, 0, 478),
    ('05-current-elon-reference.mp4', 4183, 4488, 0, 478),
    ('06-scary-to-whats-up.mp4', 0, 240, 258, 771),
    ('07-action-to-whats-up.mp4', 0, 57, 258, 771),
    ('08-chat-too-generous.mp4', 17488, 17658, 0, 478),
    ('09-chat-before-ugly-babies.mp4', 17488, 17655, 0, 478),
    ('10-chat-includes-ugly-babies.mp4', 17488, 17688, 0, 478),
    ('11-chat-ends-at-be.mp4', 17488, 17654, 0, 478),
    ('12-chat-through-instagram.mp4', 17488, 17783, 0, 478),
]


def sha256(path):
    digest = hashlib.sha256()
    with path.open('rb') as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def filters(label, frames):
    duration = frames / FPS
    video = (f'[{label}:v]trim=end_frame={frames},setpts=N/(30*TB),'
             'scale=1280:720:flags=lanczos,setsar=1,format=yuv420p'
             f'[{label}v]')
    audio = (f'[{label}:a]atrim=duration={duration:.9f},asetpts=PTS-STARTPTS,'
             f'aresample=48000,apad,atrim=duration={duration:.9f},'
             f'aformat=channel_layouts=stereo[{label}a]')
    return video, audio


def build(name, hook_start, hook_end, body_start, body_end):
    output = HERE / name
    if output.exists():
        raise FileExistsError(f'Refusing to replace {output}')
    title_input = 1 if hook_start is not None else 0
    body_input = title_input + 1
    command = ['ffmpeg', '-nostdin', '-hide_banner', '-v', 'error']
    parts = []
    if hook_start is not None:
        command += ['-ss', f'{hook_start/FPS:.9f}', '-i', str(CLEAN)]
        parts.extend(filters('0', hook_end - hook_start))
    command += ['-ss', f'{TITLE_START:.9f}', '-i', str(EXTENDED)]
    parts.extend(filters(str(title_input), TITLE_FRAMES))
    command += ['-ss', f'{body_start/FPS:.9f}', '-i', str(CLEAN)]
    parts.extend(filters(str(body_input), body_end - body_start))
    order = ''.join(f'[{i}v][{i}a]' for i in range(body_input + 1))
    parts.append(f'{order}concat=n={body_input+1}:v=1:a=1[v][a]')
    command += [
        '-filter_complex', ';'.join(parts), '-map', '[v]', '-map', '[a]',
        '-map_metadata', '-1', '-map_chapters', '-1',
        '-frames:v', str((hook_end - hook_start if hook_start is not None else 0)
                         + TITLE_FRAMES + body_end - body_start),
        '-r', '30', '-fps_mode', 'cfr', '-c:v', 'libx264', '-preset', 'veryfast',
        '-crf', '20', '-pix_fmt', 'yuv420p', '-c:a', 'aac', '-b:a', '192k',
        '-movflags', '+faststart', str(output),
    ]
    subprocess.run(command, check=True)
    print(output)


def main():
    for path, digest in EXPECTED.items():
        if not path.is_file() or sha256(path) != digest:
            raise RuntimeError(f'Expected source is missing or changed: {path}')
    for preview in PREVIEWS:
        build(*preview)


if __name__ == '__main__':
    main()
