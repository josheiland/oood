#!/usr/bin/env python3
"""Private Episode 0 honeymoon-hook testers with the corrected title card."""

import argparse
import hashlib
import subprocess
from pathlib import Path

HERE = Path(__file__).resolve().parent
EPISODE = HERE.parents[1]
ROOT = EPISODE.parents[1]
CLEAN = EPISODE / "release/episode-00-clean.mp4"
CLEAN_SHA = "1c36a34e67c9b2a46133cbb9c0fac3cd8b9987970c532c14f66aaec3833b3b57"
TITLE = ROOT / "03_ASSETS/codex-mono-mirrored-font-v2/intro-card.png"
STING = ROOT / "03_ASSETS/music/oood-sting-5s.wav"
FPS = 30
TITLE_FRAMES = 158
BODY_FRAMES = 478  # 15.933 seconds; complete opening sentence after the title

VERSIONS = [
    ("13-honeymoon-full-story.mp4", [(16915, 17783)]),
    ("14-honeymoon-setup-payoff.mp4", [(16308, 16491), (17453, 17783)]),
    ("15-honeymoon-short-punchline.mp4", [(17488, 17654)]),
    ("16-honeymoon-short-ends-after-be.mp4", [(17488, 17652)], 0.02),
]


def sha256(path):
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def build(name, ranges, end_fade=0.05):
    output = HERE / name
    if output.exists():
        raise FileExistsError(output)
    command = ["ffmpeg", "-nostdin", "-hide_banner", "-v", "error", "-n"]
    filters = []
    concat = []
    index = 0
    for segment, (first, after) in enumerate(ranges):
        frames = after - first
        duration = frames / FPS
        command += ["-ss", f"{first/FPS:.9f}", "-i", str(CLEAN)]
        filters.append(
            f"[{index}:v]trim=end_frame={frames},setpts=N/(30*TB),"
            f"scale=1280:720:flags=lanczos,setsar=1,format=yuv420p[v{index}]"
        )
        fade = (f",afade=t=out:st={duration-end_fade:.9f}:d={end_fade:.9f}"
                if segment == len(ranges) - 1 else "")
        filters.append(
            f"[{index}:a]atrim=duration={duration:.9f},asetpts=PTS-STARTPTS,"
            f"aresample=48000{fade},apad,atrim=duration={duration:.9f},"
            f"aformat=channel_layouts=stereo[a{index}]"
        )
        concat.append(f"[v{index}][a{index}]")
        index += 1

    command += ["-loop", "1", "-framerate", "30", "-i", str(TITLE)]
    filters.append(
        f"[{index}:v]trim=end_frame={TITLE_FRAMES},setpts=N/(30*TB),"
        f"scale=1280:720:flags=lanczos,setsar=1,format=yuv420p[v{index}]"
    )
    title_index = index
    index += 1
    command += ["-i", str(STING)]
    filters.append(
        f"[{index}:a]volume=-1.6dB,atrim=duration={TITLE_FRAMES/FPS:.9f},"
        f"asetpts=PTS-STARTPTS,aresample=48000,apad,"
        f"atrim=duration={TITLE_FRAMES/FPS:.9f},aformat=channel_layouts=stereo[a{title_index}]"
    )
    concat.append(f"[v{title_index}][a{title_index}]")
    index += 1

    command += ["-i", str(CLEAN)]
    filters.append(
        f"[{index}:v]trim=end_frame={BODY_FRAMES},setpts=N/(30*TB),"
        f"scale=1280:720:flags=lanczos,setsar=1,format=yuv420p[v{index}]"
    )
    filters.append(
        f"[{index}:a]atrim=duration={BODY_FRAMES/FPS:.9f},asetpts=PTS-STARTPTS,"
        f"aresample=48000,apad,atrim=duration={BODY_FRAMES/FPS:.9f},"
        f"aformat=channel_layouts=stereo[a{index}]"
    )
    concat.append(f"[v{index}][a{index}]")
    filters.append(f"{''.join(concat)}concat=n={len(concat)}:v=1:a=1[v][a]")
    expected_frames = sum(after-first for first, after in ranges) + TITLE_FRAMES + BODY_FRAMES
    command += [
        "-filter_complex", ";".join(filters), "-map", "[v]", "-map", "[a]",
        "-map_metadata", "-1", "-map_chapters", "-1", "-frames:v", str(expected_frames),
        "-r", "30", "-fps_mode", "cfr", "-c:v", "libx264", "-preset", "veryfast",
        "-crf", "20", "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "192k",
        "-movflags", "+faststart", str(output),
    ]
    subprocess.run(command, check=True)
    print(f"{output} | {expected_frames} frames | {expected_frames/FPS:.3f} s", flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--only", help="Build just one named preview")
    args = parser.parse_args()
    if not CLEAN.is_file() or sha256(CLEAN) != CLEAN_SHA:
        raise RuntimeError("Expected clean master is missing or changed")
    for path in (TITLE, STING):
        if not path.is_file():
            raise FileNotFoundError(path)
    selected = [version for version in VERSIONS if args.only in (None, version[0])]
    if not selected:
        raise ValueError(f"Unknown preview: {args.only}")
    for name, *_ in selected:
        if (HERE / name).exists():
            raise FileExistsError(HERE / name)
    for version in selected:
        build(*version)


if __name__ == "__main__":
    main()
