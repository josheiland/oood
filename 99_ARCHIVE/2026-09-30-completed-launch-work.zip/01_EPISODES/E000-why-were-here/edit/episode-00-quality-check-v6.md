# Episode 0 v6 comparison check — 2026-09-28

Two renders made from the unchanged inventoried raw recording. The clean version contains exactly raw frames 0–19,781, ending at 10:59.400. It has no overlays. The theme preview uses the clean export throughout; its cold open repeats source 02:19.433–02:29.600 and the full clean episode starts at 00:15.433.

| Check | Clean | Theme preview |
|---|---:|---:|
| Duration | 10:59.400 | 11:25.600 |
| Video frames | 19,782 | 20,568 |
| Picture | 1920 × 1080, 30fps, H.264 | 1920 × 1080, 30fps, H.264 |
| Audio | AAC stereo, both hosts in both ears | AAC stereo, centered dialogue and stereo music |
| Integrated loudness / true peak | −16.46 LUFS / −1.74 dBTP | −16.51 LUFS / −1.65 dBTP |
| SRT cues | 215 | 221 |
| Chapter markers | 10 | 13 |
| Full-file decode | Passed | Passed |
| SHA-256 | `1c36a34e67c9b2a46133cbb9c0fac3cd8b9987970c532c14f66aaec3833b3b57` | `6cb3068d9b93c7546c34311fd4c24df4ca6742ec0b442dacb44fa3224ea7a866` |

The theme timeline is 00:00–00:10.167 cold open; 00:10.167–00:15.433 blue/white title with the 5.25-second sting; 00:15.433–11:14.833 complete clean episode; 11:14.833–11:25.600 blue thank-you/comment/share page with the 10.75-second outro. The title and outro were sampled from the encoded output. The clean picture was sampled at the former research-card moment and shows unobstructed hosts. Caption files passed numbering, ordering, positive-duration and chapter-end structural checks. The final “flip” caption was shifted toward the line's measured audio activity, and the old “Peace” cue was removed with the tail; an auditory caption proofread remains open.

The prior v5 video/audio and an intermediate theme test were deleted after these checks, saving roughly 428 MiB while leaving the two requested review videos, matching SRTs and thumbnail in `release/`. Rendering uses temporary assets and keeps no extra MP3/WAV copies. The proposed theme clips were already in `03_ASSETS/music/` and are not duplicated here.

Still open: both hosts should watch the exact version selected, proofread its captions by listening, confirm comfort with the honeymoon/future-family story, and resolve the spoken “20% behind” reference as described in `PUBLISHING.md`. The podcast site should be checked when the link is published. The theme's public usage rights are unconfirmed; the music video is a private comparison, not an approved release master. No upload, scheduling, or publication occurred.
