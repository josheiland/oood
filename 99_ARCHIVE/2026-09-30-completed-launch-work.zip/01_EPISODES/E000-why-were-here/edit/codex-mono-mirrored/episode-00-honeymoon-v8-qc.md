# Episode 0 honeymoon-hook native-font comparison — technical check

The private 1080p theme cut is `release/episode-00-honeymoon-mono-mirrored-codex-v8.mp4`, with matching optional-caption SRT. It uses source clean frames 17,488–17,782 for the opening through Mary's “Instagram versus reality” line, 158 frames of the newly font-rendered intro card, all 19,782 clean conversation frames, and 323 outro-card frames. Earlier Elon-hook and card-render versions remain untouched.

| Check | Result |
|---|---|
| Picture | 1920 × 1080 H.264, 30 fps, 20,558 frames, 11:25.267 |
| Audio | AAC stereo, 11:25.266; −16.4 LUFS integrated, −1.8 dBTP true peak |
| Chapters | 13; hook 00:00–00:09.833, title 00:09.833–00:15.100, full episode 00:15.100–11:14.500, outro to 11:25.267 |
| Captions | 221 numbered, non-overlapping cues through 11:25.267; hook manually retimed, clean captions shifted by 15.100 seconds |
| Decode | Full video/audio decode completed without errors |
| Joins | Sampled encoded hook, title, body, outro and final fade; host/card transitions appear at intended frames |
| SHA-256 | `96261ee1f57c62133fc462f83fea8bd44221ce453b552921db81b605d3ac13a4` |

The actual 1920 × 1080 card PNGs were inspected. The subtitle and footer text use whole-string Teachers shaping; editable SVGs retain live text and embedded font files. This is technical QC and sampled-picture review, not continuous host approval. Josh later requested three shorter hook testers (`edit/codex-hook-comparison/13`–`15`); final hook selection is therefore open. Caption listening proofread, Mary's comfort with the personal story, factual review of the “20% behind” line, website launch check, and public music rights remain open. No upload, scheduling or publication is claimed.
