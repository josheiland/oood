# Episode 000 approved recurring cards: v11 QC

Date: 2026-09-30. Local replacement for re-upload; no platform action performed.

Josh approved the updated intro/outro cards and requested their incorporation into the full Episode 000. His minimum-file instruction authorizes replacement of the prior Codex export after checks. The original raw, user hook and other agents' files were untouched.

Source: prior stable `release/episode-000.mp4` (v10), SHA-256 `03c589956ba9a12d8b06bc3438e2e8190dba9c09183db585916b7b3d723a54ec`.
Output: same stable filename, 188,620,712 bytes; SHA-256 `dd982e61af7508c1e0a20a1f79d17c9bddf20ccf6fd8a6e80c1a650951ba851e`.
Renderer: `render-recurring-cards-v11.py`. It checks the v10 source hash and stages the output before replacement. The superseded v10 media is not retained, so the historical builder cannot rerun from the current v11 file.

## Picture changes

- Frames 163–320: approved native Teachers intro with `FIGURING OUT AI TOGETHER` and no episode-number label, 00:05.433333–00:10.700.
- Frames 20103–20425: approved outro without the top show-name label; three prompts raised 48 pixels, 11:10.100–11:20.866667.
- Final 0.5-second picture fade preserved, beginning 11:20.366667.
- No hook or conversation edits. Picture is re-encoded at 1080p30 H.264 CRF 18, veryfast; audio is copied.

## Verification

Full video/audio decode completed with no errors. Output remains 1920 × 1080, 30 fps, 20,426 picture frames and 680.867 seconds. All 13 chapter dictionaries match the source exactly. AAC ADTS SHA-256 is identical to the source and earlier v9/v10: `588ae5b2bd0d6cf1be9cd0e5d33b6f9f2213aa685ab7c2a5504c411f513954bd`. Existing −16.5 LUFS / −1.7 dBTP audio measurements therefore continue to apply; no new audio processing or loudness pass was needed.

Encoded picture samples inspected at frames 162, 163, 320, 321, 20102, 20103, 20410 and 20425 confirm the exact card transitions and retained final fade. Full-resolution intro and outro frames were visually inspected for native-font text and approved layout. This was technical decoding and sampled frame inspection, not a new continuous human audiovisual review.

SRT is unchanged: SHA-256 `8662f5896d01737f9e1144c737d3be99fbdd42c2ed459f7740f1601f84385769`. Thumbnail unchanged: SHA-256 `10b0e3bff415b283cc7808812551ff77efa26064dd2ceb7601ad364a4489b5c4`. Release folder retains only the current MP4, existing SRT and existing thumbnail. Temporary QC frames were stored outside the project release folder.

## Status

Previous version published on YouTube and Spotify per Josh's 2026-09-29 report in the decisions ledger. These card changes were approved by Josh; this checked replacement is a local re-upload file. No upload, re-publication or end-screen platform assembly was performed. Subscribe/recommended-video positioning remains a platform step. Historical caption/research notes were not re-audited by this picture-only change.
