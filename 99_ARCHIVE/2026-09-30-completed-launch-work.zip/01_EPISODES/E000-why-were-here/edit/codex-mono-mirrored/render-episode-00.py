#!/usr/bin/env python3
"""Replace only the title/outro picture in Episode 0's existing theme review.

The cold open, main conversation, music, audio mix, timestamps, and chapters
come from the current extended comparison. This script never overwrites it.
"""

import hashlib
import subprocess
from pathlib import Path


HERE = Path(__file__).resolve().parent
EPISODE = HERE.parents[1]
ROOT = EPISODE.parents[1]
SOURCE = EPISODE / "release/episode-00-extended.mp4"
CARDS = ROOT / "03_ASSETS/codex-mono-mirrored"
INTRO = CARDS / "intro-card.png"
OUTRO = CARDS / "outro-card.png"
OUTPUT = EPISODE / "release/episode-00-mono-mirrored-codex-v7.mp4"
CAPTIONS = EPISODE / "release/episode-00-theme-preview-v6.srt"
NEW_CAPTIONS = EPISODE / "release/episode-00-mono-mirrored-codex-v7.srt"
SOURCE_SHA = "6cb3068d9b93c7546c34311fd4c24df4ca6742ec0b442dacb44fa3224ea7a866"

FPS = 30
HOOK_FRAMES = 305
INTRO_FRAMES = 158
MAIN_FRAMES = 19782
OUTRO_FRAMES = 323
TOTAL_FRAMES = HOOK_FRAMES + INTRO_FRAMES + MAIN_FRAMES + OUTRO_FRAMES
OUTRO_START = HOOK_FRAMES + INTRO_FRAMES + MAIN_FRAMES


def sha256(path):
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def main():
    if not SOURCE.is_file() or sha256(SOURCE) != SOURCE_SHA:
        raise RuntimeError(f"Expected Episode 0 source is missing or changed: {SOURCE}")
    for path in (INTRO, OUTRO, CAPTIONS):
        if not path.is_file():
            raise FileNotFoundError(path)
    for path in (OUTPUT, NEW_CAPTIONS):
        if path.exists():
            raise FileExistsError(f"Refusing to replace {path}")

    graph = (
        f"[0:v][1:v]overlay=0:0:enable='between(n,{HOOK_FRAMES},"
        f"{HOOK_FRAMES + INTRO_FRAMES - 1})'[with_intro];"
        f"[with_intro][2:v]overlay=0:0:enable='between(n,{OUTRO_START},"
        f"{TOTAL_FRAMES - 1})',format=yuv420p,"
        f"fade=t=out:st={(TOTAL_FRAMES - 15) / FPS:.9f}:d={15 / FPS:.9f}[v]"
    )
    command = [
        "ffmpeg", "-nostdin", "-hide_banner", "-v", "error",
        "-i", str(SOURCE),
        "-loop", "1", "-framerate", str(FPS), "-i", str(INTRO),
        "-loop", "1", "-framerate", str(FPS), "-i", str(OUTRO),
        "-filter_complex", graph,
        "-map", "[v]", "-map", "0:a:0", "-map", "0:d?",
        "-map_metadata", "0", "-map_chapters", "0",
        "-frames:v", str(TOTAL_FRAMES), "-r", str(FPS), "-fps_mode", "cfr",
        "-c:v", "libx264", "-preset", "veryfast", "-crf", "18",
        "-profile:v", "high", "-pix_fmt", "yuv420p",
        "-color_primaries", "bt709", "-color_trc", "bt709",
        "-colorspace", "bt709", "-c:a", "copy", "-c:d", "copy",
        "-movflags", "+faststart", str(OUTPUT),
    ]
    subprocess.run(command, check=True)
    NEW_CAPTIONS.write_bytes(CAPTIONS.read_bytes())
    print(OUTPUT)
    print(NEW_CAPTIONS)


if __name__ == "__main__":
    main()
