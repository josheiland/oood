#!/usr/bin/env python3
"""Stage the approved recurring cards; preserve Episode 000 audio and timing."""
from pathlib import Path
import hashlib
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[4]
SOURCE = ROOT / '01_EPISODES/E000-why-were-here/release/episode-000.mp4'
CARDS = ROOT / '03_ASSETS/codex-mono-mirrored-3digit'
SOURCE_SHA = '03c589956ba9a12d8b06bc3438e2e8190dba9c09183db585916b7b3d723a54ec'

def main():
    output = Path(sys.argv[1])
    if output.exists():
        raise FileExistsError(output)
    if hashlib.file_digest(SOURCE.open('rb'), 'sha256').hexdigest() != SOURCE_SHA:
        raise RuntimeError('Source differs from the checked current Episode 000')
    subprocess.run([
        'ffmpeg', '-hide_banner', '-loglevel', 'warning', '-stats', '-n',
        '-i', str(SOURCE),
        '-loop', '1', '-framerate', '30', '-i', str(CARDS / 'intro-card.png'),
        '-loop', '1', '-framerate', '30', '-i', str(CARDS / 'outro-card.png'),
        '-filter_complex',
        "[0:v][1:v]overlay=0:0:enable='between(n,163,320)'[intro];"
        "[2:v]format=yuv420p,fade=t=out:st=680.366666667:d=0.5[outro];"
        "[intro][outro]overlay=0:0:enable='between(n,20103,20425)',format=yuv420p[v]",
        '-map', '[v]', '-map', '0:a:0',
        '-map_metadata', '0', '-map_chapters', '0',
        '-frames:v', '20426', '-r', '30', '-fps_mode', 'cfr',
        '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '18',
        '-profile:v', 'high', '-pix_fmt', 'yuv420p',
        '-color_primaries', 'bt709', '-color_trc', 'bt709', '-colorspace', 'bt709',
        '-c:a', 'copy', '-movflags', '+faststart', str(output),
    ], check=True)

if __name__ == '__main__':
    main()
