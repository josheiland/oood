#!/usr/bin/env python3
"""Build Episode 0 from Josh's Hook_Final cut and the native-font cards."""

import hashlib
import re
import shutil
import subprocess
import tempfile
from pathlib import Path

EPISODE = Path(__file__).resolve().parents[2]
ROOT = EPISODE.parents[1]
RELEASE = EPISODE / "release"
CLEAN = RELEASE / "episode-00-clean.mp4"
CLEAN_SHA = "1c36a34e67c9b2a46133cbb9c0fac3cd8b9987970c532c14f66aaec3833b3b57"
HOOK = EPISODE / "edit/Hook_Final.mp4"
HOOK_SHA = "0da359cc209d994d68e1f4604b87544b29a809042a2201a5b68bae8077c8b4da"
CAPTIONS = RELEASE / "episode-00-clean-v6.srt"
CARDS = ROOT / "03_ASSETS/codex-mono-mirrored-font-v2"
MUSIC = ROOT / "03_ASSETS/music"
OUTPUT = RELEASE / "episode-00-honeymoon-hook-review-codex-v9.mp4"
SRT = RELEASE / "episode-00-honeymoon-hook-review-codex-v9.srt"

FPS = 30
HOOK_FIRST = 17488
HOOK_FRAMES = 163  # Josh's file has exactly these source frames
HOOK_AUDIO_DURATION = 5.416  # user-trimmed audio, kept without extending its speech
TITLE_FRAMES = 158
BODY_FRAMES = 19782
OUTRO_FRAMES = 323
HOOK_DURATION = HOOK_FRAMES / FPS
TITLE_DURATION = TITLE_FRAMES / FPS
BODY_DURATION = BODY_FRAMES / FPS
OUTRO_DURATION = OUTRO_FRAMES / FPS
BODY_START = HOOK_DURATION + TITLE_DURATION
OUTRO_START = BODY_START + BODY_DURATION
END = OUTRO_START + OUTRO_DURATION
TOTAL_FRAMES = HOOK_FRAMES + TITLE_FRAMES + BODY_FRAMES + OUTRO_FRAMES


def sha256(path):
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def ffmeta(path):
    body_chapters = [
        (0, "Opening: why we are here"), (63, "Why learn AI together"),
        (117, "Make it fun and accessible"), (214, "Meet Josh and Mary"),
        (290, "Run Your City and the show"), (349, "What to expect"),
        (397, "Curious and skeptical"), (474, "Fun facts"),
        (516, "The honeymoon AI experiment"), (617, "Closing invitation"),
    ]
    chapters = [(0, "Honeymoon AI photo cold open"),
                (HOOK_DURATION, "Theme and title")]
    chapters += [(BODY_START + s, title) for s, title in body_chapters]
    chapters.append((OUTRO_START, "Outro"))
    lines = [";FFMETADATA1", "title=Out of Our Depth | Episode 0: Why we're here",
             "artist=Josh and Mary"]
    for index, (start, title) in enumerate(chapters):
        stop = chapters[index + 1][0] if index + 1 < len(chapters) else END
        lines += ["[CHAPTER]", "TIMEBASE=1/30000", f"START={round(start * 30000)}",
                  f"END={round(stop * 30000)}", f"title={title}"]
    path.write_text("\n".join(lines) + "\n")


def parse_time(value):
    hours, minutes, rest = value.split(":")
    seconds, millis = rest.split(",")
    return 3600 * int(hours) + 60 * int(minutes) + int(seconds) + int(millis) / 1000


def format_time(seconds):
    total = round(seconds * 1000)
    hours, total = divmod(total, 3600000)
    minutes, total = divmod(total, 60000)
    seconds, millis = divmod(total, 1000)
    return f"{hours:02}:{minutes:02}:{seconds:02},{millis:03}"


def captions():
    hook = [
        (0.00, 2.76, "Chat was too generous with us."),
        (2.76, 4.82, "'Cause those kids were way better looking"),
        (4.82, HOOK_DURATION, "than our kids are gonna be."),
    ]
    cues = hook + [(HOOK_DURATION, BODY_START, "[Instrumental theme music]")]
    for block in re.split(r"\n\s*\n", CAPTIONS.read_text().strip()):
        lines = block.splitlines()
        start, stop = lines[1].split(" --> ")
        cues.append((parse_time(start) + BODY_START,
                     parse_time(stop) + BODY_START, "\n".join(lines[2:])))
    cues.append((OUTRO_START, END, "[Instrumental theme music]"))
    for start, stop, _ in cues:
        if not 0 <= start < stop <= END + 0.001:
            raise ValueError(f"Bad caption timing: {start}–{stop}")
    SRT.write_text("\n\n".join(
        f"{index}\n{format_time(start)} --> {format_time(stop)}\n{body}"
        for index, (start, stop, body) in enumerate(cues, 1)) + "\n")


def main():
    if not CLEAN.is_file() or sha256(CLEAN) != CLEAN_SHA:
        raise RuntimeError("Expected clean Episode 0 master is missing or changed")
    if not HOOK.is_file() or sha256(HOOK) != HOOK_SHA:
        raise RuntimeError("Josh's Hook_Final file is missing or changed")
    for path in (CAPTIONS, CARDS / "intro-card.png", CARDS / "outro-card.png",
                 MUSIC / "oood-sting-5s.wav", MUSIC / "oood-outro-11s.wav"):
        if not path.is_file():
            raise FileNotFoundError(path)
    for path in (OUTPUT, SRT):
        if path.exists():
            raise FileExistsError(path)
    graph = (
        f"[0:v]trim=start_frame={HOOK_FIRST}:end_frame={HOOK_FIRST+HOOK_FRAMES},"
        "setpts=N/(30*TB),format=yuv420p,setsar=1[hv];"
        f"[1:a]atrim=duration={HOOK_AUDIO_DURATION:.9f},"
        "asetpts=PTS-STARTPTS,aresample=48000,"
        f"apad,atrim=duration={HOOK_DURATION:.9f}[ha];"
        f"[2:v]trim=end_frame={TITLE_FRAMES},setpts=N/(30*TB),format=yuv420p,setsar=1[tv];"
        f"[4:a]volume=-1.6dB,aresample=48000,apad,atrim=duration={TITLE_DURATION:.9f}[ta];"
        f"[3:v]trim=end_frame={BODY_FRAMES},setpts=N/(30*TB),format=yuv420p,setsar=1[bv];"
        f"[3:a]aresample=48000,apad,atrim=duration={BODY_DURATION:.9f}[ba];"
        f"[5:v]trim=end_frame={OUTRO_FRAMES},setpts=N/(30*TB),format=yuv420p,setsar=1,"
        f"fade=t=out:st={OUTRO_DURATION-0.5:.9f}:d=0.5[ov];"
        f"[6:a]volume=-3.3dB,aresample=48000,apad,atrim=duration={OUTRO_DURATION:.9f},"
        f"afade=t=out:st={OUTRO_DURATION-0.7:.9f}:d=0.7[oa];"
        "[hv][ha][tv][ta][bv][ba][ov][oa]concat=n=4:v=1:a=1[v][a]"
    )
    with tempfile.TemporaryDirectory(prefix="oood-e000-codex-v9-") as tmp:
        work = Path(tmp)
        metadata = work / "chapters.ffmeta"
        rendered = work / "episode-00-v9.mp4"
        ffmeta(metadata)
        command = [
            "ffmpeg", "-nostdin", "-hide_banner", "-v", "error", "-n",
            "-i", str(CLEAN), "-i", str(HOOK),
            "-loop", "1", "-framerate", "30", "-i", str(CARDS / "intro-card.png"),
            "-i", str(CLEAN), "-i", str(MUSIC / "oood-sting-5s.wav"),
            "-loop", "1", "-framerate", "30", "-i", str(CARDS / "outro-card.png"),
            "-i", str(MUSIC / "oood-outro-11s.wav"), "-i", str(metadata),
            "-filter_complex", graph, "-map", "[v]", "-map", "[a]",
            "-map_metadata", "7", "-map_chapters", "7",
            "-frames:v", str(TOTAL_FRAMES), "-r", "30", "-fps_mode", "cfr",
            "-c:v", "libx264", "-preset", "veryfast", "-crf", "18",
            "-profile:v", "high", "-pix_fmt", "yuv420p",
            "-color_primaries", "bt709", "-color_trc", "bt709", "-colorspace", "bt709",
            "-c:a", "aac", "-b:a", "256k", "-movflags", "+faststart", str(rendered),
        ]
        subprocess.run(command, check=True)
        shutil.move(rendered, OUTPUT)
    captions()
    print(OUTPUT)
    print(SRT)


if __name__ == "__main__":
    main()
