# Episode 0 user-trimmed hook theme cut — technical check

Josh supplied `edit/Hook_Final.mp4` and instructed its use as the final Episode 0 hook. The file is 5.416 seconds with 163 frames at 720p and stereo audio; SHA-256 `0da359cc209d994d68e1f4604b87544b29a809042a2201a5b68bae8077c8b4da`. Its frames matched clean-master frames 17,488–17,650. The new full export uses those exact frames from the 1080p clean master for picture and Josh's file for hook audio. The user source was read only. A 17 ms silent pad aligns the supplied hook audio with the 163-frame picture before title music starts.

| Check | Result |
|---|---|
| Review export | `release/episode-00-honeymoon-hook-review-codex-v9.mp4` |
| Picture | 1920 × 1080 H.264, 30 fps, 20,426 frames, 11:20.867 |
| Audio | AAC stereo, 11:20.866; −16.5 LUFS integrated, −1.7 dBTP true peak |
| Hook audio match | First 5.416 seconds of exported audio correlate 0.999997 with Josh's file after AAC decode/re-encode |
| Chapters | 13; hook 00:00–00:05.433, title 00:05.433–00:10.700, full clean episode 00:10.700–11:10.100, outro to 11:20.867 |
| Captions | 220 numbered, ordered, non-overlapping optional-caption cues through 11:20.867; clean captions shifted 10.700 seconds |
| Decode | Full video/audio decode completed without errors |
| Picture samples | Encoded hook, native-font title, body start, outro and final fade inspected at their actual timeline positions |
| Export SHA-256 | `48a50fd0a4963a11964ca80793aeb63337d6e2cf0d691492deb9fd5ba9c54fae` |

This is an exact-cut technical and sampled-picture check, not a continuous host watch-through or publication approval. The hook follows Josh's own trim. Remaining release checks include caption listening proof, both hosts' full-export review, factual clarification of “20% behind,” Mary's comfort with the personal story, the website's launch state at upload, and confirmation of public theme-music rights. Nothing was uploaded, scheduled or published.
