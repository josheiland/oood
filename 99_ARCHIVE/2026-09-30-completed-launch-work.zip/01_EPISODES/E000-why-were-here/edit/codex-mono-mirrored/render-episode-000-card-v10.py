#!/usr/bin/env python3
"""Replace only the v9 intro picture with the three-digit Episode 000 card."""

from pathlib import Path
import hashlib
import shutil
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parents[4]
RELEASE = ROOT / "01_EPISODES/E000-why-were-here/release"
SOURCE = RELEASE / "episode-00-honeymoon-hook-review-codex-v9.mp4"
SOURCE_SRT = RELEASE / "episode-00-honeymoon-hook-review-codex-v9.srt"
CARD = ROOT / "03_ASSETS/codex-mono-mirrored-3digit/intro-card.png"
OUTPUT = RELEASE / "episode-000-honeymoon-hook-review-codex-v10.mp4"
OUTPUT_SRT = OUTPUT.with_suffix(".srt")
EXPECTED_SOURCE_SHA256 = "48a50fd0a4963a11964ca80793aeb63337d6e2cf0d691492deb9fd5ba9c54fae"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as source:
        for block in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def main():
    if sha256(SOURCE) != EXPECTED_SOURCE_SHA256:
        raise RuntimeError("Current source differs from the checked v9 review export")
    for target in (OUTPUT, OUTPUT_SRT):
        if target.exists():
            raise FileExistsError(target)
    if not CARD.is_file():
        raise FileNotFoundError(CARD)
    with tempfile.TemporaryDirectory(prefix="oood-e000-v10-") as directory:
        partial = Path(directory) / "episode-000-v10.mp4"
        subprocess.run([
            "ffmpeg", "-hide_banner", "-loglevel", "error", "-y",
            "-i", str(SOURCE), "-loop", "1", "-framerate", "30", "-i", str(CARD),
            "-filter_complex", "[0:v][1:v]overlay=0:0:enable='between(n,163,320)',format=yuv420p[v]",
            "-map", "[v]", "-map", "0:a:0", "-map", "0:d?",
            "-map_metadata", "0", "-map_chapters", "0",
            "-metadata", "title=Out of Our Depth | Episode 000: Why we're here",
            "-frames:v", "20426", "-r", "30", "-fps_mode", "cfr",
            "-c:v", "libx264", "-preset", "veryfast", "-crf", "18",
            "-profile:v", "high", "-pix_fmt", "yuv420p",
            "-color_primaries", "bt709", "-color_trc", "bt709", "-colorspace", "bt709",
            "-c:a", "copy", "-c:d", "copy", "-movflags", "+faststart", str(partial),
        ], check=True)
        shutil.move(partial, OUTPUT)
    shutil.copyfile(SOURCE_SRT, OUTPUT_SRT)
    print(OUTPUT)
    print(OUTPUT_SRT)


if __name__ == "__main__":
    main()
