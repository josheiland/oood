# Episode 0 mono/mirrored card review — 2026-09-28

Josh supplied the final intro/outro visual reference. This local variant replaces only the old cards in `release/episode-00-extended.mp4`; the Elon/Musk cold open, complete clean conversation, card lengths, instrumental music and outro audio remain in their original order. The hook choice itself is still open. Editable card sources and stills are in `03_ASSETS/codex-mono-mirrored/`.

| Check | Result |
|---|---|
| Export | `release/episode-00-mono-mirrored-codex-v7.mp4` |
| Duration / picture | 11:25.600, 20,568 frames, 1920 × 1080, 30fps H.264 |
| Intro card | Frames 305–462, 00:10.167–00:15.433 |
| Outro card | Frames 20,245–20,567, 11:14.833–11:25.600; final 0.5 s fades out |
| Audio | AAC stereo packets identical to `episode-00-extended.mp4`; SHA-256 of ADTS stream `e21ec14c7bb3bbeca1279cadf2fa79ca0e4be924c9a0a80716423037c6db2495` |
| Chapters / captions | 13 chapters at the same times; matching SRT byte-identical to `episode-00-theme-preview-v6.srt` |
| Decode and joins | Full-file decode passed without errors. Sampled encoded hook, title, conversation, outro and fade. Boundary frames 304/305, 462/463, and 20,244/20,245 show exact host/card transitions. |
| Export SHA-256 | `a60dda1d2b9d504c7054e74324fdc23170670e2318f076ce9725f9b09943a922` |

The static card PNGs were inspected at 1920 × 1080 against the supplied side-by-side design. SVG files parse as valid XML and retain editable text with embedded Teachers and JetBrains Mono fonts. The SVGs were not independently browser-rendered; the PNGs are the verified video sources. This is a technical check and sampled-picture review, not a continuous host watch-through or final publication approval. Music rights, caption listening proofread, factual clarification of “20% behind,” comfort with personal material, website launch check and host choice of opening hook remain open. Nothing was uploaded, scheduled or published.
