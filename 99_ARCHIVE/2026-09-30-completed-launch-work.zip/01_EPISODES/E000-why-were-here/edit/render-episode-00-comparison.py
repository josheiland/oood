"""Build two Episode 0 review videos without keeping intermediate media.

The clean cut is continuous raw footage. The music test uses a cold-open
excerpt, the supplied theme clips and blue cards, then replays the entire
clean cut. Raw footage and theme assets are never modified.
"""

import hashlib
import importlib.util
import re
import subprocess
import sys
import tempfile
from pathlib import Path


EPISODE = Path(__file__).resolve().parents[1]
ROOT = EPISODE.parents[1]
RAW = Path('/Users/je/Movies/Episode 0 Raw.mp4')
RAW_SHA = '428bd4c2979482c540e585cddec6f4e336783284b9b1e602c5b2a78acedba15b'
MUSIC = ROOT / '03_ASSETS/music'
RELEASE = EPISODE / 'release'
BASE_FRAMES = 19782  # 10:59.400, exactly three seconds shorter than v5
BASE_DURATION = BASE_FRAMES / 30
HOOK_START = 4183 / 30  # 2:19.433
HOOK_FRAMES = 305
TITLE_FRAMES = 158
OUTRO_FRAMES = 323
HOOK_DURATION = HOOK_FRAMES / 30
TITLE_DURATION = TITLE_FRAMES / 30
OUTRO_DURATION = OUTRO_FRAMES / 30
MAIN_OFFSET = HOOK_DURATION + TITLE_DURATION


def run(args):
    return subprocess.run(args, check=True, text=True, stdout=subprocess.PIPE,
                          stderr=subprocess.PIPE)


def sha256(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def metadata(path, theme):
    basic = [(0, 'Opening: why we are here'), (63, 'Why learn AI together'),
             (117, 'Make it fun and accessible'), (214, 'Meet Josh and Mary'),
             (290, 'Run Your City and the show'), (349, 'What to expect'),
             (397, 'Curious and skeptical'), (474, 'Fun facts'),
             (516, 'The honeymoon AI experiment'), (617, 'Closing invitation')]
    if theme:
        chapters = [(0, 'Cold open'), (HOOK_DURATION, 'Theme and title')]
        chapters += [(MAIN_OFFSET + s, title) for s, title in basic]
        chapters += [(MAIN_OFFSET + BASE_DURATION, 'Outro')]
        duration = MAIN_OFFSET + BASE_DURATION + OUTRO_DURATION
    else:
        chapters = basic
        duration = BASE_DURATION
    lines = [';FFMETADATA1', 'title=Out of Our Depth | Episode 0: Why we are here',
             'artist=Josh and Mary']
    for i, (start, title) in enumerate(chapters):
        end = chapters[i + 1][0] if i + 1 < len(chapters) else duration
        lines += ['[CHAPTER]', 'TIMEBASE=1/30000', f'START={round(start*30000)}',
                  f'END={round(end*30000)}', f'title={title}']
    path.write_text('\n'.join(lines) + '\n')


def parse_time(value):
    h, m, rest = value.split(':')
    s, ms = rest.split(',')
    return 3600 * int(h) + 60 * int(m) + int(s) + int(ms) / 1000


def format_time(seconds):
    ms = round(seconds * 1000)
    h, ms = divmod(ms, 3600000)
    m, ms = divmod(ms, 60000)
    s, ms = divmod(ms, 1000)
    return f'{h:02}:{m:02}:{s:02},{ms:03}'


def captions():
    source = (EPISODE / 'edit/caption-source-v5.srt').read_text()
    cues = []
    for block in re.split(r'\n\s*\n', source.strip()):
        lines = block.splitlines()
        start, end = lines[1].split(' --> ')
        cues.append((parse_time(start), parse_time(end), '\n'.join(lines[2:])))
    clean = []
    for start, end, body in cues:
        if start >= BASE_DURATION or body == 'Peace.':
            continue
        if body == 'flip.':
            start, end = 657.98, 658.35
        elif body == 'Yeah. Catch you on the':
            end = 657.98
        clean.append((start, min(end, BASE_DURATION), body))
    hook = [
        (0, 1.36, 'I want the tea.'),
        (1.65, 4.81, "What's the beef between Elon and Musk or\nwhoever?"),
        (5.08, 6.85, 'Well, first, last.'),
        (6.85, 9.03, "We're clearly learning."),
    ]
    themed = hook + [(HOOK_DURATION, MAIN_OFFSET, '[Instrumental theme music]')]
    themed += [(s + MAIN_OFFSET, e + MAIN_OFFSET, b) for s, e, b in clean]
    themed += [(MAIN_OFFSET + BASE_DURATION,
                MAIN_OFFSET + BASE_DURATION + OUTRO_DURATION,
                '[Instrumental theme music]')]
    for path, collection in [
        (RELEASE / 'episode-00-clean-v6.srt', clean),
        (RELEASE / 'episode-00-theme-preview-v6.srt', themed),
    ]:
        path.write_text('\n\n'.join(
            f'{i}\n{format_time(s)} --> {format_time(e)}\n{body}'
            for i, (s, e, body) in enumerate(collection, 1)) + '\n')


def cards(work):
    spec = importlib.util.spec_from_file_location(
        'cards', EPISODE / 'edit/theme-cards.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    title = work / 'title.png'
    outro = work / 'outro.png'
    module.title_frame(0).save(title)
    module.outro_frame(0).save(outro)
    return title, outro


def main():
    theme_only = '--theme-only' in sys.argv
    assert RAW.is_file() and sha256(RAW) == RAW_SHA, 'Raw recording missing or changed'
    assert (MUSIC / 'oood-sting-5s.wav').is_file()
    assert (MUSIC / 'oood-outro-11s.wav').is_file()
    clean = RELEASE / 'episode-00-clean-v6.mp4'
    themed = RELEASE / 'episode-00-theme-preview-v6.mp4'
    assert (clean.exists() if theme_only else not clean.exists()), 'Unexpected clean output state'
    assert not themed.exists(), 'Theme output already exists'
    with tempfile.TemporaryDirectory(prefix='oood-e000-v6-') as folder:
        work = Path(folder)
        clean_meta = work / 'clean.ffmeta'
        theme_meta = work / 'theme.ffmeta'
        metadata(clean_meta, False)
        metadata(theme_meta, True)
        title, outro = cards(work)
        if not theme_only:
            center = 'pan=stereo|c0=0.5*c0+0.5*c1|c1=0.5*c0+0.5*c1'
            pass1 = run(['ffmpeg', '-nostdin', '-hide_banner', '-i', str(RAW),
                         '-map', '0:1', '-t', str(BASE_DURATION), '-vn', '-af',
                         f'{center},loudnorm=I=-16:TP=-1.5:LRA=11:print_format=json',
                         '-f', 'null', '-'])
            stats = __import__('json').loads(re.findall(r'\{[^{}]+\}', pass1.stderr)[-1])
            loudnorm = (
                f"loudnorm=I=-16:TP=-1.5:LRA=11:measured_I={stats['input_i']}:"
                f"measured_TP={stats['input_tp']}:measured_LRA={stats['input_lra']}:"
                f"measured_thresh={stats['input_thresh']}:offset={stats['target_offset']}:linear=true"
            )
            af = f'{center},{loudnorm},aresample=48000,apad,atrim=duration={BASE_DURATION},volume=-0.4dB'
            run(['ffmpeg', '-nostdin', '-hide_banner', '-y', '-i', str(RAW),
                 '-i', str(clean_meta), '-filter_complex',
                 f'[0:v]trim=end_frame={BASE_FRAMES},setpts=N/(30*TB)[v]',
                 '-map', '[v]', '-map', '0:1', '-map_metadata', '1', '-map_chapters', '1',
                 '-frames:v', str(BASE_FRAMES), '-r', '30', '-fps_mode', 'cfr',
                 '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '18',
                 '-profile:v', 'high', '-pix_fmt', 'yuv420p',
                 '-color_primaries', 'bt709', '-color_trc', 'bt709', '-colorspace', 'bt709',
                 '-af', af, '-c:a', 'aac', '-b:a', '256k', '-movflags', '+faststart', str(clean)])
        graph = (
            f'[0:v]trim=start_frame={round(HOOK_START*30)}:end_frame={round(HOOK_START*30)+HOOK_FRAMES},'
            'setpts=N/(30*TB),format=yuv420p,setsar=1[hv];'
            f'[0:a]atrim=start={HOOK_START}:duration={HOOK_DURATION},asetpts=PTS-STARTPTS,'
            f'afade=t=in:d=0.02,afade=t=out:st={HOOK_DURATION-0.05}:d=0.05,'
            f'aresample=48000,apad,atrim=duration={HOOK_DURATION}[ha];'
            f'[1:v]trim=end_frame={TITLE_FRAMES},setpts=N/(30*TB),format=yuv420p,setsar=1[tv];'
            f'[3:a]volume=-1.6dB,aresample=48000,apad,atrim=duration={TITLE_DURATION}[ta];'
            '[2:v]setpts=N/(30*TB),format=yuv420p,setsar=1[bv];'
            '[2:a]aresample=48000,apad,atrim=duration=659.4[ba];'
            f'[4:v]trim=end_frame={OUTRO_FRAMES},setpts=N/(30*TB),format=yuv420p,setsar=1[ov];'
            f'[5:a]volume=-3.3dB,aresample=48000,apad,atrim=duration={OUTRO_DURATION},'
            f'afade=t=out:st={OUTRO_DURATION-0.7}:d=0.7[oa];'
            '[hv][ha][tv][ta][bv][ba][ov][oa]concat=n=4:v=1:a=1[v][a]'
        )
        run(['ffmpeg', '-nostdin', '-hide_banner', '-y', '-i', str(clean),
             '-loop', '1', '-framerate', '30', '-i', str(title),
             '-i', str(clean), '-i', str(MUSIC / 'oood-sting-5s.wav'),
             '-loop', '1', '-framerate', '30', '-i', str(outro),
             '-i', str(MUSIC / 'oood-outro-11s.wav'), '-i', str(theme_meta),
             '-filter_complex', graph, '-map', '[v]', '-map', '[a]',
             '-map_metadata', '6', '-map_chapters', '6',
             '-frames:v', str(HOOK_FRAMES + TITLE_FRAMES + BASE_FRAMES + OUTRO_FRAMES),
             '-r', '30', '-fps_mode', 'cfr', '-c:v', 'libx264', '-preset', 'veryfast',
             '-crf', '18', '-profile:v', 'high', '-pix_fmt', 'yuv420p',
             '-color_primaries', 'bt709', '-color_trc', 'bt709', '-colorspace', 'bt709',
             '-c:a', 'aac', '-b:a', '256k', '-movflags', '+faststart', str(themed)])
    captions()
    print(clean)
    print(themed)


if __name__ == '__main__':
    main()
