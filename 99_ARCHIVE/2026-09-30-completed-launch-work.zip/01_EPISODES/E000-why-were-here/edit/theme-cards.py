"""Blue-flood title and thank-you cards for the Episode 0 music test (white type, per Josh 2026-09-28)."""
import sys, subprocess, tempfile, shutil
from pathlib import Path
sys.path.insert(0, '/Users/je/oood/01_EPISODES/E002-make-ai-useful/edit/graphics-v2')
from PIL import Image, ImageDraw
import oood_graphics as G
WHITE = '#FFFFFF'

def title_frame(dy):
    im = Image.new('RGB', (1920, 1080), G.BLUE); d = ImageDraw.Draw(im)
    lab, big, sub = G.font(G.MONO, 32, 500), G.font(G.TEACHERS, 230, 800), G.font(G.TEACHERS, 64, 600)
    G.tracked(d, (150, 300 + dy), 'EPISODE 00', lab, WHITE, 0.18)
    G.tracked(d, (140, 350 + dy), 'OUT OF OUR', big, WHITE, -0.03)
    G.tracked(d, (140, 560 + dy), 'DEPTH', big, WHITE, -0.03)
    d.text((150, 830 + dy), "Why we're here", font=sub, fill=WHITE)
    return im

def outro_frame(dy):
    im = Image.new('RGB', (1920, 1080), G.BLUE); d = ImageDraw.Draw(im)
    lab, big, body = G.font(G.MONO, 30, 500), G.font(G.TEACHERS, 150, 800), G.font(G.TEACHERS, 78, 700)
    G.tracked(d, (150, 250 + dy), 'OUT OF OUR DEPTH', lab, WHITE, 0.18)
    G.tracked(d, (140, 300 + dy), 'THANKS FOR', big, WHITE, -0.03)
    G.tracked(d, (140, 440 + dy), 'WATCHING', big, WHITE, -0.03)
    d.text((150, 720 + dy), 'PLEASE COMMENT OR SHARE', font=body, fill=WHITE)
    return im

def render(fn, seconds, out, fade_out_frames=0):
    tmp = Path(tempfile.mkdtemp()); n = round(seconds * 30)
    for i in range(n):
        dy = int(24 * (1 - G.ease_out(min(1, (i + 1) / 12))))
        fr = fn(dy)
        if fade_out_frames and i >= n - fade_out_frames:
            a = (n - i - 1) / fade_out_frames
            fr = Image.blend(Image.new('RGB', fr.size, 'black'), fr, a)
        fr.save(tmp / f'f{i:04d}.png')
    subprocess.run(['ffmpeg', '-v', 'error', '-y', '-framerate', '30', '-i', str(tmp / 'f%04d.png'), '-c:v', 'libx264',
                    '-crf', '14', '-pix_fmt', 'yuv420p', '-color_primaries', 'bt709', '-color_trc', 'bt709', '-colorspace', 'bt709', str(out)], check=True)
    shutil.rmtree(tmp)
