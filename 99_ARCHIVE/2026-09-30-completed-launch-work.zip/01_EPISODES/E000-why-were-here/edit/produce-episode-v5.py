"""Render Episode 0's full-conversation review cut with sparse source cards.

Temporary graphics and loudness logs live in a temporary directory. Only the
review video and optional MP3 are retained. The source recording is immutable.
"""

import argparse
import hashlib
import json
from pathlib import Path
import re
import subprocess
import tempfile

from PIL import Image, ImageDraw, ImageFont


ROOT = Path(__file__).resolve().parents[3]
EPISODE = Path(__file__).resolve().parents[1]
SOURCE = Path('/Users/je/Movies/Episode 0 Raw.mp4')
SOURCE_SHA256 = '428bd4c2979482c540e585cddec6f4e336783284b9b1e602c5b2a78acedba15b'
FONT = ROOT / '03_ASSETS/brand-fonts/teachers.ttf'
FRAMES = 19872
DURATION = FRAMES / 30
RELEASE = EPISODE / 'release'
BLUE, CREAM, FOAM, NAVY = '#38B6FF', '#FBF1E5', '#FDF8F2', '#0B2A45'


def sha256(path):
    digest = hashlib.sha256()
    with path.open('rb') as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def font(size, weight):
    result = ImageFont.truetype(str(FONT), size)
    result.set_variation_by_axes([weight])
    return result


def draw_card(path, title, body, source):
    """A compact, top-center card; no host face or optional-caption overlap."""
    im = Image.new('RGBA', (1920, 1080), (0, 0, 0, 0))
    draw = ImageDraw.Draw(im)
    x, y, w, h = 560, 22, 800, 212
    draw.rounded_rectangle((x, y, x + w, y + h), radius=14, fill=CREAM)
    draw.rectangle((x + 8, y + 126, x + w - 8, y + h - 8), fill=FOAM)
    draw.rectangle((x, y + 14, x + 11, y + h - 14), fill=BLUE)
    title_size = 56
    while draw.textlength(title.upper(), font=font(title_size, 800)) > w - 72:
        title_size -= 2
        if title_size < 42:
            raise ValueError(f'Title too long: {title}')
    draw.text((x + 35, y + 19), title.upper(), font=font(title_size, 800), fill=NAVY)
    body_size = 37
    while draw.textlength(body, font=font(body_size, 600)) > w - 72:
        body_size -= 2
        if body_size < 29:
            raise ValueError(f'Body too long: {body}')
    draw.text((x + 35, y + 82), body, font=font(body_size, 600), fill=NAVY)
    source_size = 29
    while draw.textlength(source, font=font(source_size, 400)) > w - 72:
        source_size -= 1
        if source_size < 23:
            raise ValueError(f'Source too long: {source}')
    draw.text((x + 35, y + 150), source, font=font(source_size, 400), fill=NAVY)
    im.save(path)


def run(args):
    return subprocess.run(args, check=True, text=True, stdout=subprocess.PIPE,
                          stderr=subprocess.PIPE)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--no-mp3', action='store_true')
    args = parser.parse_args()
    assert SOURCE.is_file() and sha256(SOURCE) == SOURCE_SHA256, 'Inventoried raw recording missing or changed'
    assert FONT.is_file(), 'Teachers font missing'
    RELEASE.mkdir(parents=True, exist_ok=True)
    video = RELEASE / 'episode-00-review-v5.mp4'
    mp3 = RELEASE / 'episode-00-audio-v5.mp3'
    assert not video.exists() and not mp3.exists(), 'V5 exists; version the next revision'

    cards = [
        (44.8, 51.8, 'AI@GSB', 'APPLIED AI INITIATIVE', 'gsb.stanford.edu/experience/learning/applied-ai'),
        (98.3, 104.5, 'WOMEN ~20% LESS LIKELY', 'TO USE GENERATIVE AI', 'Otis et al. (2025) | 18 studies, ~143k people'),
        (296.6, 305.6, 'RUN YOUR CITY', 'INTRODUCING KIDS TO SPORTS', 'runyourcity.org'),
        # Josh confirmed the inbox is live and the site will be live by publication.
        (625.1, 632.5, 'REACH OUT', 'outofourdepth.com', 'hi@outofourdepth.com'),
    ]

    with tempfile.TemporaryDirectory(prefix='oood-e000-v5-') as tmp:
        work = Path(tmp)
        images = []
        for index, (start, end, title, body, source) in enumerate(cards):
            path = work / f'card-{index}.png'
            draw_card(path, title, body, source)
            images.append(path)

        center = 'pan=stereo|c0=0.5*c0+0.5*c1|c1=0.5*c0+0.5*c1'
        pass1 = run(['ffmpeg', '-nostdin', '-hide_banner', '-i', str(SOURCE),
                     '-map', '0:1', '-t', str(DURATION), '-vn', '-af',
                     f'{center},loudnorm=I=-16:TP=-1.5:LRA=11:print_format=json',
                     '-f', 'null', '-'])
        stats = json.loads(re.findall(r'\{[^{}]+\}', pass1.stderr)[-1])
        loudnorm = (
            f"loudnorm=I=-16:TP=-1.5:LRA=11:measured_I={stats['input_i']}:"
            f"measured_TP={stats['input_tp']}:measured_LRA={stats['input_lra']}:"
            f"measured_thresh={stats['input_thresh']}:offset={stats['target_offset']}:"
            'linear=true'
        )
        audio_filter = f'{center},{loudnorm},aresample=48000,apad,atrim=duration={DURATION},volume=-0.4dB'

        chapters = [
            (0, 'Opening: why we are here'), (63, 'Why learn AI together'),
            (117, 'Make it fun and accessible'), (214, 'Meet Josh and Mary'),
            (290, 'Run Your City and the show'), (349, 'What to expect'),
            (397, 'Curious and skeptical'), (474, 'Fun facts'),
            (516, 'The honeymoon AI experiment'), (617, 'Closing invitation'),
        ]
        metadata = [';FFMETADATA1', 'title=Out of Our Depth | Episode 0: Why we are here',
                    'artist=Josh and Mary']
        for i, (start, title) in enumerate(chapters):
            end = chapters[i + 1][0] if i + 1 < len(chapters) else DURATION
            metadata.extend(['[CHAPTER]', 'TIMEBASE=1/30000',
                             f'START={round(start * 30000)}', f'END={round(end * 30000)}',
                             f'title={title}'])
        ffmeta = work / 'chapters.ffmeta'
        ffmeta.write_text('\n'.join(metadata) + '\n')

        filters = [f'[0:v]trim=end_frame={FRAMES},setpts=N/(30*TB)[v0]']
        for index, (start, end, *_rest) in enumerate(cards, 1):
            filters.append(
                f"[v{index-1}][{index}:v]overlay=0:0:"
                f"enable='between(t,{start},{end})':shortest=0[v{index}]"
            )
        filter_graph = ';'.join(filters)
        inputs = ['-i', str(SOURCE)]
        for path in images:
            inputs.extend(['-loop', '1', '-framerate', '30', '-i', str(path)])
        meta_index = len(images) + 1
        inputs.extend(['-i', str(ffmeta)])
        command = ['ffmpeg', '-nostdin', '-hide_banner', '-y', *inputs,
                   '-filter_complex', filter_graph, '-map', f'[v{len(images)}]',
                   '-map', '0:1', '-map_metadata', str(meta_index),
                   '-map_chapters', str(meta_index), '-frames:v', str(FRAMES),
                   '-r', '30', '-fps_mode', 'cfr', '-t', str(DURATION),
                   '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '18',
                   '-profile:v', 'high', '-pix_fmt', 'yuv420p',
                   '-color_primaries', 'bt709', '-color_trc', 'bt709',
                   '-colorspace', 'bt709', '-af', audio_filter,
                   '-c:a', 'aac', '-b:a', '256k', '-movflags', '+faststart', str(video)]
        try:
            run(command)
        except subprocess.CalledProcessError as exc:
            (RELEASE / 'episode-00-v5-error.log').write_text(exc.stderr)
            raise
        if not args.no_mp3:
            run(['ffmpeg', '-nostdin', '-hide_banner', '-y', '-i', str(SOURCE),
                 '-map', '0:1', '-vn', '-af', audio_filter, '-c:a', 'libmp3lame',
                 '-b:a', '192k', '-metadata',
                 'title=Why we are here | Out of Our Depth', str(mp3)])
        (RELEASE / 'popup-cues-v5.json').write_text(json.dumps([
            {'start_seconds': start, 'end_seconds': end,
             'title': title, 'body': body, 'source_or_link': source}
            for start, end, title, body, source in cards
        ], indent=2) + '\n')
        print(f'Rendered {video}; {FRAMES} frames; source SHA256 {SOURCE_SHA256}')


if __name__ == '__main__':
    main()
