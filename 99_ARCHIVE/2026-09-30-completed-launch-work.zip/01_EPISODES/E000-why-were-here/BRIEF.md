# Episode brief: Why we are here

- **Episode ID:** E000
- **Status:** near-complete 11:02.400 v5 technically checked and recommended for host review; Josh prefers this editorial direction, while exact-export, factual, website launch and Mary review remain open.
- **Owner:** Josh and Mary
- **Recording:** supplied 2026-09-26; source creation metadata is also September 26
- **Publication:** unconfirmed; the broader September 27 launch target is not a schedule
- **Content lane:** show introduction / teaser
- **Audience:** curious people who want AI to feel understandable and enjoyable

## One-sentence promise

Meet Josh and Mary, understand why they are learning AI in public, and know what to expect from Out of Our Depth.

## Why now / core question

Introduce the show before the AI basics and practical-tools episodes. Why spend time learning with these two?

## Working thesis

Their shared life and curiosity make the useful AI explanations worth returning for. Let the actual banter establish that promise.

## Audience starting point

No AI background or prior knowledge of the hosts required. The source expands AI to artificial intelligence near the opening.

## Story arc

1. Spontaneous opening, newlyweds and Stanford setup.
2. Names, how they met, and their interests.
3. Mary explains Run Your City and the motivation for opening up their learning.
4. Make AI fun: preserve the Elon/Musk exchange with its setup and correction.
5. Separate useful tools from noise while acknowledging criticism of AI.
6. Bring the relationship to life through caffeine banter and a real honeymoon AI-photo experiment.
7. Explain the proposed news/deep-dive format and invite viewer input.

## Must-support claims

See `02_RESEARCH/episode-00-source-checks-2026-09-26.md`. Personal biography is host testimony; organizational facts have public corroboration. V5 retains the spoken gender-adoption figure and broad jobs/nonprofit-adoption opinions. The supplied image traces to a 2025 working paper finding an approximately one-fifth relative *usage* gap; a 2026 revision estimates a smaller recent-period gap. Neither establishes a precise current or “effective adoption” measure. Confirm the intended meaning or record a spoken correction before publication.

## Host experience

Josh: education interests, shared background, practical usefulness and the honeymoon experiment. Mary: founder perspective, healthcare, accessibility and enjoyment. Both: nickname joke, caffeine contrast, puppies, newlywed setup and real reactions to generated family photos. No invented dialogue or reaction shots. The personal story needs both hosts' approval before publication.

## Visuals and music

Original two-host 1080p camera picture in source order. V5 adds four brief branded cards for AI@GSB, the 2025 gender-use study, Run Your City and the podcast contact details, clear of faces and optional captions. Full links and the later research qualification are in the publishing draft. Josh confirmed the inbox is live and the site will be live by publication; the site needs a launch-day check. Both voices are centered in the stereo mix for headphones. A branded thumbnail and SRT sidecar accompany the video; no music is added.

## Clip candidates

The honeymoon AI-photo story, Elon/Musk exchange and caffeine banter. No separate social clips requested or rendered.

## Definition of ready

- [x] Clear purpose and complete editorial proposal
- [x] Source preserved and edits reversible
- [ ] Confirm the retained 20% line means approximate relative usage, or record a spoken correction; confirm the on-screen address spellings and verify the site is live at upload
- [x] V5 export QC report complete
- [ ] Josh and Mary approve the exact video, sound, captions and public personal details
