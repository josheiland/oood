# Episode 0 - Why we're here

**Current recording plan, 2026-09-26:** Episode 0, then Episode 1, then the Episode 2 reshoot this weekend (September 26–27). Make the interaction itself entertaining: real preferences, playful disagreement, surprise, and callbacks. Use these as conversation prompts, not a lecture script. See [editorial direction](../00_CONTEXT/editorial-direction.md). Publication timing remains unconfirmed.

- **Hook:** Open on a real, surprising or funny recent AI use; react to each other's choices before explaining the show.
- **Who we are + route:** Josh and Mary: a couple running Run Your City together. Today: who we are, why we're doing this, and what viewers will get.
- **Mary's lens:** Founder, CEO, and visual thinker. One specific way AI helped her, plus the judgment or taste she still had to supply.
- **Josh's lens:** Operator, student, and systems experimenter. One useful test and one overbuilt or failed attempt; let Mary challenge the approach.
- **Our shared lens:** A Run Your City moment where your different instincts improved the outcome. Make clear the show also covers everyday life, school, and work beyond nonprofits.
- **Why this show:** You're learning in public: test tools, explain jargon, show misses, separate experience and opinion from checked facts, and keep the human choices visible.
- **Close:** Promise a clear idea viewers can use each episode. Tease AI basics, then making the tools useful; invite one thing viewers want you to test.

**Before rolling:** Match light, framing, seats, and both mics; check sync.

# Episode 1 - AI basics without the jargon

- **Hook + route:** "OpenAI, GPT, ChatGPT - aren't those the same thing?" Use your real confusion or disagreement. Promise three answers: what these tools do, what the names mean, and how to start.
- **What AI means here:** Focus on generative tools that create or transform material. Show one ordinary task from Mary's real notes: useful first draft, then a mistake she catches.
- **The three layers:** Company builds or serves it; model produces the response; app is where you use it. Show OpenAI/GPT/ChatGPT, Anthropic/Claude/Claude, Google/Gemini/Gemini; explain overlapping names.
- **Teach-back:** Mary sorts one unfamiliar name into those layers in her own words; Josh clarifies only what matters. Make the distinction stick, not feel like a quiz.
- **Which app to try:** Put the same real, low-stakes task into two apps. Disagree about which output helps more and why; avoid declaring a permanent winner.
- **Reality check:** Polished answers can be wrong; check consequential claims. An app does not automatically know your files or preferences - the bridge to Episode 2.
- **Close:** Recap company/model/app. Ask viewers to identify the app they already use and try one real task; tease giving it better context, access, and instructions.

**Before rolling:** Match light, framing, seats, and both mics; check sync. Hide private information in screen recordings.

# Episode 2 - Make AI useful: context, connectors, skills

**2026-09-25 update:** Josh has requested another reshoot. The [new recording cue sheet](E002-make-ai-useful/reshoot-recording-cue-sheet-2026-09-25.md) is the current local preparation draft; the [full feedback plan](E002-make-ai-useful/reshoot-feedback-and-plan-2026-09-25.md) explains the recommended changes. The bullets below preserve the earlier primer. The linked Google Doc has not been updated in this planning pass.

- **Hook + route:** Compare a generic answer with one given useful background; let Mary judge. Promise three upgrades: Project = background, connector = access, skill = reusable directions. Introduce Run Your City as one example.
- **Project / context:** Define an ongoing workspace. Mary chooses the few Run Your City details an assistant actually needs - mission, audience, voice - then give a home or school parallel. Flag stale context.
- **Bridge to connector:** It has background, but the needed answer lives in a recent file or email. Say that problem aloud before naming the tool.
- **Connector / access:** Define a controlled link to another service. Demo one safe, specific lookup; show what access was granted and verify the answer against its source.
- **Bridge to skill:** It can find information, but you're still repeating the same directions. Say that problem aloud before naming the tool.
- **Skill / instructions:** Define a saved instruction for a repeat task. If Mary wants to share, she explains her dyslexia-related reading preferences first; then Josh names Dyslexify. Mary shows her Run Your City brand skill and the judgment behind it.
- **Demystify "bot":** Show the saved prompt or instructions underneath any named bot, what information it can reach, and what still requires a person.
- **Honest failure:** Revisit the stale or irrelevant grant-search result and how you caught it. Let the hosts differ on when AI helps versus when a personal message should stay personal.
- **Close:** Quick recall of background / access / reusable directions, then a short last-five-chats exchange for a human laugh. Viewer action: start one small Project with only essential context.

**Before rolling:** Match light, framing, seats, and both mics; check sync. Capture safe screen demos without private data.
