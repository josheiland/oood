# OOOD launch episode Drive archive

Archived 2026-09-30 at Josh's request. All three episodes are published on YouTube and Spotify per Josh. Exact public platform transcoded bytes were not compared to the local export.

[Final release archive](https://drive.google.com/drive/folders/1IR0qHIE4TglkJuy1qlH1bCcBEaH662Rj) · [Original raw recordings](https://drive.google.com/drive/folders/1KrXgS2Ms6MSz6KXF5YWz1M3fZ_6_fshm)

Each episode contains one final video, matching SRT, the current 1280 × 720 YouTube thumbnail, the saved description/chapters, and a manifest. The descriptions are the latest saved copy; exact current platform descriptions were not fetched. Existing caption auditory proof status is unchanged.

| Episode | Drive folder | Video MD5 | Bytes |
| --- | --- | --- | --- |
| 000 | [Release files](https://drive.google.com/drive/folders/1BtzCXPB2v8w1y7SWS3PoUIzOsoKfaAqy) | `c8f4a8c0aff7051fc72937340f315bcb` | 188620712 |
| 001 | [Release files](https://drive.google.com/drive/folders/1VKme1NR8TNqgaR5JnTBqswkwIV6lgXCX) | `47da42e2bedd218cd93146f167ac6ad0` | 1016926540 |
| 002 | [Release files](https://drive.google.com/drive/folders/1OdHgDxylP4Rs_zQ7_U8PHSlKTZZbnRBt) | `9367cee16904ed0845417c84ee018711` | 706010130 |

The final videos are: E000 recurring-card v11 (11:20.867); E001 final v2 with lossless BT.709 metadata repair (52:25.733); E002 ep2hook v3 with lossless BT.709 metadata repair (33:14.267). Josh stopped the separate continuous-encode job because no new render was needed.

The compact production-records ZIP preserves 455 lightweight context, research, edit, QC, caption, and rebuild records. It is a point-in-time backup taken before local media removal. Shared brand templates, small user-selected hooks, and lightweight working records remain in the repository.

Every uploaded asset was read back from Drive and checked for its destination parent, byte size, and MD5 checksum before local final videos were removed. All three original raw recordings already existed in Drive; their local duplicates were removed only after MD5 comparison.

Older documents may retain historical local media links. Use this archive and the checksum receipts as the current location. `cleanup-plan.md`, `cleanup-executed.json`, `cleanup-intermediates.json`, and `raw-local-cleanup.json` record local removals. Josh explicitly approved the 15 listed superseded jtan media files after confirming they were outdated. Their actual runtimes and edit records establish that they are earlier comparison cuts, matching audio masters and unused hook testers, replaced by the September 30 selected-hook releases. Final videos and raw originals were rechecked in Drive before removal. `jtan-authorized-cleanup.json` records the additional 5,993,927,160 bytes (5.582 GiB) removed. Total local media reclaimed by this chat: 24,646,325,055 bytes (22.954 GiB). All lightweight jtan records and rebuild scripts remain preserved.
