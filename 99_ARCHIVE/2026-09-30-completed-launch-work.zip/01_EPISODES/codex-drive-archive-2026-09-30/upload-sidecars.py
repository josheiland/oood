import concurrent.futures
import hashlib
import json
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parent
MANIFEST = json.loads((ROOT / 'archive-manifest.json').read_text())

def call(slug, data, file=None):
    cmd = ['composio', 'execute', slug, '-d', json.dumps(data)]
    if file:
        cmd += ['--file', str(file)]
    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode:
        raise RuntimeError(result.stderr[-1000:])
    parsed = json.loads(result.stdout)
    if not parsed.get('successful'):
        raise RuntimeError(str(parsed.get('error')))
    return parsed['data']

def upload(job):
    asset, folder = job
    path = Path(asset['local_path'])
    checkpoint = ROOT / ('uploaded-' + folder + '-' + asset['name'] + '.json')
    if checkpoint.exists():
        return
    existing = call('GOOGLEDRIVE_FIND_FILE', {
        'folder_id': folder, 'q': "trashed = false and name = '" + asset['name'] + "'",
        'fields': 'files(id,name,size,md5Checksum,parents,webViewLink)',
    })['files']
    if existing:
        if len(existing) != 1:
            raise RuntimeError('Ambiguous existing file: ' + asset['name'])
        metadata = existing[0]
    else:
        result = call('GOOGLEDRIVE_RESUMABLE_UPLOAD', {
            'metadata': {'name': asset['name']}, 'folder_to_upload_to': folder,
        }, path)
        file_id = result.get('file', {}).get('id') or result.get('id')
        if not file_id:
            raise RuntimeError('Upload outcome uncertain: inspect folder before retry')
        metadata = call('GOOGLEDRIVE_GET_FILE_METADATA', {
            'fileId': file_id, 'fields': 'id,name,size,md5Checksum,parents,webViewLink,trashed',
        })
    with path.open('rb') as f:
        md5 = hashlib.file_digest(f, 'md5').hexdigest()
    assert metadata.get('md5Checksum') == md5, asset['name']
    assert int(metadata['size']) == path.stat().st_size, asset['name']
    assert folder in metadata['parents'] and not metadata.get('trashed'), asset['name']
    checkpoint.write_text(json.dumps(metadata, indent=2) + '\n')
    print('Uploaded and verified:', asset['name'], flush=True)

jobs = [(a, ep['folder_id']) for ep in MANIFEST['episodes'] for a in ep['assets'] if not a['name'].endswith('.mp4')]
zip_path = ROOT / 'production-records-2026-09-30.zip'
jobs.append(({'name': zip_path.name, 'local_path': str(zip_path)}, MANIFEST['final_folder_id']))
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
    for result in pool.map(upload, jobs):
        pass
