# Episode 1: AI basics source checks

Accessed 2026-09-26. Applies only to the new `/Users/je/Movies/Episode 1 Raw.mp4`, not the historical September 21 claim register. Edit choices are proposals. Host experience is self-reported; vendor documentation establishes product behavior, not independent comparative quality.

## Primary sources

| ID | Source / publisher | Publication date | Exact claim supported and limits |
|---|---|---|---|
| S01 | [All models](https://developers.openai.com/api/docs/models/all), OpenAI | Undated live documentation; accessed 2026-09-26 | GPT-6 Astra, Sol, and Luna are OpenAI model names. A model name is distinct from the ChatGPT product. Does not establish a universal quality ranking. |
| S02 | [Quickstart](https://learn.chatgpt.com/docs/quickstart), OpenAI | Undated live documentation; accessed 2026-09-26 | ChatGPT offers Chat and Work; Codex is available for software work with codebase context and developer tools. Supports the broad chat/work/code distinction, not identical capabilities or permissions across providers. |
| S03 | [What interfaces can I use to access Claude?](https://support.claude.com/en/articles/8114487-what-interfaces-can-i-use-to-access-claude), Anthropic | Undated live help documentation; accessed 2026-09-26 | Claude has web, desktop, mobile and developer interfaces. The current help structure documents Cowork and Claude Code. Does not mean selecting a mode retrains weights. |
| S04 | [Claude Fable](https://www.anthropic.com/claude/fable), Anthropic | Live page; Fable 5.1 announcement dated 2026-09-01; accessed 2026-09-26 | Fable is an Anthropic model. Vendor capability claims are not independent benchmarks. |
| S05 | [Claude Opus](https://www.anthropic.com/claude/opus), Anthropic | Live page; accessed 2026-09-26 | Opus is an Anthropic model. Mary's preference for its writing style is personal experience, not an objective ranking. |
| S06 | [Gemini](https://deepmind.google/models/gemini/), Google DeepMind | Undated live model page; accessed 2026-09-26 | Gemini is Google's model family. Does not support the recording's claim that Gemini is a distant third in usage or quality. |
| S07 | [gpt-oss](https://developers.openai.com/cookbook/topic/gpt-oss), OpenAI | Undated live topic page; accessed 2026-09-26 | OpenAI offers open-weight models that can run locally or be fine-tuned. Therefore, describing all OpenAI models as closed is incorrect. |
| S08 | [Tracing the thoughts of a large language model](https://www.anthropic.com/news/tracing-thoughts-language-model), Anthropic | 2025-03-27; accessed 2026-09-26 | Language-model training involves next-token prediction; models can hallucinate. Interpretability work describes more complex internal processing than a literal lookup database. Does not establish every modern model's complete training recipe. |
| S09 | [Scaling Managed Agents: Decoupling the brain from the hands](https://www.anthropic.com/engineering/managed-agents), Anthropic | 2026-04-08; accessed 2026-09-26 | A harness includes the loop calling the model and routing tool calls; it is more than the visible user interface. The car analogy is an introductory analogy, not a precise architectural definition. |

## Initial focused-v2 editorial findings

These treatment notes describe the first short proposal. The fuller-v3 addendum below supersedes the omit recommendations for selected work, learning, hardware, open-weight, cloud and safety passages. The underlying factual cautions still apply.

| Raw source | Finding | Proposed treatment |
|---|---|---|
| 01:15-01:32 | Initial provider explanation self-corrects from ChatGPT to the actual companies. | Use the corrected complete company statement. |
| 01:32-02:22; 05:11-06:18 | Grok provider shorthand, blanket benchmark/usage rankings, and all-models-closed claim. | Omit from the beginner cut. Rankings need a named measure and dated comparison; no corrective overlay alone. |
| 02:54-03:52; 13:38-14:34 | Host preferences and confusing names. | Preserve as personal taste, including the spoken correction identifying OpenAI's model names. Do not promote the preferences as a comparative test. |
| 06:24-07:50 | Weights are described as weighting good/bad data; changing app mode is described as changing parameters. | Omit the inaccurate explanation. Do not fix only in captions or graphics. |
| 07:52-09:53 | Introductory model training and multimodal explanation. | Retain a concise supported portion; avoid claiming every model supports every input and output modality. |
| 10:00-11:29 | Mary's car analogy; Josh restates maker/car/engine. | Preserve the metaphor and the clear restatement. The harness/interface wording is imprecise; use the restatement without that sentence if a clean edit permits. |
| 11:30-13:38; 32:23-36:04 | Open weights, open source, specialization, revenue and ranking claims. | Omit from this cut. In particular, the open-source-without-open-weights explanation is misleading. Harvey/OpenEvidence examples do not establish their actual architecture or superiority. |
| 14:34-15:43 | Tokens and usage/cost are conflated. | Omit the blanket rule that a stronger model necessarily uses more tokens. A token is a chunk of data; plan usage limits and pricing are separate. |
| 15:43-20:01; 23:45-27:49 | Jobs, mathematicians, healthcare and future predictions. | Omit from this basics episode. These deserve a separate sourced discussion, preserving disagreement and uncertainty if reused. |
| 20:40-21:22; 22:24-23:44 | Learning by asking the tool; coding-class story. | Preserve as self-reported examples. Mary must approve the personal grade/dyslexia anecdote in the exact review cut. It is not a clinical claim or evidence of general coding reliability. |
| 28:30-31:44 | Hardware valuation, loose GPU explanations, bypassing permissions. | Omit. Permission bypassing is not part of the viewer action. |
| 36:05-38:07 | On-prem/cloud, hospital security, moon data centers. | Omit from the basics cut; the latter claims need specific evidence and do not teach company/model/app. |
| 38:07 onward | Founder reputations, motivations, lawsuits, family counts, and safety anecdotes. | Do not treat the conversation as independent sourcing. Omit the broad company-history tangent from this episode. |

Final retained-claim mapping and any pickup recommendations are recorded with the final edit/QC notes. No fact check establishes private workflow results, host approval or publication.

## Fuller v3 review-cut addendum, 2026-09-26

The fuller cut adds the following topics. These sources support **limited technical definitions**, not the hosts' career forecasts, comparative rankings or private experiences. Accessed 2026-09-26.

| ID | Source / publisher | Publication date | Exact claim supported and limits |
|---|---|---|---|
| S10 | [gpt-oss open-weight recipes](https://developers.openai.com/cookbook/topic/gpt-oss), OpenAI | Undated live documentation; accessed 2026-09-26 | Open-weight models can be run locally or fine-tuned. Confirms OpenAI itself offers open-weight models, so the source's all-vendor closed claim must stay cut. Does not mean any laptop can run every model well. |
| S11 | [CUDA programming guide, GPU origins](https://docs.nvidia.com/cuda/cuda-programming-guide/01-introduction/introduction.html), NVIDIA | Undated live documentation; accessed 2026-09-26 | GPUs began as graphics processors for real-time 3D rendering and excel at parallel operations. Supports the basic gaming-to-AI explanation, not a company valuation or a claim that a GPU is separate from a chip. |
| S12 | [Why GPUs are great for AI](https://blogs.nvidia.com/blog/why-gpus-are-great-for-ai/), NVIDIA | 2023-12-04; accessed 2026-09-26 | GPU parallel processing supports training and inference. Vendor source; no inference about the economic prospects of one chip company follows. |
| S13 | [What is cloud computing?](https://cloud.google.com/learn/what-is-cloud-computing), Google Cloud | Undated live documentation; accessed 2026-09-26 | Cloud offers computing resources over the internet; on-prem resources are hosted by the organization. Security depends on implementation and cannot be reduced to “hospital equals on-prem.” |
| S14 | [Agentic misalignment](https://www.anthropic.com/research/agentic-misalignment), Anthropic | 2025-06-20; accessed 2026-09-26 | Reports harmful behavior in engineered *simulations* with tool access. It does not support saying current models have escaped real containment or hacked companies. The v3 paperclip passage is an explicitly hypothetical thought experiment, not a real incident. |

**V3 host speech to review carefully:** the mathematician/job discussion is opinion and speculation, not an employment forecast. Mary's views on unequal access, AI, communication and privacy are personal judgments. The GPU and cloud section uses broad beginner language; check exact cut continuity. The battery exchange and imprecise chip-versus-GPU sentence remain out of the revised v3. The safety passage should not be packaged as evidence of a real-world model escape. Source-assisted captions and end-to-end listening are required to verify that omitted false claims have not survived a boundary.
