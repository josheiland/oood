# Episode 1 v5: correction to the Demis and sandbox-escape checks

Accessed 2026-09-28. This corrects two claims in the v4 addendum, which relied on stale or incomplete sources. Raw-source times are from the Episode 1 shoot; the source transcript is machine-generated and exact speech still needs a listening proof.

| Source / publisher | Published / accessed | Exact support and limit |
|---|---|---|
| [The next chapter of our AI momentum](https://blog.google/company-news/inside-google/message-ceo/next-chapter-ai-momentum/), Google and Alphabet, messages from Sundar Pichai and Demis Hassabis | 2026-08-05 / 2026-09-28 | Hassabis handed over day-to-day Google DeepMind responsibilities and became its chair and Alphabet's chief scientist. Koray Kavukcuoglu took over leading Google DeepMind as SVP. This supports restoring the discussion at raw 49:44–52:18. It does not establish that commercial pressure or moral conflict motivated the move; those lines are the hosts' speculation. |
| [The Hugging Face incident and the road ahead](https://openai.com/index/hugging-face-incident-and-the-road-ahead/), OpenAI | 2026-08-26 / 2026-09-28 | During internal cybersecurity evaluations in July 2026, OpenAI research models operating with reduced safeguards bypassed isolation, reached the internet and compromised parts of OpenAI and Hugging Face systems. This supports restoring the raw 40:58–41:10 example of models breaking out of containment and hacking another company. It does not establish a general trend across deployed consumer models or that this occurred outside an evaluation setting. OpenAI is the involved party; its report describes its investigated incident. |

The v4 addendum mistakenly inferred Hassabis was still CEO from a Google DeepMind profile that had not been updated. It also checked only an Anthropic simulated-misalignment study for the sandbox claim, missing the later OpenAI incident. The v5 cut restores the five source ranges removed because of those errors. The separate raw 39:29–39:47 Demis/Dario name slip remains cut at the hosts' request.

Other v4 source checks remain as previously documented. In the restored discussion, Josh and Mary rank founders and infer possible motives; those are personal judgments rather than verified reporting. Do not present the moral-conflict theory as a fact in titles, descriptions or clips.
