# Research note: Episode 002 reshoot, disputed product lines

- **Date started:** 2026-09-29
- **Researcher:** Codex
- **Related episode(s):** E002 September 26 reshoot
- **Status:** primary sources checked 2026-09-29; recheck before publication

## Question

Which spoken product assertions in the current raw are wrong or misleading enough to change the audio?

## Bottom line

Granola's free Basic plan does not have a 20–25 meeting monthly limit. Humanizer is not named among Anthropic's built-in skills. Claude uses five-hour sessions, and Josh's current Codex account has a five-hour primary window. ChatGPT limits also vary by plan and model, including daily and weekly allowances, so the raw five-hour remark should be understood as conversational shorthand, not a universal product rule. Josh explicitly directed on 2026-09-29 that the line remain in Episode 002. A simple Claude skill can consist of Markdown instructions, though skills may contain scripts and resources. Granola's iPhone call capture requires an outbound call through its own dialer; the raw line is directionally correct but incomplete.

## Claim log

| ID | Spoken claim / proposed correction | Source and exact support | Published | Accessed | Evidence quality | Limitations |
|---|---|---|---|---|---|---|
| C01 | Raw 06:34: free Granola gives 20–25 meetings per month. Correct: Basic has unlimited meetings with 30-day history. | [Granola pricing](https://www.granola.ai/pricing) lists Basic 30-day history; [Granola pricing explainer](https://www.granola.ai/blog/granola-pricing-startups-free-trial-discounts) explicitly says no meeting limit, unlimited meetings per month. Publisher: Granola. | Pricing page undated; explainer March 20, year not displayed | 2026-09-29 | Primary vendor product/source | Product terms can change. |
| C02 | Raw 15:46: Humanizer is built into Claude. Correct: Humanizer is not one of Anthropic's built-in skills; Mary may have installed a custom/community skill. | [Use skills in Claude](https://support.claude.com/en/articles/12512180-use-skills-in-claude) lists Anthropic's built-in Excel, Word, PowerPoint and PDF skills and separates user-uploaded skills. [Agent Skills overview](https://platform.claude.com/docs/en/agents-and-tools/agent-skills/overview) calls its document list the complete pre-built list. Publisher: Anthropic. | Help page updated this week, exact date not shown; platform page undated | 2026-09-29 | Primary vendor documentation | Separately confirm which Humanizer Mary installed if naming its origin in public copy. |
| C03 | Raw 09:29–09:46: a skill is “just a document with text.” Better: simple skills can be Markdown instructions; some also include scripts/resources. | [What are skills?](https://support.claude.com/en/articles/12512176-what-are-skills) defines folders of instructions, scripts and resources and says simple skills need no code. Publisher: Anthropic. | Updated “over a week ago”; exact date not shown | 2026-09-29 | Primary vendor documentation | The raw is a simplification rather than a fabricated capability; decide whether a pickup is worth its cost. |
| C04 | Raw 17:39–17:47: Chat, Claude and most tools give usage within each five-hour window. Keep in the edit per Josh's 2026-09-29 direction; treat it as a rough account-specific example rather than a universal rule. | [Claude limit resets](https://support.claude.com/en/articles/17007452-what-is-a-limit-reset) mentions five-hour session and weekly limits. Publisher: Anthropic. [GPT-5.6 and GPT-6 Pro in ChatGPT](https://help.openai.com/en/articles/20001354-gpt-56-and-gpt-6-pro-in-chatgpt) says ChatGPT usage depends on plan and model and describes unlimited everyday text chats for Free/Go and daily/weekly Pro-model allowances. Publisher: OpenAI. A live Codex account usage read on 2026-09-29 showed a 300-minute primary window for Josh's account; this is private account evidence, not a claim about every ChatGPT product. | Anthropic updated “over a week ago”; OpenAI updated 2026-09-29 (relative label) | 2026-09-29 | Primary vendor documentation plus account-specific display | “Most folks” and “most tools” were not independently established; limits change. This nuance does not override Josh's edit direction. |
| C05 | Raw 07:07–07:21: Granola captures phone calls if you make the call. Qualify: outbound iPhone calls placed via Granola's built-in dialer. | [How to take meeting notes on a phone while walking](https://www.granola.ai/blog/how-to-take-meeting-notes-on-a-phone-while-walking-without-typing) specifies the built-in iPhone dialer and excludes audio from separate apps on the same phone. Publisher: Granola. | June 12, year not displayed | 2026-09-29 | Primary vendor blog/how-to | The spoken sentence has the crucial outbound restriction, so omission of dialer may not require an audio edit. |

## Editorial implications

Correct C01 and C02 in audio. Keep C04 under Josh's direct editorial direction; avoid repeating it as a precise universal claim in show notes or other public copy. C03 and C05 can be clarified without removing their segments. The named shop remark and withdrawn Canvas story are editorial/host-boundary issues, not product-source claims.
