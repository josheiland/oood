---
tags: [oood, episode-02, research, claims]
---

# Episode 2 v2 — claim register for the 2026-09-26 reshoot cut

Checked 2026-09-26 against `01_EPISODES/E002-make-ai-useful/edit/episode-02-final-cut-v2.mp4`. Export times refer to that file. Product documentation carried over from `episode-02-source-checks-2026-09-25.md` is cited there with full access details; this register records how each claim in the new recording is handled. Host anecdotes are the hosts' accounts, not independently verified.

| Export time | Claim as spoken | Evidence | Treatment in v2 |
|---|---|---|---|
| 02:30–03:25 | A project holds background instructions and files; point it at your website for numbers that change | Anthropic, "How can I create and manage projects?" (support.claude.com/en/articles/9519177); OpenAI Projects docs (learn.chatgpt.com/docs/projects) | Kept. Pointing at a website only works when the AI can browse or reach the source, so a "Heads up" note appears on "go to our website" (03:21). |
| 04:15–04:20 | Drive-linked project files "pull updates occasionally" | Prior check: refresh behavior depends on app and connection | Kept; Josh's own hedge ("occasionally", "for the most part") carries it. No overlay. |
| 05:22–06:40 | Connectors give access to Calendar, Slack, Gmail, Granola | Anthropic, "Use connectors to extend Claude's capabilities" (support.claude.com/en/articles/11176164) | Kept. |
| 05:50 | Granola "records meetings" | Granola, "Is it safe to connect your meeting notes to AI?" (granola.ai/blog/is-it-safe-connect-meeting-notes-ai): transcribes in real time, does not keep meeting audio | Note overlay: "Granola says it does not keep the audio." |
| (cut) | Granola free tier "20 or 25 meetings", student year-long trial; recording phone calls you place | No plan-specific source; phone-call feature not verified | Removed. |
| 05:56 | Get consent before recording; a legal requirement in some states | General practice, not legal advice | Kept as spoken. |
| 06:56–07:05 | ChatGPT now allows multiple Gmail accounts; Claude still one Gmail and one Slack ("the latest that I checked") | 9to5Mac, 2026-08-28, "ChatGPT and Codex now support multiple Gmail and Google Calendar accounts" (9to5mac.com/2026/08/28/chatgpt-and-codex-now-support-multiple-gmail-and-google-calendar-accounts/); Claude Training, "Can you connect two Gmail accounts to Claude?" (claudetraining.com/claude-multiple-gmail-accounts). Both secondary; accessed 2026-09-26 | Kept. Consistent with current reporting. Recheck on publish day; this changes fast. |
| 07:07–07:35 | Composio links many accounts to Claude; "totally free, I don't pay anything" | Josh's own account and usage | Kept as personal experience. Note overlay describes what Composio is, without pricing. |
| 08:39–10:00 | A skill is "just a document with text"; trigger with a slash or by name | Anthropic, "Use skills in Claude" (support.claude.com/en/articles/12512180): skills are folders of instructions and can include code/resources | Kept as a teaching simplification. "Using a skill" note at 10:01. |
| 10:40 | Record a skill by letting Claude watch your screen | Anthropic, "How to create custom skills" (support.claude.com/en/articles/12512198): Record a skill in Cowork on Mac | Note overlay names the feature and says to review and test. Josh's Mercury result is his account. |
| 12:24 | Claude Design | Anthropic, "Set up your design system in Claude Design" (support.claude.com/en/articles/14604397) | Kept. |
| 12:52–13:30 | Wispr Flow learns your words via its dictionary | Wispr docs, "Teach Flow your words with the dictionary" | Kept; note overlay. |
| **16:09–16:22** | **Mary: humanizer is "I think built into Claude"; "Claude comes with tons of skills… product management"** | **Anthropic's pre-built skills cover document work (Word, Excel, PowerPoint, PDF). Humanizer is a community skill users install; it is not built in** | **Flagged, not fixed in v2. Mary hedges ("I think"), but it's inaccurate. Recommended v3 fix: cut from "that I think is built into Claude" through "I don't know all of them that they come with" (about 10 s). An overlay can't reverse a spoken claim.** |
| 18:03 | Usage resets in five-hour windows "for Chat and for Claude and most of these tools" | Claude documents five-hour session limits; ChatGPT limits vary by plan and model | Low risk; kept. Tighten in v3 only if the hosts want. |
| 24:25 | RYC went from about 75 chapters to "well over a hundred" | Project brief: 75 in spring 2026, about 105 in fall 2026 | Kept. |
| various | Personal names: Lewis (Mary's brother), RYC's Olivia, Tyler, Chloe | Host testimony | Hosts to confirm they're comfortable naming them publicly. |
| (cut) | Mary had Claude log into Canvas, draft and submit a class assignment | Mary said on tape she would probably not use the story | Removed entirely, including her "I don't think I can use that example." |
| (cut) | A local Charlottesville business's website was "clearly made by AI" | Opinion about a named third party | Removed. |
