# Research note: product-name examples for the launch primers

- **Date started:** 2026-09-23
- **Researcher:** Codex
- **Related episode(s):** Proposed Episode 1 (AI basics); proposed Episode 2 (make AI useful)
- **Status:** Working source check; repeat before recording and publication

## Question

Which familiar names can illustrate the difference between an AI company, a model family, and an app without relying on changeable version numbers or feature claims?

## Bottom line

The primers use OpenAI/GPT/ChatGPT, Anthropic/Claude/Claude, and Google/Gemini/Gemini as examples. Official product pages support these names. Because Claude and Gemini can name both a model family and a user-facing product, the hosts should explain that overlap aloud. The primers do not make specific version, pricing, availability, or performance claims.

## Claim log

| ID | Claim in our words | Source | Published | Accessed | Evidence quality | Limitations |
|---|---|---|---|---|---|---|
| C01 | OpenAI lists GPT models as part of its model catalog; ChatGPT is its user-facing app. | [OpenAI model catalog](https://developers.openai.com/api/docs/models/all); [ChatGPT](https://chatgpt.com/) | Dates not specified on cited pages | 2026-09-23 | Official product sources | Model offerings and app labels may change. |
| C02 | Anthropic uses Claude as a model/product name. | [Claude API](https://www.anthropic.com/claude/api); [Claude](https://claude.ai/) | Dates not specified on cited pages | 2026-09-23 | Official product sources | The same name spans a model family and an app. |
| C03 | Google uses Gemini as a model/product name. | [Google AI Studio](https://ai.google.dev/aistudio); [Gemini](https://gemini.google.com/) | Dates not specified on cited pages | 2026-09-23 | Official product sources | The same name spans models and an app; available models can change. |

## Definitions and comparability

“Company,” “model family,” and “app” are teaching categories, not a claim that each product has a one-to-one architecture. An app may offer multiple models, and capabilities vary by account, region, and date. This note does not compare quality or safety.

## Counterevidence and uncertainty

Product naming is fluid. A three-column graphic is useful for orientation but is not a complete product map.

## Script-ready language

“OpenAI makes GPT models and the ChatGPT app. Anthropic uses Claude for both its models and its app. Google uses Gemini for both. When you hear a name, ask whether the speaker means the company, the model doing the work, or the app they opened.” Recheck the labels and any on-screen interfaces before release.
