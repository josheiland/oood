# Episode 2 — additional-reshoot source addendum

- **Date:** 2026-09-25
- **Related episode:** E002
- **Purpose:** Support the planning document's core terminology and distinguish new editorial recommendations from established product facts.
- **Status:** Documentation checked; actual demonstration app, plan, account permissions, and result have not been tested in this planning task.

## Fresh source checks

| Claim supported | Source / publisher | URL | Publication / update date | Accessed | Limits |
|---|---|---|---|---|---|
| A ChatGPT project organizes related chats and provides shared instructions, uploaded files, and connected sources | Projects and chats — OpenAI, ChatGPT Learn | https://learn.chatgpt.com/docs/projects | No absolute date displayed in retrieved body | 2026-09-25 | Does not establish identical behavior across products, exhaustive recall of every chat, or automatic freshness of every source |
| Claude connectors provide access and actions subject to the connected service's permissions; documented organization controls can restrict reading versus writing | Use connectors to extend Claude's capabilities — Anthropic | https://support.claude.com/en/articles/11176164-use-connectors-to-extend-claude-s-capabilities | 2026-08-20, displayed on page | 2026-09-25 | The documented organization restrictions are scoped to Team/Enterprise owners. Do not promise the same settings in every account/app. Inspect the actual demo configuration |
| Custom Claude skills can be added and enabled; explicit requests can help invocation; testing across prompts is recommended; skills may include resources or code | Use skills in Claude — Anthropic | https://support.claude.com/en/articles/12512180-use-skills-in-claude | Absolute date not captured in retrieved excerpt | 2026-09-25 | Product documentation, not proof of reliable results or of the hosts' workflows; plan and surface details vary |

These are primary vendor sources for documented features, not independent evidence of productivity, output quality, or reliability. This addendum deliberately makes no new pricing, quantified performance, health, legal, or financial-outcome claim.

## Direct project evidence

| Source | Date / access | Supports | Limits |
|---|---|---|---|
| [OOOD planning meeting](https://notes.granola.ai/d/b62feebf-fa25-4fb4-af2e-00a4df3bad47), private watchback notes and AI summary | Meeting 2026-09-23; retrieved 2026-09-25 | Direct notes request clearer routes/transitions, Mary explaining, initial references established, less dryness, RYC context, and continuity between takes | Private notes are stronger evidence of explicit feedback than the AI summary; neither establishes current recording/publication status |
| [Episode 2 reference transcript](../01_EPISODES/E002-make-ai-useful/edit/episode-02-reference-transcript-v1.md) | September 25 cut; read 2026-09-25 | Existing spoken content and approximate export locations for feedback | Not publication-ready captions; uncertain overlaps and speaker attribution; MP4 remains authoritative |
| [Episode 2 technical checks](../01_EPISODES/E002-make-ai-useful/edit/episode-02-quality-check-v1.md) and [edit notes](../01_EPISODES/E002-make-ai-useful/edit/episode-02-edit-notes-v1.md) | Read 2026-09-25 | Previously measured export state, documented raw blackouts and duplicate mixes | Not a new audiovisual inspection or diagnosis of the blackout cause |
| Josh's current direct instruction to reshoot once more | 2026-09-25 | Another reshoot is the current production direction | Does not approve this plan's example, runtime, permanent format, or release date |

## Carried-forward evidence

- [Existing Episode 2 product source checks](episode-02-source-checks-2026-09-25.md) cover Granola, Wispr, project-field differences, recorded skill creation, and design. This planning pass does not independently retest those workflows. Reconfirm any retained exact claim in the chosen app before recording.
- [Video/audio research](podcast-video-audio-and-demos-2026-09-25.md) documents mixed viewing/listening behavior and evidence limitations. No fresh audience study is asserted here. The suggested 21-minute structure and short inserts are editorial proposals, not findings established by those studies.
- [Earlier outline](../01_EPISODES/001-make-your-ai-useful/edit/episode-01-outline-v1.md) supplies the location of the prior failure segment. Reconfirm the host account before re-recording it; don't portray it as a new observed test.
