---
tags: [oood, episode-02, research, claims]
---

# Episode 2 v3 — source addendum

Accessed 2026-09-27. Applies to the proposed v3 cut from the September 26 reshoot. The v2 register remains the base claim log; these are the claims revisited for this correction. Host stories remain their own accounts.

| Source | Publisher / date | Exact claim supported | Edit treatment |
|---|---|---|---|
| [Use skills in Claude](https://support.claude.com/en/articles/12512180-use-skills-in-claude) | Anthropic Help Center; original publication date not stated; page showed “updated this week” on access date | Anthropic lists its built-in skills for Excel, Word, PowerPoint and PDF work, and distinguishes them from user-created or uploaded skills. It does not list Humanizer as built in. | Remove Mary's uncertain statement that her Humanizer skill is built into Claude and the immediately following list of supposed default skills. Preserve her personal account of using a Humanizer skill. No graphic attempts to contradict audible speech. |
| [What are skills?](https://support.claude.com/en/articles/12512176-what-are-skills) | Anthropic Help Center; original publication date not stated; page showed “updated this week” on access date | Skills can be folders of instructions, scripts and resources. | The existing “reusable directions” graphic is a plain-English summary. Josh's “document with text” wording remains a simplification, not a full format specification. |
| [ChatGPT release notes, August 28, 2026](https://help.openai.com/en/articles/6825453-chatgpt-release-notes) | OpenAI, 2026-08-28 | Multiple Gmail, Google Calendar and Google Contacts accounts became connectable in ChatGPT on supported plans. | Supports the ChatGPT part of Josh's account comparison. |
| [Use Google Workspace connectors](https://support.claude.com/en/articles/10166901-use-google-workspace-connectors) | Anthropic Help Center; original publication date not stated; page showed “updated today” on access date | Claude's Google Workspace documentation describes access to the Google account the user connected. | Consistent with the single connected Google-account part of Josh's time-qualified description. It does not independently establish the Slack-account limit. Recheck product wording before publication. |

No new host outcome, metric or publication result is inferred from these sources. The names Lewis, Olivia, Tyler and Chloe still need host approval for public use.
