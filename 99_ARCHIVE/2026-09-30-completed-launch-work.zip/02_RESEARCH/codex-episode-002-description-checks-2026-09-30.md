# Research note: Episode 002 description checks

- **Date started:** 2026-09-30
- **Researcher:** Codex
- **Related episode(s):** E002 make AI useful
- **Status:** checked for local description draft; no publication or legal advice requested

## Question

Does the description accurately summarize the final ep2hook export, and are its consent and account-access notes supported?

## Findings

The hosts describe these workflows in the selected 33:14.267 export. Present them as their reported experience. California Penal Code 632 addresses recording confidential communications without all parties' consent; qualify the sentence accordingly. Composio connections grant permissions to accounts, and its scopes documentation supports asking viewers to review those permissions. Detailed chapter timings are traced in the episode's chapter audit.

## Claim log

| ID | Claim in our words | Source | Published | Accessed | Evidence quality | Limitations |
|---|---|---|---|---|---|---|
| C01 | California generally requires all parties' consent to record a confidential conversation. | [California Penal Code 632](https://leginfo.legislature.ca.gov/faces/codes_displaySection.xhtml?lawCode=PEN&sectionNum=632), California Legislative Information | Last amendment listed: 2016, effective 2017-01-01 | 2026-09-30 | Primary statute, subsections (a), (c), (e), (f) | Confidentiality and exceptions matter. Do not claim every conversation everywhere requires consent. |
| C02 | Review the permissions you grant when connecting accounts through Composio. | [Controlling scopes](https://docs.composio.dev/docs/authentication/controlling-scopes), Composio | Undated live documentation | 2026-09-30 | Primary vendor documentation | Describes permissions such as reading email or managing calendars; does not independently establish security or a guarantee of capability. |
| C03 | Chapters start at 00:00, ascend, and last at least ten seconds. | [Video Chapters](https://support.google.com/youtube/answer/9884579?hl=en), YouTube Help | Undated live documentation | 2026-09-30 | Primary platform documentation | These timing rules do not guarantee that a channel/video has chapter access. |
| C04 | Josh describes one newsletter replacing 20 newsletters, and a grant finder that posts updates to Slack. | Exact final MP4 plus its matching SRT: newsletter starts 22:22.660; 20 newsletters at 22:43.760; grant finder at 23:37.100; Slack at 25:04.060 | Recorded September 26; export September 30, 2026 | 2026-09-30 | Host account of personal workflow | No independent test of private automations. The description says what the hosts built, not a universal product promise. |
| C05 | Josh describes borrowing Mary's brand skill. | Exact final MP4 plus matching SRT at 14:33.313 | Recorded September 26; export September 30, 2026 | 2026-09-30 | Direct host account | “Stole” is the hosts' joke, retained from supplied copy. |

## Definitions and comparability

Projects provide background/context; connectors provide permitted access to outside tools; skills provide reusable directions/workflows. A skill alone does not establish scheduling or autonomous execution. Keep the hosts' five-hour usage experience in the selected video as Josh instructed, without adding a universal written claim.

## Counterevidence and uncertainty

The show and Stanford URLs were supplied by Josh and retained. Their live pages could not be inspected in this session (show retrieval/DNS failure; Stanford retrieval returned 403); this is not evidence the links are broken. Run Your City, Composio, Granola and Wispr Flow homepages were retrievable. No announcement of approval, scheduling or publication is supported.

## Usable examples

- Newsletter: 22:22.
- Grant finder: 23:37.
- Brand skill: 14:33.

## Script-ready language

Get everyone's OK before recording a meeting. California generally requires all parties' consent to record a confidential conversation. Composio is a third-party service, so check the permissions you're granting when you connect your accounts.

## Sources

1. [California Penal Code 632](https://leginfo.legislature.ca.gov/faces/codes_displaySection.xhtml?lawCode=PEN&sectionNum=632) — California Legislative Information, last listed amendment effective 2017-01-01.
2. [Controlling scopes](https://docs.composio.dev/docs/authentication/controlling-scopes) — Composio, undated.
3. [Video Chapters](https://support.google.com/youtube/answer/9884579?hl=en) — YouTube Help, undated.
4. `01_EPISODES/E002-make-ai-useful/edit/codex-user-hook-2026-09-30/episode-002-full-review-v3.mp4` and matching `.srt` — OOOD, 2026-09-30; exact hash recorded in chapter audit.


## 2026-09-30 correction: shared YouTube/Spotify spacing

The original chapter check covered YouTube only. [Spotify Episode chapters](https://support.spotify.com/us/creators/article/episode-chapters/) — Spotify, undated, accessed 2026-09-30 — specifies at least three chapters and 30 seconds between starts; it advises merging chapters shorter than 30 seconds. Its manual-format guidance specifies 00:00, chronological plain-text titles, one chapter per line. The current v2 description merges short adjacent sections into 23 chapters; minimum start gap is 33 seconds and the final chapter lasts 65.267 seconds. OOOD adopts this stricter spacing for shared descriptions, including the final chapter as a house default. The video and original topic anchors are unchanged. See `01_EPISODES/E002-make-ai-useful/codex-chapter-audit-v2-2026-09-30.md`.
