# OOOD Marketing & Episodes Brainstorm

- Document ID: 1AvDfSBg6xxMyGNH7D9JhbGEzm3NP46459uxMoQDLSXc
- Revision ID: ANLCKQmz_GmkkWJeOUMg9R1Y6hFqhaY6vPXdgiv7KQJ38Ifd2H40Uy4IH1xhYyXYuLl1I_EY8Ee9QDD_W90p8wyGR15etiWus16ex9qAXeI
- Selected tab: all
- Protected controls: 2
- Opaque controls: 2
- Authoritative dropdowns: 0

Protected-control annotations are preservation instructions. Do not insert their displayed placeholder text to recreate a native control.

## YouTube + Spotify Details (t.93h9qj1tx8d5)

[P00001 | 1:27 | HEADING_1]
YouTube & Spotify Details

[P00002 | 27:332 | HEADING_1]
AI Directions: Include “https://” links everywhere because they only work on Spotify, take note of what you suggested vs what we have – finalized examples here are most important to replicate (tone, detail, etc.); always have chapters at least 30 seconds apart (to avoid violating Spotify chapter rules)

[P00003 | 332:342 | HEADING_1]
Episode 1

[P00004 | 342:343 | NORMAL_TEXT]
⟦EMPTY PARAGRAPH⟧

[P00005 | 343:373 | NORMAL_TEXT]
Thumbnail: WE’RE DOING WHAT?!

[P00006 | 373:375 | NORMAL_TEXT]
[INLINE_OBJECT kix.9ceb1e71cwe4]

[P00007 | 375:376 | NORMAL_TEXT]
⟦EMPTY PARAGRAPH⟧

[P00008 | 376:442 | NORMAL_TEXT]
Title: We Can’t Keep Up With AI Either (So We Started a Podcast!)

[P00009 | 442:443 | NORMAL_TEXT]
⟦EMPTY PARAGRAPH⟧

[P00010 | 443:456 | NORMAL_TEXT]
Description:

[P00011 | 456:672 | NORMAL_TEXT]
We got married a few weeks ago, started our second year of business school at Stanford, and apparently thought now was a great time to start a podcast. About AI. A thing we’re very much still figuring out ourselves.

[P00012 | 672:673 | NORMAL_TEXT]
⟦EMPTY PARAGRAPH⟧

[P00013 | 673:994 | NORMAL_TEXT]
This first one is mostly us: who we are, why we’re doing this, and why we think everyone should be learning AI (yes, even the haters). We also talk about running a youth sports nonprofit together, the 15-ish puppies we’ve fostered, and the time Josh had AI make family holiday photos of our future kids on our honeymoon.

[P00014 | 994:995 | NORMAL_TEXT]
⟦EMPTY PARAGRAPH⟧

[P00015 | 995:1119 | NORMAL_TEXT]
What should we try next? Drop it in the comments or email hi@outofourdepth.com. We read everything (…there’s not much yet).

[P00016 | 1119:1120 | NORMAL_TEXT]
⟦EMPTY PARAGRAPH⟧

[P00017 | 1120:1129 | NORMAL_TEXT]
Chapters

[P00018 | 1129:1150 | NORMAL_TEXT]
00:00 Why we’re here

[P00019 | 1150:1178 | NORMAL_TEXT]
01:14 Why learn AI together

[P00020 | 1178:1213 | NORMAL_TEXT]
02:08 Making it fun and accessible

[P00021 | 1213:1238 | NORMAL_TEXT]
03:45 Meet Josh and Mary

[P00022 | 1238:1258 | NORMAL_TEXT]
05:01 Run Your City

[P00023 | 1258:1279 | NORMAL_TEXT]
06:00 What to expect

[P00024 | 1279:1307 | NORMAL_TEXT]
06:48 Curious and skeptical

[P00025 | 1307:1323 | NORMAL_TEXT]
08:05 Fun facts

[P00026 | 1323:1363 | NORMAL_TEXT]
08:47 The honeymoon AI photo experiment

[P00027 | 1363:1388 | NORMAL_TEXT]
10:28 Closing invitation

[P00028 | 1388:1389 | NORMAL_TEXT]
⟦EMPTY PARAGRAPH⟧

[P00029 | 1389:1433 | NORMAL_TEXT]
Out of Our Depth: [https://outofourdepth.com](https://outofourdepth.com)

[P00030 | 1433:1476 | NORMAL_TEXT]
Run Your City: [https://www.runyourcity.org](https://www.runyourcity.org)

[P00031 | 1476:1544 | NORMAL_TEXT]
AI@GSB: [https://www.gsb.stanford.edu/experience/learning/applied-ai](https://www.gsb.stanford.edu/experience/learning/applied-ai)

[P00032 | 1544:1545 | NORMAL_TEXT]
⟦EMPTY PARAGRAPH⟧

[P00033 | 1545:1768 | NORMAL_TEXT]
Research note: when we say women are "20% behind," that's the relative gap in generative AI use from a 2025 analysis of 18 studies: [https://www.hbs.edu/ris/Publication%20Files/25023_52957d6c-0378-4796-99fa-aab684b3b2f8.pdf](https://www.hbs.edu/ris/Publication%20Files/25023_52957d6c-0378-4796-99fa-aab684b3b2f8.pdf)

[P00034 | 1768:1769 | NORMAL_TEXT]
⟦EMPTY PARAGRAPH⟧

[P00035 | 1769:1797 | NORMAL_TEXT]
#AI #Podcast #OutOfOurDepth

[P00036 | 1797:1798 | NORMAL_TEXT]
⟦EMPTY PARAGRAPH⟧

[P00037 | 1798:1823 | HEADING_1]
Episode 2 - AI landscape

[P00038 | 1823:1824 | NORMAL_TEXT]
⟦EMPTY PARAGRAPH⟧

[P00039 | 1824:1859 | NORMAL_TEXT]
Thumbnail: WAIT, WHAT'S A MODEL?! 

[P00040 | 1859:1861 | NORMAL_TEXT]
[INLINE_OBJECT kix.hfsn08kw1k8f]

[P00041 | 1861:1862 | NORMAL_TEXT]
⟦EMPTY PARAGRAPH⟧

[P00042 | 1862:1917 | NORMAL_TEXT]
Title: Who's Who in AI (Explained With a Toyota Prius)

[P00043 | 1917:1918 | NORMAL_TEXT]
⟦EMPTY PARAGRAPH⟧

[P00044 | 1918:4423 | NORMAL_TEXT]
Description:Claude, ChatGPT, Opus, Astra, tokens, open weights... if you've ever nodded along to an AI conversation while secretly having no clue what anyone meant, this one's for you. (Us too. Like, yesterday.)This is our who's who of AI: who actually builds the models, the difference between a model and the app you're typing into (the model is the engine, the app is the car, and tokens are the gas; stay with us). Then it gets a little spicy. Mary thinks the world's best mathematicians are about to matter less, Josh disagrees, and we rank Demis, Dario, Sam, and Elon from most to least loved.What AI word do you still secretly not understand? Drop it in the comments or email hi@outofourdepth.com and we'll tackle it. No stupid questions (we asked most of them in this episode).Chapters00:00 Data centers on the moon? + AI intro01:09 Who actually builds the models02:20 Claude vs. ChatGPT: what we actually use05:12 Gemini, the Dodgers of AI06:20 Open vs. closed: how models learn08:49 The car analogy: models vs. apps12:28 Why are the model names so bad?13:26 Tokens are gas14:35 Are mathematicians out of a job?18:33 Jobs vs. tasks20:16 Who gets left behind21:36 Mary's coding midterm (29 or 92?)24:18 What's overhyped24:59 What we're betting on: being human27:14 NVIDIA and the wider AI market28:22 Why it's so easy to switch29:44 How do open models make money?33:05 On-prem vs. the cloud (and the moon)35:05 Dario and the Anthropic origin story37:40 When AI breaks the rules42:07 Sam, Zuck, and Elon45:56 Ranking the AI leaders49:21 Mary's last three AI chats and goodbyeOut of Our Depth:[https://www.outofourdepth.com/](https://www.outofourdepth.com/)[https://www.outofourdepth.com](https://www.outofourdepth.com/)Run Your City:[https://www.runyourcity.org/](https://www.runyourcity.org/)[https://www.runyourcity.org](https://www.runyourcity.org/)AI@GSB:[https://www.gsb.stanford.edu/experience/learning/applied-ai](https://www.gsb.stanford.edu/experience/learning/applied-ai)[https://www.gsb.stanford.edu/experience/learning/applied-ai](https://www.gsb.stanford.edu/experience/learning/applied-ai)Research notes:On AI and math: OpenAI published ten results in mathematics and theoretical computer science obtained by an internal model. These are the company's reported findings; our discussion about what they mean for mathematicians is opinion. Read the report:[https://cdn.openai.com/pdf/ten-proofs-oai.pdf](https://cdn.openai.com/pdf/ten-proofs-oai.pdf)[https://cdn.openai.com/pdf/ten-proofs-oai.pdf](https://cdn.openai.com/pdf/ten-proofs-oai.pdf)More on Astra and the math results:[https://the-decoder.com/openai-announces-its-next-major-model-astra-by-dropping-ten-previously-unsolved-math-solutions/](https://the-decoder.com/openai-announces-its-next-major-model-astra-by-dropping-ten-previously-unsolved-math-solutions/)[https://the-decoder.com/openai-announces-its-next-major-model-astra-by-dropping-ten-previously-unsolved-math-solutions](https://the-decoder.com/openai-announces-its-next-major-model-astra-by-dropping-ten-previously-unsolved-math-solutions/)On Demis: Google announced that Demis Hassabis handed over day-to-day Google DeepMind operations to become its chair and Alphabet's chief scientist:[https://blog.google/company-news/inside-google/message-ceo/next-chapter-ai-momentum/](https://blog.google/company-news/inside-google/message-ceo/next-chapter-ai-momentum/)[https://blog.google/company-news/inside-google/message-ceo/next-chapter-ai-momentum](https://blog.google/company-news/inside-google/message-ceo/next-chapter-ai-momentum/)#AI #Podcast #OutOfOurDepth

[P00045 | 4423:4424 | NORMAL_TEXT]
⟦EMPTY PARAGRAPH⟧

[P00046 | 4424:4466 | HEADING_1]
Episode 3 - Projects, Connectors & Skills

[P00047 | 4466:4467 | NORMAL_TEXT]
⟦EMPTY PARAGRAPH⟧

[P00048 | 4467:4500 | NORMAL_TEXT]
Thumbnail: AI FEATURES WE EAT UP

[P00049 | 4500:4502 | NORMAL_TEXT]
[INLINE_OBJECT kix.sgo85bo0r9c6]

[P00050 | 4502:4503 | NORMAL_TEXT]
⟦EMPTY PARAGRAPH⟧

[P00051 | 4503:4590 | NORMAL_TEXT]
Title: Projects, Connectors & Skills… Take Your AI From Fresh Intern to Full-Time Hire

[P00052 | 4590:4591 | NORMAL_TEXT]
⟦EMPTY PARAGRAPH⟧

[P00053 | 4591:4848 | NORMAL_TEXT]
Description:Ever asked AI something and gotten an answer so generic it could've been for anyone? Same. These are the three features that fixed that for us: projects, connectors, and skills. We use them every day and tell our friends to set them up first.

[P00054 | 4848:4849 | NORMAL_TEXT]
⟦EMPTY PARAGRAPH⟧

[P00055 | 4849:5184 | NORMAL_TEXT]
We explain all three with one very committed intern metaphor, then get into what we've actually built: a grant finder that posts straight into our nonprofit's Slack, a newsletter that reads Josh's 20 other newsletters so he doesn't have to, and the brand skill Josh stole from Mary. Also, Josh cannot go to bed with unused AI credits.

[P00056 | 5184:5185 | NORMAL_TEXT]
⟦EMPTY PARAGRAPH⟧

[P00057 | 5185:6201 | NORMAL_TEXT]
What's the most repetitive thing you do every week? Drop it in the comments or email hi@outofourdepth.com and we might try turning it into a skill on the show.Chapters00:00 Intro: why these three features01:43 Projects: give your AI a desk04:56 Mary's fitness project05:59 Connectors, Granola and recording consent08:12 Skills: reusable workflows08:45 Josh's bank account skill09:56 Teaching a skill by showing the workflow10:49 Projects vs. skills (hello, Dyslexify)11:56 Claude Design and Wispr Flow13:40 Leveling up your intern14:33 The brand skill Josh stole from Mary15:42 Humanizer: less AI slop16:29 The skills behind this podcast17:23 Josh vs. unused credits19:01 Why AI tells make people tune out19:49 Composio: connecting multiple accounts21:43 Recap: projects, connectors and skills22:22 One newsletter instead of 2023:37 A grant finder for Run Your City26:07 Rebuilding our whole website27:52 Why human effort still matters29:53 Where AI missed the mark32:09 What's next: agents

[P00058 | 6201:6202 | NORMAL_TEXT]
⟦EMPTY PARAGRAPH⟧

[P00059 | 6202:6357 | NORMAL_TEXT]
Out of Our Depth:[https://outofourdepth.com/](https://outofourdepth.com/)[https://outofourdepth.com](https://outofourdepth.com/)Run Your City:[https://www.runyourcity.org/](https://www.runyourcity.org/)[https://www.runyourcity.org](https://www.runyourcity.org/)AI@GSB:[https://www.gsb.stanford.edu/experience/learning/applied-ai](https://www.gsb.stanford.edu/experience/learning/applied-ai)[https://www.gsb.stanford.edu/experience/learning/applied-ai](https://www.gsb.stanford.edu/experience/learning/applied-ai)

[P00060 | 6357:6358 | NORMAL_TEXT]
⟦EMPTY PARAGRAPH⟧

[P00061 | 6358:6471 | NORMAL_TEXT]
Tools we mentionComposio:[https://composio.dev/](https://composio.dev/)[https://composio.dev](https://composio.dev/)Granola:[https://www.granola.ai/](https://www.granola.ai/)[https://www.granola.ai](https://www.granola.ai/)Wispr Flow:[https://wisprflow.ai/](https://wisprflow.ai/)[https://wisprflow.ai](https://wisprflow.ai)

[P00062 | 6471:6472 | NORMAL_TEXT]
⟦EMPTY PARAGRAPH⟧

[P00063 | 6472:6760 | NORMAL_TEXT]
A note on recording and access: get everyone's OK before recording a meeting with a tool like Granola. California generally requires all parties' consent to record a confidential conversation:[https://leginfo.legislature.ca.gov/faces/codes_displaySection.xhtml?lawCode=PEN&sectionNum=632](https://leginfo.legislature.ca.gov/faces/codes_displaySection.xhtml?lawCode=PEN&sectionNum=632)[https://leginfo.legislature.ca.gov/faces/codes_displaySection.xhtml?lawCode=PEN&sectionNum=632](https://leginfo.legislature.ca.gov/faces/codes_displaySection.xhtml?lawCode=PEN&sectionNum=632)

[P00064 | 6760:6761 | NORMAL_TEXT]
⟦EMPTY PARAGRAPH⟧

[P00065 | 6761:6934 | NORMAL_TEXT]
Composio is a third-party service, so check the permissions you're granting when you connect your accounts:[https://docs.composio.dev/docs/authentication/controlling-scopes](https://docs.composio.dev/docs/authentication/controlling-scopes)[https://docs.composio.dev/docs/authentication/controlling-scopes](https://docs.composio.dev/docs/authentication/controlling-scopes)

[P00066 | 6934:6935 | NORMAL_TEXT]
⟦EMPTY PARAGRAPH⟧

[P00067 | 6935:6963 | NORMAL_TEXT]
#AI #Podcast #OutOfOurDepth

[P00068 | 6963:6964 | NORMAL_TEXT]
⟦EMPTY PARAGRAPH⟧

[P00069 | 6964:6965 | NORMAL_TEXT]
⟦EMPTY PARAGRAPH⟧

[P00070 | 6965:6967 | NORMAL_TEXT]
—

[P00071 | 6967:6968 | NORMAL_TEXT]
⟦EMPTY PARAGRAPH⟧

[P00072 | 6968:6979 | HEADING_1]
Episode XX

[P00073 | 6979:6980 | NORMAL_TEXT]
⟦EMPTY PARAGRAPH⟧

[P00074 | 6980:6991 | NORMAL_TEXT]
Thumbnail:

[P00075 | 6991:6992 | NORMAL_TEXT]
⟦EMPTY PARAGRAPH⟧

[P00076 | 6992:6993 | NORMAL_TEXT]
⟦EMPTY PARAGRAPH⟧

[P00077 | 6993:7001 | NORMAL_TEXT]
Title: 

[P00078 | 7001:7002 | NORMAL_TEXT]
⟦EMPTY PARAGRAPH⟧

[P00079 | 7002:7015 | NORMAL_TEXT]
Description:

[P00080 | 7015:7016 | NORMAL_TEXT]
⟦EMPTY PARAGRAPH⟧

## Podcast Ideas (t.3su0y9bom91t)

[P00081 | 1:15 | NORMAL_TEXT]
Podcast ideas

[P00082 | 15:147 | NORMAL_TEXT | LIST id=kix.etzju01y0l76 level=0]
What's an agent?! Chatbots answer, agents act – mental model of what they are, what’s possible, & current limitations (part 1 of 2)

[P00083 | 147:295 | NORMAL_TEXT | LIST id=kix.etzju01y0l76 level=0]
Personal agents + productivity hacks: Muse, Instinct, dots and Grok Bot, what they are, what we like, and what we'd never let them do (part 2 of 2)

[P00084 | 295:399 | NORMAL_TEXT | LIST id=kix.etzju01y0l76 level=0]
Model deep dive, Gemini 4: Google's new top model, why it matters, and why almost nobody can use it yet

[P00085 | 399:493 | NORMAL_TEXT | LIST id=kix.etzju01y0l76 level=0]
OpenAI, chill with it: GPT-6, the "is this AGI?" claim, and ChatGPT turning into an app store

[P00086 | 493:583 | NORMAL_TEXT | LIST id=kix.etzju01y0l76 level=0]
Why are Sam + Dario slowing down? Gated launches, and why it can't just be for our safety

[P00087 | 583:698 | NORMAL_TEXT | LIST id=kix.etzju01y0l76 level=0]
The future?! Our bet on the future of work: which jobs and skills matter now, and what we'd do if we were 22 again

[P00088 | 698:808 | NORMAL_TEXT | LIST id=kix.etzju01y0l76 level=0]
Staying up to date: ~30 minutes a day, how we built our X, our newsletter (audio + not), and podcasts we like

[P00089 | 808:884 | NORMAL_TEXT | LIST id=kix.etzju01y0l76 level=0]
AI tool tier list: everything we pay for, ranked, and whether it's worth it

[P00090 | 884:1012 | NORMAL_TEXT | LIST id=kix.etzju01y0l76 level=0]
Privacy + break-ins: rogue agents going off script, plus what AI knows about us (ads, health data, the settings we're changing)

[P00091 | 1012:1096 | NORMAL_TEXT | LIST id=kix.etzju01y0l76 level=0]
Everything that enables AI: chips, data centers, electricity, and who controls them

[P00092 | 1096:1182 | NORMAL_TEXT | LIST id=kix.etzju01y0l76 level=0]
Is AI bad for the planet? The energy and water question everyone's embarrassed to ask

[P00093 | 1182:1285 | NORMAL_TEXT | LIST id=kix.etzju01y0l76 level=0]
The voices of AI: the builders, researchers, and skeptics, what they're like, and Mary draws them live

[P00094 | 1285:1361 | NORMAL_TEXT | LIST id=kix.etzju01y0l76 level=0]
Future of AI in the XX industry (healthcare, education, sports, arts, etc.)

[P00095 | 1361:1447 | NORMAL_TEXT | LIST id=kix.etzju01y0l76 level=0]
AI x RYC hackathon: an AI board member and an AI hiring panel (hire, intern, or pass)

[P00096 | 1447:1448 | NORMAL_TEXT]
⟦EMPTY PARAGRAPH⟧

[P00097 | 1448:1466 | NORMAL_TEXT]
Prompt for Primer

[P00098 | 1466:1510 | NORMAL_TEXT]
Here's the tightened version. Main changes:

[P00099 | 1510:1618 | NORMAL_TEXT | LIST id=kix.9j48yffm2m2l level=0]
Real length target: 2 hrs ≈ 18–20k words (your AI Stack primer was 17k ≈ 107 min). About 40 min at your 3x.

[P00100 | 1618:1747 | NORMAL_TEXT | LIST id=kix.9j48yffm2m2l level=0]
Pitch checkpoint first: it proposes the angle and outline before writing 20k words, and has to push back if the idea is generic.

[P00101 | 1747:1856 | NORMAL_TEXT | LIST id=kix.9j48yffm2m2l level=0]
Staged writing: one reply can't hold 20k good words, so it builds chapter by chapter instead of compressing.

[P00102 | 1856:1922 | NORMAL_TEXT | LIST id=kix.9j48yffm2m2l level=0]
Rules for tea and side quests: true, sourced, labeled, skippable.

[P00103 | 1922:2032 | NORMAL_TEXT | LIST id=kix.9j48yffm2m2l level=0]
Audio-first for Speechify: prep kit, glossary and sources moved to appendices after an "End of audio" marker.

[P00104 | 2032:2106 | NORMAL_TEXT | LIST id=kix.9j48yffm2m2l level=0]
"Our takes first" pause so the primer doesn't form your opinions for you.

[P00105 | 2106:2142 | NORMAL_TEXT]
⟦PROTECTED: opaqueTemplateControl/copy-only@2106:2107 U+E907 — preserve this control and its containing structure⟧
⟦PROTECTED_CONTROL U+E907⟧# Out of Our Depth: Episode Primer

[P00106 | 2142:2143 | NORMAL_TEXT]
⟦EMPTY PARAGRAPH⟧

[P00107 | 2143:2506 | NORMAL_TEXT]
You're building a deep-study primer for one Out of Our Depth episode. Use the OOOD project context (who Mary and Josh are, the audience, tone, editorial philosophy). The primer is how Mary and Josh learn the topic well enough to explain it, argue about it, and ask sharp questions on air. It is a study guide, not a script: don't write our lines or our opinions.

[P00108 | 2506:2507 | NORMAL_TEXT]
⟦EMPTY PARAGRAPH⟧

[P00109 | 2507:2525 | NORMAL_TEXT]
## Episode inputs

[P00110 | 2525:2534 | NORMAL_TEXT]
- Topic:

[P00111 | 2534:2562 | NORMAL_TEXT]
- Working title (optional):

[P00112 | 2562:2616 | NORMAL_TEXT]
- Type: news / current debate OR deep dive / use case

[P00113 | 2616:2659 | NORMAL_TEXT]
- Our angle or the question we care about:

[P00114 | 2659:2701 | NORMAL_TEXT]
- What we already know (skip or go fast):

[P00115 | 2701:2744 | NORMAL_TEXT]
- Questions we specifically want answered:

[P00116 | 2744:2765 | NORMAL_TEXT]
- Anything to avoid:

[P00117 | 2765:2766 | NORMAL_TEXT]
⟦EMPTY PARAGRAPH⟧

[P00118 | 2766:2826 | NORMAL_TEXT]
## Step 1: Pitch before you write (stop and wait for my OK)

[P00119 | 2826:2854 | NORMAL_TEXT]
Give me, in one short page:

[P00120 | 2854:2931 | NORMAL_TEXT]
- The central tension in one sentence, and the "so what" for a normal person

[P00121 | 2931:3048 | NORMAL_TEXT]
- Your honest take on the idea: if it's generic, overdone, or the question is weak, say so and pitch a sharper angle

[P00122 | 3048:3131 | NORMAL_TEXT]
- 3 to 5 core mental models you'll build the primer around, each with its metaphor

[P00123 | 3131:3175 | NORMAL_TEXT]
- One running metaphor for the whole primer

[P00124 | 3175:3238 | NORMAL_TEXT]
- 3 facts or stories so surprising we'll repeat them at dinner

[P00125 | 3238:3279 | NORMAL_TEXT]
- Chapter outline with rough word counts

[P00126 | 3279:3328 | NORMAL_TEXT]
- What's time-sensitive and needs fresh research

[P00127 | 3328:3329 | NORMAL_TEXT]
⟦EMPTY PARAGRAPH⟧

[P00128 | 3329:3349 | NORMAL_TEXT]
## Step 2: Research

[P00129 | 3349:3523 | NORMAL_TEXT]
- Search for current information. AI changes weekly, so don't rely on memory for anything about the present (who's in charge, latest models, current numbers, laws, lawsuits)

[P00130 | 3523:3650 | NORMAL_TEXT]
- Prioritize primary sources (papers, company docs, filings, official data), then top reporting, then credible expert analysis

[P00131 | 3650:3785 | NORMAL_TEXT]
- Separate fact, interpretation, and speculation. Label confidence in plain words: solid / early evidence / contested / educated guess

[P00132 | 3785:3902 | NORMAL_TEXT]
- Treat one study as one study: who ran it, how big, what it can and can't show. Benchmarks aren't news on their own

[P00133 | 3902:3986 | NORMAL_TEXT]
- Never invent quotes, stats, studies, or citations. If you can't verify it, cut it

[P00134 | 3986:4049 | NORMAL_TEXT]
- Date-stamp anything that could change ("as of October 2026")

[P00135 | 4049:4050 | NORMAL_TEXT]
⟦EMPTY PARAGRAPH⟧

[P00136 | 4050:4070 | NORMAL_TEXT]
## Step 3: Write it

[P00137 | 4070:4323 | NORMAL_TEXT]
Length: 18,000 to 20,000 words (about 2 hours at normal narration speed). Build it chapter by chapter across as many passes as needed. Don't compress to fit one response, and don't pad: every section earns its length with substance, examples, or story.

[P00138 | 4323:4324 | NORMAL_TEXT]
⟦EMPTY PARAGRAPH⟧

[P00139 | 4324:4373 | NORMAL_TEXT]
Chapters (adjust to the topic, keep the spirit):

[P00140 | 4373:4471 | NORMAL_TEXT]
1. Cold open: a hook story or question, then why this matters to a normal person right now (~800)

[P00141 | 4471:4586 | NORMAL_TEXT]
2. The short version: the 60-second explanation, then the 5-minute one, then "if you remember three things" (~700)

[P00142 | 4586:4699 | NORMAL_TEXT]
3. Pause, our takes first: 5 to 8 questions Mary and Josh each answer on their own before reading further (~300)

[P00143 | 4699:4825 | NORMAL_TEXT]
4. Core mental models: for each, the metaphor first, then what's literally happening, then where the metaphor breaks (~2,500)

[P00144 | 4825:4968 | NORMAL_TEXT]
5. How we got here: origin story, turning points, and the tea: feuds, flops, lawsuits, board drama, bets that aged badly, weird facts (~2,000)

[P00145 | 4968:5098 | NORMAL_TEXT]
6. How it actually works, three levels deep: Level 1 intuitive, Level 2 precise, Level 3 nerd corner (clearly skippable) (~2,500)

[P00146 | 5098:5182 | NORMAL_TEXT]
7. Who's who: companies, people, money, incentives, who wins and who loses (~1,500)

[P00147 | 5182:5290 | NORMAL_TEXT]
8. What the evidence actually says: key studies and numbers, their limits, where hype outruns data (~2,000)

[P00148 | 5290:5433 | NORMAL_TEXT]
9. The real debates: the strongest case for each side (steelman, no strawmen), where the evidence points, what's genuinely unresolved (~2,000)

[P00149 | 5433:5631 | NORMAL_TEXT]
10. Back to real life: what to delegate vs. keep doing ourselves; capability vs. reliability vs. authority; concrete examples for work, school, parenting, and nonprofits like Run Your City (~1,500)

[P00150 | 5631:5704 | NORMAL_TEXT]
11. Myths and misconceptions, including ones smart people believe (~800)

[P00151 | 5704:5803 | NORMAL_TEXT]
12. The "stupid questions" FAQ: 30 to 50 embarrassing-to-ask questions with plain answers (~2,000)

[P00152 | 5803:5866 | NORMAL_TEXT]
13. What to watch next, and what would change our minds (~500)

[P00153 | 5866:5963 | NORMAL_TEXT]
14. Teach-back: 5 prompts to explain it to each other in our own words, then a full recap (~600)

[P00154 | 5963:5964 | NORMAL_TEXT]
⟦EMPTY PARAGRAPH⟧

[P00155 | 5964:5976 | NORMAL_TEXT]
Throughout:

[P00156 | 5976:6096 | NORMAL_TEXT]
- Mental models first, details second. Start intuitive, then get precise. Answer the dumb question before the smart one

[P00157 | 6096:6254 | NORMAL_TEXT]
- Where it fits, connect to our AI Stack primer (Learn → Look → Think → Act, and the 7 layers) so primers build on each other instead of re-explaining basics

[P00158 | 6254:6327 | NORMAL_TEXT]
- End every chapter with a one-line "Sticky version" we could say on air

[P00159 | 6327:6393 | NORMAL_TEXT]
- Make big numbers human-scale (compare to things we can picture)

[P00160 | 6393:6664 | NORMAL_TEXT]
- Tea: true and sourced only. Label it confirmed, widely reported, or rumor (rumor only if it's famous, and clearly flagged). Pick tea that teaches something about how the industry or its incentives work. Punch up at companies and public figures, never at private people

[P00161 | 6664:6789 | NORMAL_TEXT]
- Side quests: 1 or 2 per chapter, labeled "Side quest," 30 to 90 seconds, true, fun, ideally looping back to the main point

[P00162 | 6789:6944 | NORMAL_TEXT]
- Tone: a sharp, funny friend who did all the reading. Curious, practical, skeptical not cynical, excited not hypey. No doom for drama, no marketing speak

[P00163 | 6944:6945 | NORMAL_TEXT]
⟦EMPTY PARAGRAPH⟧

[P00164 | 6945:6992 | NORMAL_TEXT]
Audio-first format (this goes into Speechify):

[P00165 | 6992:7093 | NORMAL_TEXT]
- Write to be heard: short paragraphs, spoken chapter titles ("Chapter 4: ..."), natural transitions

[P00166 | 7093:7182 | NORMAL_TEXT]
- No tables, no walls of bullets, no em dashes, no URLs or citation brackets in the body

[P00167 | 7182:7326 | NORMAL_TEXT]
- Write symbols and numbers the way they're said (percent, dollars, billion). Spell out acronyms the first time, with pronunciation if it's odd

[P00168 | 7326:7406 | NORMAL_TEXT]
- Plain words; define any jargon in everyday language the first time it appears

[P00169 | 7406:7464 | NORMAL_TEXT]
- Put a clear "End of audio" marker before the appendices

[P00170 | 7464:7465 | NORMAL_TEXT]
⟦EMPTY PARAGRAPH⟧

[P00171 | 7465:7508 | NORMAL_TEXT]
Appendices (after the audio, for reading):

[P00172 | 7508:7671 | NORMAL_TEXT]
A. Show prep kit: 8 to 10 clip-worthy facts or moments, 5 disagreement prompts for Mary vs. Josh, 2 or 3 on-air experiments or demos, 3 to 5 hook or title options

[P00173 | 7671:7698 | NORMAL_TEXT]
B. Glossary in plain words

[P00174 | 7698:7793 | NORMAL_TEXT]
C. Sources grouped by chapter, with links and dates, flagging the strongest and any shaky ones

[P00175 | 7793:7794 | NORMAL_TEXT]
⟦EMPTY PARAGRAPH⟧

[P00176 | 7794:7836 | NORMAL_TEXT]
## Step 4: Quality pass before delivering

[P00177 | 7836:7897 | NORMAL_TEXT]
- Check every name, number, date, and quote against a source

[P00178 | 7897:7934 | NORMAL_TEXT]
- Confirm the word count is in range

[P00179 | 7934:7975 | NORMAL_TEXT]
- Strip em dashes and unexplained jargon

[P00180 | 7975:8033 | NORMAL_TEXT]
- Read-aloud test: fix anything that sounds clunky spoken

[P00181 | 8033:8034 | NORMAL_TEXT]
⟦EMPTY PARAGRAPH⟧

[P00182 | 8034:8154 | NORMAL_TEXT]
Deliver as a document with clear headings (Poppins if possible), plus a PDF I can load into Speechify and my notes app.

[P00183 | 8154:8392 | NORMAL_TEXT]
⟦PROTECTED: opaqueTemplateControl/copy-only@8154:8155 U+E907 — preserve this control and its containing structure⟧
⟦PROTECTED_CONTROL U+E907⟧Run each episode in its own chat in this project with web search or Research on, so each one gets full attention. Your message mentioned four episodes but didn't list them; send me the topics and I'll pre-fill the inputs block for each.

[P00184 | 8392:8393 | NORMAL_TEXT]
⟦EMPTY PARAGRAPH⟧

## Notes (t.nlz85f4bboz8)

[P00185 | 1:7 | NORMAL_TEXT]
Links

[P00186 | 7:69 | NORMAL_TEXT | LIST id=kix.lkj751s322ll level=0]
Youtube: [www.youtube.com/watch?v=XB4LpkVXgqA&feature=youtu.be](http://www.youtube.com/watch?v=XB4LpkVXgqA&feature=youtu.be)

[P00187 | 69:187 | NORMAL_TEXT | LIST id=kix.lkj751s322ll level=0]
Spotify: [https://open.spotify.com/episode/1oBgq6Spwsm8ExNowZwoNV?si=XtjEGGejRSCBiPlCNI8Npg&nd=1&dlsi=1ba08e2ae45f44cc](https://open.spotify.com/episode/1oBgq6Spwsm8ExNowZwoNV?si=XtjEGGejRSCBiPlCNI8Npg&nd=1&dlsi=1ba08e2ae45f44cc)

[P00188 | 187:223 | NORMAL_TEXT | LIST id=kix.lkj751s322ll level=0]
Website: [https://outofourdepth.com/](https://outofourdepth.com/)

[P00189 | 223:224 | NORMAL_TEXT]
⟦EMPTY PARAGRAPH⟧

[P00190 | 224:470 | NORMAL_TEXT]
I need to come up with a marketing plan for the Out of Our Depth podcast. We just launched our first video, our first YouTube video, and our website. We have Instagram, Twitter, LinkedIn, and Facebook, and you can watch it on YouTube or Spotify.

[P00191 | 470:471 | NORMAL_TEXT]
⟦EMPTY PARAGRAPH⟧

[P00192 | 471:742 | NORMAL_TEXT]
I'm trying to understand what to prioritize. Is there a way to make short-form content from long-form? Is it first helpful to prioritize making a lot of videos? This weekend, right now, we just have a "Why We're Here." We already have "AI Landscape" and one more filmed.

[P00193 | 742:743 | NORMAL_TEXT]
⟦EMPTY PARAGRAPH⟧

[P00194 | 743:1122 | NORMAL_TEXT]
What thoughts, more broadly, but also super tactically, on how to prioritize? I have a lot of personal followers, so could I share on Instagram? I would also want to get an understanding of what's helpful to post, if at all, or should we just lean into YouTube and watch and think about the other ones? I probably need something on the other ones, or maybe just a "Coming Soon."

[P00195 | 1122:1123 | NORMAL_TEXT]
⟦EMPTY PARAGRAPH⟧

[P00196 | 1123:1259 | NORMAL_TEXT]
Help me create a marketing plan to launch this, and then Sunday we want to both post on our LinkedIns. I can also post on my Facebook. 

