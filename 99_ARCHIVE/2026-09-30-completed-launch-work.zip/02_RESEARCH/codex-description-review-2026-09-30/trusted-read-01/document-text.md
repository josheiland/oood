# OOOD Marketing & Episodes Brainstorm

- Document ID: 1AvDfSBg6xxMyGNH7D9JhbGEzm3NP46459uxMoQDLSXc
- Revision ID: ANLCKQk0e-ekXIuqXWO2fCPHf6rMHRVGxGYPXvVsVaPg0bAL6htmVOgH6e4xlASXjst7B6aPu_UA_zok2GnI9V8pbbI7bvCOJ604J8P0gcQ
- Selected tab: all
- Protected controls: 0
- Opaque controls: 0
- Authoritative dropdowns: 0

Protected-control annotations are preservation instructions. Do not insert their displayed placeholder text to recreate a native control.

## YouTube + Spotify Details (t.93h9qj1tx8d5)

[P00001 | 1:27 | HEADING_1]
YouTube & Spotify Details

[P00002 | 27:332 | HEADING_1]
AI Directions: Include “https://” links everywhere because they only work on Spotify, take note of what you suggested vs what we have – finalized examples here are most important to replicate (tone, detail, etc.); always have chapters at least 30 seconds apart (to avoid violating Spotify chapter rules)

[P00003 | 332:342 | HEADING_1]
Episode 1

[P00004 | 342:343 | NORMAL_TEXT]
⟦EMPTY PARAGRAPH⟧

[P00005 | 343:373 | NORMAL_TEXT]
Thumbnail: WE’RE DOING WHAT?!

[P00006 | 373:375 | NORMAL_TEXT]
[INLINE_OBJECT kix.9ceb1e71cwe4]

[P00007 | 375:376 | NORMAL_TEXT]
⟦EMPTY PARAGRAPH⟧

[P00008 | 376:442 | NORMAL_TEXT]
Title: We Can’t Keep Up With AI Either (So We Started a Podcast!)

[P00009 | 442:443 | NORMAL_TEXT]
⟦EMPTY PARAGRAPH⟧

[P00010 | 443:456 | NORMAL_TEXT]
Description:

[P00011 | 456:672 | NORMAL_TEXT]
We got married a few weeks ago, started our second year of business school at Stanford, and apparently thought now was a great time to start a podcast. About AI. A thing we’re very much still figuring out ourselves.

[P00012 | 672:673 | NORMAL_TEXT]
⟦EMPTY PARAGRAPH⟧

[P00013 | 673:994 | NORMAL_TEXT]
This first one is mostly us: who we are, why we’re doing this, and why we think everyone should be learning AI (yes, even the haters). We also talk about running a youth sports nonprofit together, the 15-ish puppies we’ve fostered, and the time Josh had AI make family holiday photos of our future kids on our honeymoon.

[P00014 | 994:995 | NORMAL_TEXT]
⟦EMPTY PARAGRAPH⟧

[P00015 | 995:1119 | NORMAL_TEXT]
What should we try next? Drop it in the comments or email hi@outofourdepth.com. We read everything (…there’s not much yet).

[P00016 | 1119:1120 | NORMAL_TEXT]
⟦EMPTY PARAGRAPH⟧

[P00017 | 1120:1129 | NORMAL_TEXT]
Chapters

[P00018 | 1129:1150 | NORMAL_TEXT]
00:11 Why we’re here

[P00019 | 1150:1178 | NORMAL_TEXT]
01:14 Why learn AI together

[P00020 | 1178:1213 | NORMAL_TEXT]
02:08 Making it fun and accessible

[P00021 | 1213:1238 | NORMAL_TEXT]
03:45 Meet Josh and Mary

[P00022 | 1238:1258 | NORMAL_TEXT]
05:01 Run Your City

[P00023 | 1258:1279 | NORMAL_TEXT]
06:00 What to expect

[P00024 | 1279:1307 | NORMAL_TEXT]
06:48 Curious and skeptical

[P00025 | 1307:1323 | NORMAL_TEXT]
08:05 Fun facts

[P00026 | 1323:1363 | NORMAL_TEXT]
08:47 The honeymoon AI photo experiment

[P00027 | 1363:1388 | NORMAL_TEXT]
10:28 Closing invitation

[P00028 | 1388:1389 | NORMAL_TEXT]
⟦EMPTY PARAGRAPH⟧

[P00029 | 1389:1433 | NORMAL_TEXT]
Out of Our Depth: [https://outofourdepth.com](https://outofourdepth.com)

[P00030 | 1433:1476 | NORMAL_TEXT]
Run Your City: [https://www.runyourcity.org](https://www.runyourcity.org)

[P00031 | 1476:1544 | NORMAL_TEXT]
AI@GSB: [https://www.gsb.stanford.edu/experience/learning/applied-ai](https://www.gsb.stanford.edu/experience/learning/applied-ai)

[P00032 | 1544:1545 | NORMAL_TEXT]
⟦EMPTY PARAGRAPH⟧

[P00033 | 1545:1768 | NORMAL_TEXT]
Research note: when we say women are "20% behind," that's the relative gap in generative AI use from a 2025 analysis of 18 studies: [https://www.hbs.edu/ris/Publication%20Files/25023_52957d6c-0378-4796-99fa-aab684b3b2f8.pdf](https://www.hbs.edu/ris/Publication%20Files/25023_52957d6c-0378-4796-99fa-aab684b3b2f8.pdf)

[P00034 | 1768:1769 | NORMAL_TEXT]
⟦EMPTY PARAGRAPH⟧

[P00035 | 1769:1797 | NORMAL_TEXT]
#AI #Podcast #OutOfOurDepth

[P00036 | 1797:1798 | NORMAL_TEXT]
⟦EMPTY PARAGRAPH⟧

[P00037 | 1798:1823 | HEADING_1]
Episode 2 - AI landscape

[P00038 | 1823:1824 | NORMAL_TEXT]
⟦EMPTY PARAGRAPH⟧

[P00039 | 1824:1859 | NORMAL_TEXT]
Thumbnail: WAIT, WHAT'S A MODEL?! 

[P00040 | 1859:1861 | NORMAL_TEXT]
[INLINE_OBJECT kix.hfsn08kw1k8f]

[P00041 | 1861:1862 | NORMAL_TEXT]
⟦EMPTY PARAGRAPH⟧

[P00042 | 1862:1917 | NORMAL_TEXT]
Title: Who's Who in AI (Explained With a Toyota Prius)

[P00043 | 1917:1918 | NORMAL_TEXT]
⟦EMPTY PARAGRAPH⟧

[P00044 | 1918:4496 | NORMAL_TEXT]
Description:Claude, ChatGPT, Opus, Astra, tokens, open weights... if you've ever nodded along to an AI conversation while secretly having no clue what anyone meant, this one's for you. (Us too. Like, yesterday.)This is our who's who of AI: who actually builds the models, the difference between a model and the app you're typing into (the model is the engine, the app is the car, and tokens are the gas; stay with us). Then it gets a little spicy. Mary thinks the world's best mathematicians are about to matter less, Josh disagrees, and we rank Demis, Dario, Sam, and Elon from most to least loved.What AI word do you still secretly not understand? Drop it in the comments or email hi@outofourdepth.com and we'll tackle it. No stupid questions (we asked most of them in this episode).Chapters00:00 Data centers on the moon? (hook and intro)00:14 The AI landscape, explained01:09 Who actually builds the models02:20 Claude vs. ChatGPT: what we actually use05:12 Gemini, the Dodgers of AI06:20 Open vs. closed models06:44 How models actually learn08:49 The car analogy: models vs. apps12:28 Why are the model names so bad?13:26 Tokens are gas14:35 Are mathematicians out of a job?18:33 Jobs vs. tasks20:16 Who gets left behind21:36 Mary's coding midterm (29 or 92?)24:18 What's overhyped24:59 What we're betting on: being human27:14 NVIDIA and the wider AI market28:22 Why it's so easy to switch29:44 How do open models make money?33:05 On-prem vs. the cloud (and the moon)35:05 Dario and the Anthropic origin story37:40 When AI breaks the rules42:07 Sam, Zuck, and Elon45:56 Ranking the AI leaders49:21 Mary's last three AI chats52:04 See you next timeOut of Our Depth:[https://www.outofourdepth.com/](https://www.outofourdepth.com/)[https://www.outofourdepth.com](https://www.outofourdepth.com/)Run Your City:[https://www.runyourcity.org/](https://www.runyourcity.org/)[https://www.runyourcity.org](https://www.runyourcity.org/)AI@GSB:[https://www.gsb.stanford.edu/experience/learning/applied-ai](https://www.gsb.stanford.edu/experience/learning/applied-ai)[https://www.gsb.stanford.edu/experience/learning/applied-ai](https://www.gsb.stanford.edu/experience/learning/applied-ai)Research notes:On AI and math: OpenAI published ten results in mathematics and theoretical computer science obtained by an internal model. These are the company's reported findings; our discussion about what they mean for mathematicians is opinion. Read the report:[https://cdn.openai.com/pdf/ten-proofs-oai.pdf](https://cdn.openai.com/pdf/ten-proofs-oai.pdf)[https://cdn.openai.com/pdf/ten-proofs-oai.pdf](https://cdn.openai.com/pdf/ten-proofs-oai.pdf)More on Astra and the math results:[https://the-decoder.com/openai-announces-its-next-major-model-astra-by-dropping-ten-previously-unsolved-math-solutions/](https://the-decoder.com/openai-announces-its-next-major-model-astra-by-dropping-ten-previously-unsolved-math-solutions/)[https://the-decoder.com/openai-announces-its-next-major-model-astra-by-dropping-ten-previously-unsolved-math-solutions](https://the-decoder.com/openai-announces-its-next-major-model-astra-by-dropping-ten-previously-unsolved-math-solutions/)On Demis: Google announced that Demis Hassabis handed over day-to-day Google DeepMind operations to become its chair and Alphabet's chief scientist:[https://blog.google/company-news/inside-google/message-ceo/next-chapter-ai-momentum/](https://blog.google/company-news/inside-google/message-ceo/next-chapter-ai-momentum/)[https://blog.google/company-news/inside-google/message-ceo/next-chapter-ai-momentum](https://blog.google/company-news/inside-google/message-ceo/next-chapter-ai-momentum/)#AI #Podcast #OutOfOurDepth

[P00045 | 4496:4497 | NORMAL_TEXT]
⟦EMPTY PARAGRAPH⟧

[P00046 | 4497:4539 | HEADING_1]
Episode 3 - Projects, Connectors & Skills

[P00047 | 4539:4540 | NORMAL_TEXT]
⟦EMPTY PARAGRAPH⟧

[P00048 | 4540:4573 | NORMAL_TEXT]
Thumbnail: AI FEATURES WE EAT UP

[P00049 | 4573:4575 | NORMAL_TEXT]
[INLINE_OBJECT kix.sgo85bo0r9c6]

[P00050 | 4575:4576 | NORMAL_TEXT]
⟦EMPTY PARAGRAPH⟧

[P00051 | 4576:4663 | NORMAL_TEXT]
Title: Projects, Connectors & Skills… Take Your AI From Fresh Intern to Full-Time Hire

[P00052 | 4663:4664 | NORMAL_TEXT]
⟦EMPTY PARAGRAPH⟧

[P00053 | 4664:4921 | NORMAL_TEXT]
Description:Ever asked AI something and gotten an answer so generic it could've been for anyone? Same. These are the three features that fixed that for us: projects, connectors, and skills. We use them every day and tell our friends to set them up first.

[P00054 | 4921:4922 | NORMAL_TEXT]
⟦EMPTY PARAGRAPH⟧

[P00055 | 4922:5257 | NORMAL_TEXT]
We explain all three with one very committed intern metaphor, then get into what we've actually built: a grant finder that posts straight into our nonprofit's Slack, a newsletter that reads Josh's 20 other newsletters so he doesn't have to, and the brand skill Josh stole from Mary. Also, Josh cannot go to bed with unused AI credits.

[P00056 | 5257:5258 | NORMAL_TEXT]
⟦EMPTY PARAGRAPH⟧

[P00057 | 5258:6274 | NORMAL_TEXT]
What's the most repetitive thing you do every week? Drop it in the comments or email hi@outofourdepth.com and we might try turning it into a skill on the show.Chapters00:00 Intro: why these three features01:43 Projects: give your AI a desk04:56 Mary's fitness project05:59 Connectors, Granola and recording consent08:12 Skills: reusable workflows08:45 Josh's bank account skill09:56 Teaching a skill by showing the workflow10:49 Projects vs. skills (hello, Dyslexify)11:56 Claude Design and Wispr Flow13:40 Leveling up your intern14:33 The brand skill Josh stole from Mary15:42 Humanizer: less AI slop16:29 The skills behind this podcast17:23 Josh vs. unused credits19:01 Why AI tells make people tune out19:49 Composio: connecting multiple accounts21:43 Recap: projects, connectors and skills22:22 One newsletter instead of 2023:37 A grant finder for Run Your City26:07 Rebuilding our whole website27:52 Why human effort still matters29:53 Where AI missed the mark32:09 What's next: agents

[P00058 | 6274:6275 | NORMAL_TEXT]
⟦EMPTY PARAGRAPH⟧

[P00059 | 6275:6430 | NORMAL_TEXT]
Out of Our Depth:[https://outofourdepth.com/](https://outofourdepth.com/)[https://outofourdepth.com](https://outofourdepth.com/)Run Your City:[https://www.runyourcity.org/](https://www.runyourcity.org/)[https://www.runyourcity.org](https://www.runyourcity.org/)AI@GSB:[https://www.gsb.stanford.edu/experience/learning/applied-ai](https://www.gsb.stanford.edu/experience/learning/applied-ai)[https://www.gsb.stanford.edu/experience/learning/applied-ai](https://www.gsb.stanford.edu/experience/learning/applied-ai)

[P00060 | 6430:6431 | NORMAL_TEXT]
⟦EMPTY PARAGRAPH⟧

[P00061 | 6431:6544 | NORMAL_TEXT]
Tools we mentionComposio:[https://composio.dev/](https://composio.dev/)[https://composio.dev](https://composio.dev/)Granola:[https://www.granola.ai/](https://www.granola.ai/)[https://www.granola.ai](https://www.granola.ai/)Wispr Flow:[https://wisprflow.ai/](https://wisprflow.ai/)[https://wisprflow.ai](https://wisprflow.ai)

[P00062 | 6544:6545 | NORMAL_TEXT]
⟦EMPTY PARAGRAPH⟧

[P00063 | 6545:6833 | NORMAL_TEXT]
A note on recording and access: get everyone's OK before recording a meeting with a tool like Granola. California generally requires all parties' consent to record a confidential conversation:[https://leginfo.legislature.ca.gov/faces/codes_displaySection.xhtml?lawCode=PEN&sectionNum=632](https://leginfo.legislature.ca.gov/faces/codes_displaySection.xhtml?lawCode=PEN&sectionNum=632)[https://leginfo.legislature.ca.gov/faces/codes_displaySection.xhtml?lawCode=PEN&sectionNum=632](https://leginfo.legislature.ca.gov/faces/codes_displaySection.xhtml?lawCode=PEN&sectionNum=632)

[P00064 | 6833:6834 | NORMAL_TEXT]
⟦EMPTY PARAGRAPH⟧

[P00065 | 6834:7007 | NORMAL_TEXT]
Composio is a third-party service, so check the permissions you're granting when you connect your accounts:[https://docs.composio.dev/docs/authentication/controlling-scopes](https://docs.composio.dev/docs/authentication/controlling-scopes)[https://docs.composio.dev/docs/authentication/controlling-scopes](https://docs.composio.dev/docs/authentication/controlling-scopes)

[P00066 | 7007:7008 | NORMAL_TEXT]
⟦EMPTY PARAGRAPH⟧

[P00067 | 7008:7036 | NORMAL_TEXT]
#AI #Podcast #OutOfOurDepth

[P00068 | 7036:7037 | NORMAL_TEXT]
⟦EMPTY PARAGRAPH⟧

[P00069 | 7037:7038 | NORMAL_TEXT]
⟦EMPTY PARAGRAPH⟧

[P00070 | 7038:7040 | NORMAL_TEXT]
—

[P00071 | 7040:7041 | NORMAL_TEXT]
⟦EMPTY PARAGRAPH⟧

[P00072 | 7041:7052 | HEADING_1]
Episode XX

[P00073 | 7052:7053 | NORMAL_TEXT]
⟦EMPTY PARAGRAPH⟧

[P00074 | 7053:7064 | NORMAL_TEXT]
Thumbnail:

[P00075 | 7064:7065 | NORMAL_TEXT]
⟦EMPTY PARAGRAPH⟧

[P00076 | 7065:7066 | NORMAL_TEXT]
⟦EMPTY PARAGRAPH⟧

[P00077 | 7066:7074 | NORMAL_TEXT]
Title: 

[P00078 | 7074:7075 | NORMAL_TEXT]
⟦EMPTY PARAGRAPH⟧

[P00079 | 7075:7088 | NORMAL_TEXT]
Description:

[P00080 | 7088:7089 | NORMAL_TEXT]
⟦EMPTY PARAGRAPH⟧

## Podcast Ideas (t.3su0y9bom91t)

[P00081 | 1:15 | NORMAL_TEXT]
Podcast ideas

[P00082 | 15:28 | NORMAL_TEXT]
This weekend

[P00083 | 28:88 | NORMAL_TEXT | LIST id=kix.etzju01y0l76 level=0]
What's an agent?! Chatbots answer, agents act (part 1 of 2)

[P00084 | 88:149 | NORMAL_TEXT | LIST id=kix.etzju01y0l76 level=1]
Need mental model, what’s possible now + current limitations

[P00085 | 149:297 | NORMAL_TEXT | LIST id=kix.etzju01y0l76 level=0]
Personal agents + productivity hacks: Muse, Instinct, dots and Grok Bot, what they are, what we like, and what we'd never let them do (part 2 of 2)

[P00086 | 297:401 | NORMAL_TEXT | LIST id=kix.etzju01y0l76 level=0]
Model deep dive, Gemini 4: Google's new top model, why it matters, and why almost nobody can use it yet

[P00087 | 401:495 | NORMAL_TEXT | LIST id=kix.etzju01y0l76 level=0]
OpenAI, chill with it: GPT-6, the "is this AGI?" claim, and ChatGPT turning into an app store

[P00088 | 495:585 | NORMAL_TEXT | LIST id=kix.etzju01y0l76 level=0]
Why are Sam + Dario slowing down? Gated launches, and why it can't just be for our safety

[P00089 | 585:700 | NORMAL_TEXT | LIST id=kix.etzju01y0l76 level=0]
The future?! Our bet on the future of work: which jobs and skills matter now, and what we'd do if we were 22 again

[P00090 | 700:810 | NORMAL_TEXT | LIST id=kix.etzju01y0l76 level=0]
Staying up to date: ~30 minutes a day, how we built our X, our newsletter (audio + not), and podcasts we like

[P00091 | 810:886 | NORMAL_TEXT | LIST id=kix.etzju01y0l76 level=0]
AI tool tier list: everything we pay for, ranked, and whether it's worth it

[P00092 | 886:1014 | NORMAL_TEXT | LIST id=kix.etzju01y0l76 level=0]
Privacy + break-ins: rogue agents going off script, plus what AI knows about us (ads, health data, the settings we're changing)

[P00093 | 1014:1098 | NORMAL_TEXT | LIST id=kix.etzju01y0l76 level=0]
Everything that enables AI: chips, data centers, electricity, and who controls them

[P00094 | 1098:1184 | NORMAL_TEXT | LIST id=kix.etzju01y0l76 level=0]
Is AI bad for the planet? The energy and water question everyone's embarrassed to ask

[P00095 | 1184:1287 | NORMAL_TEXT | LIST id=kix.etzju01y0l76 level=0]
The voices of AI: the builders, researchers, and skeptics, what they're like, and Mary draws them live

[P00096 | 1287:1340 | NORMAL_TEXT | LIST id=kix.etzju01y0l76 level=0]
Future of AI in XX industry (healthcare, education, 

[P00097 | 1340:1426 | NORMAL_TEXT | LIST id=kix.etzju01y0l76 level=0]
AI x RYC hackathon: an AI board member and an AI hiring panel (hire, intern, or pass)

[P00098 | 1426:1427 | NORMAL_TEXT]
⟦EMPTY PARAGRAPH⟧

## Notes (t.nlz85f4bboz8)

[P00099 | 1:7 | NORMAL_TEXT]
Links

[P00100 | 7:69 | NORMAL_TEXT | LIST id=kix.lkj751s322ll level=0]
Youtube: [www.youtube.com/watch?v=XB4LpkVXgqA&feature=youtu.be](http://www.youtube.com/watch?v=XB4LpkVXgqA&feature=youtu.be)

[P00101 | 69:187 | NORMAL_TEXT | LIST id=kix.lkj751s322ll level=0]
Spotify: [https://open.spotify.com/episode/1oBgq6Spwsm8ExNowZwoNV?si=XtjEGGejRSCBiPlCNI8Npg&nd=1&dlsi=1ba08e2ae45f44cc](https://open.spotify.com/episode/1oBgq6Spwsm8ExNowZwoNV?si=XtjEGGejRSCBiPlCNI8Npg&nd=1&dlsi=1ba08e2ae45f44cc)

[P00102 | 187:223 | NORMAL_TEXT | LIST id=kix.lkj751s322ll level=0]
Website: [https://outofourdepth.com/](https://outofourdepth.com/)

[P00103 | 223:224 | NORMAL_TEXT]
⟦EMPTY PARAGRAPH⟧

[P00104 | 224:470 | NORMAL_TEXT]
I need to come up with a marketing plan for the Out of Our Depth podcast. We just launched our first video, our first YouTube video, and our website. We have Instagram, Twitter, LinkedIn, and Facebook, and you can watch it on YouTube or Spotify.

[P00105 | 470:471 | NORMAL_TEXT]
⟦EMPTY PARAGRAPH⟧

[P00106 | 471:742 | NORMAL_TEXT]
I'm trying to understand what to prioritize. Is there a way to make short-form content from long-form? Is it first helpful to prioritize making a lot of videos? This weekend, right now, we just have a "Why We're Here." We already have "AI Landscape" and one more filmed.

[P00107 | 742:743 | NORMAL_TEXT]
⟦EMPTY PARAGRAPH⟧

[P00108 | 743:1122 | NORMAL_TEXT]
What thoughts, more broadly, but also super tactically, on how to prioritize? I have a lot of personal followers, so could I share on Instagram? I would also want to get an understanding of what's helpful to post, if at all, or should we just lean into YouTube and watch and think about the other ones? I probably need something on the other ones, or maybe just a "Coming Soon."

[P00109 | 1122:1123 | NORMAL_TEXT]
⟦EMPTY PARAGRAPH⟧

[P00110 | 1123:1259 | NORMAL_TEXT]
Help me create a marketing plan to launch this, and then Sunday we want to both post on our LinkedIns. I can also post on my Facebook. 

