# Previous episode descriptions: chapter-spacing audit

- Date: 2026-09-30.
- Target edited in place: [OOOD Marketing & Episodes Brainstorm](https://docs.google.com/document/d/1AvDfSBg6xxMyGNH7D9JhbGEzm3NP46459uxMoQDLSXc/edit), tab `t.93h9qj1tx8d5` (YouTube + Spotify Details).
- Authority: Josh requested review and fixes to previous descriptions after adopting the 30-second Spotify-compatible chapter default.
- Source rule: [Spotify Episode chapters](https://support.spotify.com/us/creators/article/episode-chapters/), official undated help checked 2026-09-30. At least three chronological plain-text entries, first 00:00, and 30 seconds between starts. OOOD also keeps the final chapter at least 30 seconds.
- Preserve the document's current public episode labels: its Episode 1 is local E000 (intro); Episode 2 is local E001 (AI landscape); Episode 3 is local E002 (projects/connectors/skills). This scope did not authorize renumbering episodes.

## Verified results

| Document section | Final cut used | Chapters | Shortest start gap | Final chapter length | Result |
|---|---|---|---|---|---|
| Episode 1: intro | E000 `release/episode-000.mp4`, 11:20.867 | 10 | 42 seconds | 52.867 seconds | First read showed 00:11; a concurrent edit changed it to 00:00 before Codex's write. Verified compliant; no additional text change needed. |
| Episode 2: AI landscape | E001 `edit/codex-handcover-episode0-outro-2026-09-30/episode-001-full-review-v2.mp4`, 52:25.733 | 23 | 41 seconds | 184.733 seconds | Three targeted merges saved and verified in the native document. |
| Episode 3: projects/connectors/skills | E002 `edit/codex-user-hook-2026-09-30/episode-002-full-review-v3.mp4`, 33:14.267 | 23 | 33 seconds | 65.267 seconds | Already uses corrected v2 list; passes. |

## AI-landscape changes

- 00:00 cold open/intro + 00:14 landscape setup → `00:00 Data centers on the moon? + AI intro`.
- 06:20 open/closed models + 06:44 learning explanation → `06:20 Open vs. closed: how models learn`.
- 49:21 recent chats + 52:04 goodbye → `49:21 Mary's last three AI chats and goodbye`.

All retained timestamps preserve final-cut anchors from `01_EPISODES/E001-ai-basics/codex-youtube-chapter-audit-2026-09-30.md`. Episode 000 times were checked against current MP4 metadata and selected SRT cues; MP4 duration was rechecked for E000 and E001. No media rerender was needed.

## Write and readback evidence

A strict revision-guarded batch was rejected because the document changed concurrently; it made no changes. The fresh read showed the intro's first start was already fixed. Codex then used three exact-text replacements scoped solely to the verified YouTube + Spotify Details tab, avoiding stale positional indexes. Each replacement reported one occurrence changed. Full connector readback confirmed the requested text and chapter intervals.

The details tab's text matches exactly the fresh pre-write text plus these three replacements; existing links, images, chapter typography (Poppins 9pt), and the three-tab topology were preserved. Other concurrent edits were observed in the Podcast Ideas tab, including two opaque controls. Those controls are outside the description scope; Codex did not modify that tab. Full-document readback evidence is kept in a Git-ignored local folder.

## Current copy and status

- Intro snapshot: `01_EPISODES/E000-why-were-here/codex-description-final-cut-2026-09-30.txt`, copied from verified current document text.
- AI-landscape snapshot: `01_EPISODES/E001-ai-basics/codex-description-final-cut-v2-2026-09-30.txt`, matching the corrected document text. Supersedes the older local 26-chapter YouTube-only description for shared-platform use.
- The Google Doc was updated; no YouTube or Spotify description was changed, no episode was uploaded or scheduled, and this check does not establish continuous host review or caption auditory proof.
