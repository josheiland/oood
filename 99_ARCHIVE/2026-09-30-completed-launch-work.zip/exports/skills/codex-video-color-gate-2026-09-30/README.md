# Producer skill with enforced video color gate

Created 2026-09-30 in a fresh Codex folder, preserving prior portable packages. Includes live producer instructions, per-frame/coded-header verifier, updated render/QC implementation, current project/editorial/brand snapshots and assets. Local Codex and Claude discovery symlinks use the live updated skill. Portable upload was not performed.

ZIP integrity and inclusion checks passed. Actual behavioral verification: original E002 export is rejected; repaired full export passes all coded headers and frames; two-second hook/intro regression passes all baseline render checks after a first failing test revealed encoder-only tagging was insufficient. The prior skill-validator runtime lacks PyYAML, so frontmatter was kept unchanged and validation focused on these meaningful production cases.
