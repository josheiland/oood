# OOOD release-package portable update

Created 2026-09-30 in a new Codex folder, preserving all earlier packages. This ZIP contains the live release-package skill with Josh's Spotify-compatible chapter rule, plus current project, editorial and brand snapshots. Discovery symlinks for local Codex and Claude both use the updated live skill. The ZIP is ready for manual upload if a portable Claude skill is used; no upload or automatic cross-app sync occurred.

Source is `skills/oood-release-package/`; snapshots use the same source mapping and link normalization as `scripts/package-oood-skills.py`, written inside this new ZIP to avoid overwriting older packages or other skills' generated files.

Verification: ZIP integrity passed, the packaged skill includes the 30-second rule, and its project snapshot references the current v2 description. The standard skill validator could not run because PyYAML is absent from both available Python runtimes. The existing name/description frontmatter is unchanged; the new guidance was inspected and the actual 23-chapter intervals were verified.
