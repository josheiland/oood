# Project brief

Last updated: 2026-09-30

## Identity

**Out of Our Depth** is an AI-focused show created and hosted by **Josh Eiland and Mary**. The name reflects the hosts' position: curious, capable people learning a fast-moving field in public, testing what is useful, and translating it for others without pretending to know everything.

## Purpose

Help intelligent, busy people understand what is changing in AI, why it matters, and how to use it in real life and in organizations.

The show should:

- make AI developments understandable without flattening the important nuance;
- connect news and technical concepts to concrete decisions and workflows;
- show honest experimentation, including what did not work;
- combine broad relevance with grounded experience from building and operating organizations.

## Hosts and distinctive perspective

- Josh is an MBA student at Stanford GSB and COO of Run Your City.
- Mary is the founder and CEO of Run Your City.
- Their shared operating experience gives the show a credible lens on AI adoption in nonprofits and lean organizations.
- Their advantage is not claiming to be frontier AI researchers. It is asking the questions thoughtful non-experts actually have, doing the work to find solid answers, and translating the implications.

## Audience

Primary audience:

- curious professionals who want to understand and use AI;
- organization leaders and operators deciding where AI is genuinely useful;
- people who find much AI coverage either too technical, too promotional, or too shallow.

Some episodes will serve narrower groups—such as nonprofit leaders—while remaining useful to a broader audience.

## Editorial positioning

- Curious, direct, practical, and intellectually honest.
- Explain jargon when it matters; avoid jargon as status signaling.
- Be excited about meaningful capabilities without becoming uncritical boosters.
- Surface uncertainty, limitations, tradeoffs, and evidence quality.
- Use Josh and Mary's real experiences when they illuminate the topic.
- Prioritize teachable frameworks, memorable examples, and practical takeaways.
- Keep the energy modern and culturally current, not corporate or overly polished.
- Keep the show casual, relatable, and entertaining. The role of screen-share demonstrations versus a complete audio experience remains unresolved; Josh reaffirmed this priority and tradeoff on 2026-09-25.
- Make the content fun and accessible, and build audience affection for Josh, Mary, and their relationship/dynamic. This is a core goal for episode structure and editing, not just added jokes or graphics. Preserve genuine reactions, affectionate disagreement, and both hosts' judgment. See `00_CONTEXT/editorial-direction.md`.
- No emojis by default in project copy.

## Content model

Working cadence: two main videos per week.

1. **Current developments:** consequential AI news, launches, debates, and what they mean.
2. **Deep dives:** a concept, sector, workflow, tool category, or use case explained and tested.

Short-form clips and social posts should be derived from strong moments rather than treated as disconnected content.

## Initial launch inventory

**Drive archive and local cleanup (2026-09-30):** Josh confirmed all three launch episodes are published on **YouTube and Spotify**, superseding earlier unresolved Spotify retry status. At his request, essential release sets are now under [Video Files/Final](https://drive.google.com/drive/folders/1IR0qHIE4TglkJuy1qlH1bCcBEaH662Rj), one folder per episode: final MP4, matching SRT, current published YouTube thumbnail, saved description/chapters and manifest. Every uploaded file passed Drive-parent, size and MD5 readback; a compact ZIP preserves lightweight production records. Raw recordings remain in [Video Files/Raw](https://drive.google.com/drive/folders/1KrXgS2Ms6MSz6KXF5YWz1M3fZ_6_fshm), with all three local source duplicates rechecked by MD5 before removal. Large media exports/intermediates were removed after archive verification, including the 15 outdated jtan comparison/tester/audio files Josh subsequently explicitly approved. This chat reclaimed 22.954 GiB in total. Small source hooks, shared brand assets and lightweight project/edit/research records from both agents remain local. The abandoned E002 continuous encode was excluded because Josh stopped that chat and said no new render was needed. [Current archive receipt](../01_EPISODES/codex-drive-archive-2026-09-30/README.md) supersedes earlier local-media pointers below; exact public platform bytes and caption auditory proof were not independently checked.

**Current YouTube publication status (2026-09-30):** Josh confirmed that all three launch episodes are posted. The official channel feed independently verifies the current public uploads: [Episode 000](https://www.youtube.com/watch?v=y0NH_zvAdEo), [Episode 001](https://www.youtube.com/watch?v=-YWPmoWKbrM), and [Episode 002](https://www.youtube.com/watch?v=d-ykZl4WHjo), published September 30 in that order. Episode 000's September 29 URL below is historical; use the September 30 URL for current website links. This supersedes the earlier unconfirmed YouTube publication status in the production history below. Public availability does not independently establish byte identity with local exports, caption proof, or the outcome of Episode 001's Spotify repair. Josh requested that the website show the three published episodes. The update is deployed and verified at [outofourdepth.com](https://outofourdepth.com): 002 is featured and 001/000 appear beneath it, with verified fallbacks and the automatic latest-upload lookup retained. Josh subsequently directed the website to use the exact YouTube titles, including capitalization and punctuation, rather than the shortened index titles.

The hosts reviewed the first rough cut on 2026-09-23 and chose to reshoot it. Josh supplied the Episode 2 reshoot on 2026-09-25. Their proposed first-three release order is:

1. **Episode 000 — Why we're here:** introduce Josh and Mary, their dynamic, and what the show offers.
2. **Episode 001 — AI basics:** explain generative AI and the difference between a company, model, and app.
3. **Episode 002 — Make AI useful:** use Projects/context, connectors, and reusable skills to show how AI becomes more useful.

The [three-tab episode-primer Google Doc](https://docs.google.com/document/d/1gWK3_jPo7-Y5J_zjiGggAhPWY-EtNpHh5X3jszLH6bY/edit) and `01_EPISODES/launch-primers-draft.md` contain concise chronological bullet outlines for recording, built around a hook, clear route, concrete examples, and a recall-and-action close. Run Your City is one recurring source of examples, not the audience boundary. The proposed release target is Sunday night, 2026-09-27, with a coordinated marketing push after all three are ready; the earlier Episode 2 recording is confirmed by its supplied reshoot. Episode 0 and Episode 1 recordings are confirmed below. Episode 000 was published on YouTube and Spotify per Josh on 2026-09-29; all three current YouTube uploads are now confirmed above.

Josh supplied `/Users/je/Movies/Episode 0 Raw.mp4` on 2026-09-26 (11:05.500, 1080p30). He chose to preserve the organic conversation, remove callouts and the post-wrap ending, and center both voices. Josh personally trimmed `edit/Hook_Final.mp4`, which remains the exact honeymoon-photo cold open. The prior Episode 000 version was published on YouTube (`https://www.youtube.com/watch?v=XB4LpkVXgqA`) and Spotify (`https://open.spotify.com/episode/1oBgq6Spwsm8ExNowZwoNV`) on 2026-09-29 per Josh's report in the decisions ledger. On 2026-09-30 he approved the recurring cards and requested their incorporation for re-publication. The current local `release/episode-000.mp4` is the updated **11:20.867** export: intro tagline `FIGURING OUT AI TOGETHER`, no intro episode-number label or outro top show-name label, and outro prompts raised 48 pixels. The exact hook, full conversation, copied AAC audio, music, final fade, SRT and all 13 chapters retain their timeline. Full decode and sampled boundary/card checks passed; details are in `edit/codex-mono-mirrored/episode-000-recurring-cards-v11-qc.md`. The stable release filename was replaced after checks to keep one current video; no platform re-upload was performed. Raw footage, the user hook and other agents' files were preserved. Josh confirmed music rights on 2026-09-28; the rights document is not in this repo. Earlier caption, personal-material and research review notes remain historical and are not evidence of a new check of the published platform version.

Mary supplied the Episode 000 thumbnail layout on 2026-09-28. Josh directed a native-font recreation and adoption of that paired-host format for future full-episode thumbnails, then supplied a clean copy of the posed photo. The current 1280 × 720 release JPEG is `release/episode-000-thumbnail.jpg`; its editable SVG, clean photo, JSON copy and renderer are in `03_ASSETS/codex-mary-thumbnail-template/`. Superseded thumbnail, hook-preview and card-comparison assets were removed on 2026-09-29 at Josh's request, freeing about 725 MiB. Draft YouTube and Spotify descriptions are in `01_EPISODES/E000-why-were-here/PUBLISHING.md`. The copy remains a saved proposal; the publication report is recorded separately above.

Josh supplied `/Users/je/Movies/Episode 1 Raw.mp4` on 2026-09-26. The source is 55:47.233 at 1080p30, with four identical audio mixes. After questioning whether the first **9:58.367** proposal cut too much, Josh and Mary requested that **most of the raw episode stay intact**, with the hand-cover start/end, their specified flubs, and only clear factual mistakes removed. Josh also asked to restore the provider rankings, Harvey/OpenEvidence, token/usage intuition, GPU slip with correction, Mary's permissions preference, open-model comparison, Chinese subsidy, on-prem hospital, and OpenAI structure discussions. The 53:24.900 `episode-01-clean-review-v7.mp4` preserves this conversation with only seven raw-source removals, five four-frame internal joins and four brief factual pop-ups. On 2026-09-29 Josh asked for eight short hook previews and one full music version with the updated three-digit Mono, Mirrored cards. Those [eight 31–37-second previews](../01_EPISODES/E001-ai-basics/edit/codex-hook-options-2026-09-29/README.md) show a hook, 5.267-second title/music, and the first 15.933 seconds of the episode. The 53:51.433 `episode-001-full-review-v5.mp4` uses the model-names hook, then the full clean v7 conversation, and an outro with Josh's exact two asks. The prior blue/white theme v8 is historically documented but its video file was absent at the 2026-09-29 check. The Hallie anecdote and verified Demis Hassabis role-change and model sandbox-escape discussions remain. The exact removals are in `01_EPISODES/E001-ai-basics/edit/episode-01-removed-footage-v6.md`. V5, v4 and v3 are shorter historical comparison cuts; their length never meant most footage was unusable. At that stage, continuous audiovisual viewing, auditory caption proof, personal-detail approval, hook selection and exact-export host approval were open. Josh confirmed the proposed theme's music rights are cleared on 2026-09-28. At that review stage, no Episode 001 scheduling or publication was claimed; current YouTube publication is confirmed above. The older `001-make-your-ai-useful` folder is the earlier practical-tools recording, not this Episode 1 source.

**Episode 001 current host-review export (2026-09-30):** Josh selected his exact saved `ep1hook.mp4` after confirming it contains the moon/data-center exchange and directed the NVIDIA discussion shortened for listener focus. The [current 52:25.733 full review](../01_EPISODES/E001-ai-basics/edit/codex-handcover-episode0-outro-2026-09-30/episode-001-full-review-v2.mp4) keeps the brief NVIDIA setup but removes the raw 28:54.867–30:17.867 GPU detour. Its first picture after the recurring tagline intro begins with Mary's hand already obscuring the camera at raw 00:15.833; the approach to the lens is gone. The outro uses Episode 000's **exact three prompts**, current raised layout, music and fade, superseding the earlier Episode 001-specific two-ask page. The two GPU correction pop-ups fall in the detour cut, leaving two factual clarification cards. [All eight exact raw-source removals](../01_EPISODES/E001-ai-basics/edit/codex-handcover-episode0-outro-2026-09-30/removed-footage.md) and technical checks are documented in the new folder. The 52:26.567 two-ask export and earlier model-names-hook version remain for comparison. Continuous exact-export host review and auditory caption proof remain open. At that review stage, no Episode 001 upload, scheduling or publication was confirmed; current YouTube publication is confirmed above. The [current YouTube description draft](../01_EPISODES/E001-ai-basics/codex-description-final-cut-v2-2026-09-30.txt) uses visible HTTPS links and 23 detailed final-v2 chapters, including 00:00; the brief NVIDIA chapter and math/Demis notes match the retained content and checked sources. It is saved locally, not applied to YouTube.

**Episode 001 Spotify upload repair (2026-09-30):** Josh reported Spotify rejecting the final v2 because color characteristics change mid-video. The change is at the outro start, 52:14.967: BT.709 primaries/transfer become unspecified. [The corrected Spotify upload file](../01_EPISODES/E001-ai-basics/edit/codex-spotify-color-fix-2026-09-30/episode-001-spotify-upload.mp4) sets explicit limited-range BT.709 tags throughout without recompression. It preserves the 52:25.733 cut, coded picture/audio content, timestamps, all 22 embedded chapters and existing caption/description timing. The previous file remains preserved. No new upload or successful processing is claimed; Spotify retry confirmation remains open.

Josh requested another reshoot of Episode 2 on 2026-09-25. That preparation is recorded in `01_EPISODES/E002-make-ai-useful/reshoot-feedback-and-plan-2026-09-25.md` and the cue sheet. The new take was supplied on September 26. Runtime and example recommendations remained subordinate to the hosts' entertainment and relationship goal; the actual edit follows the recorded conversation.

**Episode 2 reshoot recorded; earlier corrected cut prepared (2026-09-27).** Josh supplied the September 26 `/Users/je/Movies/Episode 2 Raw.mp4` (34:17.100). The earlier proposed cut is `01_EPISODES/E002-make-ai-useful/edit/episode-02-final-cut-v3.mp4` (30:55.600), derived from jtan's v2 assembly of that take. It keeps the kit v2 graphics, cold open and leveled dialogue while removing the unsupported spoken claim that the Humanizer skill is built into Claude. V2 (31:07.300) is preserved for comparison. V3 has retimed captions and chapters, but its Humanizer join clips “makes”; the later fuller cuts below preserve that word. Host continuous review, caption listening proof, name approvals and publication timing remain open; no host approval, scheduling or publication is confirmed.

**Episode 002 mishaps-only cut and hook testers (2026-09-29).** At Josh's request, jtan built eight ~25-second hook testers (`01_EPISODES/E002-make-ai-useful/edit/jtan-hooks-002/`) and a full 33:13.433 theme cut (`edit/jtan-full-002/episode-002-full-credits-hook-jtan-v2.mp4`) from the re-downloaded, hash-verified September 26 raw. It uses the `EPISODE 002` Mono, Mirrored card and outro, with the raw order intact and no pop-ups. Only 86 seconds of clear mishaps are removed (two factual errors, one abandoned restart, the Charlottesville remark, the Canvas story Mary said she wouldn't use, and dead air). The hook is swappable by re-running the builder. Hook choice, continuous host review, caption proof and name approvals remain open; nothing is scheduled or published.

**Episode 002 factual review (2026-09-29).** Josh specified that the show may be spicy but should not spread false information, and asked Codex and Claude to compare clear recording/factual removals. Their discussion initially favored removing or rerecording Josh's broad five-hour usage-window remark, but Josh then explicitly directed that it stay: his usage window is five hours, not daily. The preferred assembly at that stage was the 33:13.433 `edit/jtan-full-002/episode-002-full-credits-hook-jtan-v2.mp4`, which keeps that exchange and omits the seven mishap ranges. The separate 33:05.100 `edit/codex-raw-audit-2026-09-29/episode-002-fact-corrected-codex-v1.mp4` removes an additional 8.333 seconds and remains a technically checked comparison. The removal review, remaining de-identification question for the Charlottesville remark, sources and QC are in that Codex folder and `02_RESEARCH/codex-episode-02-raw-source-checks-2026-09-29.md`. The simple-skills and Granola outbound-call lines stay.

**Episode 002 current review export (2026-09-30).** Josh requested the latest Episode 000 cards/music, then selected his saved `ep2hook.mp4` instead of the credits cold open. The current 33:14.267 [full review](../01_EPISODES/E002-make-ai-useful/edit/codex-user-hook-2026-09-30/episode-002-full-review-v3.mp4) retains the complete seven-second running exchange from `01_EPISODES/E000-why-were-here/edit/ep2hook.mp4`, followed by the exact current recurring cards: `FIGURING OUT AI TOGETHER`, hidden top labels and outro prompts raised 48 pixels. The five-hour exchange, raw order and seven removals stay. All picture after the hook is copied from the prior recurring-card v2; audio is encoded once with matching dialogue/music signals. The 12 chapters and 573 caption cues are retimed to the +25-frame shift. Full decode, measured −16.0 LUFS / −1.4 dBTP and sampled hook/card/boundary/fade checks passed. The hook choice is resolved; continuous host listening, caption proof, named-person comfort and exact-export approval remain open. At that review stage, no upload, schedule or publication was claimed; current YouTube publication is confirmed above. The [current YouTube description draft](../01_EPISODES/E002-make-ai-useful/codex-description-final-cut-v2-2026-09-30.txt) preserves Josh's supplied voice, uses visible HTTPS links and includes 23 detailed chapters rebuilt from this exact export, beginning at 00:00. Composio now appears at 19:49, the newsletter at 22:22 and the grant finder at 23:37. Consent wording is qualified to confidential conversations. The 23 chapter starts are at least 33 seconds apart, and the final chapter lasts 65.267 seconds. The draft and its chapter/source audits are saved locally; no platform update occurred.

The prior September 25 Episode 2 source is now `/Users/je/Movies/Episode 2 Raw - old.mp4` (44:16.033, 1080p30). Its complete proposed cut, `01_EPISODES/E002-make-ai-useful/edit/episode-02-final-cut-v1.mp4` (23:50.733), is preserved as reference for the new reshoot, with leveled dialogue, chapter metadata, explanatory overlays, and a graphic covering one retained source picture dropout. A second dropout falls in removed material. Exact edit choices and source checks accompany it. Technical checks passed, but host approval was not established; it is not the planned release master after the additional-reshoot instruction.

The previous 2026-09-21 recording and edit remain a reference for the reshoot. Eight raw recordings (62:52 total) are present in `01_EPISODES/001-make-your-ai-useful/raw/`. A 25:17 proposed rough cut v1 and five supporting documents are in that episode's `edit/` directory, with export checks and a reproducible edit list. Mary's level was corrected in the prior cut; a separate v2 MP4 adds gentle background-noise reduction. V1 is preserved for comparison, and some room sound remains. Neither cut is host-approved for publication, and the old folder name does not establish the revised episode number.

## Distribution

Confirmed accounts:

- Instagram: `@OutOfOurDepthPod`
- TikTok: `@OutOfOurDepthPod`
- YouTube: `@OutOfOurDepthPod`
- LinkedIn: Out of Our Depth / associated show presence
- X: `@OutOfOurDepthX` because the preferred handle exceeds X's limit
- Facebook: intentionally deferred for now

## Brand and creative direction

Josh updated recurring cards on 2026-09-30: remove the intro episode-number label, use one show-wide tagline instead of episode-specific subtitle copy, and remove the outro top show-name label to accommodate subscribe and recommended-video elements. Native templates omit the labels. Josh approved `FIGURING OUT AI TOGETHER` as the recurring tagline and asked to raise the three outro lines slightly; the exports now move them up 48 pixels with their spacing unchanged. He subsequently clarified that Episode 000's exact three outro prompts are the recurring default, including for Episode 001, unless the hosts direct different copy. End-screen element placement remains open. Episode 000 incorporates the approved cards in its local re-upload export; the current Episode 001 and Episode 002 host-review exports use that same intro style and exact outro card.

- Logo and cover art were created by Mary.
- Music direction: modern, catchy, and vibey, with hip-hop influence; avoid old-fashioned, generic ringtone, or stock-corporate energy.
- Variations explored include disco/funk, soul/retro, and dream-pop directions.
- Josh designated the latest downloaded `Out of Our Depth Brand Kit.zip` as the source for future podcast visuals. Preserved locally in `03_ASSETS/brand-kit/`; source hash and status are recorded in the asset manifest. `03_ASSETS/brand-guidelines.md` and `brand-tokens.json` capture operational rules.
- Teachers typography; blue `#38B6FF`, cream `#FBF1E5`, foam `#FDF8F2`, navy `#0B2A45`, tint `#A9DCFF`, small-type blue `#0E6FC0`; cream/foam waterline. Follow the kit's square, two-line icon specification despite older circular art in the ZIP.
- Mary's paired-host thumbnail format is the current direct host design for full episodes: close real photo, upper-left blue square lockup, and lower-left navy bar with three-digit episode title. Its sampled blue/cream/navy colors and native Teachers layout are in `03_ASSETS/brand-guidelines.md` and `03_ASSETS/codex-mary-thumbnail-template/`.
- Four reusable production skills are in `skills/`, with project discovery links and portable Claude ZIP packages. Usage/model guidance is in `00_CONTEXT/production-skills-and-models.md`.

## Production setup

Current known setup:

- Recording in OBS.
- Logitech camera.
- Record at 1920 × 1080 rather than 4K.
- Set both OBS and Logi Tune to 1080p. Leaving Logi Tune at 4K caused accumulating video delay relative to audio.
- A roughly 15-minute test after matching both settings showed little to no delay; a full-episode validation is still needed.
- Test-recording audio quality was reported as good.
- Final microphone choice and finalized production checklist are not yet recorded here.

## Current priorities

1. Review and approve the proposed Episode 0, Episode 1 and corrected Episode 2 cuts, captions, personal details and copy. Make the hosts' dynamic central; confirm release timing separately.
2. Record, edit, fact-check, and review all three proposed launch episodes against the Sunday-night target; confirm release timing before any publication claim.
3. Turn publication claims into a traceable source pack.
4. Finalize the repeatable recording, editing, clip, and publishing workflow.
5. Define the newsletter's role and cadence.
6. Apply the supplied brand kit consistently; finish canonical logo/platform exports, music choice, and production assets where still unresolved.


**Shared description chapter review (2026-09-30):** Josh asked Codex to review prior descriptions in [OOOD Marketing & Episodes Brainstorm](https://docs.google.com/document/d/1AvDfSBg6xxMyGNH7D9JhbGEzm3NP46459uxMoQDLSXc/edit). The document labels the intro Episode 1, AI landscape Episode 2, and projects/connectors/skills Episode 3; those labels were preserved. The intro now begins at 00:00 after a concurrent edit and passes with ten chapters. Codex saved three merges to the AI-landscape list, yielding 23 chapters with at least 41 seconds between starts. The projects/connectors/skills list already passes with 23 chapters and at least 33 seconds between starts. All final chapters exceed 30 seconds. Full native readback verified the edits; local copy snapshots and [audit](../02_RESEARCH/codex-prior-descriptions-chapter-audit-2026-09-30.md) match. No YouTube/Spotify platform description or video was changed.


**Episode 002 Spotify upload repair (2026-09-30):** Josh reported the same color-consistency rejection as Episode 001. The current [Spotify upload copy](../01_EPISODES/E002-make-ai-useful/edit/codex-spotify-color-fix-2026-09-30/episode-002-spotify-upload.mp4) repairs unspecified primaries/transfer in the intro at 00:07.133 without recompression. It preserves the exact ep2hook cut, 33:14.267 runtime, all 59,828 frames, picture-slice/AAC hashes, 153,311 media packet timing records, 12 embedded chapters and sidecar timing. Every coded color header and decoded frame now has identical limited BT.709 metadata. The shared producer renderer and QC enforce a new coded-header/full-frame gate; its short hook/intro regression passes. Successful Spotify retry/processing remains unconfirmed; no upload or publication occurred.
