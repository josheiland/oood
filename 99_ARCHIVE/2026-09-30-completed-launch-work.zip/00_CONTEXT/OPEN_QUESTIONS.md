# Open questions

Only unresolved decisions belong here. Move resolved items into `DECISIONS.md` and update `PROJECT_BRIEF.md` when needed.

## Launch

- All three launch episodes are public on YouTube as of 2026-09-30. What is the coordinated marketing-push plan and future publication schedule?
- Is the working twice-weekly cadence sustainable once editing and clip production are included?
- Which performance signals will trigger format, length, title, or cadence changes?

## Audience and editorial

- What is the sharpest one-sentence show description?
- How broad should the default audience be versus explicitly targeting leaders/operators?
- Which recurring segments, if any, should become part of the format?
- What role should screen-share demonstrations play while preserving a complete audio experience and a casual, relatable, entertaining tone? Josh raised this unresolved tradeoff on 2026-09-25. Evidence and an unapproved recommendation are in `02_RESEARCH/podcast-video-audio-and-demos-2026-09-25.md`.
- Should each description carry its own TLDR and short vocabulary list, and should a fuller recap live on the website? How will host opinions be distinguished from checked facts?
- Would occasional playful sound effects help the hosts' humor, or distract from it? What, if anything, should appear at the end of each episode or indicate progress through a longer video?
- What standards determine whether a news item is consequential enough to cover?

## Production

- Which microphones were ultimately purchased and what are the final gain/filter settings?
- Does a full-length 1080p recording remain synchronized end to end?
- What is the canonical OBS scene collection and backup process?
- Who owns editing, thumbnails, captions, clips, quality control, and publishing?

## Brand and assets

- Where will the subscribe and recommended-video elements sit on the outro? The top show-name label is removed, and the three footer lines are 48 pixels higher. Confirm placement against the remaining thank-you and footer text when assembling the end screen. The recurring intro tagline is decided: `FIGURING OUT AI TOGETHER`.

- Which canonical logo/cover exports will be distributed from the adopted September 2026 kit? The written specification is square/two-line; older circular art remains in the source ZIP. Fonts, colors, composition, and platform rules are now recorded in `03_ASSETS/brand-guidelines.md`.
- Resolved: Episode 000 uses Josh's definitive `Hook_Final.mp4` honeymoon opening and theme music. The prior version was published per Josh on 2026-09-29. He approved the recurring cards on 2026-09-30 and requested the revised full video; the checked local replacement is ready for his re-upload.
- Which optional reaction popups and recurring motion treatments do the hosts want beyond the kit's chapter/lower-third rules?

## Distribution and newsletter

- What is the newsletter's specific job: episode recap, standalone analysis, source pack, community channel, or a combination?
- Which email platform and sender address will be used?
- Should a Facebook presence be added after launch, and what evidence would justify it?
- What is the repeatable workflow for turning a full episode into short clips and platform-native posts?

## Research and first episodes

- Will Josh and Mary approve the exact 52:25.733 Episode 001 v2 full review in `edit/codex-handcover-episode0-outro-2026-09-30/` after continuous viewing/listening? Josh selected his `ep1hook.mp4` file, confirmed to be the moon/data-center exchange, and specified that post-title picture start on Mary's covered lens at raw 00:15.833. He replaced the Episode 001 two-ask ending with Episode 000's exact three-prompt outro. Review all eight raw-source removals, six internal crossfades, two factual pop-ups, personal details, work/safety opinions, provider/open-model comparisons, captions and audio balance. The brief NVIDIA setup stays but the 83-second GPU detour is gone. The verified Demis role-change and sandbox-escape examples stay; speculation about Demis's motives is host opinion. Draft captions need auditory proof. The v2 export measures −17.67 LUFS and −1.29 dBTP; Josh confirmed music rights. Episode 001 is now public on YouTube (verified 2026-09-30); the prior review-stage status is superseded. Josh later reported a Spotify upload rejection caused by missing outro color tags; use `edit/codex-spotify-color-fix-2026-09-30/episode-001-spotify-upload.mp4`, which preserves that exact cut with consistent BT.709 tags. Spotify publication resolved by Josh's 2026-09-30 confirmation. The repaired final cut is now archived in Drive; use the archive receipt for its current location.
- Where will the platform subscribe/recommended-video elements sit on Episode 000? Its current September 30 YouTube upload is verified, but exact identity with the local card-revision export has not been checked. Josh approved the cards and requested this revised local full export on 2026-09-30. The prior version's publication is confirmed by Josh's 2026-09-29 report; the new `release/episode-000.mp4` has not been re-uploaded by Codex. The captions retain their existing bytes and timing; prior caption/research review notes are historical, not independently rechecked platform status.
- Will Josh and Mary approve the current preferred 33:14.267 Episode 002 host-review cut (`01_EPISODES/E002-make-ai-useful/edit/codex-user-hook-2026-09-30/episode-002-full-review-v3.mp4`) after continuous playback? Josh selected his saved `ep2hook.mp4`, resolving the hook choice. It incorporates the current Episode 000 recurring cards and matching music, seven removals and five-hour exchange. Confirm all joins by ear and proofread the retimed captions before approval; YouTube publication is now verified, but the public video has not been independently matched byte-for-byte to this local export. Josh reported a Spotify color-consistency rejection; use `edit/codex-spotify-color-fix-2026-09-30/episode-002-spotify-upload.mp4`, which preserves the same cut and fixes the intro's tags. Spotify publication resolved by Josh's 2026-09-30 confirmation; current release files are archived in Drive.
- Should the named Charlottesville shop opinion stay in de-identified form, or is the nine-second removal preferred? Are Josh and Mary comfortable with the Episode 002 named personal examples (Lewis, Olivia, Tyler and Chloe)?
- Who owns final review and publishing for future episodes? The three launch episodes are public on YouTube as of September 30.
- Can the next full-length recording pass microphone, camera-continuity, and original lip-sync checks? The previous source's four audio tracks contain duplicate mixes, and it has two picture blackouts (one removed and one covered in its edit). Diagnose those OBS issues before recording again.
- Which personal examples do the hosts want to retell, and can the chosen demonstration and all product wording be verified in the actual app/account? The feedback plan recommends spoken corrections; prior source checks do not independently verify private workflow outcomes.
- For a future nonprofit-focused episode, which defensible statistics establish sector adoption and effectiveness? This is no longer Episode 1's framing requirement.
- How should the show accurately compare skill/workflow capabilities across ChatGPT, Claude, and Gemini?
- When is Composio a credible workaround for multiple accounts? (Checked 2026-09-26: ChatGPT added multiple Google accounts on 2026-08-28; Claude's built-in Gmail connector is still one account. Recheck before publishing.)
- Which claims from Run Your City experience can be shared publicly?
