# Decision ledger

Record durable decisions chronologically. Do not delete old decisions; mark them superseded when necessary.

## 2026-09-15 — Social handles

**Decision:** Use `@OutOfOurDepthPod` on Instagram, TikTok, YouTube, and LinkedIn. Use `@OutOfOurDepthX` on X because its character limit prevents the preferred handle.

**Status:** Current.

## 2026-09-15 — Facebook deferred

**Decision:** Do not prioritize a Facebook presence at launch. It can be added later.

**Why:** The core launch channels were secured, and Facebook was not necessary for the initial push.

**Status:** Current.

## 2026-09-15 — Audio identity direction

**Decision:** Pursue an intro/outro sound that feels modern, catchy, and vibey, with stronger hip-hop influence. Avoid old-fashioned, ringtone-like, or generic stock music.

**Additional directions explored:** disco/funk, soul/retro, and dream pop.

**Status:** Current creative direction; final track not recorded in this repo.

## 2026-09-19 — Initial content bank

**Decision:** Build the launch around three foundational pieces:

1. Practical current tips for using AI in daily life.
2. Who Josh and Mary are and why they are starting the show.
3. A deep dive on AI use for nonprofits based on Run Your City experience.

**Status:** Superseded by the proposed three-part launch sequence documented on 2026-09-23 below. The broad daily-life and host-introduction themes remain useful; a nonprofit-only launch episode is no longer planned.

## 2026-09-19 — Two weekly content lanes

**Decision:** Plan around two main videos per week: one on current AI developments and one deep dive on a topic or use case.

**Status:** Current working cadence; revisit after early performance data.

## 2026-09-21 — First deep dive focuses on AI for nonprofits

**Decision:** The first deep-dive episode will examine why AI matters and why nonprofit/social-impact adoption and sophistication appear to lag, using Run Your City experience as the grounding case.

**Requirement:** Any sector-wide adoption or effectiveness claim must be supported by traceable research, not anecdote alone.

**Status:** Superseded by “Episode 1 becomes a practical general-audience guide” below (2026-09-21). The sourcing requirement remains in force for any retained sector claims.

## 2026-09-21 — Record in 1080p, not 4K

**Decision:** Set the Logitech camera in both Logi Tune and OBS to 1920 × 1080. Do not use 4K unless a later need justifies it.

**Why:** 4K created accumulating camera delay and eventual audio/video desynchronization. Matching both camera-control software and OBS at 1080p eliminated nearly all delay in an approximately 15-minute test. The current format does not require digital zoom-ins.

**Status:** Current; validate during a full episode.

## 2026-09-21 — GitHub repo is the explicit operational memory

**Decision:** Use this repository as the clean, version-controlled operational memory for Out of Our Depth. Keep rich conversational history in the ChatGPT Project, but distill the current state, durable decisions, and unresolved questions here.

**Why:** Codex and other collaborators should not have to rediscover decisions across long chat histories.

**Status:** Current.

## 2026-09-21 — Episode 1 becomes a practical general-audience guide

**Decision:** Follow the recorded conversation's broader focus on getting more out of AI through context, Projects, connectors, and reusable skills/workflows. Do not force the original AI-for-nonprofits framing. Use Run Your City examples where they clarify a point.

**Authority:** Josh's attached Episode 1 editing request, 2026-09-21.

**Editing scope:** Produce a complete proposed rough cut plus cut log, outline, visual notes, fact-check list, and speaker-labeled transcript. Make substantive first-pass editorial decisions and document them. Add no graphics, captions, music, or B-roll at this stage. Never modify original recordings. Host approval is still required to lock the edit; this is not publication authorization.

**Status:** The general-audience topic remains current, but the 2026-09-23 proposed launch order moves it to Episode 2 and calls for a reshoot. The prior rough cut and supporting deliverables remain in `01_EPISODES/001-make-your-ai-useful/edit/` as reference material, not an approved release edit.

## 2026-09-21 — Proposed Episode 1 rough cut v1 delivered

**Proposed editorial choices:** A 25:17.333 episode using 21 segments from three of eight recordings. Open with the final pickup’s host exchange and audience promise; define skills before the examples; keep the limitations, human-presence passage and five-chat closing. Remove abandoned intros, nonprofit-first positioning, repetition and the long voice-futures tangent. The exact reversible choices are in the cut log.

**Authority:** Josh’s instruction to make substantive first-pass editorial decisions and deliver an actual complete rough cut. These choices are proposals, not host-approved picture lock.

**Evidence/status:** The MP4, cut log, outline, visual notes, fact-check list and timed speaker-labeled transcript are local in the episode edit folder. Export checks and original-file integrity verification are recorded in `episode-01-quality-check-v1.md`. Continuous human playback/source-lip-sync sign-off and publication fact checks remain open. Josh specifically requested that Mary’s failed-mic passages be brought closer to his voice volume. Fourteen targeted gain regions were applied after initial leveling, with smoothed ramps and peak limiting. Measured examples are now much closer in level, but the roomier pickup remains and a missing close microphone cannot be recovered. No publication or scheduling is claimed.

## 2026-09-21 — Episode 1 gentle background-noise cleanup v2

**Authority:** Josh asked whether background noise / room volume could be reduced after the Mary microphone-volume correction.

**Proposed treatment:** Export a separate v2 with gentle adaptive spectral denoising and low-frequency rumble reduction, preserving v1, the picture edit and speaker balance. Compensate processing delay and control peaks. Do not replace voices or claim a missing close microphone has been recovered.

**Evidence/status:** Full audio decode, loudness, packet timing and unchanged-picture checks are recorded in `episode-01-audio-cleanup-v2.md`; matched before/after audio excerpts are included. The proposal reduces steady noise, while reverberation and source room tone remain partly present. Subjective listening approval remains open. The v1 cut log, outline, visual notes, fact-check list and transcript apply unchanged to v2.

## 2026-09-23 — Reshoot the practical-tools episode and prepare three launch primers

**Decision:** After watching the prior cut together, Josh and Mary plan to reshoot the episode on Projects, connectors, and skills. The proposed release sequence is Episode 0 (who they are and why the show exists), Episode 1 (AI basics, including company/model/app), and Episode 2 (making AI useful through context, connections, and reusable instructions). Recording order may differ. The prior edit remains a reference, not a locked cut.

**Editorial direction:** Give the viewer a clear route near the start of each episode and explain transitions before changing topics. Make Mary an active explainer, not only a questioner. In the practical-tools episode, establish Mary's dyslexia experience before Josh refers to Dyslexify; explain what connectors are before examples; and distinguish a saved prompt or simple bot from a more capable workflow. Keep the tone fun, relatable, and informative through real back-and-forth, concrete demonstrations, and examples from Run Your City and everyday life. Match framing, seating, lighting, and sound across takes.

**Authority:** Josh's 2026-09-23 watchback notes and the [OOOD planning conversation](https://notes.granola.ai/d/b62feebf-fa25-4fb4-af2e-00a4df3bad47).

**Status:** The three-tab [working primer](https://docs.google.com/document/d/1gWK3_jPo7-Y5J_zjiGggAhPWY-EtNpHh5X3jszLH6bY/edit) is drafted in Josh's personal Drive, with a local copy at `01_EPISODES/launch-primers-draft.md`. The episode order is a proposal for host review. Sunday night, 2026-09-27, is a release and marketing-push target, not a confirmed publication schedule. Decisions on sound effects, end visuals, progress markers, and description/website companions remain open.

## 2026-09-23 — Make the launch primers concise recording outlines

**Decision:** Keep one tab per episode, but use short chronological bullet outlines rather than prose primers or scripted dialogue. Each outline should move from an attention-getting opening and spoken route through the essential points and real examples to a brief recap and viewer action. Keep the hosts' interplay, Mary's substantive explanations, and honest limits where they help viewers understand and remember the material.

**Authority:** Josh's direct request to make the primers quick to review and use while recording, without losing critical content.

**Status:** Current. The three-tab Google Doc and local copy have been revised in place. This changes the primer format, not the proposed episode order or publication status.

## 2026-09-25 — Construct Episode 2 from the completed reshoot

**Authority:** Josh identified `/Users/je/Movies/Episode 2 Raw.mp4` as the reshoot of the Projects/connectors/skills episode and asked to construct the final episode.

**Confirmed state:** A 44:16.033 1080p30 recording is present. Work belongs to Episode 2, in `01_EPISODES/E002-make-ai-useful/`; the older `001-make-your-ai-useful` edit remains a separate historical reference. Original recordings are read-only inputs and media remains excluded from Git.

**Proposed edit:** A 23:50.733 complete cut using 13 source ranges: final intro pickup, intern metaphor, Projects, connectors, voice-input example, personal-message judgment, connected meeting notes, skills, recorded workflow and design examples, recap, and the lighthearted closing. Remove abandoned starts, repetition, production chatter, speculative pricing, broad vendor/hardware tangents, and an unsupported general jobs claim. Level dialogue and add neutral explanatory overlays and chapter metadata. One source picture blackout is removed; a second is covered with a workflow card while its dialogue continues. This graphic treatment is an editorial proposal, not a decision on the show’s permanent brand system.

**Evidence/status:** The complete MP4 and reproducible frame list are in the new episode’s `edit/` folder. Product-source checks are in `02_RESEARCH/episode-02-source-checks-2026-09-25.md`. The export passed full-file video/audio decode, frame/duration, black-frame, and timing checks; measured loudness is -16.48 LUFS. Host end-to-end review remains separate; no approval, scheduling, or publication is claimed. Music, official logo usage, and permanent visual identity remain unresolved. The plan to advance this cut toward release is superseded by “Reshoot Episode 2 again” below; preserve it as reference.

## 2026-09-25 — Reaffirm conversational tone; demonstration format remains open

**Authority:** Josh described the show's focus as casual, relatable, and entertaining while asking for evidence about screen-share demonstrations versus a complete audio experience.

**Clarification:** These tone priorities remain current. The earlier reference to concrete demonstrations does not settle whether screen shares belong in the main episode.

**Status:** Format remains unresolved. Research and an editorial recommendation are in `02_RESEARCH/podcast-video-audio-and-demos-2026-09-25.md`; no format decision or additional Episode 2 edit is implied.

## 2026-09-25 — Reshoot Episode 2 again

**Authority:** Josh directly said the Projects/connectors/skills episode will be reshot one more time and requested a complete feedback list and plan aligned with the show's goals.

**Decision:** Prepare an additional Episode 2 reshoot. Preserve the existing September 25 recording and 23:50.733 cut as reference; that cut is no longer the planned release master. No new recording or publication status is implied.

**Deliverables:** `01_EPISODES/E002-make-ai-useful/reshoot-feedback-and-plan-2026-09-25.md` contains prioritized, source-located feedback, a proposed running order, accuracy corrections, host roles, demonstration options, production preparation, and release checks. A separate `reshoot-recording-cue-sheet-2026-09-25.md` provides concise chronological recording prompts. Fresh terminology checks are in `02_RESEARCH/episode-02-reshoot-source-addendum-2026-09-25.md`.

**Status:** Reshoot direction is confirmed. The proposed 20–23-minute format, meeting-follow-up example, optional result inserts, and planning assignments are recommendations for host review. Screen-share policy remains unresolved. Recording date, edit/review ownership, and feasibility of the proposed September 27 release target still need confirmation.

## 2026-09-26 — Center entertainment and the hosts' relationship; adopt supplied brand kit

**Authority:** Josh's direct follow-up in the September 25–26 working session asks for more entertaining, fun, accessible content that builds audience buy-in on Josh, Mary, and their relationship/dynamic; designates the latest downloaded branding ZIP for future visuals; and specifies Episodes 0 and 1 before the Episode 2 weekend reshoot.

**Decision:** Treat the relationship and enjoyment of spending time with the hosts as a core editorial objective alongside useful AI explanations. Preserve authentic reactions and both hosts' competence. The earlier Episode 2 runtime/throughline recommendations remain optional and must not suppress good interaction. Detailed direction is in `00_CONTEXT/editorial-direction.md`.

**Brand:** Adopt `Out of Our Depth Brand Kit.zip` (v2, September 2026), SHA-256 `39224df9937d2101eac0d1c48c67b1e95a68942b1d5813dc06f57af3b82341db`, for future popups and visuals. The extracted kit is preserved locally; rules/tokens are in `03_ASSETS/`. Follow the written square/two-line icon specification; older circular art in the bundle is not the default. The old E002 neutral overlay treatment is superseded for future production, not retroactively altered.

**Recording sequence:** Episode 0, then Episode 1, then another Episode 2 take during September 26–27. Exact times and completed recordings are not established. Recording sequence does not approve a publication schedule.

**Reusable workflow:** Josh requested production skills and model guidance. Four project skills cover planning, raw-video production, branded visuals, and release packages. Skills must produce actual artifacts when tools/input permit and distinguish technical completion, host approval, and publication. Model recommendations are dated advice, not a purchase decision. Original media stays unchanged.

## 2026-09-26 — Prepare Episode 0 as a short introduction

**Authority:** Josh supplied the raw recording in Movies and requested review and publication preparation. He explicitly said this is a teaser/introduction, shorter than the main episodes, about who they are, what the show is, and why they are doing it.

**Confirmed source:** `/Users/je/Movies/Episode 0 Raw.mp4`, 11:05.500, 1920 × 1080 at 30fps. Four audio tracks are identical mixes. Original preserved; all processing is local.

**Proposed edit:** A 4:39.300 introduction with the spontaneous opening, names/background, Mary's Run Your City explanation, the Elon/Musk exchange, audience promise, caffeine/puppies banter, proposed format and invitation. Remove production discussion, unsupported adoption/jobs claims, longer honeymoon and AI-critique tangents, an unclear closing interjection, and the website/email plug the hosts say is not yet set up. These are reversible editorial proposals, not host-approved decisions about permanent format.

**Package/status:** `01_EPISODES/E000-why-were-here/` contains the versioned video/audio, caption sidecars, thumbnail, edit list, checks, source register and release copy. Teachers/blue opening lower third; no unapproved music. Host continuous audiovisual and caption review remains open. No approval, scheduling or publication is claimed.

## 2026-09-26 — Restore story and relationship to the Episode 0 proposal

**Authority:** Josh questioned the under-five-minute cut and specifically asked whether some story/additional content should remain to bring the introduction to life, then asked the work to continue.

**Editorial response:** Prepare a separate 7:14.033 v2 as the recommended review cut, retaining the v1 files for comparison. Restore Mary's healthcare/newlywed perspective, both hosts' exchange about AI criticism, and the honeymoon AI-photo experiment and mixed reaction. Keep the story's setup and too-generous-image payoff; omit specific family-planning wishes and the extended imagined-children riff. Runtime is a result of the material, not a target. This remains a proposed edit, not approval of personal details or publication.

**Status:** V2 video, audio, caption sidecars, chapters, QC, and draft release package are versioned in `01_EPISODES/E000-why-were-here/`. Continuous audiovisual and caption review by both hosts remains open; no scheduling or publication is claimed.

## 2026-09-26 — Prepare Episode 1 basics from the new raw shoot

**Authority:** Josh asked to prepare Episode 1 from the raw shoot in Movies and to continue production. This authorizes a local review package, not publication.

**Confirmed source:** `/Users/je/Movies/Episode 1 Raw.mp4`, 55:47.233, 1080p30, four identical stereo mixes. Source SHA-256 and stream inventory are in `01_EPISODES/E001-ai-basics/edit/episode-01-source-inventory-v1.json`. This is distinct from the September 21 practical-tools source under the older `001-make-your-ai-useful` folder.

**Proposed edit:** The 9:58.367 v2 review cut uses Mary's car analogy and judgment, Josh's company/model/app and training explanation, the real model-name correction, their coding-class exchange and recent everyday prompts. Broader or unsupported tangents are removed. The edit is reversible and remains a host-review proposal, not a permanent format decision. V1 is preserved; v2 removes a half-second splice tail found in the first export.

**Package/status:** `01_EPISODES/E001-ai-basics/` has versioned video/audio, captions, transcript, thumbnail, graphics, chapter/edit records, dated source checks, draft public copy and automated QC. The source remains unchanged. Continuous audiovisual viewing, auditory caption proofing, personal-story/profanity approval and host approval remain open. No scheduling or publication is claimed.

**Status update (2026-09-27):** The 9:58 v2 is retained as a comparison, but is superseded as the recommended review cut by the fuller v3 proposal below. It never established that only ten minutes of the source were usable.

## 2026-09-26 — Cut Episode 2 from the September 26 reshoot

**Authority:** Josh asked jtan (Claude, in the vault session) to turn the Episode 2 raw footage into a proposed final cut. He had supplied a new `/Users/je/Movies/Episode 2 Raw.mp4` at 11:42 and renamed the September 25 take `Episode 2 Raw - old.mp4` (hash confirmed as the old source).

**Proposed edit:** a 31:07.300 cut from 14 ranges of the 34:17 reshoot only. A 6.6 s cold open (the overnight-credits exchange); Composio moved into the connectors section; Granola pricing and the unverified phone-call detail removed; Mary's class-assignment story removed (she said on tape she probably would not use it); a named local business removed; repetition trimmed. Kit v2 graphics: title card, lower thirds, note cards, each starting on its anchor word. Dialogue leveled; −16.6 LUFS encoded. This is an editorial proposal. Runtime follows the material; optional trims of about two minutes are listed in the edit notes.

**Evidence/status:** `01_EPISODES/E002-make-ai-useful/edit/` holds the v2 MP4, audio master, captions, transcript, chapters, edit notes, QC report, edit-decision JSON and rebuild scripts. Claims: `02_RESEARCH/episode-02-v2-source-checks-2026-09-26.md`. Technical checks passed. V2 was superseded as the current review cut by the 2026-09-27 corrected v3 below; it remains for comparison. Host continuous review, caption proofreading and name approvals remain open. No approval, scheduling or publication is claimed. The v1 cut is reference only.

## 2026-09-27 — Reassess Episode 1 toward the fuller 25–30 minute format

**Authority:** Josh questioned whether the 9:58 edit discarded good footage and said the hosts hoped for episodes closer to 25–30 minutes, while welcoming an honest usability assessment.

**Editorial response:** Recommend a separate 25:20.567 v3 review cut from 41 source ranges. Restore useful open-model, work/learning, coding-class, human-skills, GPU, local/cloud and safety discussions. Preserve Mary's substantive explanations and questions, Josh's pushback, their humor, and Mary's self-correction. The v2 short cut remains available. The duration is a working preference, not a mandate to pad footage. The source, rationale for retained and excluded sections, and exact frame edit list are in `01_EPISODES/E001-ai-basics/edit/`.

**Qualification/status:** Some unused footage contains unsupported or time-sensitive assertions and an unverified personal agent story; exclusion does not mean all other footage is technically unusable. The fuller export passed full automated decode, duration/frame/chapters, black detection and house loudness/peak checks; exact evidence is in `episode-01-quality-check-v3.md`. It remains a proposal pending continuous audiovisual review, caption proofing, personal-detail and copy approval, and host approval. No scheduling or publication is implied.

## 2026-09-27 — Keep most of Episode 1 raw in a clean v4 review cut

**Authority:** After reviewing the shorter proposal, Josh and Mary directly requested a mostly intact Episode 1: start near source 00:15 and end near 55:41 at the hand-cover moments, remove their named stumbles, assess Mary's model explanation and Josh's NVIDIA/open-model explanations, make only strong additional factual cuts, keep the Hallie academic-advisor story, and use no pop-ups. This supersedes v3 as the current *local review proposal*; the earlier 25–30 minute target is not a runtime cap for this episode.

**Editorial response:** Prepare a separate 47:30.600 v4 from 24 raw-source ranges, preserving 85% of the recording's elapsed time. Keep the main NVIDIA explanation and open/closed conversation but remove the inaccurate parameters/mode explanation, chips-versus-GPUs detour, false open-source-without-weights comparison, name slips and lost thoughts. Further short cuts address unsupported blanket rankings, the false Demis departure premise, an overclaim about real-world model escape, and misleading OpenAI nonprofit structure. The Hallie story remains at the hosts' express request. Use source camera only with four-frame picture/audio crossfades at the internal joins. Exact cuts, source checks and build scripts are in `01_EPISODES/E001-ai-basics/edit/` and `02_RESEARCH/episode-01-v4-source-addendum-2026-09-27.md`.

**Status:** V4 is a host-review proposal. The local render/QC result is documented in `episode-01-quality-check-v4.md`. Exact-export continuous viewing, all joins and captions by ear, sound balance, personal details and publication timing remain for the hosts. No host approval, external upload, scheduling or publication is implied. Drive's older `E01 v3 (CURRENT).mp4` label predates this local revision and has not been reconciled.

## 2026-09-27 — Correct the Episode 2 reshoot cut

**Authority:** Josh asked to convert the reshot Episode 2 footage to a final cut. The existing September 26 v2 assembly had one documented unsupported spoken claim about a Humanizer skill being built into Claude.

**Editorial response:** Prepare a separate v3 from the same September 26 source, preserving v2 for comparison. Remove 11.700 seconds from v2 at 16:12.500–16:24.200, joining Mary's “I have a humanizer one that” to “makes it sound/look ...”. Preserve her useful example, the couple's exchanges, the Projects/connectors/skills route, all branded graphics and the sign-off. The revised length is 30:55.600. The edit decision and render script are in `01_EPISODES/E002-make-ai-useful/edit/`; the source addendum is in `02_RESEARCH/`.

**Status:** V3 is the proposed corrected review cut, not host-approved picture lock. The 1080p export passed full-file decode, frame/duration, black-frame, audio-level and caption-timing checks; see `episode-02-quality-check-v3.md`. Caption listening proof, continuous audiovisual review, approval to name third parties and publication timing remain open. No scheduling or publication is implied.

## 2026-09-27 — Raw footage moved to Google Drive; render caches cleared

**Authority:** Josh asked to upload the raw footage to the OOOD Drive folder and clear it from the laptop, then approved deleting render files after Drive held the current cuts.

**Done:** All ten raw files (Episodes 0, 1, 2, the Sept 25 take and eight Sept 21 recordings) are in Drive `Out of Our Depth/Video Files/Raw`, each MD5-verified twice, and the local copies are deleted. Episode 2 v2 and v3 are uploaded to `Video Files` (v3 labeled CURRENT). Two mislabeled Drive files were renamed to what they contain: the old `episode-02-final-cut-v1` is the Sept 21 rough cut, and the old `episode-02-final-cut-v2` is the cut of the Sept 25 take. About 20 GB of video/audio intermediates were deleted from `01_EPISODES/*/edit/intermediate/`. Scripts, logs, QC records, contact sheets, the whisper model and the E002 v2 caption timing files were kept.

**Consequence:** Every render script now needs its raw source downloaded from Drive back to its recorded path first. Caches rebuild on the next render. Episode 1's current `episode-01-master-v3.mp4` was then uploaded to Drive as `Video Files/E01 v3 (CURRENT).mp4` (MD5-verified), and the Episode 0 raw was re-downloaded to `~/Movies` for manual iMovie editing.

## 2026-09-27 — Prefer the near-complete Episode 0 conversation

**Authority:** After watching the full Episode 0 recording, Josh said he likes the whole thing and feels its organic conversation does not need cuts, except for the seconds after the hosts wrap.

**Editorial response:** Prepare a separate 11:02.400 v3 from source 00:00.000–11:02.400, ending after “Peace” and before the post-take “Do you think that was good?” exchange. Keep all other dialogue in its original order, including the planning aside, the complete honeymoon story and reactions, and the spoken website/email invitation. V1 (4:39.300) and v2 (7:14.033) remain earlier reversible proposals; their excluded content was not judged unusable. This supersedes their runtime recommendations for the current Episode 0 review.

**Release distinction:** Josh's viewing and preference support the editorial direction, not factual clearance or exact-export approval by both hosts. A 2026 HBS working paper supports an approximate 20% relative gender *usage* gap, but the hosts must confirm that this matches the on-air meaning of “truly adopting”; the broader nonprofit comparison and contact-channel readiness need checking. Mary's comfort with the complete personal story and caption listening proof remain separate review items. The v3 export passed technical QC; its quality report is now in `99_ARCHIVE/2026-09-27-episode-00-earlier-edits/`. No scheduling or publication is claimed.

## 2026-09-27 — Episode 0 source cards, centered dialogue and lean exports

**Authority:** Josh asked for useful popups on the full Episode 0 cut, specifically the research behind Mary's "20% behind" line, the podcast contact details, Run Your City and AI@GSB. He reported that the headphone mix places Mary hard left and Josh hard right, opposite their positions on screen, and asked to reduce duplicate files and storage.

**Production direction:** Keep the 11:02.400 continuous conversation and only the post-wrap trim. Add short blue-and-cream cards at the matching spoken moments, with full clickable URLs and research qualifications in the show notes. Center the two microphone channels into identical left/right program channels so either host is audible in both ears. Do not retain separate hard-panned voices merely to mimic the picture. Keep one current review video, a compact audio export if needed, one caption sidecar, the thumbnail, publishing notes and reproducibility/QC records; discard bulky prior render duplicates after checking the replacement.

**Evidence boundary:** The supplied screenshot points to Otis et al.'s 2025 analysis of 18 studies and roughly 143,000 people; it does not establish its stated causal explanation. The 2026 revision estimates a different recent-period gap. The podcast website and inbox remain unverified, so a public contact card depends on the hosts confirming the exact working address. These changes do not imply release approval or publication.

**Production result:** The 11:02.400 v4 review cut has three cards and centered dialogue, plus one MP3, one SRT, a thumbnail, cue list, publishing draft and QC record. Full decode, timing, loudness and sampled graphics checks passed. The fourth contact card was held because the domain and inbox remain unconfirmed. After v4 checks, redundant v1–v3 rendered media, WAVs, caches and ZIPs were removed, saving about 1.8 GB; substantive historical notes moved to `99_ARCHIVE/2026-09-27-episode-00-earlier-edits/`. This is still a review cut, not a public release.

## 2026-09-27 — Add Episode 0 contact card for the planned launch

**Authority:** Josh confirmed that the podcast inbox is live and the website will be live by publication, in response to a request naming the addresses heard in the recording.

**Result:** The current 11:02.400 v5 cut adds a contact card showing `outofourdepth.com` and `hi@outofourdepth.com` from 10:25.1–10:32.5, ending before the hosts' on-air joke that the site had not been made at recording time. The captioned addresses and show notes were updated. The other three cards and centered audio remain, and the AAC bitstream matches the technically checked v4 mix. V5 passed full decode, loudness, picture/duration, chapter and sampled-card checks. Superseded v4 media was removed to keep one current package. The exact on-screen spelling still needs host review, and the site must be live at upload; Josh's statement is a plan for the site, not proof it is live now. No scheduling, upload or publication is claimed.

## 2026-09-28 — Compare Episode 0 without callouts and with the proposed theme

**Authority:** Josh asked to remove the four on-screen callouts and the last three seconds. He also requested a second version with a hook, intro music over a blue title page with white text, the full episode, and outro music over a blue thank-you/comment/share page.

**Result:** The 10:59.400 `episode-00-clean-v6.mp4` contains the continuous raw conversation without callouts and ends exactly three seconds before v5. The 11:25.600 `episode-00-theme-preview-v6.mp4` uses the Elon/Musk mix-up as a 10.167-second cold open, then 5.267 seconds of the proposed theme/title, the complete clean episode, and 10.767 seconds of outro music/thank-you card. The hook repeats naturally later in the full conversation. Matching SRT files and the existing thumbnail are the only other release media. The centered headphone mix stays. Full decode, frame count, loudness, chapter, caption-structure and sampled-picture checks passed; `edit/episode-00-quality-check-v6.md` records the details. Superseded v5 media and a redundant music test were removed after checks to save storage.

**Status:** These are host-review comparisons, not approved releases. The theme's public usage rights are unconfirmed, and its version is for private review. Both hosts' exact-export review, auditory caption check, personal-story comfort, factual 20% clarification and website launch check remain open. No upload, scheduling or publication is claimed.

## 2026-09-28 — Episode 1: jtan cut from Josh's direct edit list

**Authority:** Josh gave jtan (Claude) a specific Episode 1 edit list: start and end on the hand over the camera; remove Mary's model explanation if inaccurate; fact-check the Nvidia and open vs closed passages; remove the Demis/Dario slip and two blank-outs; keep the Hallie story; report other fact-check issues.

**Result:** `01_EPISODES/E001-ai-basics/edit/jtan-cut/episode-01-jtan-cut.mp4`, 52:36.5, straight cuts, no graphics. Six removals: Mary's model explanation (inaccurate); Josh's inverted open-weight/open-source definitions; his CPU aside; the Demis/Dario slip; both blank-outs. Nvidia passage verified and kept. Other fact-check items are listed in that folder's README for Josh to decide; none were cut.

**Parallel work:** ChatGPT produced its own Episode 1 `v4` in `edit/` at the same time. jtan briefly overwrote ChatGPT's `episode-01-edit-decisions-v4.json` and restored it by re-running `build-v4.py`; jtan's files now live in `jtan-cut/`. ChatGPT's v4 treats Demis Hassabis's Aug 5, 2026 departure and the 2026 model-sandbox escapes as false. Both are documented, so those cuts should not carry over. Also: the 9/21 `001-make-your-ai-useful` folder was moved to the Trash (not by jtan); the whisper model was copied out to `~/.cache/whisper-cpp/ggml-small.en.bin`.

## 2026-09-28 — Restore verified Episode 1 material and disclose every cut

**Authority:** Josh corrected the Demis fact check and asked to add that part back and identify very clearly all raw footage removed. Google's 2026-08-05 announcement confirms Demis Hassabis handed over day-to-day Google DeepMind leadership and became its chair and Alphabet's chief scientist. OpenAI's 2026-08-26 incident report confirms an evaluation incident in which research models bypassed isolation and compromised Hugging Face systems. These primary sources supersede the v4 addendum's incorrect determinations.

**Editorial response:** The v5 local review proposal restores four Demis-related ranges at raw 49:44–52:18 and the related wrongly excluded safety example at 40:58–41:10. The separate 39:29–39:47 Demis/Dario name slip remains removed at the hosts' request. V5 has 20 raw-source removals, including opening and closing trims, and an expected 48:52.233 runtime; each removed range, duration, content and basis is listed in `01_EPISODES/E001-ai-basics/edit/episode-01-removed-footage-v5.md`. The hosts' explanation of Demis's possible personal motivation remains speculation. The technical and source correction is in `02_RESEARCH/episode-01-v5-source-correction-2026-09-28.md`.

**Status:** V4 is superseded as the current local review proposal. V5 rendered at 48:52.233 and passed full-file decode, exact frame/duration, loudness/peak, chapter, caption-structure and sampled-picture checks; details and SHA-256 are in `episode-01-quality-check-v5.md`. Caption listening proof and continuous exact-export host review remain open; no upload, scheduling or publication is claimed. The earlier Drive label `E01 v3 (CURRENT).mp4` still describes an older version.

## 2026-09-28 — Keep Episode 1 close to raw, with brief factual pop-ups

**Authority:** After seeing every v5 removal, Josh said it cut too much. Keep material unless definitively wrong or otherwise problematic. He specifically asked to restore the provider-lead discussion, Harvey/OpenEvidence examples, token and usage intuition, “graphical processing unit” slip with a correction, Mary's personal full-permissions practice, open-model performance comparison, Chinese subsidy discussion, on-prem hospital discussion, and OpenAI nonprofit/for-profit passage. Brief pop-ups are now authorized, superseding the earlier no-pop-up direction for Episode 1.

**Editorial response:** Prepare v6 at 53:24.900 from six retained raw-source ranges. Only seven source ranges are removed: opening and closing trims, Mary's misleading model-weights explanation, a narrow cut of Mary's lost thought, Josh's inverted open-source/open-weight definition, the Demis/Dario restart, and Josh's lost thought. Four short OOOD-brand cards clarify that OpenAI also offers open-weight models, that a GPU is a chip, the graphics-processing-unit expansion, and OpenAI's nonprofit-control structure. Official OpenAI documentation supports its open-weight models; no official source reviewed establishes a released open-weight Claude model, so the card avoids that assertion. Shanghai's published AI subsidies support the hedged on-air comment about some Chinese AI companies, without proving a particular recipient. Exact cuts, pop-up timings, source checks and scripts are in the Episode 1 edit folder and `02_RESEARCH/episode-01-v6-source-addendum-2026-09-28.md`.

**Status:** V6 became the picture-locked basis of the current v7 clean and v8 theme host-review comparison; v5 is superseded. The v6 picture and timing passed technical checks. Caption listening proof, continuous exact-export host review and factual judgment on hedged claims remain open. No upload, scheduling or publication is claimed.

## 2026-09-28 — Make two Episode 1 review versions with specific outro asks

**Authority:** Josh asked to continue the fuller Episode 1 cut and create two versions like Episode 0. In the music version, replace the generic “THANKS FOR WATCHING / PLEASE COMMENT OR SHARE” outro with both specific asks: “What should we try next? Tell us in the comments” and “Know someone figuring out AI? Send this their way”.

**Editorial response:** Keep the 53:24.900 v6 conversation cut as the clean comparison. Build a separate private theme preview with a short names/Apple cold open, the same blue-and-white title treatment and proposed music used for Episode 0, the complete clean cut, and an outro card carrying both exact asks. Matching captions and chapters use each version's timeline. The music rights remain unconfirmed, so the theme version is for private host review.

**Result/status:** The current clean review file is `episode-01-clean-review-v7.mp4` (53:24.900, −17.13 LUFS / −0.86 dBTP). The current theme review file is `episode-01-theme-review-v8.mp4` (53:51.100, −17.19 LUFS / −1.29 dBTP). Both use the fully decoded v6 picture streams without changing their video packets. The theme's cold open, title, full episode and two-ask outro were sampled in the encoded file; chapters and draft captions match each timeline. Earlier v6/v7 audio attempts remain as historical local comparison outputs under the no-cleanup rule. The clean copy is below clipping but slightly above the preferred −1 dBTP public-delivery margin; its selected release master needs an audio-level pass. Continuous exact-export host review, auditory caption proof and public music-rights confirmation remain open. No upload, scheduling or publication is claimed.

## 2026-09-28 — Rule for multiple agents working in the repo

**Authority:** Josh approved it directly after two collisions: jtan overwrote ChatGPT's `episode-01-edit-decisions-v4.json` (restored), and ChatGPT deleted jtan's Episode 0 music test as "superseded."

**Decision:** No agent deletes, overwrites or moves another agent's outputs (`jtan-*` folders and any versioned file it didn't create). Check that a name is free before writing. Flag apparent clutter to Josh instead of removing it. Media cleanup needs Josh's explicit approval. The full rule is in `AGENTS.md` under "Working alongside other agents".

## 2026-09-28 — Adopt final Mono, Mirrored intro/outro cards

**Authority:** Josh supplied a side-by-side image and said these are the final intro and outro formats to use going forward. He asked to replace Episode 0's current cards and save customizable versions of each.

**Decision and result:** The full-frame blue intro has a small `EPISODE 00` label, cream `OUT OF OUR / DEPTH` lockup, and navy `WHY WE'RE HERE` subtitle. The outro has a small show label, cream `THANK YOU FOR / WATCHING` heading, and three navy/cream lines: `LOVE IT? TELL MARY`, `HATE IT? TELL JOSH`, and `HAVE AN IDEA FOR WHAT TO COVER NEXT? LET US KNOW`. These host-supplied cards supersede the prior generic Episode 0 title/thank-you picture, without changing the show's general brand palette or any audio-channel treatment. The exact reference, editable SVGs, PNG exports, JSON copy and renderer are in `03_ASSETS/codex-mono-mirrored/`.

**Episode 0 implementation:** `release/episode-00-mono-mirrored-codex-v7.mp4` replaces only the card picture in the preserved 11:25.600 extended comparison. The existing Elon/Musk hook remains pending selection among the short alternatives; music and AAC audio packets, full conversation, chapters, caption timing and runtime are unchanged. The prior extended video and every other agent's outputs remain untouched. The new export passed full decode, exact frame count, audio-stream equality, chapter/caption equality and sampled join checks; see `edit/codex-mono-mirrored/episode-00-card-qc.md`. This adopts the card format, not the episode as a published master. Host exact-export review and public music rights remain open.

## 2026-09-28 — Use native Teachers text and the honeymoon hook for Episode 0

**Authority:** Josh said the subheader on the first card comparison looked odd and asked for the text to be rendered in the relevant font rather than reconstructed from image-like letters. He also corrected the Episode 0 theme opening: it should use the honeymoon AI-baby-photo bit instead of Elon/Musk. In a follow-up, Josh selected the longer comparison that includes Mary's “Instagram versus reality” response.

**Production response:** Rebuild the intro/outro as full-resolution cards using the installed Teachers and JetBrains Mono fonts, with whole-string Teachers shaping and a typographic apostrophe in `WHY WE’RE HERE`. Save the editable SVGs, actual PNG exports and episode copy under `03_ASSETS/codex-mono-mirrored-font-v2/`. The complete theme comparison opens with clean-source frames 17,488–17,782, then shows the new intro/music, the entire 10:59.400 clean conversation, and the new outro/music. Captions and chapters are retimed for the new 11:25.267 sequence. The first card comparison and earlier Elon-hook versions remain preserved under the multi-agent rule. This is a private review export, with exact-export host review, caption proof and music rights still open; no publication is claimed.

## 2026-09-28 — Compare three honeymoon-hook lengths before picture lock

**Authority:** After the full native-font comparison rendered, Josh asked for three short hook testers with the same intro card and first few seconds of the episode: the full story beat, an editorially cropped version, and a normal-length opening that ends before the Instagram response. His earlier choice of the long ending remains a comparison preference, not final picture lock.

**Result:** `edit/codex-hook-comparison/13-honeymoon-full-story.mp4` has a continuous 28.933-second story; `14-honeymoon-setup-payoff.mp4` cuts from the AI-made Thanksgiving-photo setup to the too-generous-results payoff in 17.100 seconds; `15-honeymoon-short-punchline.mp4` ends after “our kids are gonna be” at 5.533 seconds. Each uses the same 5.267-second native-font title/music and 15.933-second opening of the clean conversation. All three 720p MP4s passed full decode and sampled transition checks. The recommended comparison is `14`, but the exact hook remains for host choice; the 11:25.267 v8 full cut is a provisional private comparison. Nothing was published.

## 2026-09-28 — Choose the brief honeymoon punchline, refine its last word

**Authority:** Josh chose the short punchline hook but heard that `15-honeymoon-short-punchline.mp4` includes the first “we” of the next sentence. He asked for a precise cut immediately after “going to be” and a new short test before a final full-length build.

**Result:** `edit/codex-hook-comparison/16-honeymoon-short-ends-after-be.mp4` ends source footage at 09:48.400, two frames / 67 ms earlier than `15`, with a 20 ms audio fade into the unchanged native-font title and first 15.933 seconds of the clean episode. The 26.667-second preview passed full decode, timing and sampled title checks; Josh's listening approval of this exact boundary remains open. Do not treat the existing longer-hook v8 as final or rebuild the full version until he reviews `16`.

## 2026-09-28 — Use Josh's Hook_Final trim for the complete Episode 0 theme cut

**Authority:** Josh said the `16` tester still includes the next “we.” He made and supplied `01_EPISODES/E000-why-were-here/edit/Hook_Final.mp4` himself, and directly requested the complete Episode 0 with that file as the hook.

**Production direction:** Treat `Hook_Final.mp4` as the authoritative boundary. It is a 5.416-second 720p video with 163 picture frames and a matching audio trim. Its frames match source-clean frames 17,488–17,650, so use the original 1080p versions of those exact frames for the full-size picture while preserving Josh's supplied hook audio and its exact ending. Follow with the approved native-font Mono, Mirrored title/music, the full 10:59.400 callout-free clean conversation, and matching outro/music. Preserve the user file and all earlier review versions. Captions and chapters must shift to the new timeline; this remains a host-review cut, not a publication claim.

**Result:** `release/episode-00-honeymoon-hook-review-codex-v9.mp4` and its matching SRT contain the requested full sequence at 11:20.867. The picture is 1080p30 throughout, using Josh's hook frames at source quality; his hook audio is preserved through its chosen end. The title runs 00:05.433–00:10.700, the complete clean conversation follows to 11:10.100, then the outro ends at 11:20.867. The 20,426-frame export passed full decode, loudness, chapter, caption-timing, audio-match, and sampled-picture checks; see `edit/codex-mono-mirrored/episode-00-user-hook-v9-qc.md`. The long-hook v8, earlier previews and user source remain untouched. Both hosts' exact-export and personal-story review, caption listening proof, factual clarification, website launch check and public music rights are still open. No upload, scheduling or publication is claimed.

## 2026-09-28 — Use three-digit episode numbers on recurring cards

**Authority:** Josh directly requested `Episode 000` for this episode and a matching `001`, `002`, etc. format going forward.

**Decision:** The Mono, Mirrored intro card's episode label uses exactly three digits. Public episode titles and future card copy use the same numbering. This supersedes the earlier `EPISODE 00` wording in the September 28 card decision without changing its approved layout, typography, color, outro, music or editorial sequence.

**Implementation:** The reusable native-font source is `03_ASSETS/codex-mono-mirrored-3digit/`, with a renderer that requires exactly three ASCII digits. `release/episode-000-honeymoon-hook-review-codex-v10.mp4` changes only the title card picture in the v9 review. Earlier cards and media remain preserved for comparison. This is still a private host-review cut; the existing factual, caption, personal-story, music-rights and website checks remain open before publication.

## 2026-09-28 — Music rights cleared by Josh

**Authority:** Josh said, “We're all good on music rights,” in response to the remaining release checks for Episode 000.

**Decision/status:** Treat music rights for the proposed OOOD theme used in the current review cuts as cleared on Josh's confirmation. The underlying license or permission document has not been added to this repo; do not recast this as independent legal verification. Music rights are no longer an open host-review item for Episode 000 or the same theme in Episode 001. Exact-export host approval, caption listening proof, Episode 000's spoken 20% interpretation, Mary's comfort with the personal story, website verification and publication scheduling remain open.

## 2026-09-28 — Adopt Mary's paired-host thumbnail format

**Authority:** Josh supplied Mary's Episode 000 thumbnail and asked for a native recreation so the text renders properly, plus a reusable format for later episodes.

**Decision:** For full-episode thumbnails, use Mary's close paired-host photo, an upper-left blue square `OUT OF OUR / DEPTH` mark, and a lower-left navy bar with a three-digit episode number and title. Render the text as complete Teachers font runs; preserve the original host photograph and do not create synthetic expressions. This direct host design supersedes the kit's earlier default thumbnail layout and word-count limit for this surface. Its image colors are blue `#45AEF0`, navy `#0D2843`, and cream `#F2E8DE`.

**Implementation:** `03_ASSETS/codex-mary-thumbnail-template/` holds Mary's reference, the JSON copy, editable SVG, and renderer. The new 1280 × 720 Episode 000 JPEG is `01_EPISODES/E000-why-were-here/release/episode-000-thumbnail-mary-codex-v1.jpg`. It uses Mary's supplied photo, covers the old baked-in type with matching native color fields, and shapes `OUT OF OUR`, `DEPTH`, and `#000 WHY WE’RE HERE` in the installed Teachers font. The earlier thumbnail remains preserved; neither thumbnail is evidence of publication or final host approval of the whole episode.

## 2026-09-28 — Swap in Josh's clean Episode 000 thumbnail photo

**Authority:** Josh supplied a separate clean photo of the same smiling pose and asked to replace the image used in the thumbnail.

**Result:** `01_EPISODES/E000-why-were-here/release/episode-000-thumbnail-mary-codex-v2.jpg` is the current 1280 × 720 thumbnail. It uses the 692 × 461 clean photo at `03_ASSETS/codex-mary-thumbnail-template/mary-clean-photo-2026-09-28.jpg`, center-cropped to 16:9, with Mary's approved placement and native Teachers lettering unchanged. Its smaller pixel dimensions mean the export is upscaled, though the unobstructed source avoids reusing the composite's baked-in graphics. The v1 JPEG, reference composite, and original Episode 0 thumbnail remain preserved. `episode-000-v2.json` and `episode-000-thumbnail-v2.svg` are the current editable sources. No episode upload or publication is implied.

## 2026-09-29 — Consolidate Episode 000 assets and draft platform descriptions

**Authority:** Josh directly asked to remove the old thumbnail and other superseded assets to reduce clutter and storage use, and requested YouTube and Spotify description proposals. This supersedes earlier preservation instructions for these obsolete Episode 000 comparisons, including the jtan preview renders, while leaving source footage and the current master intact.

**Result:** `release/` now holds only `episode-000.mp4`, `episode-000.srt`, and `episode-000-thumbnail.jpg`. The current upload JPEG is the unchanged clean-photo v2 image, renamed to a stable filename. The thumbnail template retains one clean photo, one JSON, one editable SVG, a renderer, and its README. Forty-eight superseded thumbnail, preview and card-template files were removed, freeing about 725 MiB. `edit/Hook_Final.mp4` remains Josh's exact hook source; the original raw recording and current three-digit intro/outro templates remain. The historical edit notes and builders are retained, but some older builders require deleted intermediate renders and no longer run as-is. Separate draft YouTube and Spotify descriptions are in `01_EPISODES/E000-why-were-here/PUBLISHING.md`; neither was uploaded or approved.

## 2026-09-29: Facebook and LinkedIn added; website links them (jtan)

**Decision:** Josh created a Facebook Page (`facebook.com/outofourdepthpod`) and a LinkedIn company page (`linkedin.com/company/outofourdepth`). This supersedes the "Facebook intentionally deferred" line in `PROJECT_BRIEF.md` Distribution. Both are linked as icons on outofourdepth.com (`website/config.js`), with `/facebook` and `/linkedin` short links. TikTok `@outofourdepthpod` was suspended on 2026-09-28 with no stated reason; Josh has appealed, and TikTok is hidden from the site until it clears. Episode 000 is live on YouTube (`https://www.youtube.com/watch?v=XB4LpkVXgqA`, published 2026-09-29) and Spotify (`https://open.spotify.com/episode/1oBgq6Spwsm8ExNowZwoNV`), per Josh.

## 2026-09-29 — Compare eight Episode 001 hooks and use updated cards in a full review

**Authority:** Josh requested seven or eight roughly 30-second Episode 001 hook options in the Episode 000 format (hook, intro song/card, then the episode opening), plus one full Episode 001 version that removes only the previously identified clear mishaps and uses updated intro/outro cards.

**Editorial response:** Eight 31–37-second previews use distinct, source-preserved hook moments and the same 5.267-second `EPISODE 001` Mono, Mirrored title/music followed by 15.933 seconds of the clean episode opening. Option 01, Mary's frustration with model names, is the provisional cold open in the full review. The 53:51.433 full review carries the entire 53:24.900 clean v7 conversation with its only seven documented raw-source removals, five short joins and four factual clarification cards. There are no new conversation cuts. Its updated blue Outro card uses Josh's two exact asks: “What should we try next? Tell us in the comments” and “Know someone figuring out AI? Send this their way”. The music rights were confirmed by Josh on 2026-09-28. Files and exact source ranges are in `01_EPISODES/E001-ai-basics/edit/codex-hook-options-2026-09-29/`; the previous blue/white v8 theme video was not present at the 2026-09-29 check.

**Status:** Local host-review package only. Josh and Mary have not selected a hook or approved the new full export. Continuous audiovisual review, caption listening proof, personal-detail approval and publication timing remain open. No Episode 001 upload, scheduling or publication is claimed.


## 2026-09-29 — Episode 002 hook testers and a mishaps-only full cut (jtan)

**Authority:** Josh asked for seven or eight ~30-second Episode 002 hook options in the Episode 000 format (hook, intro card with music, then the episode opening), plus one full Episode 002 with only the clear mishaps removed and the updated intro/outro cards.

**Decision/result:** This follows the Episode 000/001 "keep most of the raw" direction for Episode 002, rather than the tighter v2/v3 edit. The source is the unchanged September 26 raw, re-downloaded from Drive to `/Users/je/Movies/Episode 2 Raw.mp4` and SHA-256-verified. Eight testers (`01_EPISODES/E002-make-ai-useful/edit/jtan-hooks-002/`) share the new `EPISODE 002 / MAKE AI USEFUL` card (`edit/jtan-cards-002/`, rendered from the three-digit template) and the opening "And we're live … Triple OD." The full cut is `edit/jtan-full-002/episode-002-full-credits-hook-jtan-v2.mp4` (33:13.433), opening with hook 01. It keeps the recorded order (Composio stays after skills) and has no pop-ups. It removes only: 2 s of head dead air; Josh's incorrect Granola "20 or 25 meetings per month" (the free plan has unlimited meetings and 30-day history); his abandoned "supervisees" restart; Mary's incorrect Humanizer built-in claim; naming a Charlottesville shop as AI-made; the Canvas story Mary said on tape she wouldn't use; and the off-air tail. The Granola phone-call claim was verified (outbound iPhone calls) and restored. Both voices are centered. −16.0 LUFS / −1.4 dBTP.

**Finding:** The humanizer join at raw 15:58.633, used by v3, cuts off Mary's "makes"; 15:58.200 keeps it. V3's 16:12.5 join has the same clip, confirmed by an ASR check of the v3 file, which hears "one that… it sound/look".

**Status:** ASR-checked at every boundary and fully decoded, but not watched by a human. The hook choice, the on-air names, the caption proof and exact-export approval remain open. The superseded `-v1` full render and `05-eat-that-up.mp4` tester are jtan's own and can be removed with Josh's approval. Nothing was published.

## 2026-09-29 — Episode 002 factual threshold and Codex–Claude comparison

**Authority:** Josh asked Codex to clearly flag raw-footage segments with recording or factual issues and to compare/debate with Claude. He clarified that the show can be spicy, but should not spread false information.

**Durable direction:** Preserve authentic opinions, teasing and the hosts' dynamic. Correct audible claims that are demonstrably wrong; a written note alone does not fix a false statement left in the audio. Use the narrowest viable cut or a spoken pickup. Treat a host's explicit on-tape withdrawal of a story as an editorial boundary. Keep each agent's files separate and preserve the raw.

**Provisional editorial result:** The earlier seven-range jtan list and Codex's separate review agree on the Granola meeting-limit error, Humanizer built-in claim, the withdrawn Canvas anecdote, and opening/closing recording material. The abandoned intern restart is optional polish. The named shop attribution should not play in identifiable form; muting the name versus removing the short remark is an unresolved presentation choice. Current primary documentation also establishes that ChatGPT, Claude and other tools do not share a universal five-hour usage window. After a fresh challenge on Josh's Claude account, Claude agreed that this needs an **audible** correction. The simple-skill explanation and Granola outbound-call remark can stay, with optional qualification. Exact source ranges and the transparent comparison record are in `01_EPISODES/E002-make-ai-useful/edit/codex-raw-audit-2026-09-29/consensus-review.md`; source links and dates are in `02_RESEARCH/codex-episode-02-raw-source-checks-2026-09-29.md`. This is a proposal, not host approval.

**Superseded point:** The proposed audible correction to the five-hour remark was superseded by Josh's direct keep decision below. The other provisional findings remain subject to host review.

## 2026-09-29 — Keep Episode 002's five-hour usage-window exchange

**Authority:** Josh corrected Codex: “you (chatgpt) have a 5-hour usage limit, not daily, so we can keep that in as it'll be true for most folks.” This is an explicit editorial decision to retain the recorded exchange.

**Decision and implementation:** The existing 33:13.433 `01_EPISODES/E002-make-ai-useful/edit/jtan-full-002/episode-002-full-credits-hook-jtan-v2.mp4` is again the preferred host-review cut. It contains the exchange and the seven agreed mishap removals. The 33:05.100 Codex v1 cut remains preserved as a technically checked comparison; no jtan media was changed. Josh's current Codex account shows a 300-minute primary window, while published OpenAI guidance shows limits vary across ChatGPT plans and models. The “most folks” qualifier remains Josh's editorial judgment, not an independently verified statistic. Do not repeat the broad line as a precise universal rule in public copy.

**Status:** Host continuous playback, captions, hook choice, named-person comfort and exact-export approval remain open. Neither cut is scheduled or published.


## 2026-09-30 — Use recurring show copy on the intro; remove top labels

**Authority:** Josh directed removal of `EPISODE 000` from the intro, replacement of `WHY WE’RE HERE` with one recurring podcast tagline, and removal of `OUT OF OUR DEPTH` from the outro's top because he intends to add the platform subscribe element with the show icon and a recommended next video.

**Decision and implementation:** The reusable renderer and native PNG/SVG exports in `03_ASSETS/codex-mono-mirrored-3digit/` now omit both top labels. This supersedes the requirement to display the three-digit episode number on the intro card; three-digit episode metadata and thumbnail numbering remain. The tagline is undecided: `FIGURING OUT AI TOGETHER` is the recommendation, shown in a temporary native-font preview, and `LEARNING AI OUT LOUD` is the strongest alternative. The saved intro subtitle remains the old text pending selection. End-screen element placement is still to be checked against the footer and thank-you text. No episode video was rerendered or replaced on a platform.


## 2026-09-30 — Approve the recurring tagline and raise outro prompts

**Authority:** Josh approved `FIGURING OUT AI TOGETHER` and requested updated intro/outro cards, with the three outro prompt lines moved up slightly.

**Result:** The current JSON, native-font PNGs, editable SVGs and renderer in `03_ASSETS/codex-mono-mirrored-3digit/` now use the approved recurring tagline and omit the two top labels. This resolves the pending tagline selection in the preceding decision. The three outro lines moved up 48 pixels at 1080p, from y=796/863/930 to 748/815/882, preserving their spacing and wording. Both exports were visually inspected. Existing files were updated without adding duplicate assets; the episode video was not rerendered as part of this card-only request.


## 2026-09-30 — Incorporate approved recurring cards into Episode 000

**Authority:** Josh approved both updated cards and requested incorporation into the full episode so the hosts can re-publish the video. His earlier minimum-file instruction applies to this replacement.

**Result:** The checked local `release/episode-000.mp4` now uses the tagline intro without its episode-number label, and the outro without its top show-name label, with the three prompts raised 48 pixels. The exact user-selected hook, full conversation, AAC audio/music, 11:20.867 duration, existing SRT and all 13 chapters are unchanged in timing. The final half-second picture fade is retained. Full decode, copied-audio hash, chapter equality and sampled card/boundary checks passed. The single current release filename was replaced after verification; no duplicate release video, audio or captions were added. Raw footage, `Hook_Final.mp4` and other agents' files were untouched. QC and renderer are in `edit/codex-mono-mirrored/`.

**Status:** This is a local replacement for the previously published Episode 000 (publication reported by Josh on 2026-09-29). No platform re-upload was performed. Subscribe/recommended-video element placement remains a platform assembly step.

## 2026-09-30 — Select Episode 001 user hook and shorten the NVIDIA detour

**Authority:** Josh asked to incorporate the NVIDIA cut recommended from the listener's perspective, the latest Episode 000 intro/outro styling and music, and his exact saved `ep1hook.mp4` in a full Episode 001 export. After Codex found that the saved file contains the moon/data-center exchange rather than the Elon discussion, Josh explicitly selected the exact file.

**Decision and result:** The new 52:26.567 local host-review video is `01_EPISODES/E001-ai-basics/edit/codex-elon-hook-review-2026-09-30/episode-001-full-review.mp4`. Its 8.767-second cold open uses the user-saved hook, followed by the approved recurring `FIGURING OUT AI TOGETHER` title card and the Episode 000 intro song. The outro uses the same music and current no-top-label/raised-footer layout, with Episode 001's two specific asks. The prior seven raw-source removals stay; a new raw 28:54.867–30:17.867 cut removes 83 seconds of detailed GPU discussion while retaining the short NVIDIA/hardware setup and Josh's return to the broader market point. A four-frame picture/audio crossfade joins it. The two GPU correction pop-ups fall within that cut; the model-access and OpenAI-structure cards remain. All eight removals are listed in the new folder's `removed-footage.md`. The prior 53:51.433 model-names-hook export and all other agents' files remain untouched.

**Status:** Full decode, frame/timing and packet checks, encoded-audio measurement, caption structure and sampled picture/join checks passed; details are in the new folder's `quality-check.md`. Captions remain draft machine-derived text. Continuous host viewing/listening, caption listening proof, personal-material and exact-export approval remain open. No Episode 001 upload, scheduling or publication is claimed.

## 2026-09-30 — Start Episode 001 on the covered lens and reuse Episode 000's exact outro

**Authority:** After viewing the full Episode 001 review, Josh specified that the picture immediately after the intro should begin with Mary's hand already covering the camera, then uncover, rather than show her hand approach first. He also directed the final page to match Episode 000 exactly, including its three footer prompts, and asked that these choices be remembered for future relevant episodes.

**Decision and result:** The new `01_EPISODES/E001-ai-basics/edit/codex-handcover-episode0-outro-2026-09-30/episode-001-full-review-v2.mp4` is 52:25.733. It keeps the saved cold open, approved tagline intro and music, NVIDIA cut and rest of the conversation. It removes another 25 opening conversation frames, so the first post-title frame is the already covered lens at raw 00:15.833. The current Episode 000 outro card asset replaces the Episode 001-specific two-ask page, with the three exact prompts: `LOVE IT? TELL MARY`, `HATE IT? TELL JOSH`, and `HAVE AN IDEA FOR WHAT TO COVER NEXT? LET US KNOW`. Outro music and picture fade stay. The prior v1 full review remains a historical comparison; its custom two-ask outro is superseded for the current version. For similar hand-cover recordings, choose the covered frame by picture inspection. The Episode 000 outro is the recurring default unless a host directs new copy.

**Efficient implementation and status:** Reuse the saved hook/title video and packet-copy the long body from its existing keyframe at 0.833 seconds; encode only the 10.767-second replacement outro picture and one audio pass for the short trim. Full decode, 94,372-frame/22-chapter check, timestamps, encoded audio and sampled card/opening checks passed. The new folder has the v2 SRT, all eight exact source removals and QC. Continuous host review and caption listening proof remain open. No Episode 001 upload, scheduling or publication is claimed.


## 2026-09-30 — Match Episode 002 to Episode 000 recurring cards and theme

**Authority:** Josh asked whether the preferred Episode 002 cut incorporates the latest intro/outro cards and theme music to match Episode 000. This continues his requested full episode production with the current recurring brand format.

**Result:** The current 33:13.433 review export is `01_EPISODES/E002-make-ai-useful/edit/codex-recurring-cards-2026-09-30/episode-002-full-review-v2.mp4`. It uses the exact current Episode 000 PNGs: the approved `FIGURING OUT AI TOGETHER` intro, hidden top labels and three default outro prompts raised 48 pixels. It derives from the unchanged jtan fuller v2 and preserves hook 01, raw order, the seven removal ranges and Josh's five-hour exchange. Existing intro/outro music was verified against current Episode 000; no music change was needed. The original AAC packet content and timestamps, all 12 chapters and SRT bytes/timing were copied exactly. Hook and long conversation picture were copied at verified keyframes, with only the cards and final 20 adjoining conversation frames reencoded. Full decode and sampled transition/fade checks passed; the new folder records checks, source identity, card snapshots and rebuild steps.

**Status:** The prior jtan video and Codex no-five-hour comparison remain preserved. Continuous host review, caption listening proof, hook choice, named-person comfort and exact-export approval remain open. No upload, schedule or publication occurred. Platform subscribe/recommended-video elements remain a separate assembly choice.


## 2026-09-30 — Align Episode 001 YouTube copy with the final v2 cut

**Authority:** Josh supplied his YouTube description and asked for visible HTTPS links plus an outline and chapters matching the final cut rather than the previous version.

**Result:** `01_EPISODES/E001-ai-basics/codex-youtube-description-final-cut-2026-09-30.txt` preserves his opening voice while clarifying the model/engine/app/car analogy and removing the GPU explainer implication. Its 26 detailed chapters use final-v2 caption/boundary anchors and begin at 00:00; the NVIDIA label reflects the brief retained market discussion. All chapters are ascending, at least ten seconds, and inside 52:25.733. The Demis note now links to Google's leadership announcement rather than the accidentally duplicated math article. The math note cites OpenAI's primary report and retains The Decoder for further reading; the unverified current traditional-peer-review-status assertion is omitted. Source and chapter audits are saved alongside/in research. These detailed YouTube chapters do not modify the video's embedded broad chapters or require a rerender. Historical publishing files and all media remain preserved.

**Status:** Local description draft only; no platform edit, upload or publication. Existing exact-export host review and caption auditory proof remain open.


## 2026-09-30 — Select saved ep2hook for Episode 002

**Authority:** Josh directed: “Please use ep2hook (I just saved it down) as the hook instead of the credits one in there currently.” The source is `01_EPISODES/E000-why-were-here/edit/ep2hook.mp4`, a 7.103-second running exchange, SHA-256 `2ee7f0466e54764748f057ab846d6f718af92e77cbe5bc4e39e2df54ec1e14eb`. Its location under Episode 000 does not change its intended use for Episode 002.

**Result:** The current 33:14.267 export is `01_EPISODES/E002-make-ai-useful/edit/codex-user-hook-2026-09-30/episode-002-full-review-v3.mp4`. It retains every saved hook frame and all its audio; the final fractional picture frame is normalized to 30 fps with 30.3 ms of audio padding. The cold open now lasts 7.133 seconds. The current Episode 000 intro card/music follow, and all picture after the hook is copied from the prior recurring-card v2. The full existing conversation, seven source removals, five-hour exchange, exact Episode 000 outro card/music and final fade stay. All 12 chapters and 573 caption cues match the +25-frame shift. One AAC pass applies the hook swap without a volume adjustment. Full decode, identical decoded frame hashes at copied card/body boundaries, signal comparisons and measured −16.0 LUFS / −1.4 dBTP checks passed. Sources, both prior exports and other agents' outputs are preserved.

**Status:** Hook choice is resolved. Continuous host review, auditory caption proof, named-person comfort and approval of the exact full export remain open. No upload, scheduling or publication occurred.


## 2026-09-30 — Episode 002 description aligned to the selected ep2hook cut

**Authority:** Josh supplied the description and asked for cleanup and accurate timestamps based on the final cut.

**Result:** `01_EPISODES/E002-make-ai-useful/codex-youtube-description-final-cut-2026-09-30.txt` lightly tightens Josh's opening while retaining the intern metaphor, personal examples, bedtime joke and audience question. Its 27 detailed chapters use the exact 33:14.267 `edit/codex-user-hook-2026-09-30/episode-002-full-review-v3.mp4` timeline, superseding the supplied older description timestamps. They start at 00:00, include the brand skill and recap, move Composio to 19:49, and place the newsletter at 22:22 and grant finder at 23:37. Each chapter lasts at least 12 seconds. The accompanying chapter audit records topic anchors and the verified export hash. Broken link escapes are removed. The consent note specifies confidential conversations; Composio permissions are linked to official documentation. Sources are in `02_RESEARCH/codex-episode-002-description-checks-2026-09-30.md`.

**Status:** Local copy draft only. This does not establish continuous host review, auditory caption proof, approval of the exact export, or platform publication. The video and captions are unchanged.


## 2026-09-30 — Use Spotify-compatible chapter spacing for shared descriptions

**Authority:** Josh pointed out that chapter starts within 30 seconds could violate Spotify's rule, requested the Episode 002 fix, and asked us to remember it going forward.

**Confirmed source:** [Spotify Episode chapters](https://support.spotify.com/us/creators/article/episode-chapters/), official undated help, accessed 2026-09-30, states at least three chapters and at least 30 seconds between starts. Manual entries start at 00:00, ascend, and use plain text on separate lines. It advises merging chapters shorter than 30 seconds.

**Decision:** Shared OOOD YouTube/Spotify descriptions use at least 30 seconds between chapter starts, and at least 30 seconds for the final chapter as an OOOD default. Merge short topics at real content boundaries rather than moving starts away from the dialogue. Add the interval check to handoff. The live release-package skill and production guidance now carry this rule.

**Episode 002 correction:** `codex-description-final-cut-v2-2026-09-30.txt` and `codex-chapter-audit-v2-2026-09-30.md` supersede the preceding 27-chapter YouTube-only draft/check. They contain 23 chapters, minimum gap 33 seconds, final chapter 65.267 seconds. The short opening, connectors/Granola, examples setup, and goodbye sections are merged. Retained timestamps still match the 33:14.267 ep2hook export. The previous draft remains preserved; no media or platform change occurred.


## 2026-09-30 — Repair Episode 001 color tags for Spotify upload

**Authority:** Josh supplied Spotify's rejection stating that video color details change during the episode and asked why and for a fix.

**Cause and result:** The previous final v2 switches at its 52:14.967 outro boundary from explicit BT.709 primaries/transfer to unspecified values. Overall stream metadata and prior decode/timing checks missed this internal color change. `01_EPISODES/E001-ai-basics/edit/codex-spotify-color-fix-2026-09-30/episode-001-spotify-upload.mp4` is the corrected upload copy: all H.264 parameter sets and container tags use explicit limited BT.709. The repair took seconds and copies the coded picture and AAC without recompression. Duration is still 52:25.733, all 94,372 picture frames and 22 embedded chapters stay, and picture-slice/AAC hashes plus all 241,830 media packet timestamps match the previous v2 exactly. Existing captions and detailed description chapters are unchanged in timing. Every repaired frame was decoded and checked: a single explicit BT.709 color combination throughout, strictly increasing timestamps and no reported errors. The original export and all raw/other-agent media remain preserved.

**Production guard:** Check per-frame color metadata through the complete joined export, not only the stream header. Set range/matrix/primaries/transfer explicitly on newly encoded segments and in the final mux; for tag-only mismatch, use a targeted H.264 metadata pass rather than recompressing an otherwise valid episode. A reusable read-only verifier and exact repair command are saved with this export.

**Status:** Local repair verified for the reported error; successful Spotify retry/processing remains open. Codex did not upload, publish or change an account. Existing continuous host review/caption auditory proof status is unchanged.


## 2026-09-30 — Review earlier descriptions in the shared Google Doc

**Authority:** Josh requested review and fixes to previous episode descriptions in `OOOD Marketing & Episodes Brainstorm` after the Spotify chapter-spacing correction.

**Result:** The native Google Doc's AI-landscape chapter list now merges its short opening (00:00/00:14), open/closed-model explanation (06:20/06:44), and goodbye (49:21/52:04). It has 23 chapters with a minimum 41-second gap and a 184.733-second final chapter, keeping retained final-v2 anchors. The intro's first chapter was changed from 00:11 to 00:00 by a concurrent edit before Codex's successful write; it passes with ten chapters and a minimum 42-second gap. The projects/connectors/skills section already uses the corrected 23-chapter list and passes at 33 seconds. Full native readback confirmed all lists, targeted chapter styling, links/images and tab topology. Exact-text replacements scoped to the description tab avoided overwriting concurrent changes elsewhere. The document's Episode 1/2/3 labels were preserved.

**Current local copies:** `01_EPISODES/E000-why-were-here/codex-description-final-cut-2026-09-30.txt` and `01_EPISODES/E001-ai-basics/codex-description-final-cut-v2-2026-09-30.txt`. The E001 shared-platform v2 supersedes the earlier 26-chapter YouTube-only description. Audit: `02_RESEARCH/codex-prior-descriptions-chapter-audit-2026-09-30.md`.

**Status:** Google Doc edits completed and verified. No platform description update, upload, scheduling, or exact-export host approval is implied.


## 2026-09-30 — Repair Episode 002 color metadata and enforce an export gate

**Authority:** Josh supplied Spotify's repeated color-consistency rejection for this episode and directed a repair plus prevention in future exports.

**Cause:** E002 v3's intro declares unspecified H.264 primaries and transfer at 00:07.133; explicit BT.709 resumes at 00:12.400. A keyframe-only decoded scan masks the mismatch, but direct SPS inspection and the complete source decode expose it. The source has one unspecified coded declaration and 156 decoded frames with unspecified values.

**Result:** `01_EPISODES/E002-make-ai-useful/edit/codex-spotify-color-fix-2026-09-30/episode-002-spotify-upload.mp4` normalizes only metadata, preserving the compressed picture slices and AAC, exact 33:14.267 cut, 59,828 frames, all 153,311 media packet timing records, 12 chapters and unchanged caption/description timing. The new file passed all 242 coded-header checks and a full 59,828-frame color/decode audit. Original v3 and all other-agent media remain preserved. Source hash `eece6af6e408f441c356557b29d6424857ae8301e904654e8d686521ec5d47a3`; fixed hash `2d0de694425b1e13523a6a52a4895a1accb994d7b763434f7838b7c53753e858`.

**Prevention:** `skills/oood-episode-producer/scripts/color_qc.py` audits actual H.264 SPS declarations as well as the stream and every decoded frame. Shared `media_job.py qc` and `render` now enforce it. The renderer sets per-frame color parameters before encoding, explicit encoder/container flags, and H.264 normalization during the final mux. Source colors that require a real conversion are rejected by the baseline renderer. The live skill requires the same gate for custom card/hook/copy assemblies. A regression confirms QC rejects the original faulty export; a two-second hook/intro render exposed encoder-only limitations, then passed after frame-level and mux fixes.

**Status:** Corrected local upload copy delivered for retry; no upload or successful Spotify processing is claimed. Existing host-review and caption-proof status is unchanged.


## 2026-09-30 — All three launch episodes public on YouTube; website updated

**Authority:** Josh confirmed that all three episodes are posted on YouTube and requested the website updated with the latest episodes.

**Verified publication:** The official Out of Our Depth channel Atom feed confirms three public September 30 uploads, in launch order: Episode 000, `We Can’t Keep Up With AI Either (So We Started a Podcast!)`, https://www.youtube.com/watch?v=y0NH_zvAdEo (21:31:01 UTC / 2:31 p.m. Pacific); Episode 001, `Who's Who in AI (Explained With a Toyota Prius)`, https://www.youtube.com/watch?v=-YWPmoWKbrM (22:38:35 UTC / 3:38 p.m. Pacific); Episode 002, `Projects, Connectors & Skills… Take Your AI From Fresh Intern to Full-Time Hire`, https://www.youtube.com/watch?v=d-ykZl4WHjo (23:00:52 UTC / 4:00 p.m. Pacific). Publisher: YouTube / Out of Our Depth. Source: https://www.youtube.com/feeds/videos.xml?channel_id=UCr2sdn2AwHyhjm5SUtWUNGQ, accessed 2026-09-30. This supersedes unconfirmed YouTube publication status in the earlier review entries. The September 29 Episode 000 URL remains historical; current website links use the September 30 upload. Public availability does not establish exact identity with local review masters, completed caption proof or Spotify processing.

**Website result:** outofourdepth.com features 002, with 001/000 in More episodes. All three have real YouTube thumbnails, concise titles/summaries, three-digit repository numbering and direct watch links. Verified metadata and HTML fallbacks replace coming-soon copy; the automatic newest-upload feed stays enabled, with a date guard against older cached feed results. Existing brand, platform/contact links and redirects are preserved. Source edits: `website/config.js`, `index.html`, `main.js`, `styles.css`, `README.md`.

**Publication and checks:** A website-only temporary staging folder was deployed to the existing Vercel project `oood-website`; no repository history or unrelated files were uploaded. Production deployment `dpl_CQL5pcDa4zMwSVv7PnYh4uzPbqmq` reached READY and was aliased to https://outofourdepth.com. JavaScript syntax and diff whitespace checks passed. Desktop and 390px phone previews verified legibility and all three links; the unavailable local feed confirmed the verified fallback still displays them. Live homepage readback confirms all three URLs, no coming-soon copy and no obsolete intro link. Live `/api/latest` returns the verified Episode 002 upload. The published browser view confirms the same episode list.


## 2026-09-30 — Website episode titles match YouTube verbatim

**Authority:** Josh requested that all three website titles match the titles used on YouTube. This supersedes the shortened website index titles from the preceding update and the six-word index-title guideline for this surface.

**Result:** `website/config.js` and the HTML fallbacks now use the exact official channel titles, including capitalization, apostrophes, parentheses and ellipsis. The featured-card refresh keeps the current feed title while retaining known episode numbering and summaries, so a later YouTube title update is not overridden by cached local title metadata. The official channel Atom feed was checked again on September 30; its three current titles match the published page's heading readback exactly. Titles are recorded in the preceding publication entry.

**Status:** Published to https://outofourdepth.com through production deployment `dpl_BQo1i9gXxKhtLKWVimfaDPY8XiSE` (READY). Desktop and 390px phone previews verify wrapping and legibility; syntax/whitespace checks passed. The live page's three heading texts match the verified YouTube titles verbatim. Episode links and summaries remain as in the preceding update. Screenshot: `/private/tmp/oood-youtube-matching-titles-2026-09-30.jpg`.


## 2026-09-30 — Archive published launch episodes in Drive and reclaim local storage

**Authority:** Josh confirmed Episodes 000, 001 and 002 are published on YouTube and Spotify, requested essential-only Drive archiving and local folder cleanup, and chose to keep original raw recordings in Drive. He clarified that the other E002 re-encode chat was stopped because no new render was needed. This supersedes prior unconfirmed Spotify-processing status; publication confirmation does not independently establish exact public-transcode byte identity or auditory caption proof.

**Archive:** Google Drive `Out of Our Depth/Video Files/Final` (folder `1IR0qHIE4TglkJuy1qlH1bCcBEaH662Rj`) now has one folder per episode with final video, matching SRT, the current 1280 × 720 published YouTube thumbnail, latest saved description/chapters and manifest. Current export selections are E000 recurring-card v11, E001 v2 metadata-normalized Spotify copy, and E002 ep2hook v3 metadata-normalized Spotify copy. A 4,070,322-byte ZIP retains 455 lightweight context/research/edit/QC/rebuild records. Every cloud asset was read back for destination parent, byte size and MD5 before release media was removed. The archive receipt and exact Drive IDs/checksums are in `01_EPISODES/codex-drive-archive-2026-09-30/`. No cloud files were deleted or sharing changed.

**Raw originals:** Existing `Video Files/Raw` copies matched all three re-downloaded local sources by MD5 on September 30. Local duplicates in `/Users/je/Movies/` were removed; originals remain in Drive. E000 MD5 `8d2c2264b20141c344514277fbb5923c`, E001 `7c86087db258c0c766083a9c21ace497`, E002 `57e26c08221b45453ac7d2bfa31c6d70`.

**Local cleanup:** Six disposable Codex render intermediates were removed when storage ran out, followed by 73 Codex/local episode media files after complete archive verification and the three verified raw duplicates. This chat removed 18,652,397,895 bytes (17.371 GiB). Small user-selected hooks, shared brand templates and lightweight project/edit/research records remain local. Historical media pointers are retained as history; current READMEs, project brief and asset manifest point to the archive. Fifteen superseded media files in protected `jtan-*` folders (5.582 GiB) remain pending Josh's explicit override of AGENTS.md. They were excluded from automatic deletion.


## 2026-09-30 — Explicitly approved cleanup of superseded jtan media

**Authority:** Josh said, “Yes you can free up that 5.6gb too as long as you're sure they're outdated now.” This explicitly overrides the other-agent-output deletion protection only for the 15 files in the previously presented cleanup plan. It supersedes the preceding entry's pending status.

**Verification:** All 15 candidates matched their prior planned sizes and pre-plan modification times. Actual runtimes and existing edit/QC records confirm the four E001 MP4/WAV files are September 27/28 52:36.533 comparison cuts/audio, superseded by September 30's selected-hook, covered-lens, GPU-detour-cut, recurring-card final. The two E002 credits-hook full cuts and nine tester files are September 29 review options, superseded by the selected ep2hook and latest recurring-card final. E001/E002 final videos and raw originals were read back from Drive again and matched expected MD5, byte size and destination parents before deletion.

**Result:** Deleted exactly those 15 superseded media files, 5,993,927,160 bytes (5.582 GiB). All other-agent scripts, EDLs, captions, QC and source records remain local and in the compact Drive production backup. No Drive files were deleted or changed, except updating the archive README. This chat's total verified local-media cleanup is now 24,646,325,055 bytes (22.954 GiB). Receipt: `01_EPISODES/codex-drive-archive-2026-09-30/jtan-authorized-cleanup.json`.
